# Deploying PyDuke fresh

This zip already includes:
- The Tutor page wired to Google's free Gemini API (`src/lib/ask-tutor.ts`)
- A broadened offline fallback tutor that actually answers general topic
  questions (loops, functions, strings, variables, conditions, operators,
  sets, classes, scope, files, modules) instead of one generic message
- `.env` pre-filled with a working Gemini key so the Tutor works immediately
  (rotate this key later at https://aistudio.google.com/apikey — it's free
  tier, so no billing risk, but it's still worth refreshing once you're
  settled)

No database, no auth setup, and no other API keys are required — every
game, lesson, and the typing trainer run entirely in the browser.

## Deploy with the Vercel CLI (recommended, fastest path to a clean deploy)

```bash
npm install -g vercel   # one-time
cd pyduke
vercel login
vercel --prod
```

When prompted for environment variables, or afterward in the dashboard,
add:
```
GEMINI_API_KEY=<your key>
GEMINI_MODEL=gemini-flash-latest
```

## The two settings that broke the last deployment — do these immediately after

1. **Settings → Deployment Protection → set to "Disabled"** (or "Only
   Preview Deployments" if you want previews private but the live site
   public). Without this, every visitor who isn't logged into your Vercel
   account gets a login wall instead of your app — this was true even for
   the "Ready" production deployment last time.

2. **Domains tab** — if `pyduke-vercel.app` (or any custom domain) shows
   "Invalid Configuration," either fix the DNS record it lists, or just
   remove that domain and use the default `*.vercel.app` URL Vercel gives
   you automatically — that one always works without any DNS setup.

## If you go through Grok instead of the CLI

Upload/paste this project's contents into Grok the same way you did
before, then make sure it deploys to Vercel with `GEMINI_API_KEY` set — and
still check both settings above afterward, since Grok's deploy pipeline
does not control Vercel's Deployment Protection setting.
