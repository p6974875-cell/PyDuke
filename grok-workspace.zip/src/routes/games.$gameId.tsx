import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Check, Heart, RotateCcw, Trophy } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { DifficultyBadge } from "@/components/difficulty-badge";
import { ChallengeCard } from "@/components/game-challenges";
import { TypingArena } from "@/components/typing-arena";
import { GAMES, GAME_META } from "@/lib/content/games";
import { TYPING_DRILLS } from "@/lib/content/typing";
import { isGameUnlocked, livesFor, pickPlayOrder, pointsFor } from "@/lib/game-engine";
import { EMPTY_IDS, useHelix } from "@/lib/store";
import type { GameId, GameItem } from "@/lib/types";

export const Route = createFileRoute("/games/$gameId")({ component: GamePage });

function GamePage() {
  const { gameId } = Route.useParams();
  const meta = GAME_META.find((g) => g.id === gameId);
  const topics = useHelix((s) => s.topics);
  if (!meta) {
    return (
      <p>
        Unknown game.{" "}
        <Link to="/games" className="underline">
          Back
        </Link>
      </p>
    );
  }
  if (!isGameUnlocked(gameId as GameId, topics)) {
    return (
      <div className="space-y-4">
        <Head meta={meta} />
        <p className="rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
          This game unlocks after you finish the matching lesson. Keep going in Learn.
        </p>
        <Button asChild variant="secondary" size="sm">
          <Link to="/learn">Open curriculum</Link>
        </Button>
      </div>
    );
  }
  if (gameId === "typing") {
    return (
      <div className="space-y-6">
        <Head meta={meta} />
        <TypingArena drills={TYPING_DRILLS} />
      </div>
    );
  }
  const items = GAMES[gameId] ?? [];
  return (
    <div className="space-y-6">
      <Head meta={meta} />
      <GameRunner key={gameId} gameId={gameId as GameId} items={items} />
    </div>
  );
}

function Head({ meta }: { meta: (typeof GAME_META)[number] }) {
  return (
    <header>
      <Link to="/games" className="text-xs text-muted-foreground hover:text-foreground">
        Games
      </Link>
      <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">{meta.title}</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{meta.blurb}</p>
    </header>
  );
}

function GameRunner({ gameId, items }: { gameId: GameId; items: GameItem[] }) {
  const completed = useHelix((s) => s.games[gameId]?.completed ?? EMPTY_IDS);
  const bestScore = useHelix((s) => s.games[gameId]?.bestScore ?? 0);
  const complete = useHelix((s) => s.completeGameItem);
  const finish = useHelix((s) => s.finishGameSession);
  const maxLives = livesFor(gameId);
  const sequential = gameId === "boss";

  const deck = useMemo(
    () => (sequential ? items : pickPlayOrder(items, completed)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [gameId, items],
  );

  const [index, setIndex] = useState(0);
  const [lives, setLives] = useState(maxLives ?? 99);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [answered, setAnswered] = useState<Record<string, boolean>>({});
  const [over, setOver] = useState(false);
  const [seed, setSeed] = useState(0);

  const unlockedIndex = sequential
    ? Math.min(items.length, completed.filter((id) => items.some((it) => it.id === id)).length + 1)
    : deck.length;

  const safeIndex = Math.min(index, Math.max(0, (sequential ? unlockedIndex : deck.length) - 1));
  const item = deck[safeIndex];

  function mark(ok: boolean) {
    if (!item || answered[item.id] === true) return;
    const pts = ok ? pointsFor(item.difficulty, streak + 1) : 0;
    complete(gameId, item.id, ok, pts);
    const nextAnswered = { ...answered, [item.id]: ok };
    setAnswered(nextAnswered);
    let nextScore = score;
    let nextLives = lives;
    if (ok) {
      nextScore = score + pts;
      setScore(nextScore);
      setStreak((s) => s + 1);
      setCorrect((n) => n + 1);
      toast(`+${pts}`);
    } else {
      setStreak(0);
      setWrong((n) => n + 1);
      nextLives = lives - 1;
      setLives(nextLives);
    }
    const unique = Object.keys(nextAnswered).length;
    if ((maxLives !== null && nextLives <= 0) || unique >= deck.length) {
      finish(gameId, nextScore);
      setOver(true);
    } else if (ok) {
      setIndex((i) => Math.min(i + 1, deck.length - 1));
    }
  }

  function replay() {
    setIndex(0);
    setLives(maxLives ?? 99);
    setScore(0);
    setStreak(0);
    setCorrect(0);
    setWrong(0);
    setAnswered({});
    setOver(false);
    setSeed((n) => n + 1);
  }

  if (!item && !over) return <p className="text-muted-foreground">No challenges yet.</p>;

  if (over) {
    return (
      <div className="space-y-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <div className="flex items-center gap-2">
          <Trophy className="size-5 text-accent" />
          <h2 className="font-display text-xl font-medium">Session results</h2>
        </div>
        <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat k="Score" v={String(score)} />
          <Stat k="Best" v={String(Math.max(bestScore, score))} />
          <Stat k="Correct" v={String(correct)} />
          <Stat k="Missed" v={String(wrong)} />
        </dl>
        {maxLives !== null && lives <= 0 ? (
          <p className="text-sm text-destructive">Out of lives. Replay to try the remaining challenges.</p>
        ) : (
          <p className="text-sm text-muted-foreground">Deck complete. XP is already on your profile.</p>
        )}
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={replay}>
            <RotateCcw className="size-4" />
            Replay
          </Button>
          <Button size="sm" variant="secondary" asChild>
            <Link to="/games">Games</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4" key={`${seed}-${item.id}`}>
      <div className="flex flex-wrap items-center gap-3 rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)]">
        <span className="tabular-nums">Score {score}</span>
        <span className="tabular-nums text-muted-foreground">Streak {streak}</span>
        {maxLives !== null ? (
          <span className="inline-flex items-center gap-1 tabular-nums">
            <Heart className="size-3.5 text-destructive" />
            {lives}/{maxLives}
          </span>
        ) : null}
        <span className="ml-auto text-xs tabular-nums text-muted-foreground">
          {safeIndex + 1}/{deck.length}
        </span>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        {deck.map((it, i) => {
          const locked = sequential && i >= unlockedIndex;
          const done = answered[it.id] ?? completed.includes(it.id);
          return (
            <button
              key={it.id}
              type="button"
              disabled={locked}
              onClick={() => setIndex(i)}
              className={`h-11 min-w-11 rounded-md px-2 text-xs tabular-nums ${
                i === safeIndex ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
              } disabled:opacity-30`}
            >
              {done ? <Check className="mx-auto size-3.5" /> : i + 1}
            </button>
          );
        })}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="font-display text-xl font-medium">{item.title}</h2>
        <DifficultyBadge value={item.difficulty} />
        {completed.includes(item.id) ? (
          <span className="inline-flex items-center gap-1 text-xs text-success">
            <Check className="size-3.5" /> Cleared before
          </span>
        ) : null}
      </div>
      <p className="text-sm text-muted-foreground">{item.prompt}</p>
      <ChallengeCard item={item} onResult={mark} />
      <div className="flex gap-2">
        <Button
          variant="secondary"
          size="sm"
          disabled={safeIndex === 0}
          onClick={() => setIndex((i) => Math.max(0, i - 1))}
        >
          <ArrowLeft className="size-4" />
          Prev
        </Button>
        <Button
          variant="secondary"
          size="sm"
          disabled={safeIndex >= (sequential ? unlockedIndex : deck.length) - 1}
          onClick={() => setIndex((i) => i + 1)}
        >
          Next
          <ArrowRight className="size-4" />
        </Button>
      </div>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-lg bg-secondary px-3 py-2">
      <dt className="text-xs text-muted-foreground">{k}</dt>
      <dd className="font-display text-xl tabular-nums">{v}</dd>
    </div>
  );
}
