import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { DifficultyBadge } from "@/components/difficulty-badge";
import { FixCard, OrderCard, PredictCard } from "@/components/game-cards";
import { TypingArena } from "@/components/typing-arena";
import { GAMES, GAME_META } from "@/lib/content/games";
import { resolveGameId } from "@/lib/content/game-ids";
import { TYPING_DRILLS } from "@/lib/content/typing";
import { EMPTY_IDS, useHelix } from "@/lib/store";
import type { GameId, GameItem } from "@/lib/types";

export const Route = createFileRoute("/games/$gameId")({ component: GamePage });

function shuffle<T>(list: T[]): T[] {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j]!, a[i]!];
  }
  return a;
}

function GamePage() {
  const { gameId: raw } = Route.useParams();
  const gameId = resolveGameId(raw);
  const meta = GAME_META.find((g) => g.id === gameId);
  if (!gameId || !meta) {
    return (
      <p>
        Unknown game. <Link to="/games">Back</Link>
      </p>
    );
  }
  if (gameId === "typing") {
    return (
      <div className="space-y-6">
        <Head meta={meta} />
        <TypingArena drills={TYPING_DRILLS} />
      </div>
    );
  }
  const pool = GAMES[gameId] ?? [];
  return (
    <div className="space-y-6">
      <Head meta={meta} />
      <GameRunner gameId={gameId} items={pool} />
    </div>
  );
}

function Head({ meta }: { meta: (typeof GAME_META)[number] }) {
  return (
    <header>
      <Link to="/games" className="text-xs text-muted-foreground hover:text-foreground">
        Games
      </Link>
      <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">{meta.title}</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{meta.blurb}</p>
    </header>
  );
}

function GameRunner({ gameId, items }: { gameId: GameId; items: GameItem[] }) {
  const completed = useHelix((s) => s.games[gameId]?.completed ?? EMPTY_IDS);
  const complete = useHelix((s) => s.completeGameItem);
  const deck = useMemo(() => (gameId === "boss" ? items : shuffle(items)), [gameId, items]);
  const [index, setIndex] = useState(0);
  const [lives, setLives] = useState(3);

  const unlockedIndex = useMemo(() => {
    if (gameId !== "boss") return deck.length;
    let u = 0;
    for (const it of deck) {
      if (completed.includes(it.id)) u += 1;
      else break;
    }
    return Math.min(deck.length, u + 1);
  }, [gameId, deck, completed]);

  const safeIndex = Math.min(index, Math.max(0, unlockedIndex - 1));
  const item = deck[safeIndex];
  if (!item) return <p className="text-muted-foreground">No challenges yet.</p>;

  function mark(ok: boolean) {
    if (ok) {
      complete(gameId, item.id);
      toast("Challenge cleared");
      return;
    }
    if (gameId === "boss") {
      setLives((n) => Math.max(0, n - 1));
    }
  }

  const dead = gameId === "boss" && lives <= 0;

  return (
    <div className="space-y-4">
      {gameId === "boss" ? (
        <p className="text-sm text-muted-foreground">
          Lives <span className="tabular-nums text-foreground">{lives}</span> / 3
        </p>
      ) : null}
      <div className="flex flex-wrap items-center gap-2">
        {deck.map((it, i) => {
          const locked = i >= unlockedIndex;
          return (
            <button
              key={it.id}
              type="button"
              disabled={locked || dead}
              onClick={() => setIndex(i)}
              className={`tap-card h-11 min-w-11 rounded-md px-2 text-xs tabular-nums ${
                i === safeIndex ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
              } disabled:opacity-30`}
            >
              {i + 1}
            </button>
          );
        })}
      </div>
      {dead ? (
        <div className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
          <p className="font-display text-xl">The boss stands.</p>
          <p className="mt-2 text-sm text-muted-foreground">Three misses. Retry from the last cleared level.</p>
          <Button
            className="mt-4"
            onClick={() => {
              setLives(3);
              setIndex(Math.max(0, unlockedIndex - 1));
            }}
          >
            Retry
          </Button>
        </div>
      ) : (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="font-display text-xl font-medium">{item.title}</h2>
            <DifficultyBadge value={item.difficulty} />
            {completed.includes(item.id) ? (
              <span className="inline-flex items-center gap-1 text-xs text-success">
                <Check className="size-3.5" /> Done
              </span>
            ) : null}
          </div>
          <p className="text-sm text-muted-foreground">{item.prompt}</p>
          {item.hint ? <p className="text-sm text-muted-foreground">Hint: {item.hint}</p> : null}
          {gameId === "predict" ? (
            <PredictCard key={item.id} item={item} onResult={mark} />
          ) : gameId === "ordering" ? (
            <OrderCard key={item.id} item={item} onResult={mark} />
          ) : (
            <FixCard key={item.id} item={item} onResult={mark} />
          )}
        </>
      )}
      <div className="flex gap-2">
        <Button
          variant="secondary"
          size="sm"
          disabled={safeIndex === 0}
          onClick={() => setIndex((i) => Math.max(0, i - 1))}
        >
          <ArrowLeft className="size-4" />
          Prev
        </Button>
        <Button
          variant="secondary"
          size="sm"
          disabled={safeIndex >= unlockedIndex - 1 || dead}
          onClick={() => setIndex((i) => i + 1)}
        >
          Next
          <ArrowRight className="size-4" />
        </Button>
      </div>
    </div>
  );
}
