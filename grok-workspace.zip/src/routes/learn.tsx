import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { TOPICS } from "@/lib/content/topics";
import { dueTopicIds, useHelix } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/learn")({ component: LearnIndex });

const STATUS_LABEL: Record<string, string> = {
  mastered: "Mastered",
  in_progress: "In progress",
  review: "Review",
  available: "Open",
  locked: "Open",
};

function LearnIndex() {
  const topics = useHelix((s) => s.topics);
  const due = useMemo(() => dueTopicIds(topics), [topics]);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"all" | "open" | "done">("all");
  const query = q.trim().toLowerCase();
  const list = TOPICS.filter((t) => {
    const p = topics[t.id];
    const status = p?.status === "locked" ? "available" : p?.status;
    if (filter === "open" && status === "mastered") return false;
    if (filter === "done" && status !== "mastered") return false;
    if (!query) return true;
    return `${t.title} ${t.subtitle} ${t.blurb}`.toLowerCase().includes(query);
  });

  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Learn</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Curriculum</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Every lesson is open. Search, then open one — explanation, examples, mistakes, and a live
          coding task that is actually graded.
        </p>
      </header>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search lessons — try “loop”"
          className="h-11 sm:max-w-sm"
        />
        <div className="flex gap-2">
          {(["all", "open", "done"] as const).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={cn(
                "tap-card h-11 rounded-md px-3 text-sm capitalize",
                filter === f ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>
      <ol className="grid gap-2 sm:grid-cols-2">
        {list.map((t) => {
          const p = topics[t.id];
          const status = p?.status === "locked" ? "available" : p?.status ?? "available";
          const isDue = due.includes(t.id);
          return (
            <li key={t.id}>
              <Link
                to="/learn/$topicId"
                params={{ topicId: t.id }}
                className="tap-card block rounded-xl bg-card p-4 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="font-mono text-xs text-muted-foreground">
                    {String(t.number).padStart(2, "0")}
                  </span>
                  <Badge variant={status === "mastered" ? "success" : "outline"}>
                    {isDue ? "Review due" : STATUS_LABEL[status]}
                  </Badge>
                </div>
                <h2 className="mt-3 font-display text-lg font-medium">{t.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{t.blurb}</p>
                <Progress value={p?.score ?? 0} className="mt-4" />
              </Link>
            </li>
          );
        })}
      </ol>
      {list.length === 0 ? <p className="text-sm text-muted-foreground">No lessons match that search.</p> : null}
    </div>
  );
}
