import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Lock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { LEVELS, TOPICS } from "@/lib/content/topics";
import { dueTopicIds, useHelix } from "@/lib/store";
import { cn } from "@/lib/utils";
import type { TopicStatus } from "@/lib/types";

export const Route = createFileRoute("/learn")({ component: LearnIndex });

const STATUS_LABEL: Record<string, string> = {
  mastered: "Mastered",
  in_progress: "In progress",
  review: "Review",
  available: "Available",
  locked: "Locked",
};

function LearnIndex() {
  const topics = useHelix((s) => s.topics);
  const due = useMemo(() => dueTopicIds(topics), [topics]);
  const [q, setQ] = useState("");
  const [level, setLevel] = useState<number | "all">("all");
  const [status, setStatus] = useState<TopicStatus | "all">("all");

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return TOPICS.filter((t) => {
      const p = topics[t.id];
      if (level !== "all" && t.level !== level) return false;
      if (status !== "all" && p.status !== status) return false;
      if (!needle) return true;
      return `${t.title} ${t.subtitle} ${t.blurb} ${t.number}`.toLowerCase().includes(needle);
    });
  }, [q, level, status, topics]);

  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Learn</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Curriculum</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Twenty topics across five levels. Finish a lesson to unlock the next. Search, filter by
          level or status, then open the actual lesson.
        </p>
      </header>
      <div className="flex flex-col gap-3">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search lessons — lists, loops, files…"
          aria-label="Search lessons"
        />
        <div className="flex flex-wrap gap-2">
          <FilterChip active={level === "all"} onClick={() => setLevel("all")} label="All levels" />
          {LEVELS.map((lv) => (
            <FilterChip
              key={lv.id}
              active={level === lv.id}
              onClick={() => setLevel(lv.id)}
              label={`L${lv.id} ${lv.title}`}
            />
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <FilterChip active={status === "all"} onClick={() => setStatus("all")} label="Any status" />
          {(Object.keys(STATUS_LABEL) as TopicStatus[]).map((s) => (
            <FilterChip
              key={s}
              active={status === s}
              onClick={() => setStatus(s)}
              label={STATUS_LABEL[s]}
            />
          ))}
        </div>
      </div>
      {LEVELS.filter((lv) => level === "all" || level === lv.id).map((lv) => {
        const group = filtered.filter((t) => t.level === lv.id);
        if (!group.length) return null;
        return (
          <section key={lv.id} className="space-y-3">
            <div>
              <h2 className="font-display text-xl font-medium">
                Level {lv.id} — {lv.title}
              </h2>
              <p className="text-sm text-muted-foreground">{lv.blurb}</p>
            </div>
            <ol className="grid gap-2 sm:grid-cols-2">
              {group.map((t) => {
                const p = topics[t.id];
                const locked = p.status === "locked";
                const isDue = due.includes(t.id);
                const inner = (
                  <>
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-mono text-xs text-muted-foreground">
                        {String(t.number).padStart(2, "0")}
                      </span>
                      <Badge variant={p.status === "mastered" ? "success" : "outline"}>
                        {isDue ? "Review due" : STATUS_LABEL[p.status]}
                      </Badge>
                    </div>
                    <h3 className="mt-3 font-display text-lg font-medium">{t.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{t.blurb}</p>
                    <Progress value={p.score} className="mt-4" />
                  </>
                );
                if (locked) {
                  return (
                    <li
                      key={t.id}
                      className="rounded-xl bg-card/50 p-4 text-muted-foreground shadow-[var(--shadow-border)]"
                    >
                      <div className="flex items-center gap-2 text-xs">
                        <Lock className="size-3.5" />
                        Complete the previous lesson to unlock
                      </div>
                      {inner}
                    </li>
                  );
                }
                return (
                  <li key={t.id}>
                    <Link
                      to="/learn/$topicId"
                      params={{ topicId: t.id }}
                      className={cn(
                        "block rounded-xl bg-card p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
                      )}
                    >
                      {inner}
                    </Link>
                  </li>
                );
              })}
            </ol>
          </section>
        );
      })}
      {filtered.length === 0 ? (
        <p className="text-sm text-muted-foreground">No lessons match that search.</p>
      ) : null}
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  label,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-11 rounded-full px-3 text-xs",
        active ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
      )}
    >
      {label}
    </button>
  );
}
