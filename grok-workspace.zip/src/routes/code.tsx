import { createFileRoute } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { Playground } from "@/components/playground";
import { Button } from "@/components/ui/button";
import { useHelix } from "@/lib/store";

export const Route = createFileRoute("/code")({ component: CodePage });

function CodePage() {
  const snippets = useHelix((s) => s.snippets);
  const deleteSnippet = useHelix((s) => s.deleteSnippet);

  return (
    <div className="space-y-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Code</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Playground</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Write Python, run it in an isolated engine, and read what went wrong in plain language.
          Saved snippets stay on this device.
        </p>
      </header>
      <Playground />
      {snippets.length > 0 ? (
        <section className="space-y-3">
          <h2 className="font-display text-xl font-medium">Saved</h2>
          <ul className="space-y-2">
            {snippets.map((s) => (
              <li
                key={s.id}
                className="flex items-start justify-between gap-3 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]"
              >
                <div className="min-w-0">
                  <p className="font-medium">{s.title}</p>
                  <pre className="mt-2 overflow-x-auto font-mono text-xs text-muted-foreground">
                    {s.code.slice(0, 200)}
                    {s.code.length > 200 ? "…" : ""}
                  </pre>
                </div>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label="Delete"
                  onClick={() => deleteSnippet(s.id)}
                >
                  <Trash2 className="size-4" />
                </Button>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
