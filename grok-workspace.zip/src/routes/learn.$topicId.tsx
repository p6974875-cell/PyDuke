import { createFileRoute, Link } from "@tanstack/react-router";
import { LessonView } from "@/components/lesson-view";
import { TOPIC_BY_ID } from "@/lib/content/topics";
import { useHelix } from "@/lib/store";
import type { TopicId } from "@/lib/types";

export const Route = createFileRoute("/learn/$topicId")({ component: LessonPage });

function LessonPage() {
  const { topicId } = Route.useParams();
  const topic = TOPIC_BY_ID[topicId as TopicId];
  const status = useHelix((s) => s.topics[topicId as TopicId]?.status);

  if (!topic) {
    return (
      <p className="text-muted-foreground">
        Unknown lesson. <Link to="/learn">Back to curriculum</Link>
      </p>
    );
  }
  if (status === "locked") {
    return (
      <div className="max-w-lg space-y-3">
        <h1 className="font-display text-2xl">{topic.title}</h1>
        <p className="text-sm text-muted-foreground">
          This lesson unlocks when you finish the one before it. Work in order — each topic builds
          on the last.
        </p>
        <Link to="/learn" className="text-sm text-accent">
          View curriculum
        </Link>
      </div>
    );
  }
  return <LessonView topicId={topic.id} />;
}
