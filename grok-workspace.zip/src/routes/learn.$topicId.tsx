import { createFileRoute, Link } from "@tanstack/react-router";
import { LessonView } from "@/components/lesson-view";
import { TOPIC_BY_ID } from "@/lib/content/topics";
import type { TopicId } from "@/lib/types";

export const Route = createFileRoute("/learn/$topicId")({ component: LessonPage });

function LessonPage() {
  const { topicId } = Route.useParams();
  const topic = TOPIC_BY_ID[topicId as TopicId];

  if (!topic) {
    return (
      <p className="text-muted-foreground">
        Unknown lesson. <Link to="/learn">Back to curriculum</Link>
      </p>
    );
  }
  return <LessonView topicId={topic.id} />;
}
