import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Send, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LiveTutor } from "@/components/live-tutor";
import { TutorMessage } from "@/components/tutor-message";
import { askTutor, tutorStatus } from "@/lib/ask-tutor";
import { localTutorReply } from "@/lib/explain-error";
import { progressSummary, useHelix } from "@/lib/store";
import { TOPIC_BY_ID } from "@/lib/content/topics";

export const Route = createFileRoute("/tutor")({ component: TutorPage });

const STARTERS = [
  "Explain this like a beginner.",
  "Why can't I modify this tuple?",
  "Give me a hint.",
  "Teach me loops.",
  "Give me a harder challenge.",
  "Why am I getting this error?",
];

function TutorPage() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Tutor</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">PyDuke tutor</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Chat uses Gemini on the server. Live uses Gemini Live — a realtime voice session, not a
          text reply spoken by a fake voice.
        </p>
      </header>
      <Tabs defaultValue="chat">
        <TabsList>
          <TabsTrigger value="chat">Chat</TabsTrigger>
          <TabsTrigger value="live">Live tutor</TabsTrigger>
        </TabsList>
        <TabsContent value="chat">
          <TutorChat />
        </TabsContent>
        <TabsContent value="live">
          <LiveTutor />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function TutorChat() {
  const messages = useHelix((s) => s.tutor);
  const push = useHelix((s) => s.pushTutor);
  const clear = useHelix((s) => s.clearTutor);
  const current = useHelix((s) => s.currentTopicId);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [backend, setBackend] = useState<"gemini" | "fallback" | "unknown">("unknown");

  useEffect(() => {
    void tutorStatus().then((s) => setBackend(s.gemini ? "gemini" : "fallback"));
  }, []);

  async function send(content: string) {
    const q = content.trim();
    if (!q || busy) return;
    setText("");
    push({ role: "user", content: q });
    setBusy(true);
    const state = useHelix.getState();
    const summary = progressSummary(state);
    const context = `Current lesson: ${TOPIC_BY_ID[state.currentTopicId]?.title ?? state.currentTopicId}. Difficulty: ${state.preferredDifficulty}.`;
    try {
      const history = state.tutor.slice(-8).map((m) => ({ role: m.role, content: m.content }));
      const res = await askTutor({ data: { messages: history, progressSummary: summary, context } });
      if (res.ok && res.text.trim()) {
        push({ role: "assistant", content: res.text.trim() });
      } else {
        const local = localTutorReply(q, summary);
        const note =
          !res.ok && res.error === "missing-key"
            ? "\n\n(Gemini is not configured. Add GEMINI_API_KEY to the server .env to talk to the live model.)"
            : "\n\n(The hosted model was unavailable. This is a local fallback, not Gemini.)";
        push({ role: "assistant", content: local + note });
      }
    } catch {
      push({
        role: "assistant",
        content:
          "AI Tutor is temporarily unavailable. Check your connection and try again.\n\n" +
          localTutorReply(q, summary),
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <p className="text-xs text-muted-foreground">
        {backend === "gemini"
          ? `Gemini is connected · current lesson ${TOPIC_BY_ID[current]?.title ?? current}`
          : backend === "fallback"
            ? "GEMINI_API_KEY is missing. Chat will use a local fallback until you add the key."
            : "Checking tutor backend…"}
      </p>
      <div className="flex flex-wrap gap-2">
        {STARTERS.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => void send(s)}
            className="min-h-11 rounded-full bg-secondary px-3 py-2 text-left text-xs text-muted-foreground hover:text-foreground"
          >
            {s}
          </button>
        ))}
      </div>
      <div className="space-y-3">
        {messages.length === 0 ? (
          <p className="rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
            Ask about an error, a line of code, or the current lesson. Hints come before solutions.
          </p>
        ) : (
          messages.map((m) => (
            <div
              key={m.id}
              className={
                m.role === "user"
                  ? "ml-8 rounded-xl bg-secondary px-4 py-3 text-sm"
                  : "mr-8 rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)]"
              }
            >
              <p className="mb-1 text-[11px] uppercase tracking-wider text-muted-foreground">
                {m.role === "user" ? "You" : "PyDuke"}
              </p>
              {m.role === "assistant" ? <TutorMessage content={m.content} /> : <p className="whitespace-pre-wrap">{m.content}</p>}
            </div>
          ))
        )}
        {busy ? <p className="text-xs text-muted-foreground">Thinking…</p> : null}
      </div>
      <form
        className="flex flex-col gap-2 sm:flex-row"
        onSubmit={(e) => {
          e.preventDefault();
          void send(text);
        }}
      >
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Why does this loop stop?"
          className="min-h-20 flex-1"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void send(text);
            }
          }}
        />
        <div className="flex gap-2 sm:flex-col">
          <Button type="submit" disabled={busy || !text.trim()} className="sm:self-end">
            <Send className="size-4" />
            Send
          </Button>
          <Button
            type="button"
            variant="ghost"
            disabled={messages.length === 0}
            onClick={() => clear()}
          >
            <Trash2 className="size-4" />
            Clear
          </Button>
        </div>
      </form>
    </div>
  );
}
