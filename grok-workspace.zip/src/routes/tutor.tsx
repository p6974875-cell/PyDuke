import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Mic, Send, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { TutorMarkdown } from "@/components/tutor-markdown";
import { askTutor } from "@/lib/ask-tutor";
import { tutorAvailability } from "@/lib/tutor-live";
import { progressSummary, useHelix } from "@/lib/store";
import { TOPIC_BY_ID } from "@/lib/content/topics";

export const Route = createFileRoute("/tutor")({ component: TutorPage });

const STARTERS = [
  "Explain this like a beginner.",
  "Why am I getting this error?",
  "Give me a hint.",
  "Teach me loops.",
  "Give me a harder challenge.",
  "Explain this code.",
];

function TutorPage() {
  const messages = useHelix((s) => s.tutor);
  const push = useHelix((s) => s.pushTutor);
  const clear = useHelix((s) => s.clearTutor);
  const current = useHelix((s) => s.currentTopicId);
  const lastCode = useHelix((s) => s.lastCode);
  const lastError = useHelix((s) => s.lastError);
  const lastExercise = useHelix((s) => s.lastExercise);
  const preferred = useHelix((s) => s.preferredDifficulty);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [avail, setAvail] = useState<{ gemini: boolean; xai: boolean } | null>(null);
  const [provider, setProvider] = useState<string>("");

  useEffect(() => {
    void tutorAvailability()
      .then((a) => setAvail({ gemini: a.gemini, xai: a.xai }))
      .catch(() => setAvail({ gemini: false, xai: false }));
  }, []);

  async function send(content: string) {
    const q = content.trim();
    if (!q || busy) return;
    setText("");
    setErr("");
    push({ role: "user", content: q });
    setBusy(true);
    const state = useHelix.getState();
    const summary = progressSummary(state);
    try {
      const history = state.tutor.slice(-8).map((m) => ({
        role: m.role,
        content: m.content,
      }));
      const res = await askTutor({
        data: {
          messages: history,
          progressSummary: summary,
          currentLesson: TOPIC_BY_ID[state.currentTopicId]?.title,
          currentExercise: lastExercise || undefined,
          submittedCode: lastCode || undefined,
          lastError: lastError || undefined,
          difficulty: preferred,
        },
      });
      if (res.ok && res.text.trim()) {
        push({ role: "assistant", content: res.text.trim() });
        if ("provider" in res && res.provider) setProvider(res.provider);
      } else {
        setErr(
          res.ok
            ? "Empty reply."
            : res.error === "unavailable"
              ? "AI Tutor is temporarily unavailable. Check GEMINI_API_KEY and your connection, then try again."
              : res.error,
        );
      }
    } catch {
      setErr("AI Tutor is temporarily unavailable. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  const online = Boolean(avail?.gemini || avail?.xai);

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Tutor</p>
          <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Ask PyDuke</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Gemini-backed Python teacher. Hints before solutions. Context:{" "}
            {TOPIC_BY_ID[current]?.title ?? current}
            {provider ? ` · last reply via ${provider === "gemini" ? "Gemini" : "xAI fallback"}` : ""}.
          </p>
        </div>
        <Button asChild variant="secondary" size="sm">
          <Link to="/tutor/live">
            <Mic className="size-4" />
            Live Tutor
          </Link>
        </Button>
      </header>
      {avail && !online ? (
        <p className="rounded-lg bg-secondary px-4 py-3 text-sm text-muted-foreground">
          No tutor key is configured. Add <code className="font-mono text-foreground">GEMINI_API_KEY</code>{" "}
          on the server (see SETUP.md). Offline canned replies are not used.
        </p>
      ) : null}
      <div className="flex flex-wrap gap-2">
        {STARTERS.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => send(s)}
            className="rounded-full bg-secondary px-3 py-1.5 text-left text-xs text-muted-foreground hover:text-foreground"
          >
            {s}
          </button>
        ))}
      </div>
      <div className="space-y-3">
        {messages.length === 0 ? (
          <p className="rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
            Ask about the line you are on. If you have a traceback, paste it. I will not dump a full
            solution until you have tried.
          </p>
        ) : (
          messages.map((m) => (
            <div
              key={m.id}
              className={
                m.role === "user"
                  ? "ml-8 rounded-xl bg-secondary px-4 py-3 text-sm"
                  : "mr-8 rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)]"
              }
            >
              <p className="mb-1 text-[11px] uppercase tracking-wider text-muted-foreground">
                {m.role === "user" ? "You" : "PyDuke"}
              </p>
              {m.role === "assistant" ? (
                <TutorMarkdown text={m.content} />
              ) : (
                <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
              )}
            </div>
          ))
        )}
        {busy ? <p className="text-xs text-muted-foreground">Thinking…</p> : null}
        {err ? <p className="text-sm text-destructive">{err}</p> : null}
      </div>
      <form
        className="flex flex-col gap-2 sm:flex-row"
        onSubmit={(e) => {
          e.preventDefault();
          void send(text);
        }}
      >
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Why does this loop stop?"
          className="min-h-20 flex-1"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void send(text);
            }
          }}
        />
        <div className="flex gap-2 sm:flex-col">
          <Button type="submit" disabled={busy || !text.trim()} className="sm:self-end">
            <Send className="size-4" />
            Send
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            disabled={messages.length === 0}
            onClick={() => clear()}
          >
            <Trash2 className="size-4" />
            Clear
          </Button>
        </div>
      </form>
    </div>
  );
}
