import { createFileRoute } from "@tanstack/react-router";
import { mintLiveToken } from "@/lib/gemini.server";

export const Route = createFileRoute("/api/ai/live")({
  server: {
    handlers: {
      POST: async () => {
        const minted = await mintLiveToken();
        if (!minted.ok) {
          const status = minted.error === "missing-key" ? 503 : 502;
          return Response.json({ ok: false, error: minted.error }, { status });
        }
        const wsUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained?access_token=${encodeURIComponent(minted.token)}`;
        return Response.json({ ok: true, wsUrl, model: minted.model });
      },
    },
  },
});
