import { createFileRoute } from "@tanstack/react-router";
import { geminiGenerate } from "@/lib/gemini.server";

export const Route = createFileRoute("/api/ai/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: {
          messages?: { role: "user" | "assistant" | "system"; content: string }[];
          context?: string;
        };
        try {
          body = (await request.json()) as typeof body;
        } catch {
          return Response.json({ ok: false, error: "invalid-json" }, { status: 400 });
        }
        const messages = (body.messages ?? []).slice(-8);
        if (!messages.length) {
          return Response.json({ ok: false, error: "empty" }, { status: 400 });
        }
        const system = `You are PyDuke, a Python teacher. Answer any Python question. Hint before dumping exercise solutions.
${body.context ? `\nContext:\n${body.context.slice(0, 1500)}` : ""}`;
        const result = await geminiGenerate({ system, messages });
        if (!result.ok) {
          const status = result.error === "missing-key" ? 503 : 502;
          return Response.json(result, { status });
        }
        return Response.json(result);
      },
    },
  },
});
