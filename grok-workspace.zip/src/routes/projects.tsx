import { createFileRoute, Link } from "@tanstack/react-router";
import { PROJECTS } from "@/lib/content/projects";
import { TOPIC_BY_ID } from "@/lib/content/topics";
import { useHelix } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { DifficultyBadge } from "@/components/difficulty-badge";

export const Route = createFileRoute("/projects")({ component: ProjectsPage });

function ProjectsPage() {
  const done = useHelix((s) => s.projectsCompleted);
  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Projects</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Build something</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Thin slices, not dumps of advanced code. Each project is a function you can test, then wrap
          with input later.
        </p>
      </header>
      <div className="grid gap-3 sm:grid-cols-2">
        {PROJECTS.map((p) => (
          <Link
            key={p.id}
            to="/projects/$projectId"
            params={{ projectId: p.id }}
            className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
          >
            <div className="flex items-center justify-between gap-2">
              <DifficultyBadge value={p.difficulty} />
              {done.includes(p.id) ? <Badge variant="success">Done</Badge> : null}
            </div>
            <h2 className="mt-3 font-display text-xl font-medium">{p.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{p.blurb}</p>
            <p className="mt-3 text-xs text-muted-foreground">
              {p.concepts.map((c) => TOPIC_BY_ID[c].title).join(" · ")}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
