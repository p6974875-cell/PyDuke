import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Play } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { CodeEditor } from "@/components/code-editor";
import { PythonOutput } from "@/components/python-output";
import { PROJECTS } from "@/lib/content/projects";
import { gradeCode } from "@/lib/grade";
import type { RunResult } from "@/lib/python-engine";
import { useHelix } from "@/lib/store";

export const Route = createFileRoute("/projects/$projectId")({ component: ProjectPage });

function ProjectPage() {
  const { projectId } = Route.useParams();
  const project = PROJECTS.find((p) => p.id === projectId);
  if (!project) {
    return (
      <p>
        Unknown project. <Link to="/projects">Back</Link>
      </p>
    );
  }
  return <ProjectStudio project={project} />;
}

function ProjectStudio({ project }: { project: (typeof PROJECTS)[number] }) {
  const [code, setCode] = useState(project.starter);
  const [result, setResult] = useState<RunResult | null>(null);
  const [msg, setMsg] = useState("");
  const [ok, setOk] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const [show, setShow] = useState(false);
  const [running, setRunning] = useState(false);
  const complete = useHelix((s) => s.completeProject);
  const done = useHelix((s) => s.projectsCompleted.includes(project.id));

  async function check() {
    setRunning(true);
    try {
      const g = await gradeCode(code, project.checks);
      setResult(g.run);
      setMsg(g.message);
      setOk(g.passed);
      setAttempted(true);
      if (g.passed) {
        complete(project.id);
        toast("Project complete");
      }
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-6">
      <header>
        <Link to="/projects" className="text-xs text-muted-foreground">
          Projects
        </Link>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">{project.title}</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{project.blurb}</p>
      </header>
      <ol className="grid gap-3 sm:grid-cols-3">
        {project.steps.map((s, i) => (
          <li key={s.title} className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
            <p className="font-mono text-xs text-muted-foreground">{String(i + 1).padStart(2, "0")}</p>
            <h2 className="mt-2 font-medium">{s.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
          </li>
        ))}
      </ol>
      <CodeEditor value={code} onChange={setCode} onRun={check} minHeight={260} />
      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={check} disabled={running}>
          <Play className="size-4" />
          Run & check
        </Button>
        <Button size="sm" variant="ghost" disabled={!attempted} onClick={() => setShow(true)}>
          Compare
        </Button>
        {done ? <span className="self-center text-xs text-success">Completed</span> : null}
      </div>
      {msg ? <p className={ok ? "text-sm text-success" : "text-sm text-destructive"}>{msg}</p> : null}
      <PythonOutput result={result} code={code} />
      {show ? (
        <div className="space-y-2 rounded-xl bg-secondary p-4">
          <pre className="overflow-x-auto font-mono text-[13px]">{project.solution}</pre>
          <p className="text-sm text-muted-foreground">{project.explanation}</p>
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">Write a solution before comparing.</p>
      )}
    </div>
  );
}
