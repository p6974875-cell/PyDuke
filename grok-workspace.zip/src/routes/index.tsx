import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  ArrowRight,
  BookOpen,
  CalendarDays,
  Keyboard,
  Mic,
  Puzzle,
  Terminal,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { ACHIEVEMENTS } from "@/lib/achievements";
import { DAILY_SLOTS } from "@/lib/content/daily";
import { TOPICS, TOPIC_BY_ID } from "@/lib/content/topics";
import { dueTopicIds, useHelix } from "@/lib/store";
import { levelFromXp, todayKey, xpIntoLevel } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const name = useHelix((s) => s.name);
  const setName = useHelix((s) => s.setName);
  const xp = useHelix((s) => s.xp);
  const streak = useHelix((s) => s.streak);
  const current = useHelix((s) => s.currentTopicId);
  const topics = useHelix((s) => s.topics);
  const dailyDate = useHelix((s) => s.dailyDate);
  const dailyDone = useHelix((s) => s.dailyDone);
  const earned = useHelix((s) => s.achievements);
  const due = useMemo(() => dueTopicIds(topics), [topics]);
  const topic = TOPIC_BY_ID[current];
  const mastered = TOPICS.filter((t) => topics[t.id].status === "mastered").length;
  const greeting = name ? `Welcome back, ${name}.` : "Learn Python by writing it.";
  const [draft, setDraft] = useState("");
  const today = todayKey();
  const doneToday = dailyDate === today ? dailyDone.length : 0;
  const recentAch = ACHIEVEMENTS.filter((a) => earned.includes(a.id)).slice(-3);

  return (
    <div className="space-y-8">
      <header className="helix-enter">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Home</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight sm:text-4xl">{greeting}</h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">
          Twenty lessons, a real Python engine in the browser, games that grade your code, typing
          for the punctuation that trips people up, and a Gemini tutor. Short sessions. Write more
          than you read.
        </p>
      </header>

      {!name ? (
        <form
          className="flex max-w-md flex-col gap-2 sm:flex-row helix-enter helix-enter-delay-1"
          onSubmit={(e) => {
            e.preventDefault();
            const v = draft.trim();
            if (v) setName(v);
          }}
        >
          <Input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="What should PyDuke call you?"
            aria-label="Your name"
          />
          <Button type="submit" variant="secondary" disabled={!draft.trim()}>
            Save name
          </Button>
        </form>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-3 helix-enter helix-enter-delay-1">
        <Stat label="Level" value={String(levelFromXp(xp))} hint={`${xpIntoLevel(xp)} / 150 XP`} />
        <Stat label="Streak" value={String(streak)} hint="days in a row" />
        <Stat label="Mastered" value={`${mastered}/${TOPICS.length}`} hint="topics locked in" />
      </div>

      <Card className="helix-enter helix-enter-delay-2">
        <CardHeader>
          <CardTitle>Continue learning</CardTitle>
          <CardDescription>
            Lesson {topic.number} · {topic.title}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">{topic.blurb}</p>
          <Progress value={topics[current].score} />
          <Button asChild>
            <Link to="/learn/$topicId" params={{ topicId: current }}>
              Open lesson
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        </CardContent>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2">
        <Link
          to="/practice"
          className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
        >
          <CalendarDays className="size-4 text-accent" />
          <p className="mt-3 font-medium">Daily practice</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {doneToday}/{DAILY_SLOTS.length} slots today. Concepts, output, debug, code, typing.
          </p>
          <Progress value={(doneToday / DAILY_SLOTS.length) * 100} className="mt-3" />
        </Link>
        <Link
          to="/tutor/live"
          className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
        >
          <Mic className="size-4 text-accent" />
          <p className="mt-3 font-medium">Live Tutor</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Speak with Gemini Live. The API key stays on the server.
          </p>
        </Link>
      </div>

      {due.length > 0 ? (
        <section className="space-y-3">
          <h2 className="font-display text-xl font-medium">Due for revision</h2>
          <p className="text-sm text-muted-foreground">
            Older mastered topics come back after about a day and a half. Misses are preferred.
          </p>
          <div className="grid gap-2 sm:grid-cols-2">
            {due.slice(0, 4).map((id) => (
              <Link
                key={id}
                to="/learn/$topicId"
                params={{ topicId: id }}
                className="rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
              >
                {TOPIC_BY_ID[id].title}
              </Link>
            ))}
          </div>
        </section>
      ) : null}

      {recentAch.length > 0 ? (
        <section className="space-y-2">
          <h2 className="font-display text-xl font-medium">Achievements</h2>
          <ul className="flex flex-wrap gap-2">
            {recentAch.map((a) => (
              <li key={a.id} className="rounded-full bg-secondary px-3 py-1 text-xs">
                {a.title}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Jump to="/learn" icon={BookOpen} title="Learn" body="Twenty topics, from names to generators." />
        <Jump to="/code" icon={Terminal} title="Code" body="Isolated Python playground." />
        <Jump to="/games" icon={Puzzle} title="Games" body="Fix, predict, order, debug, build, boss." />
        <Jump to="/typing" icon={Keyboard} title="Typing" body="Accuracy first, then speed." />
      </section>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl tabular-nums">{value}</p>
      <p className="text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}

function Jump({
  to,
  icon: Icon,
  title,
  body,
}: {
  to: string;
  icon: typeof BookOpen;
  title: string;
  body: string;
}) {
  return (
    <Link
      to={to}
      className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
    >
      <Icon className="size-4 text-accent" />
      <p className="mt-3 font-medium">{title}</p>
      <p className="mt-1 text-sm text-muted-foreground">{body}</p>
    </Link>
  );
}
