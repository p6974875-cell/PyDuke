import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { ArrowRight, BookOpen, Keyboard, MessageSquare, Phone, Puzzle, Sun, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { TOPICS, TOPIC_BY_ID } from "@/lib/content/topics";
import { dueTopicIds, useHelix } from "@/lib/store";
import { levelFromXp, xpIntoLevel } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const name = useHelix((s) => s.name);
  const xp = useHelix((s) => s.xp);
  const streak = useHelix((s) => s.streak);
  const current = useHelix((s) => s.currentTopicId);
  const topics = useHelix((s) => s.topics);
  const due = useMemo(() => dueTopicIds(topics), [topics]);
  const topic = TOPIC_BY_ID[current];
  const mastered = TOPICS.filter((t) => topics[t.id].status === "mastered").length;
  const greeting = name ? `Welcome back, ${name}.` : "Welcome back.";

  return (
    <div className="space-y-8">
      <header className="helix-enter">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Home</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight sm:text-4xl">{greeting}</h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">
          You already know lists. Open any lesson — nothing is locked. Practice, play, type, and
          ask the tutor about any Python topic.
        </p>
      </header>

      <div className="grid gap-3 sm:grid-cols-3 helix-enter helix-enter-delay-1">
        <Stat label="Level" value={String(levelFromXp(xp))} hint={`${xpIntoLevel(xp)} / 150 XP`} />
        <Stat label="Streak" value={String(streak)} hint="days in a row" />
        <Stat label="Mastered" value={`${mastered}/${TOPICS.length}`} hint="topics locked in" />
      </div>

      <Card className="helix-enter helix-enter-delay-2">
        <CardHeader>
          <CardTitle>Continue learning</CardTitle>
          <CardDescription>
            Lesson {topic.number} · {topic.title}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">{topic.blurb}</p>
          <Progress value={topics[current].score} />
          <Button asChild>
            <Link to="/learn/$topicId" params={{ topicId: current }}>
              Open lesson
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        </CardContent>
      </Card>

      {due.length > 0 ? (
        <section className="space-y-3">
          <h2 className="font-display text-xl font-medium">Due for revision</h2>
          <p className="text-sm text-muted-foreground">
            Short return visits keep older material alive.
          </p>
          <div className="grid gap-2 sm:grid-cols-2">
            {due.slice(0, 4).map((id) => (
              <Link
                key={id}
                to="/learn/$topicId"
                params={{ topicId: id }}
                className="tap-card min-h-11 rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
              >
                {TOPIC_BY_ID[id].title}
              </Link>
            ))}
          </div>
        </section>
      ) : null}

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Jump to="/practice" icon={Sun} title="Daily practice" body="A set generated from your path." />
        <Jump to="/learn" icon={BookOpen} title="Learn" body="Full curriculum with exercises." />
        <Jump to="/code" icon={Terminal} title="Code" body="Isolated Python playground." />
        <Jump to="/games" icon={Puzzle} title="Games" body="Fix, predict, order, debug, build." />
        <Jump to="/typing" icon={Keyboard} title="Typing" body="Accuracy first, then speed." />
        <Jump to="/tutor" icon={MessageSquare} title="AI tutor" body="Gemini chat with your progress." />
        <Jump to="/live-tutor" icon={Phone} title="Live tutor" body="Speak with Gemini Live." />
      </section>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl tabular-nums">{value}</p>
      <p className="text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}

function Jump({
  to,
  icon: Icon,
  title,
  body,
}: {
  to: string;
  icon: typeof BookOpen;
  title: string;
  body: string;
}) {
  return (
    <Link
      to={to}
      className="tap-card rounded-xl bg-card p-4 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
    >
      <Icon className="size-4 text-accent" />
      <p className="mt-3 font-medium">{title}</p>
      <p className="mt-1 text-sm text-muted-foreground">{body}</p>
    </Link>
  );
}
