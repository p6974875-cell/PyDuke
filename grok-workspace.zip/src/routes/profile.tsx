import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useHelix } from "@/lib/store";
import { levelFromXp } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/profile")({ component: ProfilePage });

function ProfilePage() {
  const name = useHelix((s) => s.name);
  const setName = useHelix((s) => s.setName);
  const xp = useHelix((s) => s.xp);
  const streak = useHelix((s) => s.streak);
  const preferred = useHelix((s) => s.preferredDifficulty);
  const reset = useHelix((s) => s.resetProgress);
  const [draft, setDraft] = useState(name);
  const [open, setOpen] = useState(false);

  return (
    <div className="mx-auto max-w-lg space-y-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Profile</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">You, in PyDuke</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Progress lives on this device. There is no account — the tutor still remembers because the
          notebook is local.
        </p>
      </header>
      <div className="space-y-2">
        <Label htmlFor="name">What should PyDuke call you?</Label>
        <div className="flex gap-2">
          <Input
            id="name"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="A name, or leave blank"
          />
          <Button
            onClick={() => setName(draft.trim())}
            variant="secondary"
          >
            Save
          </Button>
        </div>
      </div>
      <dl className="grid grid-cols-2 gap-3">
        <Row k="Level" v={String(levelFromXp(xp))} />
        <Row k="XP" v={String(xp)} />
        <Row k="Streak" v={String(streak)} />
        <Row k="Adapted difficulty" v={preferred} />
      </dl>
      <p className="text-sm leading-relaxed text-muted-foreground">
        Difficulty adapts from your last few checks: three successes climb, three misses ease off.
        PyDuke will not skip lists as if you had never seen them, and it will not pretend you have
        finished tuples until you have.
      </p>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="outline">Reset progress</Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset this device?</DialogTitle>
            <DialogDescription>
              Lessons, games, typing history, and XP return to the arrival state (lists as the live
              lesson, earlier topics mastered). Your name is kept.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                reset();
                setOpen(false);
              }}
            >
              Reset
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <dt className="text-xs text-muted-foreground">{k}</dt>
      <dd className="mt-1 font-medium capitalize tabular-nums">{v}</dd>
    </div>
  );
}
