import { createFileRoute, Link } from "@tanstack/react-router";
import { LiveTutorSession } from "@/components/live-tutor-session";

export const Route = createFileRoute("/tutor/live")({ component: LivePage });

function LivePage() {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <header>
        <Link to="/tutor" className="text-xs text-muted-foreground hover:text-foreground">
          Tutor
        </Link>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Live Tutor</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Speak with PyDuke over Gemini Live. The permanent API key stays on the server; this page
          only uses a short-lived session token.
        </p>
      </header>
      <LiveTutorSession />
    </div>
  );
}
