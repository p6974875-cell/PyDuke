import { createFileRoute, Link } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { GAME_META, GAMES } from "@/lib/content/games";
import { TYPING_DRILLS } from "@/lib/content/typing";
import { GAME_UNLOCKS, isGameUnlocked } from "@/lib/game-engine";
import { useHelix } from "@/lib/store";
import { Progress } from "@/components/ui/progress";
import type { GameId } from "@/lib/types";

export const Route = createFileRoute("/games")({ component: GamesPage });

function GamesPage() {
  const games = useHelix((s) => s.games);
  const topics = useHelix((s) => s.topics);
  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Games</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Play to learn</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Each game grades real Python. Finish the matching lesson to unlock it. Challenges shuffle;
          scores and XP persist on this device.
        </p>
      </header>
      <div className="grid gap-3 sm:grid-cols-2">
        {GAME_META.map((g) => {
          const items = g.id === "typing" ? TYPING_DRILLS.length : (GAMES[g.id]?.length ?? 0);
          const done = games[g.id]?.completed.length ?? 0;
          const pct = items ? Math.round((done / items) * 100) : 0;
          const open = isGameUnlocked(g.id as GameId, topics);
          const req = GAME_UNLOCKS[g.id as GameId];
          const inner = (
            <>
              <p className="text-xs text-muted-foreground">{g.topicHint}</p>
              <h2 className="mt-2 font-display text-xl font-medium">{g.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{g.blurb}</p>
              <Progress value={open ? pct : 0} className="mt-4" />
              <p className="mt-2 text-xs tabular-nums text-muted-foreground">
                {open
                  ? `${done}/${items || "—"} · best ${games[g.id]?.bestScore ?? 0}`
                  : req.label}
              </p>
            </>
          );
          if (!open) {
            return (
              <div
                key={g.id}
                className="rounded-xl bg-card/60 p-5 text-muted-foreground shadow-[var(--shadow-border)]"
              >
                <div className="mb-2 inline-flex items-center gap-1 text-xs">
                  <Lock className="size-3.5" />
                  Locked
                </div>
                {inner}
              </div>
            );
          }
          return (
            <Link
              key={g.id}
              to="/games/$gameId"
              params={{ gameId: g.id }}
              className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
            >
              {inner}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
