import { createFileRoute, Link } from "@tanstack/react-router";
import { GAME_META, GAMES } from "@/lib/content/games";
import { GAME_SLUG } from "@/lib/content/game-ids";
import { useHelix } from "@/lib/store";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/games")({ component: GamesPage });

function GamesPage() {
  const games = useHelix((s) => s.games);
  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Games</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Play to learn</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Each game runs real Python in the browser. Difficulty climbs. Boss battle is sequential.
        </p>
      </header>
      <div className="grid gap-3 sm:grid-cols-2">
        {GAME_META.map((g) => {
          const items = g.id === "typing" ? 10 : (GAMES[g.id]?.length ?? 0);
          const done = games[g.id]?.completed.length ?? 0;
          const pct = items ? Math.round((done / items) * 100) : 0;
          return (
            <Link
              key={g.id}
              to="/games/$gameId"
              params={{ gameId: GAME_SLUG[g.id] }}
              className="tap-card rounded-xl bg-card p-5 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
            >
              <p className="text-xs text-muted-foreground">{g.topicHint}</p>
              <h2 className="mt-2 font-display text-xl font-medium">{g.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{g.blurb}</p>
              <Progress value={pct} className="mt-4" />
              <p className="mt-2 text-xs tabular-nums text-muted-foreground">
                {done}/{items || "—"}
              </p>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
