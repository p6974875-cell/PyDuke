import { createFileRoute, Link } from "@tanstack/react-router";
import { LiveTutor } from "@/components/live-tutor";

export const Route = createFileRoute("/live-tutor")({ component: LiveTutorPage });

function LiveTutorPage() {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Live</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Live tutor</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Speak with Gemini Live about any Python topic. Prefer typing?{" "}
          <Link to="/tutor" className="text-accent">
            Open chat
          </Link>
          .
        </p>
      </header>
      <LiveTutor />
    </div>
  );
}
