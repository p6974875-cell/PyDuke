import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { Check } from "lucide-react";
import { FixCard, PredictCard } from "@/components/game-cards";
import { ExercisePanel } from "@/components/exercise-panel";
import { TypingArena } from "@/components/typing-arena";
import { Progress } from "@/components/ui/progress";
import { dailyKey, dailyPack } from "@/lib/content/daily";
import { useHelix } from "@/lib/store";

export const Route = createFileRoute("/practice")({ component: PracticePage });

function PracticePage() {
  const current = useHelix((s) => s.currentTopicId);
  const dailyDate = useHelix((s) => s.dailyDate);
  const dailyDone = useHelix((s) => s.dailyDone);
  const completeDaily = useHelix((s) => s.completeDaily);
  const today = dailyKey();
  const done = dailyDate === today ? dailyDone : [];
  const pack = useMemo(() => dailyPack(today, current), [today, current]);
  const items = [
    ...pack.predicts.map((p) => `predict:${p.id}`),
    `debug:${pack.debug.id}`,
    `ex:${pack.exercise.id}`,
    `type:${pack.typing.id}`,
  ];
  const cleared = items.filter((id) => done.includes(id)).length;

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Daily</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Today's practice</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          A set generated from your current path for {today}. Completing an item awards XP and
          stays done if you refresh.
        </p>
        <Progress value={items.length ? (cleared / items.length) * 100 : 0} className="mt-4 max-w-sm" />
        <p className="mt-2 text-xs tabular-nums text-muted-foreground">
          {cleared}/{items.length} complete
        </p>
      </header>

      {pack.predicts.map((item, i) => (
        <section key={item.id} className="space-y-3">
          <Head n={i + 1} title="Predict the output" done={done.includes(`predict:${item.id}`)} />
          <PredictCard
            item={item}
            onResult={(ok) => {
              if (ok) completeDaily(`predict:${item.id}`);
            }}
          />
        </section>
      ))}

      <section className="space-y-3">
        <Head n={pack.predicts.length + 1} title="Debug / fix" done={done.includes(`debug:${pack.debug.id}`)} />
        <p className="text-sm text-muted-foreground">{pack.debug.prompt}</p>
        <FixCard
          item={pack.debug}
          onResult={(ok) => {
            if (ok) completeDaily(`debug:${pack.debug.id}`);
          }}
        />
      </section>

      <section className="space-y-3">
        <Head n={pack.predicts.length + 2} title="Coding exercise" done={done.includes(`ex:${pack.exercise.id}`)} />
        <ExercisePanel exercise={pack.exercise} topicId={current} />
        <MarkWhen
          done={done.includes(`ex:${pack.exercise.id}`)}
          onDone={() => completeDaily(`ex:${pack.exercise.id}`)}
        />
      </section>

      <section className="space-y-3">
        <Head n={pack.predicts.length + 3} title="Two-minute typing" done={done.includes(`type:${pack.typing.id}`)} />
        <TypingArena drills={[pack.typing]} />
        <button
          type="button"
          className="h-11 rounded-md bg-secondary px-4 text-sm"
          onClick={() => completeDaily(`type:${pack.typing.id}`)}
        >
          Mark typing complete
        </button>
      </section>

      <p className="text-sm text-muted-foreground">
        Want a full lesson instead?{" "}
        <Link to="/learn/$topicId" params={{ topicId: current }} className="text-accent">
          Continue {current}
        </Link>
      </p>
    </div>
  );
}

function Head({ n, title, done }: { n: number; title: string; done: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <h2 className="font-display text-xl font-medium">
        {n}. {title}
      </h2>
      {done ? (
        <span className="inline-flex items-center gap-1 text-xs text-success">
          <Check className="size-3.5" /> Done
        </span>
      ) : null}
    </div>
  );
}

function MarkWhen({
  done,
  onDone,
}: {
  done: boolean;
  onDone: () => void;
}) {
  if (done) return null;
  return (
    <button type="button" className="h-11 rounded-md bg-secondary px-4 text-sm" onClick={onDone}>
      Mark this exercise done for today
    </button>
  );
}
