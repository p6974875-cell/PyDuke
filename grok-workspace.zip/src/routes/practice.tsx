import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, type ReactNode } from "react";
import { Check } from "lucide-react";
import { ChallengeCard, McqPrompt } from "@/components/game-challenges";
import { ExercisePanel } from "@/components/exercise-panel";
import { TypingArena } from "@/components/typing-arena";
import { Progress } from "@/components/ui/progress";
import { buildDaily, DAILY_SLOTS } from "@/lib/content/daily";
import { todayKey } from "@/lib/utils";
import { useHelix } from "@/lib/store";

export const Route = createFileRoute("/practice")({ component: PracticePage });

function PracticePage() {
  const topics = useHelix((s) => s.topics);
  const dailyDate = useHelix((s) => s.dailyDate);
  const dailyDone = useHelix((s) => s.dailyDone);
  const markDaily = useHelix((s) => s.markDaily);
  const today = todayKey();
  const done = dailyDate === today ? dailyDone : [];
  const set = useMemo(() => buildDaily(today, topics), [today, topics]);
  const pct = Math.round((done.length / DAILY_SLOTS.length) * 100);

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
          Daily practice
        </p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Today’s set</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Two concepts, two output predictions, one debug, one coding exercise, and a typing sprint.
          Seeded by the date — same day, same set. Weak topics you missed before are preferred.
        </p>
        <div className="mt-4 flex items-center gap-3">
          <Progress value={pct} className="max-w-xs" />
          <span className="text-xs tabular-nums text-muted-foreground">
            {done.length}/{DAILY_SLOTS.length}
          </span>
        </div>
      </header>

      {set.concepts.map((c, i) => {
        const slot = `concept-${i}`;
        return (
          <Slot key={c.id} title={`Concept ${i + 1}`} done={done.includes(slot)}>
            {done.includes(slot) ? (
              <p className="text-sm text-success">Logged for today.</p>
            ) : (
              <McqPrompt
                question={c.question}
                choices={c.choices}
                answer={c.answer}
                explanation={c.explanation}
                onResult={() => markDaily(slot)}
              />
            )}
          </Slot>
        );
      })}

      {set.predicts.map((item, i) => {
        const slot = `predict-${i}`;
        return (
          <Slot key={item.id} title={`Predict ${i + 1}: ${item.title}`} done={done.includes(slot)}>
            {done.includes(slot) ? (
              <p className="text-sm text-success">Logged for today.</p>
            ) : (
              <ChallengeCard item={item} onResult={() => markDaily(slot)} />
            )}
          </Slot>
        );
      })}

      {set.debug ? (
        <Slot title={`Debug: ${set.debug.title}`} done={done.includes("debug")}>
          {done.includes("debug") ? (
            <p className="text-sm text-success">Logged for today.</p>
          ) : (
            <ChallengeCard item={set.debug} onResult={() => markDaily("debug")} />
          )}
        </Slot>
      ) : null}

      {set.exercise ? (
        <Slot title={`Code: ${set.exercise.exercise.title}`} done={done.includes("code")}>
          <ExercisePanel
            exercise={set.exercise.exercise}
            topicId={set.exercise.topicId}
            onPassed={() => markDaily("code")}
          />
        </Slot>
      ) : null}

      <Slot title={`Typing · ${set.typing.title}`} done={done.includes("typing")}>
        <p className="text-sm text-muted-foreground">Two-minute sprint. Accuracy first.</p>
        <TypingArena
          drills={[set.typing]}
          timedSeconds={120}
          onComplete={() => markDaily("typing")}
        />
      </Slot>

      {done.length >= DAILY_SLOTS.length ? (
        <p className="rounded-xl bg-card p-5 text-sm shadow-[var(--shadow-border)]">
          Daily set complete. Come back tomorrow for a new seed.{" "}
          <Link to="/progress" className="underline">
            See progress
          </Link>
        </p>
      ) : null}
    </div>
  );
}

function Slot({ title, done, children }: { title: string; done: boolean; children: ReactNode }) {
  return (
    <section className="space-y-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-display text-lg font-medium">{title}</h2>
        {done ? (
          <span className="inline-flex items-center gap-1 text-xs text-success">
            <Check className="size-3.5" /> Done
          </span>
        ) : null}
      </div>
      {children}
    </section>
  );
}
