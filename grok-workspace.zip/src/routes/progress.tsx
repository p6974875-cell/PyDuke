import { createFileRoute, Link } from "@tanstack/react-router";
import { TOPICS } from "@/lib/content/topics";
import { GAME_META, GAMES } from "@/lib/content/games";
import { PROJECTS } from "@/lib/content/projects";
import { unlockedAchievements, ACHIEVEMENTS } from "@/lib/achievements";
import { useHelix } from "@/lib/store";
import { Progress } from "@/components/ui/progress";
import { levelFromXp, xpIntoLevel } from "@/lib/utils";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export const Route = createFileRoute("/progress")({ component: ProgressPage });

function ProgressPage() {
  const s = useHelix();
  const mastered = TOPICS.filter((t) => s.topics[t.id].status === "mastered");
  const review = s.dueRevision();
  const gamesDone = GAME_META.reduce((n, g) => n + (s.games[g.id]?.completed.length ?? 0), 0);
  const gamesTotal = GAME_META.reduce(
    (n, g) => n + (g.id === "typing" ? 10 : GAMES[g.id]?.length ?? 0),
    0,
  );
  const lastType = s.typingHistory.at(-1);
  const avgAcc =
    s.typingHistory.length === 0
      ? 0
      : Math.round(
          (s.typingHistory.reduce((a, h) => a + h.accuracy, 0) / s.typingHistory.length) * 10,
        ) / 10;
  const debugScore = Math.round(
    ((s.games.debug?.completed.length ?? 0) / Math.max(1, GAMES.debug.length)) * 100,
  );
  const typeData = s.typingHistory.slice(-12).map((h, i) => ({ i: i + 1, wpm: h.wpm, accuracy: h.accuracy }));
  const unlocked = unlockedAchievements(s);
  const unlockedIds = new Set(unlocked.map((a) => a.id));

  return (
    <div className="space-y-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Progress</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Where you stand</h1>
      </header>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Tile label="Python level" value={`Lv ${levelFromXp(s.xp)}`} hint={`${s.xp} XP`} />
        <Tile label="Streak" value={String(s.streak)} hint="consecutive days" />
        <Tile label="Lessons completed" value={String(s.lessonsCompleted.length)} hint={`${TOPICS.length} in path`} />
        <Tile label="Projects" value={`${s.projectsCompleted.length}/${PROJECTS.length}`} hint="builds finished" />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
          <p className="text-xs text-muted-foreground">XP in this level</p>
          <Progress value={(xpIntoLevel(s.xp) / 150) * 100} className="mt-3" />
          <p className="mt-2 text-xs tabular-nums text-muted-foreground">{xpIntoLevel(s.xp)} / 150</p>
        </div>
        <div className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
          <p className="text-xs text-muted-foreground">Games completed</p>
          <Progress value={gamesTotal ? (gamesDone / gamesTotal) * 100 : 0} className="mt-3" />
          <p className="mt-2 text-xs tabular-nums text-muted-foreground">
            {gamesDone}/{gamesTotal}
          </p>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Tile label="Typing speed" value={lastType ? `${lastType.wpm} WPM` : "—"} hint="last run" />
        <Tile label="Typing accuracy" value={`${avgAcc}%`} hint="average" />
        <Tile label="Debugging score" value={`${debugScore}%`} hint="debug game" />
      </div>
      {typeData.length > 1 ? (
        <div className="h-48 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
          <p className="mb-2 text-xs text-muted-foreground">Typing over recent runs (accuracy + WPM)</p>
          <ResponsiveContainer width="100%" height="85%">
            <LineChart data={typeData}>
              <XAxis dataKey="i" hide />
              <YAxis hide />
              <Tooltip
                contentStyle={{
                  background: "#172333",
                  border: "1px solid rgba(238,230,212,0.1)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Line type="monotone" dataKey="accuracy" stroke="#c4a15a" dot={false} strokeWidth={1.5} />
              <Line type="monotone" dataKey="wpm" stroke="#6fbf9a" dot={false} strokeWidth={1.5} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      ) : null}
      <section>
        <h2 className="font-display text-xl font-medium">Achievements</h2>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2">
          {ACHIEVEMENTS.map((a) => {
            const on = unlockedIds.has(a.id);
            return (
              <li
                key={a.id}
                className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]"
              >
                <p className={on ? "font-medium text-accent" : "font-medium text-muted-foreground"}>
                  {on ? "Unlocked · " : "Locked · "}
                  {a.title}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">{a.blurb}</p>
              </li>
            );
          })}
        </ul>
      </section>
      <section>
        <h2 className="font-display text-xl font-medium">Topics mastered</h2>
        <ul className="mt-3 flex flex-wrap gap-2">
          {mastered.map((t) => (
            <li key={t.id} className="rounded-full bg-secondary px-3 py-1 text-xs">
              {t.title}
            </li>
          ))}
        </ul>
      </section>
      <section>
        <h2 className="font-display text-xl font-medium">Needs revision</h2>
        {review.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">Nothing is due. Keep moving forward.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {review.map((id) => {
              const t = TOPICS.find((x) => x.id === id)!;
              return (
                <li key={id}>
                  <Link to="/learn/$topicId" params={{ topicId: id }} className="text-sm hover:underline">
                    {t.title}
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}

function Tile({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl tabular-nums">{value}</p>
      <p className="text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}
