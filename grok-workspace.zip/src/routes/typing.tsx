import { createFileRoute } from "@tanstack/react-router";
import { TypingArena } from "@/components/typing-arena";
import { TYPING_TECHNIQUES } from "@/lib/content/typing-techniques";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, Target } from "lucide-react";
import { TYPING_DRILLS } from "@/lib/content/typing";
import { useHelix } from "@/lib/store";
import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export const Route = createFileRoute("/typing")({ component: TypingPage });

function TypingPage() {
  const history = useHelix((s) => s.typingHistory);
  const avgAcc =
    history.length === 0
      ? 0
      : Math.round((history.reduce((a, h) => a + h.accuracy, 0) / history.length) * 10) / 10;
  const avgWpm =
    history.length === 0
      ? 0
      : Math.round(history.reduce((a, h) => a + h.wpm, 0) / history.length);
  const data = history.slice(-12).map((h, i) => ({
    i: i + 1,
    wpm: h.wpm,
    accuracy: h.accuracy,
  }));

  return (
    <div className="space-y-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Typing</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Python typing trainer</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Parentheses, colons, underscores, indentation. Do not trade accuracy for speed — a fast
          wrong program is still wrong.
        </p>
      </header>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Runs" value={String(history.length)} />
        <Stat label="Average accuracy" value={`${avgAcc}%`} />
        <Stat label="Average WPM" value={String(avgWpm)} />
      </div>
      {data.length > 1 ? (
        <div className="h-48 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <XAxis dataKey="i" hide />
              <YAxis hide />
              <Tooltip
                contentStyle={{
                  background: "#17181c",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Line type="monotone" dataKey="accuracy" stroke="#c8ccd4" dot={false} strokeWidth={1.5} />
              <Line type="monotone" dataKey="wpm" stroke="#6fbf9a" dot={false} strokeWidth={1.5} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      ) : null}
      <section className="space-y-3">
        <div>
          <h2 className="font-display text-xl font-medium">Typing techniques</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Learn the technique, then use the arena to turn it into muscle memory.
          </p>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {TYPING_TECHNIQUES.map((lesson) => (
            <Card key={lesson.id}>
              <CardHeader>
                <CardTitle className="text-base">{lesson.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <p className="text-muted-foreground">{lesson.goal}</p>
                <ul className="space-y-2">
                  {lesson.steps.map((step) => (
                    <li key={step} className="flex gap-2">
                      <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" />
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
                <div className="rounded-lg bg-code p-3">
                  <div className="mb-1 flex items-center gap-2 text-xs text-muted-foreground">
                    <Target className="size-3.5" /> Practice
                  </div>
                  <pre className="whitespace-pre-wrap font-mono text-xs leading-relaxed">{lesson.drill}</pre>
                </div>
                <p className="text-xs text-muted-foreground"><strong className="text-foreground">Tip:</strong> {lesson.tip}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
      <section className="space-y-3">
        <div>
          <h2 className="font-display text-xl font-medium">Typing arena</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Choose a drill and type the code exactly. Your attempts are saved locally.
          </p>
        </div>
        <TypingArena drills={TYPING_DRILLS} />
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl tabular-nums">{value}</p>
    </div>
  );
}
