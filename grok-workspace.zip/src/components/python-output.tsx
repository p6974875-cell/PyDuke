import { cn } from "@/lib/utils";
import type { RunResult } from "@/lib/python-engine";
import { explainError } from "@/lib/explain-error";

export function PythonOutput({
  result,
  code,
  className,
}: {
  result: RunResult | null;
  code?: string;
  className?: string;
}) {
  if (!result) {
    return (
      <div className={cn("rounded-lg bg-code px-4 py-3 text-sm text-muted-foreground", className)}>
        Output appears here after you run.
      </div>
    );
  }

  const hasOut = result.stdout.trim().length > 0;
  const err = result.error || result.stderr;
  const steps = err ? explainError(err, code ?? "") : null;

  return (
    <div className={cn("space-y-3", className)}>
      <pre className="overflow-x-auto rounded-lg bg-code px-4 py-3 font-mono text-[13px] leading-relaxed text-foreground">
        {hasOut ? result.stdout : err ? "" : "(no output)"}
        {err ? (
          <span className="block text-destructive">
            {hasOut ? "\n" : ""}
            {err}
          </span>
        ) : null}
      </pre>
      {steps ? (
        <ol className="space-y-1.5 rounded-lg bg-secondary px-4 py-3 text-sm text-muted-foreground">
          {steps.map((s, i) => (
            <li key={i} className="leading-relaxed">
              <span className="mr-2 font-mono text-xs text-accent">{i + 1}.</span>
              {s}
            </li>
          ))}
        </ol>
      ) : null}
      <p className="text-xs tabular-nums text-muted-foreground">{result.durationMs}ms</p>
    </div>
  );
}
