import { useEffect, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";

type InnerProps = {
  value: string;
  onChange: (v: string) => void;
  onRun?: () => void;
  className?: string;
  minHeight?: number;
};

export function CodeEditor(props: InnerProps) {
  const [Inner, setInner] = useState<null | ((p: InnerProps) => ReactNode)>(null);

  useEffect(() => {
    let live = true;
    void import("./code-editor-inner").then((m) => {
      if (live) setInner(() => m.CodeEditorInner);
    });
    return () => {
      live = false;
    };
  }, []);

  if (!Inner) {
    return (
      <div
        className={cn("rounded-lg bg-code shadow-[var(--shadow-border)]", props.className)}
        style={{ minHeight: props.minHeight ?? 220 }}
      />
    );
  }
  return <Inner {...props} />;
}
