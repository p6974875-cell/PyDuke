import { useEffect, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";

type InnerProps = {
  value: string;
  onChange: (v: string) => void;
  onRun?: () => void;
  className?: string;
  minHeight?: number;
};

export function CodeEditor(props: InnerProps) {
  const [Inner, setInner] = useState<null | ((p: InnerProps) => ReactNode)>(null);

  useEffect(() => {
    let live = true;
    void import("./code-editor-inner").then((m) => {
      if (live) setInner(() => m.CodeEditorInner);
    });
    return () => {
      live = false;
    };
  }, []);

  if (!Inner) {
    return (
      <textarea
        value={props.value}
        onChange={(e) => props.onChange(e.target.value)}
        onKeyDown={(e) => {
          if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
            e.preventDefault();
            props.onRun?.();
          }
        }}
        spellCheck={false}
        aria-label="Python editor"
        className={cn(
          "w-full resize-y rounded-lg bg-code p-3 font-mono text-xs leading-relaxed text-foreground shadow-[var(--shadow-border)] outline-none",
          props.className,
        )}
        style={{ minHeight: props.minHeight ?? 220 }}
      />
    );
  }
  return <Inner {...props} />;
}
