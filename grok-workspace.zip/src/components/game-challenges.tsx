import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, Eye, GripVertical, Lightbulb, Play, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CodeBlock } from "@/components/code-block";
import { CodeEditor } from "@/components/code-editor";
import { Input } from "@/components/ui/input";
import { PythonOutput } from "@/components/python-output";
import { gradeCode } from "@/lib/grade";
import { outputsMatch, type RunResult } from "@/lib/python-engine";
import { shuffle } from "@/lib/game-engine";
import type { GameItem } from "@/lib/types";
import { cn } from "@/lib/utils";

export function itemKind(item: GameItem): "code" | "predict" | "order" | "mcq" {
  if (item.kind) return item.kind;
  if (item.choices && item.answer) return "mcq";
  if (item.lines?.length) return "order";
  if (item.code && item.expected !== undefined) return "predict";
  return "code";
}

export function ChallengeCard({
  item,
  onResult,
}: {
  item: GameItem;
  onResult: (ok: boolean) => void;
}) {
  const kind = itemKind(item);
  if (kind === "mcq") return <McqCard key={item.id} item={item} onResult={onResult} />;
  if (kind === "predict") return <PredictCard key={item.id} item={item} onResult={onResult} />;
  if (kind === "order") return <OrderCard key={item.id} item={item} onResult={onResult} />;
  return <FixCard key={item.id} item={item} onResult={onResult} />;
}

function FixCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [code, setCode] = useState(item.starter ?? "");
  const [result, setResult] = useState<RunResult | null>(null);
  const [msg, setMsg] = useState("");
  const [ok, setOk] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const [show, setShow] = useState(false);
  const [hint, setHint] = useState(false);
  const [running, setRunning] = useState(false);
  const [locked, setLocked] = useState(false);

  async function runOnly() {
    setRunning(true);
    try {
      const g = await gradeCode(code, item.checks ?? []);
      setResult(g.run);
      setMsg(g.passed ? "Looks right — submit to score it." : g.message);
      setOk(g.passed);
    } finally {
      setRunning(false);
    }
  }

  async function submit() {
    if (locked) return;
    setRunning(true);
    try {
      const g = await gradeCode(code, item.checks ?? []);
      setResult(g.run);
      setMsg(g.message);
      setOk(g.passed);
      setAttempted(true);
      setLocked(g.passed);
      onResult(g.passed);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-3">
      <CodeEditor value={code} onChange={setCode} onRun={runOnly} minHeight={200} />
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="secondary" onClick={() => void runOnly()} disabled={running}>
          <Play className="size-4" />
          Run
        </Button>
        <Button size="sm" onClick={() => void submit()} disabled={running || locked}>
          Submit
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => {
            setCode(item.starter ?? "");
            setResult(null);
            setMsg("");
            setOk(false);
          }}
        >
          <RotateCcw className="size-4" />
          Reset
        </Button>
        {item.hint ? (
          <Button size="sm" variant="ghost" onClick={() => setHint((v) => !v)}>
            <Lightbulb className="size-4" />
            Hint
          </Button>
        ) : null}
        <Button size="sm" variant="ghost" disabled={!attempted} onClick={() => setShow(true)}>
          <Eye className="size-4" />
          Compare
        </Button>
      </div>
      {hint && item.hint ? <p className="text-sm text-muted-foreground">{item.hint}</p> : null}
      {msg ? <p className={ok ? "text-sm text-success" : "text-sm text-destructive"}>{msg}</p> : null}
      <PythonOutput result={result} code={code} />
      {show && item.solution ? (
        <div className="rounded-lg bg-secondary p-4">
          <CodeBlock code={item.solution} />
          <p className="mt-2 text-sm text-muted-foreground">{item.explanation}</p>
        </div>
      ) : null}
    </div>
  );
}

function PredictCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [guess, setGuess] = useState("");
  const [revealed, setRevealed] = useState(false);
  const choices = item.choices ?? [];
  const correct = outputsMatch(guess, item.expected ?? "");

  function lock(value: string) {
    if (revealed) return;
    setGuess(value);
    setRevealed(true);
    onResult(outputsMatch(value, item.expected ?? ""));
  }

  return (
    <div className="space-y-3">
      <CodeBlock code={item.code ?? ""} />
      {choices.length ? (
        <div className="grid gap-2 sm:grid-cols-2">
          {choices.map((c) => (
            <button
              key={c}
              type="button"
              disabled={revealed}
              onClick={() => lock(c)}
              className={cn(
                "min-h-11 rounded-lg bg-secondary px-3 py-2 text-left font-mono text-sm",
                revealed && outputsMatch(c, item.expected ?? "") && "text-success",
                revealed && guess === c && !outputsMatch(c, item.expected ?? "") && "text-destructive",
              )}
            >
              {c}
            </button>
          ))}
        </div>
      ) : null}
      <div className="flex flex-col gap-2 sm:flex-row">
        <Input
          value={guess}
          onChange={(e) => setGuess(e.target.value)}
          placeholder="Or type the exact output"
          disabled={revealed}
        />
        <Button size="sm" disabled={revealed || !guess.trim()} onClick={() => lock(guess)}>
          Lock in
        </Button>
      </div>
      {revealed ? (
        <div className="space-y-2 rounded-lg bg-secondary p-4 text-sm">
          <p className={correct ? "text-success" : "text-destructive"}>
            {correct ? "Your prediction matched." : "Not quite."}
          </p>
          <p className="font-mono text-foreground">Actual: {item.expected}</p>
          <p className="text-muted-foreground">{item.explanation}</p>
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">Predict before you see the output. One shot.</p>
      )}
    </div>
  );
}

function McqCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [picked, setPicked] = useState("");
  const [revealed, setRevealed] = useState(false);
  const options = useMemo(() => shuffle(item.choices ?? []), [item.id, item.choices]);
  const answer = item.answer ?? item.expected ?? "";

  function lock(value: string) {
    if (revealed) return;
    setPicked(value);
    setRevealed(true);
    onResult(value === answer);
  }

  return (
    <div className="space-y-3">
      {item.code ? <CodeBlock code={item.code} /> : null}
      <div className="grid gap-2">
        {options.map((c) => (
          <button
            key={c}
            type="button"
            disabled={revealed}
            onClick={() => lock(c)}
            className={cn(
              "min-h-11 rounded-lg bg-secondary px-3 py-2 text-left text-sm",
              revealed && c === answer && "text-success",
              revealed && picked === c && c !== answer && "text-destructive",
            )}
          >
            {c}
          </button>
        ))}
      </div>
      {revealed ? <p className="text-sm text-muted-foreground">{item.explanation}</p> : null}
    </div>
  );
}

function OrderCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [lines, setLines] = useState(() => shuffle(item.lines ?? []));
  const [drag, setDrag] = useState<number | null>(null);
  const [result, setResult] = useState<RunResult | null>(null);
  const [ok, setOk] = useState(false);
  const [show, setShow] = useState(false);
  const [running, setRunning] = useState(false);
  const [locked, setLocked] = useState(false);

  function move(i: number, dir: -1 | 1) {
    if (locked) return;
    const j = i + dir;
    if (j < 0 || j >= lines.length) return;
    const next = lines.slice();
    [next[i], next[j]] = [next[j], next[i]];
    setLines(next);
  }

  function onDrop(i: number) {
    if (drag === null || drag === i || locked) {
      setDrag(null);
      return;
    }
    const next = lines.slice();
    const [row] = next.splice(drag, 1);
    next.splice(i, 0, row);
    setLines(next);
    setDrag(null);
  }

  async function check() {
    if (locked) return;
    setRunning(true);
    try {
      const g = await gradeCode(lines.join("\n"), [{ kind: "stdout", expected: item.expected }]);
      setResult(g.run);
      setOk(g.passed);
      setLocked(g.passed);
      onResult(g.passed);
      if (g.passed) setShow(true);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-3">
      <ul className="space-y-2">
        {lines.map((line, i) => (
          <li
            key={`${line}-${i}`}
            draggable={!locked}
            onDragStart={() => setDrag(i)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => onDrop(i)}
            className={cn(
              "flex items-stretch gap-2 rounded-lg bg-code px-2 py-1 font-mono text-[13px]",
              drag === i && "opacity-60",
            )}
          >
            <span className="flex cursor-grab items-center px-1 text-muted-foreground" aria-hidden>
              <GripVertical className="size-4" />
            </span>
            <div className="flex flex-col">
              <button
                type="button"
                className="flex h-7 w-8 items-center justify-center text-muted-foreground"
                onClick={() => move(i, -1)}
                aria-label="Move up"
              >
                <ArrowUp className="size-3.5" />
              </button>
              <button
                type="button"
                className="flex h-7 w-8 items-center justify-center text-muted-foreground"
                onClick={() => move(i, 1)}
                aria-label="Move down"
              >
                <ArrowDown className="size-3.5" />
              </button>
            </div>
            <span className="flex-1 whitespace-pre py-2">{line}</span>
          </li>
        ))}
      </ul>
      <Button size="sm" onClick={() => void check()} disabled={running || locked}>
        Run in order
      </Button>
      {ok ? <p className="text-sm text-success">That order works.</p> : null}
      {!ok && locked ? <p className="text-sm text-destructive">That order does not produce the expected output.</p> : null}
      <PythonOutput result={result} code={lines.join("\n")} />
      {show ? <p className="text-sm text-muted-foreground">{item.explanation}</p> : null}
    </div>
  );
}

export function McqPrompt({
  question,
  choices,
  answer,
  explanation,
  onResult,
}: {
  question: string;
  choices: string[];
  answer: string;
  explanation: string;
  onResult: (ok: boolean) => void;
}) {
  const options = useMemo(() => shuffle(choices), [choices]);
  const [picked, setPicked] = useState("");
  const [revealed, setRevealed] = useState(false);

  return (
    <div className="space-y-3">
      <p className="text-sm">{question}</p>
      <div className="grid gap-2">
        {options.map((c) => (
          <button
            key={c}
            type="button"
            disabled={revealed}
            onClick={() => {
              if (revealed) return;
              setPicked(c);
              setRevealed(true);
              onResult(c === answer);
            }}
            className={cn(
              "min-h-11 rounded-lg bg-secondary px-3 py-2 text-left text-sm",
              revealed && c === answer && "text-success",
              revealed && picked === c && c !== answer && "text-destructive",
            )}
          >
            {c}
          </button>
        ))}
      </div>
      {revealed ? <p className="text-sm text-muted-foreground">{explanation}</p> : null}
    </div>
  );
}
