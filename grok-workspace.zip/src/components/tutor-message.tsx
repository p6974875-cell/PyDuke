import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CodeBlock } from "@/components/code-block";

export function TutorMessage({ content }: { content: string }) {
  const chunks = splitFences(content);
  return (
    <div className="space-y-3 text-sm leading-relaxed">
      {chunks.map((c, i) =>
        c.type === "code" ? (
          <CopyableCode key={i} code={c.text} />
        ) : (
          <p key={i} className="whitespace-pre-wrap">
            {c.text}
          </p>
        ),
      )}
    </div>
  );
}

function CopyableCode({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="relative">
      <CodeBlock code={code} />
      <Button
        type="button"
        size="icon-sm"
        variant="ghost"
        className="absolute right-2 top-2"
        onClick={async () => {
          await navigator.clipboard.writeText(code);
          setCopied(true);
          window.setTimeout(() => setCopied(false), 1200);
        }}
        aria-label="Copy code"
      >
        {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
      </Button>
    </div>
  );
}

function splitFences(text: string): { type: "text" | "code"; text: string }[] {
  const parts = text.split(/```(?:python|py)?\n?([\s\S]*?)```/g);
  return parts
    .map((p, i) => ({ type: (i % 2 === 1 ? "code" : "text") as "text" | "code", text: p }))
    .filter((p) => p.text.trim());
}
