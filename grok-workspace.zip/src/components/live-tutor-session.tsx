import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, PhoneOff, Radio } from "lucide-react";
import { Button } from "@/components/ui/button";
import { createLiveSessionToken, tutorAvailability } from "@/lib/tutor-live";
import { progressSummary, useHelix } from "@/lib/store";

type Status = "idle" | "connecting" | "live" | "error";

export function LiveTutorSession() {
  const [avail, setAvail] = useState<{ live: boolean } | null>(null);
  const [status, setStatus] = useState<Status>("idle");
  const [muted, setMuted] = useState(false);
  const [error, setError] = useState("");
  const [heard, setHeard] = useState("");
  const [said, setSaid] = useState("");
  const wsRef = useRef<WebSocket | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const playCtxRef = useRef<AudioContext | null>(null);
  const playTimeRef = useRef(0);
  const mutedRef = useRef(false);
  const audioReadyRef = useRef(false);

  useEffect(() => {
    void tutorAvailability().then(setAvail).catch(() => setAvail({ live: false }));
    return () => teardown();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function teardown() {
    wsRef.current?.close();
    wsRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    void ctxRef.current?.close();
    ctxRef.current = null;
    void playCtxRef.current?.close();
    playCtxRef.current = null;
    playTimeRef.current = 0;
    audioReadyRef.current = false;
  }

  async function start() {
    setError("");
    setStatus("connecting");
    try {
      const tokenRes = await createLiveSessionToken({
        data: { progressSummary: progressSummary(useHelix.getState()) },
      });
      if (!tokenRes.ok) {
        setError(tokenRes.error);
        setStatus("error");
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
      });
      streamRef.current = stream;

      const model = tokenRes.model.startsWith("models/")
        ? tokenRes.model
        : `models/${tokenRes.model}`;
      const token = tokenRes.token;
      const url =
        `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContentConstrained?access_token=${encodeURIComponent(token)}`;
      const fallback =
        `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained?access_token=${encodeURIComponent(token)}`;

      const ws = await openSocket(url, fallback);
      wsRef.current = ws;

      ws.onmessage = async (ev) => {
        const raw = typeof ev.data === "string" ? ev.data : await (ev.data as Blob).text();
        let msg: Record<string, unknown>;
        try {
          msg = JSON.parse(raw) as Record<string, unknown>;
        } catch {
          return;
        }
        if (msg.setupComplete) {
          audioReadyRef.current = true;
          setStatus("live");
        }
        const sc = msg.serverContent as
          | {
              modelTurn?: { parts?: { text?: string; inlineData?: { data?: string; mimeType?: string } }[] };
              inputTranscription?: { text?: string };
              outputTranscription?: { text?: string };
            }
          | undefined;
        if (sc?.inputTranscription?.text) setHeard((h) => h + sc.inputTranscription!.text);
        if (sc?.outputTranscription?.text) setSaid((h) => h + sc.outputTranscription!.text);
        const parts = sc?.modelTurn?.parts ?? [];
        for (const p of parts) {
          if (p.text) setSaid((h) => h + p.text);
          if (p.inlineData?.data) playPcm24(p.inlineData.data);
        }
        if (msg.error) {
          const err = msg.error as { message?: string };
          setError(err.message || "Live session error");
        }
      };
      ws.onerror = () => {
        setError("The live connection failed.");
        setStatus("error");
      };
      ws.onclose = () => {
        if (status === "live" || status === "connecting") setStatus("idle");
      };

      ws.send(
        JSON.stringify({
          setup: {
            model,
            generationConfig: {
              responseModalities: ["AUDIO"],
              speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } },
              },
            },
            systemInstruction: { parts: [{ text: tokenRes.instruction }] },
            inputAudioTranscription: {},
            outputAudioTranscription: {},
          },
        }),
      );

      const ctx = new AudioContext({ sampleRate: 16000 });
      ctxRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const proc = ctx.createScriptProcessor(4096, 1, 1);
      proc.onaudioprocess = (e) => {
        if (!audioReadyRef.current || mutedRef.current || ws.readyState !== WebSocket.OPEN) return;
        const input = e.inputBuffer.getChannelData(0);
        const pcm = floatTo16(input);
        ws.send(
          JSON.stringify({
            realtimeInput: {
              audio: { data: u8ToB64(pcm), mimeType: "audio/pcm;rate=16000" },
            },
          }),
        );
      };
      const gain = ctx.createGain();
      gain.gain.value = 0;
      source.connect(proc);
      proc.connect(gain);
      gain.connect(ctx.destination);
      setStatus("live");
    } catch (err) {
      const name = err instanceof DOMException ? err.name : "";
      if (name === "NotAllowedError" || name === "PermissionDeniedError") {
        setError("Microphone permission was denied. Allow the mic in the browser, then start again.");
      } else {
        setError(err instanceof Error ? err.message : "Could not start the live session.");
      }
      setStatus("error");
      teardown();
    }
  }

  function playPcm24(b64: string) {
    const bytes = b64ToU8(b64);
    const ctx = playCtxRef.current ?? new AudioContext({ sampleRate: 24000 });
    playCtxRef.current = ctx;
    const frames = bytes.byteLength / 2;
    const buf = ctx.createBuffer(1, frames, 24000);
    const ch = buf.getChannelData(0);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (let i = 0; i < frames; i++) ch[i] = view.getInt16(i * 2, true) / 32768;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.connect(ctx.destination);
    const now = ctx.currentTime;
    const startAt = Math.max(now, playTimeRef.current);
    src.start(startAt);
    playTimeRef.current = startAt + buf.duration;
  }

  function end() {
    teardown();
    setStatus("idle");
  }

  if (avail && !avail.live) {
    return (
      <div className="rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
        Live Tutor needs a server-side <code className="font-mono text-foreground">GEMINI_API_KEY</code>.
        Copy <span className="font-mono text-foreground">.env.example</span> to{" "}
        <span className="font-mono text-foreground">.env</span>, add the key, and restart. The permanent
        key never leaves the server — the browser only receives a short-lived Live token.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {status === "live" ? (
          <>
            <Button
              size="sm"
              variant={muted ? "secondary" : "default"}
              onClick={() => {
                mutedRef.current = !mutedRef.current;
                setMuted(mutedRef.current);
                streamRef.current?.getAudioTracks().forEach((t) => {
                  t.enabled = !mutedRef.current;
                });
              }}
            >
              {muted ? <MicOff className="size-4" /> : <Mic className="size-4" />}
              {muted ? "Unmute" : "Mute"}
            </Button>
            <Button size="sm" variant="destructive" onClick={end}>
              <PhoneOff className="size-4" />
              End session
            </Button>
            <span className="inline-flex items-center gap-1 text-xs text-success">
              <Radio className="size-3.5" /> Live
            </span>
          </>
        ) : (
          <Button size="sm" onClick={() => void start()} disabled={status === "connecting"}>
            <Mic className="size-4" />
            {status === "connecting" ? "Connecting…" : "Start live session"}
          </Button>
        )}
      </div>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      <p className="text-xs text-muted-foreground">
        Gemini Live, voice to voice. Allow the microphone. Speak a Python question; wait for the reply.
        This is not a text-chat API with a fake voice — it uses Gemini's Live WebSocket.
      </p>
      {heard || said ? (
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-lg bg-secondary p-3 text-sm">
            <p className="mb-1 text-xs uppercase tracking-wider text-muted-foreground">You</p>
            <p className="whitespace-pre-wrap">{heard || "…"}</p>
          </div>
          <div className="rounded-lg bg-card p-3 text-sm shadow-[var(--shadow-border)]">
            <p className="mb-1 text-xs uppercase tracking-wider text-muted-foreground">PyDuke</p>
            <p className="whitespace-pre-wrap">{said || "…"}</p>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function openSocket(url: string, fallback: string): Promise<WebSocket> {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(url);
    let settled = false;
    ws.onopen = () => {
      settled = true;
      resolve(ws);
    };
    ws.onerror = () => {
      if (settled) return;
      const alt = new WebSocket(fallback);
      alt.onopen = () => resolve(alt);
      alt.onerror = () => reject(new Error("Could not open the Gemini Live socket."));
    };
  });
}

function floatTo16(input: Float32Array): Uint8Array {
  const buf = new ArrayBuffer(input.length * 2);
  const view = new DataView(buf);
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Uint8Array(buf);
}

function u8ToB64(bytes: Uint8Array): string {
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

function b64ToU8(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
