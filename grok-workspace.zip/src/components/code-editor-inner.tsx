import { python } from "@codemirror/lang-python";
import { EditorView, keymap } from "@codemirror/view";
import { Prec } from "@codemirror/state";
import CodeMirror from "@uiw/react-codemirror";
import { cn } from "@/lib/utils";

const helixTheme = EditorView.theme(
  {
    "&": {
      backgroundColor: "transparent",
      color: "#eee6d4",
      fontSize: "13.5px",
      height: "100%",
    },
    ".cm-content": {
      caretColor: "#c4a15a",
      fontFamily: "var(--font-mono)",
      padding: "12px 0",
    },
    ".cm-gutters": {
      backgroundColor: "transparent",
      color: "#8e8778",
      border: "none",
    },
    ".cm-activeLine": { backgroundColor: "rgba(196,161,90,0.08)" },
    ".cm-activeLineGutter": { backgroundColor: "transparent" },
    ".cm-selectionBackground, &.cm-focused .cm-selectionBackground": {
      backgroundColor: "rgba(196,161,90,0.28) !important",
    },
    ".cm-cursor": { borderLeftColor: "#c4a15a" },
    ".cm-line": { padding: "0 14px" },
  },
  { dark: true },
);

export function CodeEditorInner({
  value,
  onChange,
  onRun,
  className,
  minHeight = 220,
}: {
  value: string;
  onChange: (v: string) => void;
  onRun?: () => void;
  className?: string;
  minHeight?: number;
}) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-lg bg-code shadow-[var(--shadow-border)]",
        className,
      )}
      style={{ minHeight }}
    >
      <CodeMirror
        value={value}
        height="100%"
        minHeight={`${minHeight}px`}
        theme={helixTheme}
        extensions={[
          python(),
          Prec.highest(
            keymap.of([
              {
                key: "Mod-Enter",
                run: () => {
                  onRun?.();
                  return true;
                },
              },
            ]),
          ),
        ]}
        onChange={onChange}
        basicSetup={{
          foldGutter: false,
          highlightActiveLine: true,
          lineNumbers: true,
          tabSize: 4,
        }}
      />
    </div>
  );
}
