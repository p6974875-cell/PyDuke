import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { CodeBlock } from "@/components/code-block";
import { ExampleRunner } from "@/components/example-runner";
import { ExercisePanel } from "@/components/exercise-panel";
import { Progress } from "@/components/ui/progress";
import { LESSON_EXTRAS } from "@/lib/content/lesson-extras";
import { LESSONS } from "@/lib/content/lessons";
import { TOPICS, TOPIC_BY_ID } from "@/lib/content/topics";
import { GAME_UNLOCKS } from "@/lib/game-engine";
import { useHelix } from "@/lib/store";
import type { GameId, TopicId } from "@/lib/types";

export function LessonView({ topicId }: { topicId: TopicId }) {
  const lesson = LESSONS[topicId];
  const extra = LESSON_EXTRAS[topicId];
  const topic = TOPIC_BY_ID[topicId];
  const progress = useHelix((s) => s.topics[topicId]);
  const completeLesson = useHelix((s) => s.completeLesson);
  const [thinkOpen, setThinkOpen] = useState(false);
  const think = lesson.think ?? extra.think;
  const realWorld = lesson.realWorld ?? extra.realWorld;
  const review = lesson.review ?? extra.review;

  const required = useMemo(
    () => lesson.exercises.filter((e) => !e.optional),
    [lesson],
  );
  const doneCount = required.filter((e) => progress.completedExercises.includes(e.id)).length;
  const ready = doneCount >= Math.min(2, required.length) || required.length === 0;
  const next = TOPICS[TOPICS.findIndex((t) => t.id === topicId) + 1];
  const unlocks = (Object.entries(GAME_UNLOCKS) as [GameId, { topic: TopicId | null; label: string }][])
    .filter(([, v]) => v.topic === topicId)
    .map(([id]) => id);

  return (
    <article className="mx-auto max-w-3xl space-y-10">
      <header className="space-y-3 helix-enter">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
          Lesson {topic.number} · Level {topic.level} · {topic.subtitle}
        </p>
        <h1 className="font-display text-3xl font-medium tracking-tight sm:text-4xl">{topic.title}</h1>
        <p className="text-muted-foreground">{topic.blurb}</p>
        <div className="flex items-center gap-3">
          <Progress value={progress.score} className="max-w-xs" />
          <span className="text-xs tabular-nums text-muted-foreground">{progress.score}%</span>
        </div>
      </header>

      <section className="rounded-xl bg-secondary p-5 helix-enter helix-enter-delay-1">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">1. Introduction</p>
        <h2 className="mt-1 font-display text-xl font-medium">{lesson.revision.heading}</h2>
        <p className="mt-2 text-[15px] leading-relaxed text-muted-foreground">{lesson.revision.body}</p>
        {lesson.revision.code ? <CodeBlock code={lesson.revision.code} className="mt-4" /> : null}
      </section>

      <section className="space-y-3 helix-enter helix-enter-delay-2">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">2. Explanation</p>
        <h2 className="font-display text-xl font-medium">{lesson.concept.heading}</h2>
        <p className="text-[15px] leading-relaxed text-foreground/90">{lesson.concept.explanation}</p>
      </section>

      <section className="space-y-3">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">3. Standard terminology</p>
        <blockquote className="rounded-lg border-l-2 border-accent/50 bg-card py-3 pl-4 pr-4 text-sm text-muted-foreground">
          <span className="font-medium text-foreground">Definition. </span>
          {lesson.concept.definition}
        </blockquote>
      </section>

      <section className="space-y-2">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">4. Simple explanation</p>
        <p className="text-[15px] leading-relaxed text-muted-foreground">
          <span className="font-medium text-foreground">Analogy. </span>
          {lesson.concept.analogy}
        </p>
      </section>

      <section className="space-y-6">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">
            5–7. Examples, lines, expected output
          </p>
          <h2 className="font-display text-xl font-medium">Examples</h2>
        </div>
        {lesson.examples.map((ex, i) => (
          <ExampleRunner
            key={ex.title}
            title={ex.title}
            code={ex.code}
            why={ex.why}
            output={ex.output ?? extra.outputs[i]}
          />
        ))}
      </section>

      <section className="space-y-4">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">8. Common mistakes</p>
        <h2 className="font-display text-xl font-medium">Common mistakes</h2>
        <div className="space-y-3">
          {lesson.mistakes.map((m) => (
            <div key={m.wrong} className="grid gap-2 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] sm:grid-cols-2">
              <div>
                <p className="mb-1 text-xs uppercase tracking-wider text-destructive">Avoid</p>
                <CodeBlock code={m.wrong} />
              </div>
              <div>
                <p className="mb-1 text-xs uppercase tracking-wider text-success">Prefer</p>
                <CodeBlock code={m.right} />
              </div>
              <p className="text-sm text-muted-foreground sm:col-span-2">{m.why}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="space-y-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">9. Real-world example</p>
        <h2 className="font-display text-xl font-medium">{realWorld.heading}</h2>
        <p className="text-[15px] leading-relaxed text-muted-foreground">{realWorld.body}</p>
        {realWorld.code ? <CodeBlock code={realWorld.code} className="mt-3" /> : null}
      </section>

      {think ? (
        <section className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">10. Practice task</p>
          <h2 className="font-display text-xl font-medium">Pause and think</h2>
          <p className="mt-2 text-[15px]">{think.question}</p>
          <Button variant="ghost" size="sm" className="mt-3" onClick={() => setThinkOpen((v) => !v)}>
            {thinkOpen ? "Hide" : "Reveal"}
          </Button>
          {thinkOpen ? (
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{think.answer}</p>
          ) : null}
        </section>
      ) : null}

      <section className="space-y-4">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">11. Interactive coding</p>
          <h2 className="font-display text-xl font-medium">Write it</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Mini exercise, then a practical one. Optional items are marked harder. Run & check grades
            against real Python output.
          </p>
        </div>
        {lesson.exercises.map((ex) => (
          <ExercisePanel key={ex.id} exercise={ex} topicId={topicId} />
        ))}
      </section>

      <section className="rounded-xl bg-secondary p-5">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">12. Short review</p>
        <h2 className="font-display text-xl font-medium">Take with you</h2>
        <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
          {review.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
      </section>

      <footer className="flex flex-wrap items-center gap-3 border-t border-border pt-6">
        <p className="w-full text-xs uppercase tracking-wider text-muted-foreground">13. Completion</p>
        <Button
          disabled={!ready || progress.status === "mastered"}
          onClick={() => {
            completeLesson(topicId);
            toast("Lesson marked complete");
          }}
        >
          <Check className="size-4" />
          {progress.status === "mastered" ? "Mastered" : "Mark lesson complete"}
        </Button>
        {next && progress.status === "mastered" ? (
          <Button variant="secondary" asChild>
            <Link to="/learn/$topicId" params={{ topicId: next.id }}>
              Next: {next.title}
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        ) : next ? (
          <p className="text-xs text-muted-foreground">Mark this lesson complete to unlock {next.title}.</p>
        ) : null}
        {!ready ? (
          <p className="text-xs text-muted-foreground">Complete at least two required exercises to finish.</p>
        ) : null}
        {unlocks.length > 0 && progress.status === "mastered" ? (
          <p className="w-full text-sm text-muted-foreground">
            Unlocked game
            {unlocks.length > 1 ? "s" : ""}:{" "}
            {unlocks.map((id) => (
              <Link key={id} to="/games/$gameId" params={{ gameId: id }} className="mr-2 underline">
                {id}
              </Link>
            ))}
          </p>
        ) : null}
      </footer>
    </article>
  );
}
