import { Badge } from "@/components/ui/badge";
import type { Difficulty } from "@/lib/types";

const map = {
  easy: { variant: "easy" as const, label: "Easy" },
  medium: { variant: "medium" as const, label: "Medium" },
  hard: { variant: "hard" as const, label: "Hard" },
  advanced: { variant: "advanced" as const, label: "Advanced" },
};

export function DifficultyBadge({ value }: { value: Difficulty }) {
  const m = map[value];
  return <Badge variant={m.variant}>{m.label}</Badge>;
}
