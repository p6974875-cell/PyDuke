import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Phone, PhoneOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { createLiveSession } from "@/lib/live-session";
import { GeminiLiveSession, type LiveStatus } from "@/lib/live-client";
import { progressSummary, useHelix } from "@/lib/store";

type Line = { who: "you" | "tutor"; text: string };

export function LiveTutor() {
  const [status, setStatus] = useState<LiveStatus>("idle");
  const [detail, setDetail] = useState("");
  const [muted, setMuted] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [lines, setLines] = useState<Line[]>([]);
  const session = useRef<GeminiLiveSession | null>(null);

  useEffect(() => {
    return () => session.current?.stop();
  }, []);

  async function start() {
    if (status === "connecting" || status === "live") return;
    setDetail("");
    setLines([]);
    setStatus("connecting");
    try {
      const minted = await createLiveSession();
      if (!minted.ok) {
        setStatus("error");
        setDetail(
          minted.error === "missing-key"
            ? "Live Tutor needs GEMINI_API_KEY in the server .env. The key stays on the server — PyDuke only mints a short-lived session token."
            : "Gemini Live could not start. Check GEMINI_API_KEY and GEMINI_LIVE_MODEL, then try again.",
        );
        return;
      }
      const snap = progressSummary(useHelix.getState());
      const live = new GeminiLiveSession(
        {
          onStatus: (s, d) => {
            setStatus(s);
            if (d) setDetail(d);
          },
          onTranscript: (who, text) => {
            setLines((prev) => {
              const last = prev[prev.length - 1];
              if (last && last.who === who) {
                return [...prev.slice(0, -1), { who, text: last.text + text }];
              }
              return [...prev, { who, text }];
            });
          },
          onSpeaking: setSpeaking,
        },
        `You are PyDuke, a live spoken Python tutor. Answer any Python question — beginner or advanced. Keep answers short enough to say aloud. Hint before giving full solutions. Current progress:\n${snap}`,
        minted.model,
      );
      session.current = live;
      await live.start(minted.wsUrl);
    } catch (err) {
      const name = err instanceof DOMException ? err.name : "";
      setStatus("error");
      if (name === "NotAllowedError" || name === "PermissionDeniedError") {
        setDetail(
          "Microphone permission was denied. Allow the mic for this site, then tap Start live session again.",
        );
      } else if (name === "NotFoundError") {
        setDetail("No microphone was found on this device.");
      } else {
        setDetail("Could not open a live session. Check your connection and try again.");
      }
    }
  }

  function end() {
    session.current?.stop();
    session.current = null;
    setSpeaking(false);
    setStatus("ended");
  }

  function toggleMute() {
    const next = !muted;
    setMuted(next);
    session.current?.setMuted(next);
  }

  return (
    <div className="space-y-5">
      <div className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <p className="text-sm text-muted-foreground">
          This is Gemini Live — a realtime voice session, not a text chat read aloud. PyDuke mints
          a short-lived token on the server. Your API key never enters the browser.
        </p>
        <p className="mt-3 text-xs uppercase tracking-wider text-muted-foreground">
          {statusLabel(status, speaking, muted)}
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          {status === "live" || status === "connecting" ? (
            <>
              <Button type="button" variant="secondary" onClick={toggleMute} disabled={status !== "live"}>
                {muted ? <MicOff className="size-4" /> : <Mic className="size-4" />}
                {muted ? "Unmute" : "Mute"}
              </Button>
              <Button type="button" variant="destructive" onClick={end}>
                <PhoneOff className="size-4" />
                End session
              </Button>
            </>
          ) : (
            <Button type="button" onClick={() => void start()}>
              <Phone className="size-4" />
              Start live session
            </Button>
          )}
        </div>
        {detail ? <p className="mt-4 text-sm text-destructive">{detail}</p> : null}
      </div>
      {lines.length > 0 ? (
        <div className="space-y-2">
          {lines.map((line, i) => (
            <p
              key={`${line.who}-${i}`}
              className={
                line.who === "you"
                  ? "rounded-lg bg-secondary px-3 py-2 text-sm"
                  : "rounded-lg bg-card px-3 py-2 text-sm shadow-[var(--shadow-border)]"
              }
            >
              <span className="mr-2 text-xs uppercase tracking-wider text-muted-foreground">
                {line.who === "you" ? "You" : "PyDuke"}
              </span>
              {line.text}
            </p>
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">
          After you start, speak a Python question. The tutor answers in voice. You can mute or end
          at any time.
        </p>
      )}
    </div>
  );
}

function statusLabel(status: LiveStatus, speaking: boolean, muted: boolean) {
  if (status === "connecting") return "Connecting to Gemini Live…";
  if (status === "live" && muted) return "Muted — tap unmute to keep talking";
  if (status === "live" && speaking) return "PyDuke is speaking";
  if (status === "live") return "Listening";
  if (status === "error") return "Session failed";
  if (status === "ended") return "Session ended";
  return "Idle";
}
