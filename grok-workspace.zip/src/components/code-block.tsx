import { cn } from "@/lib/utils";

const KEYWORDS = new Set([
  "False",
  "None",
  "True",
  "and",
  "as",
  "assert",
  "async",
  "await",
  "break",
  "class",
  "continue",
  "def",
  "del",
  "elif",
  "else",
  "except",
  "finally",
  "for",
  "from",
  "global",
  "if",
  "import",
  "in",
  "is",
  "lambda",
  "nonlocal",
  "not",
  "or",
  "pass",
  "raise",
  "return",
  "try",
  "while",
  "with",
  "yield",
]);

function escapeHtml(s: string) {
  return s.replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">");
}

const TOKEN =
  /(#.*)|("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|(\b[A-Za-z_]\w*\b)|(\b\d+(?:\.\d+)?\b)|(\s+)|(.)/g;

export function highlightPython(code: string) {
  let html = "";
  const src = code.replace(/\n$/, "");
  for (const match of src.matchAll(TOKEN)) {
    const [raw, comment, str, ident, num] = match;
    if (comment) html += `<span class="text-muted-foreground">${escapeHtml(comment)}</span>`;
    else if (str) html += `<span class="text-accent">${escapeHtml(str)}</span>`;
    else if (ident && KEYWORDS.has(ident)) html += `<span class="text-success">${ident}</span>`;
    else if (num) html += `<span class="text-warning">${num}</span>`;
    else html += escapeHtml(raw);
  }
  return html;
}

export function CodeBlock({
  code,
  className,
}: {
  code: string;
  className?: string;
}) {
  return (
    <pre
      className={cn(
        "overflow-x-auto rounded-lg bg-code p-4 text-xs leading-relaxed text-foreground shadow-[var(--shadow-border)]",
        className,
      )}
    >
      <code className="font-mono" dangerouslySetInnerHTML={{ __html: highlightPython(code) }} />
    </pre>
  );
}
