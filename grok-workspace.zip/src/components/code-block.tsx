import { useState } from "react";
import { Play } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { runPython } from "@/lib/python-engine";

const KEYWORDS =
  /\b(False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b/g;

export function highlightPython(code: string) {
  const escaped = code
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">");
  return escaped
    .replace(/(#.*)$/gm, '<span class="text-muted-foreground">$1</span>')
    .replace(
      /(".*?"|'.*?'|".*?"|'.*?')/g,
      '<span class="text-accent">$1</span>',
    )
    .replace(KEYWORDS, '<span class="text-success">$1</span>')
    .replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="text-warning">$1</span>');
}

export function CodeBlock({
  code,
  className,
  runnable,
}: {
  code: string;
  className?: string;
  runnable?: boolean;
}) {
  const [out, setOut] = useState<string | null>(null);
  const [running, setRunning] = useState(false);

  return (
    <div className={className}>
      <pre className="overflow-x-auto rounded-lg bg-code p-4 font-mono text-sm leading-relaxed text-foreground shadow-[var(--shadow-border)]">
        <code dangerouslySetInnerHTML={{ __html: highlightPython(code) }} />
      </pre>
      {runnable ? (
        <div className="mt-2 space-y-2">
          <Button
            size="sm"
            variant="secondary"
            disabled={running}
            onClick={async () => {
              setRunning(true);
              try {
                const r = await runPython(code);
                setOut(r.error || r.stdout || "(no output)");
              } finally {
                setRunning(false);
              }
            }}
          >
            <Play className="size-4" />
            Run example
          </Button>
          {out ? <p className="whitespace-pre-wrap font-mono text-sm text-muted-foreground">{out}</p> : null}
        </div>
      ) : null}
    </div>
  );
}
