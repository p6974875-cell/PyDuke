import { useState } from "react";
import { Eye, Lightbulb, Play } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { CodeEditor } from "@/components/code-editor";
import { PythonOutput } from "@/components/python-output";
import { DifficultyBadge } from "@/components/difficulty-badge";
import { gradeCode } from "@/lib/grade";
import type { RunResult } from "@/lib/python-engine";
import type { Exercise } from "@/lib/types";
import type { TopicId } from "@/lib/types";
import { useHelix } from "@/lib/store";

export function ExercisePanel({
  exercise,
  topicId,
}: {
  exercise: Exercise;
  topicId: TopicId;
}) {
  const [code, setCode] = useState(exercise.starter);
  const [result, setResult] = useState<RunResult | null>(null);
  const [message, setMessage] = useState("");
  const [passed, setPassed] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [showSolution, setShowSolution] = useState(false);
  const [running, setRunning] = useState(false);
  const recordExercise = useHelix((s) => s.recordExercise);

  async function submit() {
    setRunning(true);
    try {
      const g = await gradeCode(code, exercise.checks);
      setResult(g.run);
      setMessage(g.message);
      setAttempted(true);
      setPassed(g.passed);
      recordExercise({
        topicId,
        exerciseId: exercise.id,
        ok: g.passed,
        difficulty: exercise.difficulty,
        note: g.passed ? undefined : g.message.slice(0, 180),
      });
      if (g.passed) toast(`+XP · ${exercise.title}`);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-4 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] sm:p-5">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h3 className="font-display text-lg font-medium">{exercise.title}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{exercise.prompt}</p>
        </div>
        <DifficultyBadge value={exercise.difficulty} />
      </div>
      <CodeEditor value={code} onChange={setCode} onRun={submit} minHeight={180} />
      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={submit} disabled={running}>
          <Play className="size-4" />
          {running ? "Checking" : "Run & check"}
        </Button>
        {exercise.hint ? (
          <Button size="sm" variant="ghost" onClick={() => setShowHint((v) => !v)}>
            <Lightbulb className="size-4" />
            Hint
          </Button>
        ) : null}
        <Button
          size="sm"
          variant="ghost"
          onClick={() => {
            setCode(exercise.starter);
            setResult(null);
            setMessage("");
            setPassed(false);
            setShowSolution(false);
          }}
        >
          Reset
        </Button>
        <Button
          size="sm"
          variant="ghost"
          disabled={!attempted}
          onClick={() => setShowSolution(true)}
        >
          <Eye className="size-4" />
          Compare
        </Button>
      </div>
      {showHint && exercise.hint ? (
        <p className="text-sm text-muted-foreground">{exercise.hint}</p>
      ) : null}
      {message ? (
        <p className={passed ? "text-sm text-success" : "text-sm text-destructive"}>{message}</p>
      ) : null}
      <PythonOutput result={result} code={code} />
      {showSolution ? (
        <div className="space-y-2 rounded-lg bg-secondary p-4">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            After your attempt
          </p>
          <pre className="overflow-x-auto font-mono text-[13px] text-foreground">{exercise.solution}</pre>
          <p className="text-sm leading-relaxed text-muted-foreground">{exercise.explanation}</p>
        </div>
      ) : !attempted ? (
        <p className="text-xs text-muted-foreground">
          Write it first. Compare unlocks after you run a check.
        </p>
      ) : null}
    </div>
  );
}
