import { useState } from "react";
import { Play } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { CodeEditor } from "@/components/code-editor";
import { Input } from "@/components/ui/input";
import { PythonOutput } from "@/components/python-output";
import { CodeBlock } from "@/components/code-block";
import { gradeCode } from "@/lib/grade";
import { outputsMatch, type RunResult } from "@/lib/python-engine";
import type { GameItem } from "@/lib/types";

export function FixCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [code, setCode] = useState(item.starter ?? "");
  const [result, setResult] = useState<RunResult | null>(null);
  const [msg, setMsg] = useState("");
  const [ok, setOk] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const [show, setShow] = useState(false);
  const [running, setRunning] = useState(false);

  async function run() {
    setRunning(true);
    try {
      const g = await gradeCode(code, item.checks ?? []);
      setResult(g.run);
      setMsg(g.message);
      setOk(g.passed);
      setAttempted(true);
      onResult(g.passed);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-3">
      <CodeEditor value={code} onChange={setCode} onRun={run} minHeight={200} />
      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={() => void run()} disabled={running}>
          <Play className="size-4" />
          Check
        </Button>
        <Button size="sm" variant="ghost" disabled={!attempted} onClick={() => setShow(true)}>
          Compare
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => {
            setCode(item.starter ?? "");
            setResult(null);
            setMsg("");
            setOk(false);
            setShow(false);
          }}
        >
          Reset
        </Button>
      </div>
      {msg ? <p className={ok ? "text-sm text-success" : "text-sm text-destructive"}>{msg}</p> : null}
      <PythonOutput result={result} code={code} />
      {show && item.solution ? (
        <div className="rounded-lg bg-secondary p-4">
          <CodeBlock code={item.solution} />
          <p className="mt-2 text-sm text-muted-foreground">{item.explanation}</p>
        </div>
      ) : null}
    </div>
  );
}

export function PredictCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [guess, setGuess] = useState("");
  const [revealed, setRevealed] = useState(false);
  const correct = outputsMatch(guess, item.expected ?? "");

  return (
    <div className="space-y-3">
      <CodeBlock code={item.code ?? ""} />
      <Input
        value={guess}
        onChange={(e) => setGuess(e.target.value)}
        placeholder="What does it print?"
        disabled={revealed}
        className="h-11"
      />
      <Button
        size="sm"
        disabled={revealed || !guess.trim()}
        onClick={() => {
          setRevealed(true);
          onResult(correct);
          if (!correct) toast("Not the output — read the explanation and try the next one.");
        }}
      >
        Check prediction
      </Button>
      {revealed ? (
        <div className="space-y-2 rounded-lg bg-secondary p-4 text-sm">
          <p className={correct ? "text-success" : "text-destructive"}>
            {correct ? "Your prediction matched." : "Not quite."}
          </p>
          <p className="font-mono text-foreground">Actual: {item.expected}</p>
          <p className="text-muted-foreground">{item.explanation}</p>
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">Predict before you see the output.</p>
      )}
    </div>
  );
}

export function OrderCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [lines, setLines] = useState(() => shuffle(item.lines ?? []));
  const [result, setResult] = useState<RunResult | null>(null);
  const [ok, setOk] = useState(false);
  const [show, setShow] = useState(false);
  const [running, setRunning] = useState(false);

  function move(i: number, dir: -1 | 1) {
    const j = i + dir;
    if (j < 0 || j >= lines.length) return;
    const next = lines.slice();
    [next[i], next[j]] = [next[j], next[i]];
    setLines(next);
    setOk(false);
  }

  async function check() {
    setRunning(true);
    try {
      const g = await gradeCode(lines.join("\n"), [{ kind: "stdout", expected: item.expected }]);
      setResult(g.run);
      setOk(g.passed);
      onResult(g.passed);
      if (g.passed) setShow(true);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-3">
      <ul className="space-y-2">
        {lines.map((line, i) => (
          <li key={`${line}-${i}`} className="flex items-center gap-2 rounded-lg bg-code px-3 py-2 font-mono text-sm">
            <div className="flex flex-col">
              <button
                type="button"
                className="flex size-11 items-center justify-center text-muted-foreground"
                onClick={() => move(i, -1)}
                aria-label="Move up"
              >
                ↑
              </button>
              <button
                type="button"
                className="flex size-11 items-center justify-center text-muted-foreground"
                onClick={() => move(i, 1)}
                aria-label="Move down"
              >
                ↓
              </button>
            </div>
            <span className="whitespace-pre">{line}</span>
          </li>
        ))}
      </ul>
      <Button size="sm" onClick={() => void check()} disabled={running}>
        Run in order
      </Button>
      {ok ? <p className="text-sm text-success">That order works.</p> : null}
      <PythonOutput result={result} code={lines.join("\n")} />
      {show ? <p className="text-sm text-muted-foreground">{item.explanation}</p> : null}
    </div>
  );
}

export function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
