import { useEffect, useState } from "react";
import { Play, RotateCcw, Save } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CodeEditor } from "@/components/code-editor";
import { PythonOutput } from "@/components/python-output";
import { runPython, warmupPython, type RunResult } from "@/lib/python-engine";
import { useHelix } from "@/lib/store";

const DEFAULT = `# PyDuke playground
# Ctrl/⌘ + Enter to run. Isolated Python — no OS, no network.

names = ["Ada", "Lin"]
print("hello", ", ".join(names))
`;

export function Playground({
  initial,
  onResult,
}: {
  initial?: string;
  onResult?: (r: RunResult) => void;
}) {
  const [code, setCode] = useState(initial ?? DEFAULT);
  const [stdin, setStdin] = useState("");
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<RunResult | null>(null);
  const [engine, setEngine] = useState<"loading" | "ready" | "error">("loading");
  const [title, setTitle] = useState("");
  const saveSnippet = useHelix((s) => s.saveSnippet);

  useEffect(() => {
    warmupPython()
      .then(() => setEngine("ready"))
      .catch(() => setEngine("error"));
  }, []);

  async function run() {
    setRunning(true);
    try {
      const r = await runPython(code, stdin);
      setResult(r);
      onResult?.(r);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
      <div className="flex min-w-0 flex-col gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <Button size="sm" onClick={run} disabled={running || engine !== "ready"}>
            <Play className="size-4" />
            {running ? "Running" : "Run"}
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => {
              setCode(initial ?? DEFAULT);
              setResult(null);
            }}
          >
            <RotateCcw className="size-4" />
            Reset
          </Button>
          <div className="ml-auto flex min-w-0 items-center gap-2">
            <Input
              placeholder="Save as…"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="h-9 w-36"
            />
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                saveSnippet(title, code);
                toast("Saved to your notebook");
                setTitle("");
              }}
            >
              <Save className="size-4" />
              Save
            </Button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">
          {engine === "loading"
            ? "Loading the Python runtime (first visit only)…"
            : engine === "error"
              ? "Could not load Python. Check your connection and retry."
              : "Sandbox ready. No files leave this browser."}
        </p>
        <CodeEditor value={code} onChange={setCode} onRun={run} minHeight={280} className="flex-1" />
        <div className="space-y-1.5">
          <Label htmlFor="stdin" className="text-xs text-muted-foreground">
            Standard input for input()
          </Label>
          <Input
            id="stdin"
            value={stdin}
            onChange={(e) => setStdin(e.target.value)}
            placeholder="Lines the program can read"
          />
        </div>
      </div>
      <PythonOutput result={result} code={code} />
    </div>
  );
}
