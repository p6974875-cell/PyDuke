import { useState } from "react";
import { Eye, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CodeBlock } from "@/components/code-block";
import { PythonOutput } from "@/components/python-output";
import { runPython, type RunResult } from "@/lib/python-engine";

export function ExampleRunner({
  title,
  code,
  why,
  output,
}: {
  title: string;
  code: string;
  why: string;
  output?: string;
}) {
  const [result, setResult] = useState<RunResult | null>(null);
  const [running, setRunning] = useState(false);
  const [showExpected, setShowExpected] = useState(false);

  return (
    <div className="space-y-2">
      <h3 className="text-sm font-medium">{title}</h3>
      <CodeBlock code={code} />
      <div className="flex flex-wrap gap-2">
        <Button
          size="sm"
          variant="secondary"
          disabled={running}
          onClick={async () => {
            setRunning(true);
            try {
              setResult(await runPython(code));
            } finally {
              setRunning(false);
            }
          }}
        >
          <Play className="size-4" />
          Run example
        </Button>
        {output ? (
          <Button size="sm" variant="ghost" onClick={() => setShowExpected(true)}>
            <Eye className="size-4" />
            Expected output
          </Button>
        ) : null}
      </div>
      {showExpected && output ? (
        <pre className="overflow-x-auto rounded-lg bg-code px-4 py-3 font-mono text-[13px]">{output}</pre>
      ) : null}
      {result ? <PythonOutput result={result} code={code} /> : null}
      <p className="text-sm leading-relaxed text-muted-foreground">
        <span className="text-foreground">Why this works. </span>
        {why}
      </p>
    </div>
  );
}
