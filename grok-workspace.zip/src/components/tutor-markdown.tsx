import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { cn } from "@/lib/utils";

export function TutorMarkdown({ text }: { text: string }) {
  const parts = text.split(/```/);
  return (
    <div className="space-y-2">
      {parts.map((part, i) => {
        if (i % 2 === 1) {
          const nl = part.indexOf("\n");
          const lang = nl === -1 ? "" : part.slice(0, nl).trim();
          const code = nl === -1 ? part : part.slice(nl + 1).replace(/\n$/, "");
          return <CopyBlock key={i} code={code} lang={lang} />;
        }
        return (
          <p key={i} className="whitespace-pre-wrap leading-relaxed">
            {part}
          </p>
        );
      })}
    </div>
  );
}

function CopyBlock({ code, lang }: { code: string; lang: string }) {
  const [ok, setOk] = useState(false);
  return (
    <div className="overflow-hidden rounded-lg bg-code shadow-[var(--shadow-border)]">
      <div className="flex items-center justify-between px-3 py-1.5 text-xs text-muted-foreground">
        <span>{lang || "code"}</span>
        <button
          type="button"
          className={cn("inline-flex items-center gap-1 hover:text-foreground")}
          onClick={async () => {
            await navigator.clipboard.writeText(code);
            setOk(true);
            window.setTimeout(() => setOk(false), 1200);
          }}
        >
          {ok ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
          {ok ? "Copied" : "Copy"}
        </button>
      </div>
      <pre className="overflow-x-auto px-3 pb-3 font-mono text-xs leading-relaxed">{code}</pre>
    </div>
  );
}
