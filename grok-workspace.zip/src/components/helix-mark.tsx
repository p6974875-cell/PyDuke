import { cn } from "@/lib/utils";

export function PyDukeMark({ className }: { className?: string }) {
  return (
    <img
      src="/pyduke-mark.png"
      alt=""
      className={cn("object-contain", className)}
    />
  );
}

export function HelixMark(props: { className?: string }) {
  return <PyDukeMark {...props} />;
}
