import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useHelix } from "@/lib/store";
import type { TypingDrill } from "@/lib/types";

export function TypingArena({ drills }: { drills: TypingDrill[] }) {
  const [idx, setIdx] = useState(0);
  const drill = drills[idx] ?? drills[0];
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {drills.map((d, i) => (
          <button
            key={d.id}
            type="button"
            onClick={() => setIdx(i)}
            className={cn(
              "h-11 rounded-md px-3 text-xs",
              i === idx ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
            )}
          >
            {d.title}
          </button>
        ))}
      </div>
      {drill ? <TypingRound key={drill.id} drill={drill} /> : null}
    </div>
  );
}

function TypingRound({ drill }: { drill: TypingDrill }) {
  const target = drill.code;
  const [pos, setPos] = useState(0);
  const [errors, setErrors] = useState(0);
  const [started, setStarted] = useState<number | null>(null);
  const [doneAt, setDoneAt] = useState<number | null>(null);
  const [wrong, setWrong] = useState(false);
  const record = useHelix((s) => s.recordTyping);
  const typingHistory = useHelix((s) => s.typingHistory);
  const history = useMemo(
    () => typingHistory.filter((h) => h.drillId === drill.id),
    [typingHistory, drill.id],
  );

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (doneAt) return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === "Tab") {
        e.preventDefault();
        feed("    ");
        return;
      }
      if (e.key === "Enter") {
        e.preventDefault();
        feed("\n");
        return;
      }
      if (e.key.length === 1) {
        e.preventDefault();
        feed(e.key);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function feed(chunk: string) {
    if (doneAt) return;
    const start = started ?? Date.now();
    if (!started) setStarted(start);
    let p = pos;
    let err = errors;
    for (const ch of chunk) {
      if (p >= target.length) break;
      if (target[p] === ch) {
        p += 1;
      } else {
        err += 1;
        setWrong(true);
        window.setTimeout(() => setWrong(false), 120);
        break;
      }
    }
    setPos(p);
    setErrors(err);
    if (p >= target.length) {
      const end = Date.now();
      setDoneAt(end);
      const minutes = Math.max(0.01, (end - start) / 60000);
      const chars = target.length;
      const cpm = Math.round(chars / minutes);
      const wpm = Math.round(chars / 5 / minutes);
      const accuracy = Math.round((chars / (chars + err)) * 1000) / 10;
      record({ at: end, wpm, cpm, accuracy, errors: err, chars, drillId: drill.id });
    }
  }

  const elapsed = (doneAt ?? (started ? Date.now() : 0)) - (started ?? 0);
  const minutes = Math.max(0.01, elapsed / 60000);
  const liveWpm = started ? Math.round(pos / 5 / minutes) : 0;
  const acc = pos + errors === 0 ? 100 : Math.round((pos / (pos + errors)) * 1000) / 10;

  const best = useMemo(() => {
    if (!history.length) return null;
    return history.reduce((a, b) => (a.accuracy === b.accuracy ? (a.wpm > b.wpm ? a : b) : a.accuracy > b.accuracy ? a : b));
  }, [history]);

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Focus: {drill.focus}. Type the snippet exactly. Wrong keys count; the cursor does not skip.
        Accuracy is the score. Speed is only useful once you are precise.
      </p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Metric label="WPM" value={started ? String(liveWpm) : "—"} />
        <Metric label="Accuracy" value={`${acc}%`} />
        <Metric label="Errors" value={String(errors)} />
        <Metric label="Best acc" value={best ? `${best.accuracy}% · ${best.wpm} wpm` : "—"} />
      </div>
      <pre
        className={cn(
          "overflow-x-auto whitespace-pre-wrap rounded-xl bg-code p-4 font-mono text-[13px] leading-relaxed sm:p-5",
          wrong && "shadow-[0_0_0_1px_var(--color-destructive)]",
        )}
        tabIndex={0}
      >
        {target.split("").map((ch, i) => (
          <span
            key={i}
            className={cn(
              i < pos && "text-success",
              i === pos && "bg-accent text-accent-foreground",
              i > pos && "text-muted-foreground",
            )}
          >
            {ch === "\n" ? "↵\n" : ch === " " && i === pos ? "·" : ch}
          </span>
        ))}
      </pre>
      <div className="flex flex-wrap gap-2">
        <Button
          variant="secondary"
          size="sm"
          onClick={() => {
            setPos(0);
            setErrors(0);
            setStarted(null);
            setDoneAt(null);
          }}
        >
          Restart
        </Button>
        {doneAt ? (
          <p className="self-center text-sm text-success">
            Logged. {acc < 95 ? "Stay with accuracy before chasing WPM." : "Clean run."}
          </p>
        ) : (
          <p className="self-center text-xs text-muted-foreground">Click the snippet, then type. Tab inserts four spaces.</p>
        )}
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-card px-3 py-2 shadow-[var(--shadow-border)]">
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className="font-mono text-sm tabular-nums">{value}</p>
    </div>
  );
}
