import { createServerFn } from "@tanstack/react-start";
import { geminiGenerate } from "@/lib/gemini.server";
import { env } from "@/lib/env.server";

type Msg = { role: "user" | "assistant" | "system"; content: string };

export const askTutor = createServerFn({ method: "POST" })
  .validator(
    (input: { messages: Msg[]; progressSummary: string; context?: string }) => input,
  )
  .handler(async ({ data }) => {
    const system = `You are PyDuke, a Python teacher in a learning app.

Teaching:
- Answer ANY Python question — beginner through advanced (classes, recursion, decorators, async, generators, memory, typing, metaclasses). Never refuse a topic because it is "ahead of the current lesson".
- Current lesson context is background only. If they ask about something else, teach that.
- For a concept: definition, simple explanation, a short code example, expected output, one common mistake.
- For exercise help: hint first, then a stronger hint, then a worked explanation if they ask to see it.
- Never execute OS or network calls. Never claim their code works unless they pasted a successful run.
- Stay on Python and programming. Short, clear replies. Use fenced Python code.

Learner progress (context, not a fence):
${data.progressSummary.slice(0, 1800)}
${data.context ? `\nWorkspace context:\n${data.context.slice(0, 1500)}` : ""}`;

    const gemini = await geminiGenerate({ system, messages: data.messages.slice(-8) });
    if (gemini.ok) return gemini;

    const xaiKey = env("XAI_API_KEY");
    if (xaiKey && gemini.error === "missing-key") {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${xaiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.4,
          max_tokens: 700,
          messages: [
            { role: "system", content: system },
            ...data.messages.slice(-8).map((m) => ({
              role: m.role,
              content: m.content.slice(0, 4000),
            })),
          ],
        }),
      });
      if (res.ok) {
        const body = (await res.json()) as { choices: { message: { content: string } }[] };
        const text = body.choices[0]?.message.content ?? "";
        if (text.trim()) return { ok: true as const, text };
      }
    }

    return { ok: false as const, error: gemini.error };
  });

export const tutorStatus = createServerFn({ method: "GET" }).handler(async () => {
  return {
    gemini: Boolean(env("GEMINI_API_KEY")),
    live: Boolean(env("GEMINI_API_KEY")),
    model: env("GEMINI_MODEL") || "gemini-flash-latest",
    liveModel: env("GEMINI_LIVE_MODEL") || "gemini-3.8-live",
  };
});
