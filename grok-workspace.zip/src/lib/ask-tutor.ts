import { createServerFn } from "@tanstack/react-start";
import { generateGeminiText } from "@/lib/gemini.server";

type Msg = { role: "user" | "assistant" | "system"; content: string };

const SYSTEM_PROMPT_HEADER = `You are PyDuke, a personal Python tutor.

Teaching rules:
- Use standard terms (mutable, iterable, hashable, suite, binding) and define them once.
- Prefer short examples the learner can type.
- Match the learner's current topic from the progress summary. Do not skip ahead.
- For exercises: hint first. If they say they are still stuck, give a stronger hint. Only show a full solution if they already attempted it or explicitly ask "show me".
- Never claim their code works unless they pasted a passing result.
- Never execute OS/network access or invent runtime output you did not see.
- If they paste an error, walk the exception type, then the fix.`;

export const askTutor = createServerFn({ method: "POST" })
  .validator(
    (input: {
      messages: Msg[];
      progressSummary: string;
      currentLesson?: string;
      currentExercise?: string;
      submittedCode?: string;
      lastError?: string;
      difficulty?: string;
    }) => input,
  )
  .handler(async ({ data }) => {
    const extra = [
      data.currentLesson ? `Current lesson: ${data.currentLesson}` : "",
      data.currentExercise ? `Current exercise: ${data.currentExercise}` : "",
      data.difficulty ? `Preferred difficulty: ${data.difficulty}` : "",
      data.submittedCode ? `Submitted code:\n${data.submittedCode.slice(0, 2500)}` : "",
      data.lastError ? `Last error:\n${data.lastError.slice(0, 800)}` : "",
    ]
      .filter(Boolean)
      .join("\n");

    const system = `${SYSTEM_PROMPT_HEADER}\n\nLearner progress:\n${data.progressSummary.slice(0, 1800)}${extra ? `\n\nContext:\n${extra}` : ""}`;
    const trimmed = data.messages
      .filter((m) => m.role !== "system")
      .slice(-8)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 4000) }));

    const gemini = await generateGeminiText({ system, messages: trimmed });
    if (gemini.ok) return { ok: true as const, text: gemini.text, provider: "gemini" as const };

    const xaiKey = process.env.XAI_API_KEY;
    if ((gemini.error === "unavailable" || gemini.error === "empty") && xaiKey) {
      const xai = await askXai(xaiKey, system, trimmed);
      if (xai.ok) return { ...xai, provider: "xai" as const };
      return xai;
    }

    if (xaiKey && gemini.error === "unavailable") {
      const xai = await askXai(xaiKey, system, trimmed);
      if (xai.ok) return { ...xai, provider: "xai" as const };
    }

    if (gemini.error === "unavailable") {
      return { ok: false as const, error: "unavailable" };
    }
    return { ok: false as const, error: gemini.error };
  });

async function askXai(apiKey: string, system: string, trimmed: { role: string; content: string }[]) {
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      temperature: 0.4,
      max_tokens: 700,
      messages: [{ role: "system", content: system }, ...trimmed],
    }),
  });
  if (!res.ok) {
    return { ok: false as const, error: `xAI API error ${res.status}` };
  }
  const body = (await res.json()) as {
    choices: { message: { content: string } }[];
  };
  return { ok: true as const, text: body.choices[0]?.message.content ?? "" };
}
