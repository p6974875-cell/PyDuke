import { DEBUG, FIXER, PREDICT } from "@/lib/content/games";
import { LESSONS } from "@/lib/content/lessons";
import { TYPING_DRILLS } from "@/lib/content/typing";
import type { Exercise, GameItem, TopicId, TypingDrill } from "@/lib/types";

export interface DailyPack {
  date: string;
  predicts: GameItem[];
  debug: GameItem;
  exercise: Exercise;
  typing: TypingDrill;
}

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function pick<T>(list: T[], seed: number, offset: number): T {
  return list[(seed + offset) % list.length]!;
}

export function dailyKey(d = new Date()) {
  return d.toISOString().slice(0, 10);
}

export function dailyPack(date: string, topicId: TopicId): DailyPack {
  const seed = hash(date);
  const lesson = LESSONS[topicId] ?? LESSONS.lists;
  const exercises = lesson.exercises.length ? lesson.exercises : LESSONS.lists.exercises;
  return {
    date,
    predicts: [pick(PREDICT, seed, 0), pick(PREDICT, seed, 3)].filter(
      (p, i, arr) => arr.findIndex((x) => x.id === p.id) === i,
    ),
    debug: pick([...DEBUG, ...FIXER], seed, 1),
    exercise: pick(exercises, seed, 2),
    typing: pick(TYPING_DRILLS, seed, 4),
  };
}
