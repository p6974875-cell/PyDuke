import { CONCEPTS } from "@/lib/content/concepts";
import { GAMES } from "@/lib/content/games";
import { LESSONS } from "@/lib/content/lessons";
import { TYPING_DRILLS } from "@/lib/content/typing";
import { seeded } from "@/lib/game-engine";
import { TOPICS } from "@/lib/content/topics";
import type { Exercise, GameItem, TopicId, TopicProgress } from "@/lib/types";
import type { ConceptQ } from "@/lib/content/concepts";
import type { TypingDrill } from "@/lib/types";

export interface DailySet {
  date: string;
  concepts: ConceptQ[];
  predicts: GameItem[];
  debug: GameItem | null;
  exercise: { topicId: TopicId; exercise: Exercise } | null;
  typing: TypingDrill;
}

function dateSeed(date: string) {
  return date.split("-").reduce((n, p) => n * 31 + Number(p), 7);
}

function pick<T>(rng: () => number, arr: T[], n: number): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a.slice(0, n);
}

export function buildDaily(date: string, topics: Record<TopicId, TopicProgress>): DailySet {
  const rng = seeded(dateSeed(date));
  const open = TOPICS.filter((t) => topics[t.id]?.status !== "locked").map((t) => t.id);
  const weak = open.filter((id) => (topics[id]?.mistakes.length ?? 0) > 0);
  const poolTopics = weak.length ? [...weak, ...open] : open;

  const concepts = pick(
    rng,
    CONCEPTS.filter((c) => poolTopics.includes(c.topicId) || open.includes(c.topicId)),
    2,
  );
  const predicts = pick(rng, GAMES.predict ?? [], 2);
  const debugItems = GAMES.debug ?? [];
  const debug = debugItems[Math.floor(rng() * debugItems.length)] ?? null;

  const lessonPool = open
    .map((id) => {
      const ex = LESSONS[id]?.exercises[0];
      return ex ? { topicId: id, exercise: ex } : null;
    })
    .filter((x): x is { topicId: TopicId; exercise: Exercise } => Boolean(x));
  const exercise = lessonPool[Math.floor(rng() * Math.max(1, lessonPool.length))] ?? null;
  const typing = TYPING_DRILLS[Math.floor(rng() * TYPING_DRILLS.length)] ?? TYPING_DRILLS[0];

  return { date, concepts, predicts, debug, exercise, typing };
}

export const DAILY_SLOTS = [
  "concept-0",
  "concept-1",
  "predict-0",
  "predict-1",
  "debug",
  "code",
  "typing",
] as const;
