export interface TypingTechnique {
  id: string;
  title: string;
  goal: string;
  steps: string[];
  drill: string;
  tip: string;
}

export const TYPING_TECHNIQUES: TypingTechnique[] = [
  {
    id: "home-row",
    title: "1. Find the home position",
    goal: "Build a consistent starting position so your fingers stop hunting for keys.",
    steps: [
      "Rest your left fingers on A S D F and your right fingers on J K L ;.",
      "Keep both thumbs relaxed near the space bar.",
      "After every short phrase, return your fingers to the home position.",
    ],
    drill: "asdf jkl; asdf jkl; fdsa ;lkj",
    tip: "The F and J keys usually have small bumps. Use them as physical landmarks.",
  },
  {
    id: "eyes-off",
    title: "2. Train without looking down",
    goal: "Turn common Python keys into muscle memory.",
    steps: [
      "Look at the code, not the keyboard.",
      "Slow down when you reach symbols such as :, _, (), [] and {}.",
      "If you make a mistake, correct it calmly instead of rushing.",
    ],
    drill: "name = 'Ada'\nif name:\n    print(name)",
    tip: "Accuracy creates reliable muscle memory. Speed comes later.",
  },
  {
    id: "python-symbols",
    title: "3. Master Python symbols",
    goal: "Make punctuation feel automatic instead of interrupting your thinking.",
    steps: [
      "Practice colon + indentation together: if condition:",
      "Practice brackets as pairs: (), [], {}.",
      "Practice underscores in snake_case names.",
    ],
    drill: "user_name = {'scores': [10, 20, 30]}",
    tip: "Say the structure in your head: open bracket → content → close bracket.",
  },
  {
    id: "indentation",
    title: "4. Make indentation automatic",
    goal: "Type Python blocks with clean four-space indentation.",
    steps: [
      "Type the colon at the end of a block header.",
      "Press Tab in this trainer to insert four spaces.",
      "Outdent when the block ends instead of adding random spaces.",
    ],
    drill: "for n in range(3):\n    if n > 0:\n        print(n)",
    tip: "Think of indentation as the shape of the program, not decoration.",
  },
  {
    id: "accuracy",
    title: "5. Accuracy before speed",
    goal: "Reduce errors before trying to increase WPM.",
    steps: [
      "Aim for clean runs rather than a high first score.",
      "Notice which symbols or letters cause repeated mistakes.",
      "Repeat the same drill until your accuracy is stable.",
    ],
    drill: "def square(n):\n    return n ** 2",
    tip: "A useful target is consistent accuracy; speed can be trained afterward.",
  },
  {
    id: "rhythm",
    title: "6. Build typing rhythm",
    goal: "Keep your hands moving smoothly through short Python statements.",
    steps: [
      "Type in small groups instead of hitting each key with a separate pause.",
      "Keep your shoulders and hands relaxed.",
      "Use short daily sessions and increase difficulty gradually.",
    ],
    drill: "numbers = [n * 2 for n in range(1, 6)]\nprint(numbers)",
    tip: "Smooth and controlled beats frantic. Let familiar syntax become a rhythm.",
  },
];
