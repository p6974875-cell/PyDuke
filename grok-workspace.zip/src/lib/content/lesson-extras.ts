import type { TopicId } from "@/lib/types";

export interface LessonExtra {
  realWorld: { heading: string; body: string; code?: string };
  review: string[];
  think: { question: string; answer: string };
  outputs: string[];
}

export const LESSON_EXTRAS: Record<TopicId, LessonExtra> = {
  variables: {
    realWorld: {
      heading: "A receipt line",
      body: "A shop program binds a price and a count, then prints the line total. Names make the arithmetic readable tomorrow.",
      code: 'item = "tea"\nprice = 2.5\nqty = 3\nprint(item, price * qty)',
    },
    review: [
      "A variable is a name bound to an object.",
      "The type lives on the object, not the name.",
      "Reassignment points the name at a new object; it does not mutate the old one unless that object is mutable and you mutate it.",
      "print() writes; a # comment is ignored; Python does not need a type declaration.",
    ],
    think: {
      question: "After a = 1; b = a; a = 2, what is b? Why?",
      answer: "b is still 1. Integers are immutable. b was bound to the object 1; rebinding a does not touch b.",
    },
    outputs: ["<class 'int'>\n5.0 <class 'float'>", "[1, 2, 3]"],
  },
  io: {
    realWorld: {
      heading: "A login prompt",
      body: "Any program that asks for a name is using input(). Remember the result is always a string, even if the user types digits.",
      code: 'name = "Ada"\nprint("hello", name)',
    },
    review: [
      "print writes to standard output.",
      "input reads a line and always returns str.",
      "sep and end control how print joins and finishes a line.",
      "Convert with int() or float() before arithmetic.",
    ],
    think: {
      question: "Why does print(input() + 1) crash even if you type 4?",
      answer: "input() returns '4', a string. '4' + 1 is a TypeError. int(input()) + 1 works.",
    },
    outputs: ["A-B!done"],
  },
  operators: {
    realWorld: {
      heading: "Even pages",
      body: "A printer that only duplexes even pages uses n % 2 == 0. Remainder is the everyday test for grouping.",
      code: "page = 8\nprint('even' if page % 2 == 0 else 'odd')",
    },
    review: [
      "/ is true division (float). // is floor division.",
      "% is remainder. ** is power.",
      "and / or short-circuit.",
      "1 < x < 5 means 1 < x and x < 5.",
    ],
    think: {
      question: "What is 7 // 2 and 7 / 2?",
      answer: "3 and 3.5. Floor versus true division.",
    },
    outputs: ["True"],
  },
  conditions: {
    realWorld: {
      heading: "Ticket gate",
      body: "A gate lets you in if age >= 18 or you have a pass. One if/elif/else chain; only one branch runs.",
      code: "age = 16\nhas_pass = True\nif age >= 18 or has_pass:\n    print('enter')\nelse:\n    print('wait')",
    },
    review: [
      "if / elif / else: at most one suite runs.",
      "Empty, 0, '', None are falsy.",
      "Indentation is the block.",
      "Write both sides of a comparison: n > 0 and n < 10.",
    ],
    think: {
      question: "If two if statements (not elif) are both true, how many print?",
      answer: "Both. Separate ifs are independent. elif would skip the second.",
    },
    outputs: ["allowed"],
  },
  loops: {
    realWorld: {
      heading: "Batch of invoices",
      body: "for walks a collection. while repeats until a condition fails. range(n) is 0 .. n-1.",
      code: "total = 0\nfor n in [10, 20, 5]:\n    total += n\nprint(total)",
    },
    review: [
      "for walks an iterable. while tests a condition.",
      "range(5) is 0,1,2,3,4 — stop is exclusive.",
      "break leaves the loop. continue skips the rest of this round.",
      "Do not write for i in 5 — an int is not iterable.",
    ],
    think: {
      question: "How many times does for i in range(1, 4): print(i) run, and what does it print?",
      answer: "Three times: 1, 2, 3. Stop 4 is exclusive.",
    },
    outputs: ["0\n1\n2"],
  },
  lists: {
    realWorld: {
      heading: "A queue of names",
      body: "A waiting list is a list: append to the end, pop(0) from the front. Copies matter — aliasing shares the queue.",
      code: "q = ['Ada']\nq.append('Lin')\nprint(q.pop(0))\nprint(q)",
    },
    review: [
      "Lists are mutable sequences.",
      "b = a aliases; b = a[:] copies.",
      "Comprehensions build a new list.",
      "Index from 0. Negative indexes count from the end.",
    ],
    think: {
      question: "After a = [1]; b = a; b.append(2); what is a?",
      answer: "[1, 2]. Both names point at the same list.",
    },
    outputs: ["[1, 4, 9]", "[1, 2]"],
  },
  tuples: {
    realWorld: {
      heading: "A point",
      body: "A coordinate (x, y) should not grow extra numbers by accident. A tuple is the right shape.",
      code: "point = (3, 4)\nprint(point[0], len(point))",
    },
    review: [
      "Tuples are immutable sequences.",
      "The comma constructs a tuple: (5,) is a one-element tuple; (5) is 5.",
      "You can unpack: x, y = point.",
      "Use a tuple for fixed records; a list for growing collections.",
    ],
    think: {
      question: "Why is t = (5) not a tuple?",
      answer: "Parentheses group. The comma makes the tuple: t = (5,).",
    },
    outputs: ["3 4"],
  },
  sets: {
    realWorld: {
      heading: "Unique visitors",
      body: "A set of user ids ignores duplicates. Membership tests are the point of a set.",
      code: "seen = {1, 2, 2, 3}\nprint(seen)\nprint(2 in seen)",
    },
    review: [
      "A set holds unique unordered hashable values.",
      "in is the membership test.",
      "|, &, - are union, intersection, difference.",
      "A list is not hashable; you cannot put a list in a set.",
    ],
    think: {
      question: "What does set('abba') contain?",
      answer: "The unique letters, typically {'a', 'b'}. Order is not guaranteed.",
    },
    outputs: ["{1, 2, 3}\nTrue"],
  },
  dictionaries: {
    realWorld: {
      heading: "A stock count",
      body: "item -> quantity. Look up by name, not by position. .get avoids KeyError.",
      code: "stock = {'tea': 4, 'mug': 2}\nstock['tea'] = stock.get('tea', 0) + 1\nprint(stock['tea'])",
    },
    review: [
      "A dict maps keys to values.",
      "for x in d walks keys. Use .items() for pairs.",
      ".get(k, default) is the safe lookup.",
      "Keys must be hashable.",
    ],
    think: {
      question: "What does for x in {'a': 1} yield?",
      answer: "The key 'a', not the value 1.",
    },
    outputs: ["5"],
  },
  strings: {
    realWorld: {
      heading: "A slug",
      body: "Titles become URL slugs with lower(), split, and join. Strings are immutable — methods return new strings.",
      code: "title = 'Hello World'\nprint('-'.join(title.lower().split()))",
    },
    review: [
      "Strings are immutable sequences of characters.",
      "s[::-1] reverses. s.split() breaks on whitespace.",
      "f-strings interpolate values.",
      "Methods return new strings; they do not edit in place.",
    ],
    think: {
      question: "After s = 'ab'; s.upper(); what is s?",
      answer: "Still 'ab'. upper() returned a new string that was discarded.",
    },
    outputs: ["hello-world"],
  },
  functions: {
    realWorld: {
      heading: "A tax helper",
      body: "Package 'add VAT' as a function so every screen uses the same rule. Return the number; let the caller print.",
      code: "def with_vat(p):\n    return round(p * 1.2, 2)\n\nprint(with_vat(10))",
    },
    review: [
      "Parameters are names; arguments are values you pass.",
      "return hands a value back. No return means None.",
      "Do one job. Prefer return over print inside helpers.",
      "Never use a mutable default argument.",
    ],
    think: {
      question: "What is x after def f(): print(3) then x = f()?",
      answer: "None. f printed 3 but returned None, which was bound to x.",
    },
    outputs: ["13", "Hello, friend Ada\nHello, Dr Ada"],
  },
  scope: {
    realWorld: {
      heading: "A counter in a function",
      body: "A name assigned inside a function is local unless you declare otherwise. That is how two functions can both use i.",
      code: "def inc(n):\n    step = 1\n    return n + step\n\nprint(inc(4))",
    },
    review: [
      "Assignment in a function makes a local name.",
      "Reading an outer name is fine; assigning it needs nonlocal or global.",
      "Each call has its own frame.",
      "LEGB: local, enclosing, global, built-in.",
    ],
    think: {
      question: "Why does x = 1; def f(): x = x + 1 fail if you call f()?",
      answer: "x = makes x local for the whole function, so the right-hand x is an unbound local.",
    },
    outputs: ["5"],
  },
  errors: {
    realWorld: {
      heading: "A form field",
      body: "Users type junk. int(text) can raise ValueError. Catch that one exception and ask again — do not bare except everything.",
      code: "text = '9'\ntry:\n    n = int(text)\nexcept ValueError:\n    n = 0\nprint(n)",
    },
    review: [
      "try / except catches named exceptions.",
      "raise starts an exception.",
      "ValueError: right type, wrong value. TypeError: wrong type. NameError: unbound name.",
      "A bare except hides bugs. Catch the error you expect.",
    ],
    think: {
      question: "int('q') — which exception?",
      answer: "ValueError. The argument is a str, which int accepts, but 'q' is not a number.",
    },
    outputs: ["9"],
  },
  modules: {
    realWorld: {
      heading: "Reuse math",
      body: "import math gives you sqrt without copying the algorithm. from math import sqrt binds the name sqrt in your module.",
      code: "import math\nprint(math.sqrt(9))",
    },
    review: [
      "import module binds the module object.",
      "from module import name binds that name.",
      "__name__ == '__main__' is true for the file you ran.",
      "The standard library is already installed with Python.",
    ],
    think: {
      question: "What is the difference between import math and from math import sqrt?",
      answer: "import math means you call math.sqrt. from math import sqrt means you call sqrt.",
    },
    outputs: ["3.0"],
  },
  files: {
    realWorld: {
      heading: "A notes file",
      body: "with open(path) as f: reads or writes and closes the file even if an error happens. That is the real-world pattern.",
      code: "with open('note.txt', 'w') as f:\n    f.write('hello')\nwith open('note.txt') as f:\n    print(f.read())",
    },
    review: [
      "open(path, mode) returns a file object.",
      "'r' read, 'w' write (truncates), 'a' append.",
      "with closes the file for you.",
      "read() is the whole text. readlines() is a list of lines.",
    ],
    think: {
      question: "Why prefer with open(...) as f over a bare open?",
      answer: "with guarantees close, including when an exception fires in the block.",
    },
    outputs: ["hello"],
  },
  oop: {
    realWorld: {
      heading: "A bank account",
      body: "Balance and deposit belong together. A class is the bundle: data on self, behaviour as methods.",
      code: "class Account:\n    def __init__(self, bal):\n        self.bal = bal\n    def deposit(self, n):\n        self.bal += n\n\na = Account(10)\na.deposit(5)\nprint(a.bal)",
    },
    review: [
      "A class is a blueprint. An instance is one object.",
      "__init__ sets up the instance. self is that instance.",
      "Methods are functions on the class that receive self.",
      "Attribute access is name lookup on the object, then the class.",
    ],
    think: {
      question: "What is self?",
      answer: "The instance the method was called on. a.deposit(5) is Account.deposit(a, 5).",
    },
    outputs: ["15"],
  },
  stdlib: {
    realWorld: {
      heading: "Today's date stamp",
      body: "datetime and random and json live in the standard library. You import them; you do not download them.",
      code: "from datetime import date\nprint(date(2026, 1, 1).isoformat())",
    },
    review: [
      "The standard library ships with Python.",
      "datetime, math, random, json, os, pathlib, collections are everyday modules.",
      "random.seed makes a sequence repeatable for tests.",
      "json.dumps / json.loads convert between dicts and text.",
    ],
    think: {
      question: "Why seed random in a lesson?",
      answer: "So the output is checkable. Without a seed, choice() would not match a fixed expected string.",
    },
    outputs: ["2026-01-01"],
  },
  apis: {
    realWorld: {
      heading: "A weather payload",
      body: "APIs send JSON: a dict on the wire. You parse it, then pick fields. PyDuke fakes the network; the shape is the same.",
      code: "payload = {'temp': 12, 'city': 'York'}\nprint(payload['city'], payload['temp'])",
    },
    review: [
      "JSON is text. json.loads turns it into dicts and lists.",
      "HTTP GET fetches; the body is often JSON.",
      "Always check the keys you use exist.",
      "This playground cannot hit the real internet — use the fake fetch where provided.",
    ],
    think: {
      question: "If a response is the string '{\"n\": 1}', what do you call to get a dict?",
      answer: "json.loads. json.load is for a file object.",
    },
    outputs: ["York 12"],
  },
  projects: {
    realWorld: {
      heading: "Slice a guessing game",
      body: "Do not write the whole game at once. First a function that judges low/high/match. Then a loop around input. Then random. Each slice is testable.",
      code: "def judge(secret, guess):\n    if guess == secret:\n        return 'match'\n    return 'low' if guess < secret else 'high'\n\nprint(judge(7, 2))",
    },
    review: [
      "Name the data, then the verbs, then the I/O.",
      "A function you can test is a finished slice.",
      "Keep input() at the edge, not inside helpers.",
      "Build the smallest program that could work, then wrap it.",
    ],
    think: {
      question: "Why test judge() without input()?",
      answer: "Because you can call it with known numbers and check the string it returns. input() makes that noisy.",
    },
    outputs: ["low"],
  },
  advanced: {
    realWorld: {
      heading: "A stream of records",
      body: "A generator yields rows as you need them instead of loading a million-line file into a list.",
      code: "def countdown(n):\n    while n > 0:\n        yield n\n        n -= 1\n\nprint(list(countdown(3)))",
    },
    review: [
      "yield produces the next value and pauses the function.",
      "Type hints document contracts; they are not runtime checks.",
      "A decorator wraps a function: @dec is f = dec(f).",
      "Use these when they remove noise, not as decoration.",
    ],
    think: {
      question: "What is the difference between return and yield inside a loop?",
      answer: "return stops the function for good. yield hands back a value and continues later.",
    },
    outputs: ["[0, 1, 4, 9]", "OK"],
  },
};
