import type { Lesson, TopicId } from "@/lib/types";

export const EXTRA_LESSONS: Record<
  Extract<TopicId, "intro" | "comments" | "conversion" | "range" | "json">,
  Lesson
> = {
  intro: {
    topicId: "intro",
    revision: {
      heading: "Start here",
      body: "Python is a programming language. You write source as text. The Python interpreter reads it, line by line, and carries out the instructions.",
      code: 'print("hello")',
    },
    concept: {
      heading: "Programs are instructions",
      explanation:
        "A Python program is a sequence of statements. `print` is a built-in function: you call it with parentheses. The string \"hello\" is an argument. Python executes top to bottom unless a loop, a condition, or a function call sends it elsewhere.",
      definition:
        "Python is an interpreted language: source is executed by the CPython interpreter (or another implementation) rather than compiled to a native binary first.",
      analogy:
        "A recipe is not dinner. The cook (the interpreter) reads each step and does it. If a step is misspelled, cooking stops there.",
    },
    examples: [
      {
        title: "A one-line program",
        code: 'print("PyDuke")',
        why: "The interpreter evaluates the call and writes the text to standard output, then a newline.",
      },
      {
        title: "Two statements, in order",
        code: "print(1)\nprint(2)",
        why: "Order is the program. The second print runs only after the first finishes.",
      },
    ],
    mistakes: [
      {
        wrong: "Print(hello)",
        right: 'print("hello")',
        why: "Names are case-sensitive. `print` is lowercase. hello without quotes is a name, not text.",
      },
    ],
    think: {
      question: "What actually runs your .py file?",
      answer: "The Python interpreter. It reads the source and executes statements in order.",
    },
    exercises: [
      {
        id: "intro-print",
        title: "Say hello",
        prompt: 'Print exactly: hello python',
        difficulty: "easy",
        starter: "",
        solution: 'print("hello python")',
        explanation: "One print, one string, lowercase.",
        checks: [{ kind: "stdout", expected: "hello python" }],
      },
      {
        id: "intro-two",
        title: "Two lines",
        prompt: "Print 1 then 2 on separate lines.",
        difficulty: "easy",
        starter: "",
        solution: "print(1)\nprint(2)",
        explanation: "Two statements, two lines of output.",
        checks: [{ kind: "stdout", expected: "1\n2" }],
      },
    ],
  },
  comments: {
    topicId: "comments",
    revision: {
      heading: "Notes that Python ignores",
      body: "A comment starts with #. Python does not execute it. Use comments for why, not for restating what the next line already says.",
      code: "n = 3  # number of lives remaining",
    },
    concept: {
      heading: "Hash comments and docstrings",
      explanation:
        "Everything after # on a line is a comment. A string sitting alone as the first statement in a module, class, or function is a docstring — documentation the interpreter stores on `__doc__`. Comments do not change runtime behaviour.",
      definition:
        "A comment is source text the tokenizer discards. A docstring is a string literal used as documentation.",
      analogy:
        "Sticky notes on a recipe. The cook does not eat them. A docstring is the printed introduction at the top of the cookbook.",
    },
    examples: [
      {
        title: "A useful comment",
        code: "timeout = 8  # seconds the sandbox waits before killing a loop\nprint(timeout)",
        why: "The comment records the unit. The print still prints 8.",
      },
      {
        title: "A docstring",
        code: 'def twice(n):\n    """Return n + n."""\n    return n + n\n\nprint(twice(4))\nprint(twice.__doc__)',
        why: "The docstring is stored on the function. The return is the behaviour.",
      },
    ],
    mistakes: [
      {
        wrong: "// increment",
        right: "# increment",
        why: "Python does not use C-style // comments.",
      },
    ],
    exercises: [
      {
        id: "com-1",
        title: "Keep the print",
        prompt: "Print ok. You may add a comment on the same line.",
        difficulty: "easy",
        starter: "# write below\n",
        solution: 'print("ok")  # status',
        explanation: "The comment is ignored. print still runs.",
        checks: [{ kind: "stdout", expected: "ok" }],
      },
    ],
  },
  conversion: {
    topicId: "conversion",
    revision: {
      heading: "Types do not mix themselves",
      body: "input() always returns a str. Arithmetic needs int or float. Convert on purpose with int(), float(), str(), bool().",
      code: 'n = int("7")\nprint(n + 1)',
    },
    concept: {
      heading: "Constructors as converters",
      explanation:
        "`int(\"7\")` parses a digit string. `int(3.9)` truncates toward zero. `float(\"1.5\")` parses a decimal. `str(9)` produces '9'. `bool(0)` is False; any non-empty string is True — including `'0'`. Failed parses raise ValueError.",
      definition:
        "Type conversion (casting) constructs a new object of another type from an existing value.",
      analogy:
        "Pouring water into a measuring cup labelled millilitres. The water is the same stuff; the reading is a different representation. Some pours do not fit — that is ValueError.",
    },
    examples: [
      {
        title: "String to int",
        code: 'print(int("12") + 3)',
        why: "Without int, '12' + 3 is a TypeError. With int, you get 15.",
      },
      {
        title: "Truncation",
        code: "print(int(3.9))\nprint(int(-1.2))",
        why: "int on a float drops the fraction toward zero, not round().",
      },
    ],
    mistakes: [
      {
        wrong: 'int("3.2")',
        right: 'int(float("3.2"))',
        why: "int() does not parse a decimal string. Go through float first.",
      },
    ],
    exercises: [
      {
        id: "conv-1",
        title: "Add one",
        prompt: 'text = "8". Print that value plus 1 as a number (9).',
        difficulty: "easy",
        starter: 'text = "8"\n',
        solution: 'text = "8"\nprint(int(text) + 1)',
        explanation: "Convert, then add.",
        checks: [{ kind: "stdout", expected: "9" }],
      },
      {
        id: "conv-2",
        title: "From input",
        prompt: "Read a number from input and print its square.",
        difficulty: "medium",
        starter: "",
        solution: "n = int(input())\nprint(n * n)",
        explanation: "input is str. int it before multiplying.",
        checks: [
          { kind: "stdout", expected: "25", stdin: "5\n" },
          { kind: "stdout", expected: "0", stdin: "0\n" },
        ],
      },
    ],
  },
  range: {
    topicId: "range",
    revision: {
      heading: "Counting without a list",
      body: "range(n) produces 0, 1, …, n-1. range(a, b) starts at a and stops before b. range(a, b, s) steps by s.",
      code: "print(list(range(3)))\nprint(list(range(2, 6)))\nprint(list(range(5, 0, -1)))",
    },
    concept: {
      heading: "A lazy sequence of ints",
      explanation:
        "range is not a list. It is an immutable sequence that yields ints on demand. `for i in range(n)` is the ordinary counted loop. The stop value is excluded — that is why range(3) is 0, 1, 2. A negative step walks backward. `list(range(...))` materialises the values when you need to print them.",
      definition:
        "range(start, stop, step) is an immutable sequence of integers from start toward stop, excluding stop, stepping by step.",
      analogy:
        "A numbered ticket dispenser. It does not print every ticket in advance. It knows the next number when you ask.",
    },
    examples: [
      {
        title: "Counted loop",
        code: "for i in range(3):\n    print(i)",
        why: "i takes 0, then 1, then 2. The body runs three times.",
      },
      {
        title: "Stride",
        code: "print(list(range(0, 8, 2)))",
        why: "Start 0, stop before 8, step 2 → 0, 2, 4, 6.",
      },
    ],
    mistakes: [
      {
        wrong: "for i in range(1, 3):  # expecting 1,2,3",
        right: "for i in range(1, 4):",
        why: "Stop is exclusive. To include 3, stop at 4.",
      },
    ],
    exercises: [
      {
        id: "range-1",
        title: "0 to 4",
        prompt: "Print the numbers 0 through 4, each on its own line, using range.",
        difficulty: "easy",
        starter: "",
        solution: "for i in range(5):\n    print(i)",
        explanation: "range(5) is 0..4.",
        checks: [{ kind: "stdout", expected: "0\n1\n2\n3\n4" }],
      },
      {
        id: "range-2",
        title: "Odds",
        prompt: "Print a list of odd numbers from 1 through 7 using range.",
        difficulty: "medium",
        starter: "",
        solution: "print(list(range(1, 8, 2)))",
        explanation: "Start 1, stop 8, step 2.",
        checks: [{ kind: "stdout", expected: "[1, 3, 5, 7]" }],
      },
    ],
  },
  json: {
    topicId: "json",
    revision: {
      heading: "Dicts that can travel",
      body: "JSON is a text format: objects, arrays, strings, numbers, true/false/null. Python's json module dumps dicts/lists to that text and loads them back.",
      code: 'import json\nprint(json.dumps({"n": 3}))\nprint(json.loads(\'{"n": 3}\'))',
    },
    concept: {
      heading: "dumps and loads",
      explanation:
        "`json.dumps(obj)` serialises a Python object to a JSON string. `json.loads(text)` parses a JSON string to Python. Mapping: dict↔object, list↔array, str↔string, int/float↔number, True/False↔true/false, None↔null. Tuples dump as arrays. Keys in JSON objects are always strings.",
      definition:
        "JSON (JavaScript Object Notation) is a language-independent text encoding of nested maps and lists. dumps writes it; loads reads it.",
      analogy:
        "Packing a suitcase (dumps) and unpacking it at the other end (loads). The clothes are your dict. The suitcase is the string you can email.",
    },
    examples: [
      {
        title: "Round trip",
        code: 'import json\ndata = {"ok": True, "n": 2}\ntext = json.dumps(data)\nprint(text)\nprint(json.loads(text)["n"])',
        why: "dumps produces text. loads rebuilds a dict. True becomes JSON true.",
      },
    ],
    mistakes: [
      {
        wrong: "json.dumps({1: 'a'})  # non-string key",
        right: 'json.dumps({"1": "a"})',
        why: "JSON object keys must be strings. dumps will coerce int keys to strings, which surprises lookups later.",
      },
    ],
    exercises: [
      {
        id: "json-1",
        title: "Dump a dict",
        prompt: 'Dump {"a": 1} with json.dumps and print the result.',
        difficulty: "easy",
        starter: "import json\n",
        solution: 'import json\nprint(json.dumps({"a": 1}))',
        explanation: "dumps returns a string. print it.",
        checks: [{ kind: "stdout", expected: '{"a": 1}' }],
      },
      {
        id: "json-2",
        title: "Read a field",
        prompt: "Load '{\"x\": 9}' and print the x value.",
        difficulty: "medium",
        starter: "import json\n",
        solution: "import json\nprint(json.loads('{\"x\": 9}')['x'])",
        explanation: "loads returns a dict. Index with 'x'.",
        checks: [{ kind: "stdout", expected: "9" }],
      },
    ],
  },
};
