import type { GameId } from "@/lib/types";

const ALIAS: Record<string, GameId> = {
  fixer: "fixer",
  "code-fixer": "fixer",
  predict: "predict",
  "predict-output": "predict",
  "predict-the-output": "predict",
  ordering: "ordering",
  "code-ordering": "ordering",
  typing: "typing",
  "typing-sprint": "typing",
  debug: "debug",
  debugging: "debug",
  "debugging-challenge": "debug",
  build: "build",
  "build-it": "build",
  boss: "boss",
  "boss-battle": "boss",
};

export const GAME_SLUG: Record<GameId, string> = {
  fixer: "code-fixer",
  predict: "predict",
  ordering: "code-ordering",
  typing: "typing-sprint",
  debug: "debugging-challenge",
  build: "build-it",
  boss: "boss-battle",
};

export function resolveGameId(raw: string): GameId | undefined {
  return ALIAS[raw];
}
