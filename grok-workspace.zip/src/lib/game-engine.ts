import type { Difficulty, GameId, TopicId, TopicProgress } from "@/lib/types";

export const GAME_UNLOCKS: Record<GameId, { topic: TopicId | null; label: string }> = {
  fixer: { topic: "variables", label: "Complete Variables & data types" },
  predict: { topic: "operators", label: "Complete Operators" },
  ordering: { topic: "conditions", label: "Complete Conditions" },
  typing: { topic: null, label: "Always open" },
  debug: { topic: "loops", label: "Complete Loops" },
  build: { topic: "functions", label: "Complete Functions" },
  boss: { topic: "loops", label: "Complete Loops" },
};

export const DIFF_POINTS: Record<Difficulty, number> = {
  easy: 80,
  medium: 110,
  hard: 150,
  advanced: 200,
};

export function isGameUnlocked(
  gameId: GameId,
  topics: Record<TopicId, TopicProgress>,
): boolean {
  const req = GAME_UNLOCKS[gameId];
  if (!req.topic) return true;
  const st = topics[req.topic]?.status;
  return st === "mastered" || st === "review";
}

export function livesFor(gameId: GameId): number | null {
  if (gameId === "boss") return 3;
  if (gameId === "fixer" || gameId === "debug") return 5;
  return null;
}

export function pointsFor(difficulty: Difficulty, streak: number): number {
  const base = DIFF_POINTS[difficulty] ?? 80;
  return streak >= 3 ? Math.round(base * 1.25) : base;
}

export function pickPlayOrder<T extends { id: string; difficulty: string }>(
  items: T[],
  completed: string[],
): T[] {
  const undone = items.filter((it) => !completed.includes(it.id));
  const done = items.filter((it) => completed.includes(it.id));
  return [...shuffle(undone), ...shuffle(done)];
}

export function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function seeded(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}
