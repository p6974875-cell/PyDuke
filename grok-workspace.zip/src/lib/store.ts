import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { todayKey, levelFromXp } from "@/lib/utils";
import { MASTERED_ON_ARRIVAL, START_TOPIC, TOPICS } from "@/lib/content/topics";
import { LESSONS } from "@/lib/content/lessons";
import { ACHIEVEMENTS } from "@/lib/achievements";
import type {
  ChatMessage,
  Difficulty,
  GameProgress,
  SavedSnippet,
  TopicId,
  TopicProgress,
  TypingRecord,
} from "@/lib/types";

const XP_FOR: Record<Difficulty, number> = {
  easy: 12,
  medium: 20,
  hard: 32,
  advanced: 48,
};

function emptyGame(): GameProgress {
  return {
    completed: [],
    best: {},
    attempts: 0,
    correct: 0,
    streak: 0,
    bestStreak: 0,
    lastScore: 0,
    bestScore: 0,
  };
}

function emptyTopics(): Record<TopicId, TopicProgress> {
  const now = Date.now();
  const out = {} as Record<TopicId, TopicProgress>;
  for (const t of TOPICS) {
    let status: TopicProgress["status"] = "locked";
    if (MASTERED_ON_ARRIVAL.includes(t.id)) status = "mastered";
    else if (t.id === START_TOPIC) status = "in_progress";
    out[t.id] = {
      status,
      score: status === "mastered" ? 100 : 0,
      attempts: 0,
      lastSeenAt: status === "mastered" ? now : 0,
      completedExercises: [],
      mistakes: [],
    };
  }
  return out;
}

export const EMPTY_IDS: string[] = [];

export function dueTopicIds(topics: Record<TopicId, TopicProgress>): TopicId[] {
  const now = Date.now();
  const due: TopicId[] = [];
  for (const t of TOPICS) {
    const p = topics[t.id];
    if (!p || p.status !== "mastered") continue;
    const age = now - (p.lastSeenAt || 0);
    if (age > 1000 * 60 * 60 * 36) due.push(t.id);
  }
  return due;
}

export interface HelixState {
  name: string;
  xp: number;
  streak: number;
  lastActiveDate: string;
  currentTopicId: TopicId;
  preferredDifficulty: Difficulty;
  recentResults: boolean[];
  topics: Record<TopicId, TopicProgress>;
  games: Record<string, GameProgress>;
  projectsCompleted: string[];
  typingHistory: TypingRecord[];
  snippets: SavedSnippet[];
  tutor: ChatMessage[];
  lessonsCompleted: TopicId[];
  achievements: string[];
  dailyDate: string;
  dailyDone: string[];
  dailyCompletions: number;
  lastCode: string;
  lastError: string;
  lastExercise: string;
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  setName: (name: string) => void;
  tickStreak: () => void;
  awardXp: (n: number) => void;
  recordExercise: (opts: {
    topicId: TopicId;
    exerciseId: string;
    ok: boolean;
    difficulty: Difficulty;
    note?: string;
    code?: string;
  }) => void;
  completeLesson: (topicId: TopicId) => void;
  completeGameItem: (gameId: string, itemId: string, ok: boolean, score?: number) => void;
  finishGameSession: (gameId: string, score: number) => void;
  completeProject: (projectId: string) => void;
  recordTyping: (rec: TypingRecord) => void;
  saveSnippet: (title: string, code: string) => void;
  deleteSnippet: (id: string) => void;
  pushTutor: (msg: Omit<ChatMessage, "id" | "at">) => void;
  clearTutor: () => void;
  markDaily: (slot: string) => void;
  resetProgress: () => void;
  dueRevision: () => TopicId[];
  unlockNext: (topicId: TopicId) => void;
}

const initialSlice = () => ({
  name: "",
  xp: 0,
  streak: 0,
  lastActiveDate: todayKey(),
  currentTopicId: START_TOPIC as TopicId,
  preferredDifficulty: "medium" as Difficulty,
  recentResults: [] as boolean[],
  topics: emptyTopics(),
  games: {} as Record<string, GameProgress>,
  projectsCompleted: [] as string[],
  typingHistory: [] as TypingRecord[],
  snippets: [] as SavedSnippet[],
  tutor: [] as ChatMessage[],
  lessonsCompleted: [...MASTERED_ON_ARRIVAL] as TopicId[],
  achievements: [] as string[],
  dailyDate: todayKey(),
  dailyDone: [] as string[],
  dailyCompletions: 0,
  lastCode: "",
  lastError: "",
  lastExercise: "",
  hydrated: false,
});

const storage = createJSONStorage(() => {
  if (typeof window === "undefined") {
    return {
      getItem: () => null,
      setItem: () => {},
      removeItem: () => {},
    };
  }
  return localStorage;
});

function grantAchievements(
  set: (p: Partial<HelixState>) => void,
  get: () => HelixState,
) {
  const s = get();
  const have = new Set(s.achievements);
  const next = [...s.achievements];
  let xp = 0;
  for (const a of ACHIEVEMENTS) {
    if (have.has(a.id)) continue;
    if (a.earned(s)) {
      next.push(a.id);
      xp += a.xp;
    }
  }
  if (next.length !== s.achievements.length) {
    set({ achievements: next, xp: get().xp + xp });
  }
}

export const useHelix = create<HelixState>()(
  persist(
    (set, get) => ({
      ...initialSlice(),
      setHydrated: (v) => set({ hydrated: v }),
      setName: (name) => set({ name }),
      tickStreak: () => {
        const today = todayKey();
        const last = get().lastActiveDate;
        if (last === today) {
          if (get().dailyDate !== today) set({ dailyDate: today, dailyDone: [] });
          return;
        }
        const yest = new Date();
        yest.setDate(yest.getDate() - 1);
        const yestKey = todayKey(yest);
        set({
          lastActiveDate: today,
          streak: last === yestKey ? get().streak + 1 : 1,
          dailyDate: today,
          dailyDone: [],
        });
        grantAchievements(set, get);
      },
      awardXp: (n) => set({ xp: get().xp + n }),
      recordExercise: ({ topicId, exerciseId, ok, difficulty, note, code }) => {
        const topics = { ...get().topics };
        const t = { ...topics[topicId] };
        t.attempts += 1;
        t.lastSeenAt = Date.now();
        if (ok && !t.completedExercises.includes(exerciseId)) {
          t.completedExercises = [...t.completedExercises, exerciseId];
          t.score = Math.min(
            100,
            t.score + (difficulty === "easy" ? 15 : difficulty === "medium" ? 22 : 30),
          );
        }
        if (!ok && note) {
          t.mistakes = [...t.mistakes.slice(-11), { exerciseId, note, at: Date.now() }];
        }
        if (t.status === "locked" || t.status === "available") t.status = "in_progress";
        topics[topicId] = t;
        const recent = [...get().recentResults, ok].slice(-6);
        let preferred = get().preferredDifficulty;
        const last3 = recent.slice(-3);
        if (last3.length === 3 && last3.every(Boolean)) {
          preferred =
            preferred === "easy" ? "medium" : preferred === "medium" ? "hard" : "advanced";
        }
        if (last3.length === 3 && last3.every((x) => !x)) {
          preferred =
            preferred === "advanced" ? "hard" : preferred === "hard" ? "medium" : "easy";
        }
        set({
          topics,
          recentResults: recent,
          preferredDifficulty: preferred,
          currentTopicId: topicId,
          xp: get().xp + (ok ? XP_FOR[difficulty] : 4),
          lastCode: code ?? get().lastCode,
          lastError: ok ? "" : (note ?? get().lastError),
          lastExercise: exerciseId,
        });
        grantAchievements(set, get);
      },
      completeLesson: (topicId) => {
        const topics = { ...get().topics };
        const t = {
          ...topics[topicId],
          status: "mastered" as const,
          score: 100,
          lastSeenAt: Date.now(),
        };
        topics[topicId] = t;
        const done = get().lessonsCompleted.includes(topicId)
          ? get().lessonsCompleted
          : [...get().lessonsCompleted, topicId];
        set({ topics, lessonsCompleted: done, xp: get().xp + 40, currentTopicId: topicId });
        get().unlockNext(topicId);
        grantAchievements(set, get);
      },
      unlockNext: (topicId) => {
        const idx = TOPICS.findIndex((t) => t.id === topicId);
        const next = TOPICS[idx + 1];
        if (!next) return;
        const topics = { ...get().topics };
        const cur = topics[next.id];
        if (cur.status === "locked") {
          topics[next.id] = { ...cur, status: "available" };
          set({ topics });
        }
      },
      completeGameItem: (gameId, itemId, ok, score = 1) => {
        const games = { ...get().games };
        const prev = games[gameId];
        const already = Boolean(ok && prev?.completed.includes(itemId));
        const g = { ...emptyGame(), ...(prev ?? {}) };
        g.attempts += 1;
        if (ok) {
          g.completed = g.completed.includes(itemId) ? g.completed : [...g.completed, itemId];
          g.correct += 1;
          g.streak += 1;
          g.bestStreak = Math.max(g.bestStreak, g.streak);
          g.best = { ...g.best, [itemId]: Math.max(g.best[itemId] ?? 0, score) };
        } else {
          g.streak = 0;
        }
        games[gameId] = g;
        set({ games, xp: get().xp + (ok ? (already ? 4 : 18) : 2) });
        grantAchievements(set, get);
      },
      finishGameSession: (gameId, score) => {
        const games = { ...get().games };
        const g = { ...emptyGame(), ...(games[gameId] ?? {}) };
        g.lastScore = score;
        g.bestScore = Math.max(g.bestScore ?? 0, score);
        games[gameId] = g;
        set({ games });
      },
      completeProject: (projectId) => {
        if (get().projectsCompleted.includes(projectId)) {
          set({ xp: get().xp + 8 });
          return;
        }
        set({
          projectsCompleted: [...get().projectsCompleted, projectId],
          xp: get().xp + 80,
        });
        grantAchievements(set, get);
      },
      recordTyping: (rec) => {
        const xp = rec.accuracy >= 95 ? 16 : rec.accuracy >= 85 ? 10 : 4;
        set({ typingHistory: [...get().typingHistory.slice(-79), rec], xp: get().xp + xp });
        grantAchievements(set, get);
      },
      saveSnippet: (title, code) => {
        const item: SavedSnippet = {
          id: `${Date.now()}`,
          title: title.trim() || "Untitled",
          code,
          at: Date.now(),
        };
        set({ snippets: [item, ...get().snippets].slice(0, 40) });
      },
      deleteSnippet: (id) => set({ snippets: get().snippets.filter((s) => s.id !== id) }),
      pushTutor: (msg) => {
        const item: ChatMessage = {
          ...msg,
          id: `${Date.now()}-${Math.random()}`,
          at: Date.now(),
        };
        set({ tutor: [...get().tutor, item].slice(-40) });
      },
      clearTutor: () => set({ tutor: [] }),
      markDaily: (slot) => {
        const today = todayKey();
        let date = get().dailyDate;
        let done = get().dailyDone;
        if (date !== today) {
          date = today;
          done = [];
        }
        if (done.includes(slot)) return;
        const next = [...done, slot];
        const finished = next.length >= 7;
        set({
          dailyDate: date,
          dailyDone: next,
          dailyCompletions: get().dailyCompletions + (finished ? 1 : 0),
          xp: get().xp + (finished ? 25 : 6),
        });
        grantAchievements(set, get);
      },
      resetProgress: () => {
        const keepName = get().name;
        set({ ...initialSlice(), name: keepName, hydrated: true });
      },
      dueRevision: () => dueTopicIds(get().topics),
    }),
    {
      name: "pyduke-progress-v3",
      skipHydration: true,
      storage,
      partialize: (s) => ({
        name: s.name,
        xp: s.xp,
        streak: s.streak,
        lastActiveDate: s.lastActiveDate,
        currentTopicId: s.currentTopicId,
        preferredDifficulty: s.preferredDifficulty,
        recentResults: s.recentResults,
        topics: s.topics,
        games: s.games,
        projectsCompleted: s.projectsCompleted,
        typingHistory: s.typingHistory,
        snippets: s.snippets,
        tutor: s.tutor,
        lessonsCompleted: s.lessonsCompleted,
        achievements: s.achievements,
        dailyDate: s.dailyDate,
        dailyDone: s.dailyDone,
        dailyCompletions: s.dailyCompletions,
        lastCode: s.lastCode,
        lastError: s.lastError,
        lastExercise: s.lastExercise,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    },
  ),
);

export function progressSummary(s: HelixState) {
  const mastered = TOPICS.filter((t) => s.topics[t.id]?.status === "mastered").map((t) => t.title);
  const current = TOPICS.find((t) => t.id === s.currentTopicId)?.title ?? s.currentTopicId;
  const mistakes = Object.entries(s.topics)
    .flatMap(([id, p]) => p.mistakes.slice(-2).map((m) => `${id}: ${m.note}`))
    .slice(-6);
  const lesson = LESSONS[s.currentTopicId];
  return [
    `Learner name: ${s.name || "(not set)"}`,
    `XP: ${s.xp}, level: ${levelFromXp(s.xp)}, streak: ${s.streak}`,
    `Current topic: ${current}`,
    `Mastered: ${mastered.join(", ") || "none"}`,
    `Preferred difficulty: ${s.preferredDifficulty}`,
    `Typing last WPM: ${s.typingHistory.at(-1)?.wpm ?? "n/a"} accuracy ${s.typingHistory.at(-1)?.accuracy ?? "n/a"}`,
    `Recent mistakes: ${mistakes.join(" | ") || "none recorded"}`,
    `Lesson heading: ${lesson?.concept.heading ?? ""}`,
    `Last exercise: ${s.lastExercise || "none"}`,
    `Last error: ${s.lastError || "none"}`,
  ].join("\n");
}
