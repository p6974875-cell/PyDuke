/** Server-only Gemini config. Never import this from client components. */

export function geminiKey(): string | undefined {
  const v = process.env.GEMINI_API_KEY?.trim();
  return v || undefined;
}

export function geminiChatModel(): string {
  return process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash";
}

export function geminiLiveModel(): string {
  return process.env.GEMINI_LIVE_MODEL?.trim() || "gemini-3.8-live";
}

export type GeminiChatResult = { ok: true; text: string } | { ok: false; error: string };

export async function generateGeminiText(opts: {
  system: string;
  messages: { role: string; content: string }[];
}): Promise<GeminiChatResult> {
  const apiKey = geminiKey();
  if (!apiKey) return { ok: false, error: "unavailable" };

  const model = geminiChatModel();
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey,
      },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: opts.system }] },
        contents: opts.messages.map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }],
        })),
        generationConfig: { temperature: 0.4, maxOutputTokens: 800 },
      }),
    },
  );
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    return { ok: false, error: `Gemini API error ${res.status}${body ? `: ${body.slice(0, 180)}` : ""}` };
  }
  const json = (await res.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  const text = json.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
  if (!text.trim()) return { ok: false, error: "empty" };
  return { ok: true, text };
}
