import { GAMES } from "@/lib/content/games";
import { MASTERED_ON_ARRIVAL } from "@/lib/content/topics";
import type { HelixState } from "@/lib/store";

export interface Achievement {
  id: string;
  title: string;
  blurb: string;
  test: (s: HelixState) => boolean;
}

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: "first-lesson",
    title: "First Lesson",
    blurb: "Finish a lesson beyond the ones already marked mastered.",
    test: (s) => s.lessonsCompleted.some((id) => !MASTERED_ON_ARRIVAL.includes(id)),
  },
  {
    id: "bug-hunter",
    title: "Bug Hunter",
    blurb: "Clear 10 debugging challenges.",
    test: (s) => (s.games.debug?.completed.length ?? 0) >= 10,
  },
  {
    id: "python-typist",
    title: "Python Typist",
    blurb: "Complete 5 typing sessions.",
    test: (s) => s.typingHistory.length >= 5,
  },
  {
    id: "code-runner",
    title: "Code Runner",
    blurb: "Pass 10 coding exercises.",
    test: (s) =>
      Object.values(s.topics).reduce((n, t) => n + t.completedExercises.length, 0) >= 10,
  },
  {
    id: "week-streak",
    title: "7 Day Streak",
    blurb: "Study on 7 consecutive days.",
    test: (s) => s.streak >= 7,
  },
  {
    id: "fixer-six",
    title: "Code Surgeon",
    blurb: "Repair every Code Fixer challenge.",
    test: (s) => (s.games.fixer?.completed.length ?? 0) >= (GAMES.fixer?.length ?? 0),
  },
  {
    id: "project-one",
    title: "Shipped it",
    blurb: "Complete a project.",
    test: (s) => s.projectsCompleted.length >= 1,
  },
  {
    id: "game-master",
    title: "Game Master",
    blurb: "Clear at least one challenge in every game type.",
    test: (s) =>
      ["fixer", "predict", "ordering", "debug", "build", "boss"].every(
        (id) => (s.games[id]?.completed.length ?? 0) >= 1,
      ) && s.typingHistory.length >= 1,
  },
];

export function unlockedAchievements(s: HelixState): Achievement[] {
  return ACHIEVEMENTS.filter((a) => a.test(s));
}
