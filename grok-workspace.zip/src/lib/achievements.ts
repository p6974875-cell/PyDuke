export interface AchievementSnap {
  lessonsCompleted: string[];
  games: Record<string, { completed: string[] } | undefined>;
  typingHistory: unknown[];
  topics: Record<string, { completedExercises: string[] }>;
  streak: number;
  projectsCompleted: string[];
  dailyCompletions: number;
}

export interface AchievementDef {
  id: string;
  title: string;
  blurb: string;
  xp: number;
  earned: (s: AchievementSnap) => boolean;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: "first-lesson",
    title: "First Lesson",
    blurb: "Complete your first lesson.",
    xp: 20,
    earned: (s) => s.lessonsCompleted.length >= 1,
  },
  {
    id: "five-lessons",
    title: "Getting fluent",
    blurb: "Master five lessons.",
    xp: 40,
    earned: (s) => s.lessonsCompleted.length >= 5,
  },
  {
    id: "bug-hunter",
    title: "Bug Hunter",
    blurb: "Fix 10 debugging challenges.",
    xp: 50,
    earned: (s) => (s.games.debug?.completed.length ?? 0) >= 10,
  },
  {
    id: "python-typist",
    title: "Python Typist",
    blurb: "Complete 5 typing sessions.",
    xp: 30,
    earned: (s) => s.typingHistory.length >= 5,
  },
  {
    id: "code-runner",
    title: "Code Runner",
    blurb: "Pass 10 coding exercises.",
    xp: 40,
    earned: (s) =>
      Object.values(s.topics).reduce((n, t) => n + t.completedExercises.length, 0) >= 10,
  },
  {
    id: "seven-day",
    title: "7 Day Streak",
    blurb: "Study for 7 consecutive days.",
    xp: 60,
    earned: (s) => s.streak >= 7,
  },
  {
    id: "fixer-five",
    title: "Syntax surgeon",
    blurb: "Clear 5 Code Fixer challenges.",
    xp: 25,
    earned: (s) => (s.games.fixer?.completed.length ?? 0) >= 5,
  },
  {
    id: "boss-clear",
    title: "Boss down",
    blurb: "Finish the boss battle.",
    xp: 80,
    earned: (s) => (s.games.boss?.completed.length ?? 0) >= 8,
  },
  {
    id: "first-project",
    title: "Builder",
    blurb: "Complete a guided project.",
    xp: 35,
    earned: (s) => s.projectsCompleted.length >= 1,
  },
  {
    id: "daily-three",
    title: "Showed up",
    blurb: "Finish daily practice 3 times.",
    xp: 30,
    earned: (s) => s.dailyCompletions >= 3,
  },
];
