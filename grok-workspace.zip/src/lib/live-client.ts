function floatToPcm16(input: Float32Array, fromRate: number, toRate: number): Int16Array {
  const ratio = fromRate / toRate;
  const outLen = Math.max(1, Math.floor(input.length / ratio));
  const out = new Int16Array(outLen);
  for (let i = 0; i < outLen; i++) {
    const s = Math.max(-1, Math.min(1, input[Math.min(input.length - 1, Math.floor(i * ratio))] ?? 0));
    out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return out;
}

function pcm16ToFloat(bytes: Uint8Array): Float32Array {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const n = Math.floor(bytes.byteLength / 2);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    out[i] = view.getInt16(i * 2, true) / 0x8000;
  }
  return out;
}

function toB64(pcm: Int16Array): string {
  const u8 = new Uint8Array(pcm.buffer, pcm.byteOffset, pcm.byteLength);
  let s = "";
  const chunk = 0x8000;
  for (let i = 0; i < u8.length; i += chunk) {
    s += String.fromCharCode(...u8.subarray(i, i + chunk));
  }
  return btoa(s);
}

function fromB64(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export type LiveStatus = "idle" | "connecting" | "live" | "error" | "ended";

export interface LiveEvents {
  onStatus: (s: LiveStatus, detail?: string) => void;
  onTranscript: (who: "you" | "tutor", text: string) => void;
  onSpeaking: (speaking: boolean) => void;
}

export class GeminiLiveSession {
  private ws: WebSocket | null = null;
  private recCtx: AudioContext | null = null;
  private playCtx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private worklet: AudioWorkletNode | null = null;
  private sources: AudioBufferSourceNode[] = [];
  private nextPlay = 0;
  private muted = false;
  private closed = false;

  constructor(
    private readonly events: LiveEvents,
    private readonly system: string,
    private readonly model: string,
  ) {}

  async start(wsUrl: string) {
    this.closed = false;
    this.events.onStatus("connecting");
    this.ws = new WebSocket(wsUrl);
    this.ws.addEventListener("open", () => {
      this.ws?.send(
        JSON.stringify({
          setup: {
            model: `models/${this.model}`,
            generationConfig: {
              responseModalities: ["AUDIO"],
              speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } },
              },
            },
            systemInstruction: { parts: [{ text: this.system }] },
            inputAudioTranscription: {},
            outputAudioTranscription: {},
          },
        }),
      );
    });
    this.ws.addEventListener("message", (ev) => {
      void this.onMessage(ev.data);
    });
    this.ws.addEventListener("error", () => {
      if (!this.closed) this.events.onStatus("error", "The live connection dropped.");
    });
    this.ws.addEventListener("close", () => {
      if (!this.closed) this.events.onStatus("ended");
    });
    await this.startMic();
    this.events.onStatus("live");
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    this.stream?.getAudioTracks().forEach((t) => {
      t.enabled = !muted;
    });
  }

  stop() {
    this.closed = true;
    this.worklet?.port.close();
    this.worklet?.disconnect();
    this.stream?.getTracks().forEach((t) => t.stop());
    this.sources.forEach((s) => {
      try {
        s.stop();
      } catch {
        /* already stopped */
      }
    });
    this.sources = [];
    void this.recCtx?.close();
    void this.playCtx?.close();
    this.recCtx = null;
    this.playCtx = null;
    this.stream = null;
    this.worklet = null;
    try {
      this.ws?.close();
    } catch {
      /* ignore */
    }
    this.ws = null;
    this.events.onStatus("ended");
  }

  private async startMic() {
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 },
      video: false,
    });
    this.recCtx = new AudioContext();
    const src = this.recCtx.createMediaStreamSource(this.stream);
    const workletCode = `
      class Cap extends AudioWorkletProcessor {
        process(inputs) {
          const ch = inputs[0] && inputs[0][0];
          if (ch && ch.length) this.port.postMessage(ch);
          return true;
        }
      }
      registerProcessor('pyduke-cap', Cap);
    `;
    const blob = new Blob([workletCode], { type: "application/javascript" });
    const url = URL.createObjectURL(blob);
    await this.recCtx.audioWorklet.addModule(url);
    URL.revokeObjectURL(url);
    this.worklet = new AudioWorkletNode(this.recCtx, "pyduke-cap");
    this.worklet.port.onmessage = (ev) => {
      if (this.muted || this.ws?.readyState !== WebSocket.OPEN) return;
      const pcm = floatToPcm16(ev.data as Float32Array, this.recCtx?.sampleRate ?? 48000, 16000);
      this.ws.send(
        JSON.stringify({
          realtimeInput: {
            audio: { data: toB64(pcm), mimeType: "audio/pcm;rate=16000" },
          },
        }),
      );
    };
    src.connect(this.worklet);
    const mute = this.recCtx.createGain();
    mute.gain.value = 0;
    this.worklet.connect(mute);
    mute.connect(this.recCtx.destination);
  }

  private async onMessage(raw: unknown) {
    let text = "";
    if (typeof raw === "string") text = raw;
    else if (raw instanceof Blob) text = await raw.text();
    else if (raw instanceof ArrayBuffer) text = new TextDecoder().decode(raw);
    else return;
    let msg: Record<string, unknown>;
    try {
      msg = JSON.parse(text) as Record<string, unknown>;
    } catch {
      return;
    }
    if (msg.setupComplete) this.events.onStatus("live");
    const server = msg.serverContent as
      | {
          interrupted?: boolean;
          modelTurn?: { parts?: { text?: string; inlineData?: { data?: string; mimeType?: string } }[] };
          inputTranscription?: { text?: string };
          outputTranscription?: { text?: string };
        }
      | undefined;
    if (server?.interrupted) this.flushPlayback();
    const input = server?.inputTranscription?.text;
    if (input) this.events.onTranscript("you", input);
    const output = server?.outputTranscription?.text;
    if (output) this.events.onTranscript("tutor", output);
    const parts = server?.modelTurn?.parts ?? [];
    for (const part of parts) {
      if (part.text) this.events.onTranscript("tutor", part.text);
      const data = part.inlineData?.data;
      if (data) {
        const mime = part.inlineData?.mimeType ?? "audio/pcm;rate=24000";
        const rateMatch = /rate=(\d+)/.exec(mime);
        const rate = rateMatch ? Number(rateMatch[1]) : 24000;
        this.playPcm(fromB64(data), rate);
      }
    }
  }

  private playPcm(bytes: Uint8Array, rate: number) {
    if (!this.playCtx) this.playCtx = new AudioContext({ sampleRate: rate });
    const ctx = this.playCtx;
    const samples = pcm16ToFloat(bytes);
    const buf = ctx.createBuffer(1, samples.length, rate);
    buf.getChannelData(0).set(samples);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.connect(ctx.destination);
    const now = ctx.currentTime;
    const start = Math.max(now, this.nextPlay);
    src.start(start);
    this.nextPlay = start + buf.duration;
    this.sources.push(src);
    src.onended = () => {
      this.sources = this.sources.filter((s) => s !== src);
      if (this.sources.length === 0) this.events.onSpeaking(false);
    };
    this.events.onSpeaking(true);
  }

  private flushPlayback() {
    this.sources.forEach((s) => {
      try {
        s.stop();
      } catch {
        /* ignore */
      }
    });
    this.sources = [];
    this.nextPlay = this.playCtx?.currentTime ?? 0;
    this.events.onSpeaking(false);
  }
}
