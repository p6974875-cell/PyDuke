import { outputsMatch, runPython, type RunResult } from "@/lib/python-engine";
import type { CodeCheck } from "@/lib/types";

export interface GradeResult {
  passed: boolean;
  run: RunResult;
  message: string;
}

export async function gradeCode(
  code: string,
  checks: CodeCheck[],
  stdin = "",
): Promise<GradeResult> {
  if (!checks.length) {
    const run = await runPython(code, stdin);
    return {
      passed: run.ok,
      run,
      message: run.ok ? "Ran without error." : run.error,
    };
  }

  let last: RunResult | null = null;
  for (const check of checks) {
    const input = check.stdin ?? stdin;
    let source = code;
    if (check.kind === "equals" && check.expr) {
      source = `${code}\nprint(repr(${check.expr}))`;
    }
    const run = await runPython(source, input);
    last = run;
    if (check.kind === "no_error") {
      if (!run.ok) {
        return { passed: false, run, message: run.error || "The program raised an error." };
      }
      continue;
    }
    if (!run.ok && check.kind !== "contains") {
      return { passed: false, run, message: run.error || "The program raised an error." };
    }
    if (check.kind === "stdout" && check.expected !== undefined) {
      if (!outputsMatch(run.stdout, check.expected)) {
        return {
          passed: false,
          run,
          message: `Expected:\n${check.expected}\n\nGot:\n${run.stdout || "(empty)"}`,
        };
      }
    }
    if (check.kind === "equals" && check.expected !== undefined) {
      const got = run.stdout.trim();
      const exp = check.expected.trim();
      if (got !== exp && got !== `'${exp}'` && got !== `"${exp}"`) {
        return {
          passed: false,
          run,
          message: `Expected ${exp}, got ${got || "(empty)"}`,
        };
      }
    }
    if (check.kind === "contains" && check.expected) {
      if (!run.stdout.includes(check.expected) && !run.ok) {
        return { passed: false, run, message: run.error || "Output did not match." };
      }
      if (!run.stdout.includes(check.expected)) {
        return {
          passed: false,
          run,
          message: `Output should contain ${check.expected}. Got:\n${run.stdout || "(empty)"}`,
        };
      }
    }
  }
  return {
    passed: true,
    run: last!,
    message: "That matches what Python should do.",
  };
}
