import { createServerFn } from "@tanstack/react-start";
import { geminiKey, geminiLiveModel } from "@/lib/gemini.server";

export const tutorAvailability = createServerFn({ method: "GET" }).handler(async () => {
  const gemini = Boolean(geminiKey());
  return {
    gemini,
    live: gemini,
    xai: Boolean(process.env.XAI_API_KEY?.trim()),
    chatModel: process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash",
    liveModel: geminiLiveModel(),
  };
});

export const createLiveSessionToken = createServerFn({ method: "POST" })
  .validator((input: { progressSummary?: string }) => input)
  .handler(async ({ data }) => {
    const apiKey = geminiKey();
    if (!apiKey) {
      return { ok: false as const, error: "GEMINI_API_KEY is not configured on the server." };
    }

    const model = geminiLiveModel();
    const expire = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    const newSession = new Date(Date.now() + 60 * 1000).toISOString();

    const res = await fetch("https://generativelanguage.googleapis.com/v1alpha/auth_tokens", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey,
      },
      body: JSON.stringify({
        uses: 1,
        expireTime: expire,
        newSessionExpireTime: newSession,
        liveConnectConstraints: {
          model: model.startsWith("models/") ? model : `models/${model}`,
          config: {
            responseModalities: ["AUDIO"],
          },
        },
      }),
    });

    if (!res.ok) {
      const retry = await fetch("https://generativelanguage.googleapis.com/v1beta/auth_tokens", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          uses: 1,
          expireTime: expire,
          newSessionExpireTime: newSession,
        }),
      });
      if (!retry.ok) {
        const detail = await retry.text().catch(() => "");
        return {
          ok: false as const,
          error: `Could not mint a Live session token (${retry.status}). ${detail.slice(0, 200)}`,
        };
      }
      const body = (await retry.json()) as { name?: string; authToken?: { name?: string } };
      const token = body.name || body.authToken?.name;
      if (!token) return { ok: false as const, error: "Live token response was empty." };
      return {
        ok: true as const,
        token,
        model,
        instruction: liveSystem(data.progressSummary ?? ""),
      };
    }

    const body = (await res.json()) as { name?: string; authToken?: { name?: string } };
    const token = body.name || body.authToken?.name;
    if (!token) return { ok: false as const, error: "Live token response was empty." };
    return {
      ok: true as const,
      token,
      model,
      instruction: liveSystem(data.progressSummary ?? ""),
    };
  });

function liveSystem(progress: string) {
  return `You are PyDuke, a live spoken Python tutor. Keep replies short enough to say aloud (about 20–40 seconds). Teach; do not dump full exercise solutions unless the learner has already tried and asks to see one. Use standard terms once, then plain language. Learner progress:\n${progress.slice(0, 1200)}`;
}
