import { createServerFn } from "@tanstack/react-start";
import { mintLiveToken } from "@/lib/gemini.server";

export const createLiveSession = createServerFn({ method: "POST" }).handler(async () => {
  const minted = await mintLiveToken();
  if (!minted.ok) {
    return {
      ok: false as const,
      error:
        minted.error === "missing-key"
          ? "missing-key"
          : minted.error,
    };
  }

  const wsUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained?access_token=${encodeURIComponent(minted.token)}`;

  return {
    ok: true as const,
    wsUrl,
    model: minted.model,
  };
});
