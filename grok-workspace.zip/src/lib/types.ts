export type Difficulty = "easy" | "medium" | "hard" | "advanced";

export type TopicStatus = "locked" | "available" | "in_progress" | "review" | "mastered";

export type TopicId =
  | "variables"
  | "io"
  | "operators"
  | "conditions"
  | "loops"
  | "lists"
  | "tuples"
  | "sets"
  | "dictionaries"
  | "strings"
  | "functions"
  | "scope"
  | "errors"
  | "modules"
  | "files"
  | "oop"
  | "stdlib"
  | "apis"
  | "projects"
  | "advanced";

export interface Topic {
  id: TopicId;
  number: number;
  title: string;
  subtitle: string;
  blurb: string;
  level: 1 | 2 | 3 | 4 | 5;
}

export type CheckKind = "stdout" | "equals" | "contains" | "no_error";

export interface CodeCheck {
  kind: CheckKind;
  expected?: string;
  expr?: string;
  stdin?: string;
  label?: string;
}

export interface Exercise {
  id: string;
  title: string;
  prompt: string;
  difficulty: Difficulty;
  starter: string;
  solution: string;
  explanation: string;
  hint?: string;
  checks: CodeCheck[];
  optional?: boolean;
}

export interface CodeExample {
  title: string;
  code: string;
  why: string;
  output?: string;
}

export interface Mistake {
  wrong: string;
  right: string;
  why: string;
}

export interface Lesson {
  topicId: TopicId;
  revision: { heading: string; body: string; code?: string };
  concept: {
    heading: string;
    explanation: string;
    definition: string;
    analogy: string;
  };
  examples: CodeExample[];
  mistakes: Mistake[];
  think?: { question: string; answer: string };
  realWorld?: { heading: string; body: string; code?: string };
  review?: string[];
  exercises: Exercise[];
}

export interface GameItem {
  id: string;
  difficulty: Difficulty;
  title: string;
  prompt: string;
  code?: string;
  lines?: string[];
  starter?: string;
  solution?: string;
  expected?: string;
  explanation: string;
  hint?: string;
  checks?: CodeCheck[];
  kind?: "code" | "predict" | "order" | "mcq";
  choices?: string[];
  answer?: string;
}

export type GameId =
  | "fixer"
  | "predict"
  | "ordering"
  | "typing"
  | "debug"
  | "build"
  | "boss";

export interface GameMeta {
  id: GameId;
  title: string;
  blurb: string;
  topicHint: string;
}

export interface ProjectStep {
  title: string;
  body: string;
}

export interface Project {
  id: string;
  title: string;
  blurb: string;
  concepts: TopicId[];
  difficulty: Difficulty;
  steps: ProjectStep[];
  starter: string;
  solution: string;
  checks: CodeCheck[];
  explanation: string;
}

export interface TypingDrill {
  id: string;
  title: string;
  focus: string;
  code: string;
}

export interface TopicProgress {
  status: TopicStatus;
  score: number;
  attempts: number;
  lastSeenAt: number;
  completedExercises: string[];
  mistakes: { exerciseId: string; note: string; at: number }[];
}

export interface TypingRecord {
  at: number;
  wpm: number;
  cpm: number;
  accuracy: number;
  errors: number;
  chars: number;
  drillId: string;
}

export interface SavedSnippet {
  id: string;
  title: string;
  code: string;
  at: number;
}

export interface GameProgress {
  completed: string[];
  best: Record<string, number>;
  attempts: number;
  correct: number;
  streak: number;
  bestStreak: number;
  lastScore: number;
  bestScore: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  at: number;
}
