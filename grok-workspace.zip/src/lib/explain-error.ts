export function explainError(error: string, code: string): string[] {
  const e = error.trim();
  const steps: string[] = [];
  steps.push(`What you wrote is a program Python tried to compile and run.`);
  if (/SyntaxError/i.test(e)) {
    steps.push(`Python interpreted it as invalid syntax — the grammar of the language was broken.`);
    if (/colon/i.test(e) || /expected ':'/i.test(e)) {
      steps.push(`What went wrong: a header such as if, for, def, or while is missing its colon.`);
      steps.push(`How to fix it: end that line with \`:\` and indent the body.`);
    } else if (/EOL|unterminated/i.test(e)) {
      steps.push(`What went wrong: a string was opened and never closed on that line.`);
      steps.push(`How to fix it: match quotes — "..." or '...' — on the same line, or use a triple-quoted string.`);
    } else {
      steps.push(`What went wrong: ${e}`);
      steps.push(`How to fix it: read the caret in the traceback — it points at the first token Python could not accept.`);
    }
  } else if (/IndentationError|TabError/i.test(e)) {
    steps.push(`Python interpreted indentation as the block structure of the program.`);
    steps.push(`What went wrong: spaces and tabs mixed, or a line at the wrong indent level.`);
    steps.push(`How to fix it: indent with 4 spaces, consistently, one level per block.`);
  } else if (/NameError/i.test(e)) {
    const m = e.match(/name '([^']+)'/);
    steps.push(`Python looked up a name and did not find it in local, global, or builtin scope.`);
    steps.push(`What went wrong: ${m ? `\`${m[1]}\` was used before it was bound` : "an unbound name"}.`);
    steps.push(`How to fix it: bind the name first, or check spelling. Names are case-sensitive.`);
  } else if (/TypeError/i.test(e)) {
    steps.push(`Python applied an operation to a value whose type does not support it.`);
    if (/can only concatenate str/i.test(e) || /unsupported operand/i.test(e)) {
      steps.push(`What went wrong: two types were combined that do not share that operator (often str + int).`);
      steps.push(`How to fix it: convert with int(), str(), or float() so both sides match.`);
    } else if (/NoneType/i.test(e)) {
      steps.push(`What went wrong: a name holds None — often because a mutating method like append returned None.`);
      steps.push(`How to fix it: call the mutator, then use the object; do not assign the return value.`);
    } else {
      steps.push(`What went wrong: ${e}`);
      steps.push(`How to fix it: print(type(x)) for the values in the expression and convert as needed.`);
    }
  } else if (/KeyError/i.test(e)) {
    steps.push(`Python looked up a dictionary key that is not present.`);
    steps.push(`What went wrong: ${e}`);
    steps.push(`How to fix it: use d.get(key, default) when absence is normal, or test \`key in d\` first.`);
  } else if (/IndexError/i.test(e)) {
    steps.push(`Python asked for a sequence index that does not exist.`);
    steps.push(`What went wrong: ${e}`);
    steps.push(`How to fix it: valid indices are 0 .. len(seq)-1. Check length before indexing.`);
  } else if (/AttributeError/i.test(e)) {
    steps.push(`Python asked an object for an attribute or method it does not have.`);
    steps.push(`What went wrong: ${e}`);
    steps.push(`How to fix it: confirm the type (a list has append, a string does not in the same way you might think — strings use other methods).`);
  } else if (/ValueError/i.test(e)) {
    steps.push(`The type was right, the value was not (for example int('q')).`);
    steps.push(`What went wrong: ${e}`);
    steps.push(`How to fix it: validate or convert inside try/except ValueError.`);
  } else if (/ImportError|ModuleNotFoundError/i.test(e)) {
    steps.push(`Python could not load a module.`);
    steps.push(`What went wrong: ${e}`);
    steps.push(`How to fix it: in PyDuke, OS and network modules are blocked. Use math, json, random, datetime, collections, or pyduke_net.`);
  } else if (/Timed out/i.test(e)) {
    steps.push(`The program did not finish in time.`);
    steps.push(`What went wrong: a loop condition never became false, or work was unbounded.`);
    steps.push(`How to fix it: make sure a while-loop changes its condition, or use a for-loop over a finite iterable.`);
  } else {
    steps.push(`Python reported: ${e || "no error message"}`);
    steps.push(`What went wrong is in that message — it names the exception type.`);
    steps.push(`How to fix it: match the type to the object you passed, then change the value or the call.`);
  }
  const snippet = code.trim().split("\n").slice(0, 4).join(" / ");
  if (snippet) {
    steps.unshift(`A look at the start of your code: ${snippet}${code.trim().split("\n").length > 4 ? " …" : ""}`);
  }
  steps.push(`The corrected version works because it agrees with Python's rules for types, names, and syntax — not because of a special trick.`);
  return steps;
}

export function localTutorReply(question: string, progress: string): string {
  const q = question.toLowerCase();
  if (/tuple/.test(q) && /modif|mutat|chang|append/.test(q)) {
    return "A tuple is an immutable sequence: you cannot assign to an index or call append on it. Python protects the bindings, not inner mutable objects. To 'change' a tuple you build a new one, for example `t = (9,) + t[1:]`. Lists are the mutable counterpart. You already know lists; reach for a tuple when the collection is a fixed record.";
  }
  if (/loop stop|infinite|while/.test(q)) {
    return "A while-loop stops when its condition becomes false, or when you `break`. If the body never updates the values used in the condition, it never stops. A for-loop over a finite iterable (`range`, a list) always ends. If you expected a for-loop to stop early, check `break` and any `if` that was meant to skip with `continue`.";
  }
  if (/dict/.test(q)) {
    return "A dictionary maps hashable keys to values. You look up with `d[key]` or `d.get(key, default)`. Iterating `d` yields keys; use `.items()` for pairs. Keys must be hashable — strings, numbers, tuples of hashables — not lists.";
  }
  if (/list/.test(q) && /copy|append|comprehens/.test(q)) {
    return "You already know lists. The extra layer: `b = a` aliases, `a[:]` shallow-copies, `append` returns None, and `[expr for x in xs if cond]` builds a new list. Mutating a list while you iterate it skips items — build a new one instead.";
  }
  if (/error|traceback|exception/.test(q)) {
    return "Read the last line of the traceback first: it is `TypeName: message`. The type says which rule was broken (NameError, TypeError, SyntaxError…). The lines above it are the call stack — your file is usually at the bottom. Fix the named rule, then rerun. I can walk a specific error if you paste it.";
  }
  if (/start|beginner|new to python|first lesson/.test(q)) {
    return "Start at lesson 1 — Variables & data types — then Input & output, Operators, Conditions, and Loops. Each lesson unlocks the next. Use the playground to try a line the moment you read it. Games (Code Fixer, Predict the output) lock the idea in. Accuracy before speed in the typing trainer.";
  }
  if (/harder|challenge|difficult/.test(q)) {
    return "Try a nested list comprehension, a dict of tuples as keys, or a tiny class with an invariant (a Vault that cannot go negative). The Build it game and Boss battle level 7 mix these. Accuracy before speed — especially in the typing trainer.";
  }
  if (/revis|yesterday|forgot/.test(q)) {
    return `Spaced revision is on. PyDuke will surface older mastered topics when they go quiet. From your progress:\n${progress}\nOpen Learn and look for anything marked Review, or replay a Predict-the-output card on an older idea (loops, conditions).`;
  }
  return `I will keep this tied to where you actually are.\n\n${progress}\n\nAsk a concrete question about a line, an error, or a concept (for example “why can't I modify this tuple?”) and I will answer with a definition, a small example, and the mistake to avoid. I will not dump a full solution before you have tried.`;
}
