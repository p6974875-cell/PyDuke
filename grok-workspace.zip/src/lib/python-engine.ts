export interface RunResult {
  ok: boolean;
  stdout: string;
  stderr: string;
  error: string;
  durationMs: number;
  timedOut?: boolean;
}

type Pending = {
  resolve: (r: RunResult) => void;
  started: number;
  timer: ReturnType<typeof setTimeout>;
};

let worker: Worker | null = null;
let ready: Promise<void> | null = null;
let seq = 0;
const pending = new Map<number, Pending>();

const TIMEOUT_MS = 8000;

function recreate() {
  if (worker) {
    worker.terminate();
    worker = null;
  }
  ready = null;
  for (const [id, p] of pending) {
    clearTimeout(p.timer);
    p.resolve({
      ok: false,
      stdout: "",
      stderr: "",
      error: "Python runtime was reset.",
      durationMs: Date.now() - p.started,
      timedOut: true,
    });
    pending.delete(id);
  }
}

function ensureWorker(): Promise<void> {
  if (typeof window === "undefined") {
    return Promise.reject(new Error("Python runs in the browser."));
  }
  if (ready) return ready;
  worker = new Worker("/python-worker.js");
  ready = new Promise((resolve, reject) => {
    const w = worker!;
    const failTimer = setTimeout(() => {
      reject(new Error("Python runtime took too long to load."));
    }, 60000);
    w.onmessage = (ev: MessageEvent) => {
      const msg = ev.data;
      if (msg.type === "ready") {
        clearTimeout(failTimer);
        resolve();
        return;
      }
      if (msg.type === "error") {
        clearTimeout(failTimer);
        reject(new Error(msg.error || "Python failed to load"));
        return;
      }
      if (msg.type === "result") {
        const p = pending.get(msg.id);
        if (!p) return;
        clearTimeout(p.timer);
        pending.delete(msg.id);
        p.resolve({
          ok: Boolean(msg.ok),
          stdout: msg.stdout ?? "",
          stderr: msg.stderr ?? "",
          error: msg.error ?? "",
          durationMs: Date.now() - p.started,
        });
      }
    };
    w.onerror = (e) => {
      clearTimeout(failTimer);
      reject(new Error(e.message || "Python worker error"));
    };
    w.postMessage({ type: "boot" });
  });
  return ready;
}

export async function warmupPython() {
  await ensureWorker();
}

export async function runPython(code: string, stdin = ""): Promise<RunResult> {
  const started = Date.now();
  await ensureWorker();
  const id = ++seq;
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      recreate();
      resolve({
        ok: false,
        stdout: "",
        stderr: "",
        error: "Timed out after 8 seconds. Check for an infinite loop.",
        durationMs: Date.now() - started,
        timedOut: true,
      });
      void ensureWorker();
    }, TIMEOUT_MS);
    pending.set(id, { resolve, started, timer });
    worker!.postMessage({ type: "run", id, code, stdin });
  });
}

export function normalizeOutput(s: string) {
  return s.replace(/\r\n/g, "\n").replace(/\s+$/g, "").replace(/^\s+/g, "");
}

export function outputsMatch(got: string, expected: string) {
  return normalizeOutput(got) === normalizeOutput(expected);
}
