# PyDuke setup

PyDuke is a free Python tutor. No accounts. Progress is stored in the browser.

## 1. Install

```bash
npm install
```

## 2. Environment

Copy `.env.example` to `.env` and add your Gemini key. Do not put the key in frontend code or any `VITE_` variable.

```
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-flash-latest
GEMINI_LIVE_MODEL=gemini-3.8-live
```

On Vercel / production, set the same names as server environment variables.

## 3. Run

```bash
npm run dev
```

The app serves on port 8080.

## 4. Test AI Tutor

Open Tutor, send “What is a decorator?”. A real Gemini reply should appear.

## 5. Test Live Tutor

Open Live Tutor → Start live session → allow the microphone → speak a Python question. This uses Gemini Live (ephemeral token minted on the server). The API key never enters the browser.

If Live fails, check `GEMINI_LIVE_MODEL` against current Gemini Live model names.

## Notes

- Python execution is client-side (Pyodide worker). No student code runs on the server.
- All lessons are unlocked.
- `POST /api/ai/chat` and `POST /api/ai/live` are the server endpoints.
