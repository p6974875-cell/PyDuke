# PyDuke setup

PyDuke is a Python learning app: lessons, a browser Python engine, games, typing, progress, a Gemini tutor, and a Gemini Live voice tutor.

## 1. Install

```bash
npm install
```

## 2. Environment (server-side only)

Copy `.env.example` to `.env` and add your Gemini key. Never put the key in React, HTML, or any `VITE_` variable.

```bash
cp .env.example .env
```

Then edit `.env`:

```
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
GEMINI_LIVE_MODEL=gemini-3.8-live
```

| Variable | Required | Used for |
| --- | --- | --- |
| `GEMINI_API_KEY` | For AI Tutor + Live Tutor | Google Gemini API (text + Live WebSocket via ephemeral tokens) |
| `GEMINI_MODEL` | No | Chat model. Default `gemini-2.5-flash` |
| `GEMINI_LIVE_MODEL` | No | Live voice model. Default `gemini-3.8-live` |

The key is read only in server functions (`src/lib/ask-tutor.ts`, `src/lib/tutor-live.ts`). Live Tutor mints a short-lived ephemeral token; the browser never receives the permanent key.

## 3. Run

```bash
npm run dev
```

The app listens on port 8080.

## 4. Test AI Tutor

1. Open **Tutor**.
2. Send “Teach me loops.”
3. You should see a streamed-style reply (full message) from Gemini.
4. If the key is missing, the page says the tutor is unavailable — it will not pretend.

## 5. Test Live Tutor

1. Open **Tutor → Live**.
2. Click **Start live session** and allow the microphone.
3. Speak a Python question. You should hear Gemini reply.
4. Mute / unmute / end session work.
5. If the key is missing, Live Tutor stays disabled with setup instructions.

## 6. Production build

```bash
npm run build
```

Set the same env vars on the host (Vercel project env, etc.). Do not bake the key into the client bundle.
