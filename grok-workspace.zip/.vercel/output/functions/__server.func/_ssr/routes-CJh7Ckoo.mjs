import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { M as BookOpen, P as ArrowRight, a as Terminal, b as Keyboard, d as Puzzle, j as CalendarDays, m as Mic } from "../_libs/lucide-react.mjs";
import { C as xpIntoLevel, S as todayKey, _ as Progress, c as useHelix, f as TOPICS, l as ACHIEVEMENTS, o as dueTopicIds, p as TOPIC_BY_ID, v as Button, x as levelFromXp } from "./router-C24WQtVx.mjs";
import { t as Input } from "./input-CrCa6m5Z.mjs";
import { t as DAILY_SLOTS } from "./daily-DVWe61-s.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, r as CardDescription, t as Card } from "./card-Be_eRrus.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CJh7Ckoo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const name = useHelix((s) => s.name);
	const setName = useHelix((s) => s.setName);
	const xp = useHelix((s) => s.xp);
	const streak = useHelix((s) => s.streak);
	const current = useHelix((s) => s.currentTopicId);
	const topics = useHelix((s) => s.topics);
	const dailyDate = useHelix((s) => s.dailyDate);
	const dailyDone = useHelix((s) => s.dailyDone);
	const earned = useHelix((s) => s.achievements);
	const due = (0, import_react.useMemo)(() => dueTopicIds(topics), [topics]);
	const topic = TOPIC_BY_ID[current];
	const mastered = TOPICS.filter((t) => topics[t.id].status === "mastered").length;
	const greeting = name ? `Welcome back, ${name}.` : "Learn Python by writing it.";
	const [draft, setDraft] = (0, import_react.useState)("");
	const doneToday = dailyDate === todayKey() ? dailyDone.length : 0;
	const recentAch = ACHIEVEMENTS.filter((a) => earned.includes(a.id)).slice(-3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "helix-enter",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl font-medium tracking-tight sm:text-4xl",
						children: greeting
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground",
						children: "Twenty lessons, a real Python engine in the browser, games that grade your code, typing for the punctuation that trips people up, and a Gemini tutor. Short sessions. Write more than you read."
					})
				]
			}),
			!name ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex max-w-md flex-col gap-2 sm:flex-row helix-enter helix-enter-delay-1",
				onSubmit: (e) => {
					e.preventDefault();
					const v = draft.trim();
					if (v) setName(v);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft,
					onChange: (e) => setDraft(e.target.value),
					placeholder: "What should PyDuke call you?",
					"aria-label": "Your name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "secondary",
					disabled: !draft.trim(),
					children: "Save name"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3 helix-enter helix-enter-delay-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Level",
						value: String(levelFromXp(xp)),
						hint: `${xpIntoLevel(xp)} / 150 XP`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Streak",
						value: String(streak),
						hint: "days in a row"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Mastered",
						value: `${mastered}/${TOPICS.length}`,
						hint: "topics locked in"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "helix-enter helix-enter-delay-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Continue learning" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDescription, { children: [
					"Lesson ",
					topic.number,
					" · ",
					topic.title
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: topic.blurb
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: topics[current].score }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/learn/$topicId",
								params: { topicId: current },
								children: ["Open lesson", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/practice",
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4 text-accent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-medium",
							children: "Daily practice"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [
								doneToday,
								"/",
								DAILY_SLOTS.length,
								" slots today. Concepts, output, debug, code, typing."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: doneToday / DAILY_SLOTS.length * 100,
							className: "mt-3"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/tutor/live",
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4 text-accent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-medium",
							children: "Live Tutor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Speak with Gemini Live. The API key stays on the server."
						})
					]
				})]
			}),
			due.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Due for revision"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Older mastered topics come back after about a day and a half. Misses are preferred."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2 sm:grid-cols-2",
						children: due.slice(0, 4).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/learn/$topicId",
							params: { topicId: id },
							className: "rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
							children: TOPIC_BY_ID[id].title
						}, id))
					})
				]
			}) : null,
			recentAch.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Achievements"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-wrap gap-2",
					children: recentAch.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-full bg-secondary px-3 py-1 text-xs",
						children: a.title
					}, a.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/learn",
						icon: BookOpen,
						title: "Learn",
						body: "Twenty topics, from names to generators."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/code",
						icon: Terminal,
						title: "Code",
						body: "Isolated Python playground."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/games",
						icon: Puzzle,
						title: "Games",
						body: "Fix, predict, order, debug, build, boss."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/typing",
						icon: Keyboard,
						title: "Typing",
						body: "Accuracy first, then speed."
					})
				]
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-2xl tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
function Jump({ to, icon: Icon, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: body
			})
		]
	});
}
//#endregion
export { Home as component };
