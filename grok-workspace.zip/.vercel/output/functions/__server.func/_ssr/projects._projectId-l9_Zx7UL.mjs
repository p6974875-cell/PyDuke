import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { f as Play } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useHelix, n as Route$1, v as Button } from "./router-C24WQtVx.mjs";
import { n as PythonOutput, t as CodeEditor } from "./python-output-BJIiscp_.mjs";
import { t as gradeCode } from "./grade-cXt9EkQb.mjs";
import { t as PROJECTS } from "./projects-MJ1LfonC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects._projectId-l9_Zx7UL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProjectPage() {
	const { projectId } = Route$1.useParams();
	const project = PROJECTS.find((p) => p.id === projectId);
	if (!project) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Unknown project. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/projects",
		children: "Back"
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectStudio, { project });
}
function ProjectStudio({ project }) {
	const [code, setCode] = (0, import_react.useState)(project.starter);
	const [result, setResult] = (0, import_react.useState)(null);
	const [msg, setMsg] = (0, import_react.useState)("");
	const [ok, setOk] = (0, import_react.useState)(false);
	const [attempted, setAttempted] = (0, import_react.useState)(false);
	const [show, setShow] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	const complete = useHelix((s) => s.completeProject);
	const done = useHelix((s) => s.projectsCompleted.includes(project.id));
	async function check() {
		setRunning(true);
		try {
			const g = await gradeCode(code, project.checks);
			setResult(g.run);
			setMsg(g.message);
			setOk(g.passed);
			setAttempted(true);
			if (g.passed) {
				complete(project.id);
				toast("Project complete");
			}
		} finally {
			setRunning(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/projects",
					className: "text-xs text-muted-foreground",
					children: "Projects"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-medium tracking-tight",
					children: project.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: project.blurb
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "grid gap-3 sm:grid-cols-3",
				children: project.steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-muted-foreground",
							children: String(i + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-medium",
							children: s.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: s.body
						})
					]
				}, s.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
				value: code,
				onChange: setCode,
				onRun: check,
				minHeight: 260
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: check,
						disabled: running,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Run & check"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						disabled: !attempted,
						onClick: () => setShow(true),
						children: "Compare"
					}),
					done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "self-center text-xs text-success",
						children: "Completed"
					}) : null
				]
			}),
			msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: ok ? "text-sm text-success" : "text-sm text-destructive",
				children: msg
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonOutput, {
				result,
				code
			}),
			show ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-xl bg-secondary p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "overflow-x-auto font-mono text-[13px]",
					children: project.solution
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: project.explanation
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Write a solution before comparing."
			})
		]
	});
}
//#endregion
export { ProjectPage as component };
