import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as LiveTutor } from "./live-tutor-DPjoIRlS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/live-tutor-DP2wcxCc.js
var import_jsx_runtime = require_jsx_runtime();
function LiveTutorPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
				children: "Live"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-medium tracking-tight",
				children: "Live tutor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: [
					"Speak with Gemini Live about any Python topic. Prefer typing?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tutor",
						className: "text-accent",
						children: "Open chat"
					}),
					"."
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveTutor, {})]
	});
}
//#endregion
export { LiveTutorPage as component };
