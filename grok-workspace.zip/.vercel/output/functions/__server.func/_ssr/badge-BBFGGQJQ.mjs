import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-fNW1Yxkl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-BBFGGQJQ.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-secondary text-foreground",
		accent: "bg-accent text-accent-foreground",
		outline: "shadow-[var(--shadow-border)] text-muted-foreground",
		success: "bg-success/15 text-success",
		warning: "bg-warning/15 text-warning",
		danger: "bg-destructive/15 text-destructive",
		easy: "bg-easy/15 text-easy",
		medium: "bg-medium/15 text-medium",
		hard: "bg-hard/15 text-hard",
		advanced: "bg-advanced/15 text-advanced"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Badge as t };
