import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as xpIntoLevel, n as levelFromXp, t as cn } from "./utils-fNW1Yxkl.mjs";
import { a as TOPIC_BY_ID, c as useHelix, i as TOPICS, o as dueTopicIds } from "./store-CUZplCsw.mjs";
import { D as ArrowRight, E as BookOpen, a as Sun, d as Phone, h as MessageSquare, i as Terminal, l as Puzzle, v as Keyboard } from "../_libs/lucide-react.mjs";
import { c as Button, s as Progress } from "./router-CYzlBSjl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DkixebfF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Card = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("rounded-xl bg-card text-card-foreground shadow-[var(--shadow-border)]", className),
	...props
}));
Card.displayName = "Card";
var CardHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex flex-col gap-1.5 p-5", className),
	...props
}));
CardHeader.displayName = "CardHeader";
var CardTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
	ref,
	className: cn("font-display text-lg font-medium leading-snug tracking-tight", className),
	...props
}));
CardTitle.displayName = "CardTitle";
var CardDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
CardDescription.displayName = "CardDescription";
var CardContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("p-5 pt-0", className),
	...props
}));
CardContent.displayName = "CardContent";
var CardFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex items-center p-5 pt-0", className),
	...props
}));
CardFooter.displayName = "CardFooter";
function Home() {
	const name = useHelix((s) => s.name);
	const xp = useHelix((s) => s.xp);
	const streak = useHelix((s) => s.streak);
	const current = useHelix((s) => s.currentTopicId);
	const topics = useHelix((s) => s.topics);
	const due = (0, import_react.useMemo)(() => dueTopicIds(topics), [topics]);
	const topic = TOPIC_BY_ID[current];
	const mastered = TOPICS.filter((t) => topics[t.id].status === "mastered").length;
	const greeting = name ? `Welcome back, ${name}.` : "Welcome back.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "helix-enter",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl font-medium tracking-tight sm:text-4xl",
						children: greeting
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground",
						children: "You already know lists. Open any lesson — nothing is locked. Practice, play, type, and ask the tutor about any Python topic."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3 helix-enter helix-enter-delay-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Level",
						value: String(levelFromXp(xp)),
						hint: `${xpIntoLevel(xp)} / 150 XP`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Streak",
						value: String(streak),
						hint: "days in a row"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Mastered",
						value: `${mastered}/${TOPICS.length}`,
						hint: "topics locked in"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "helix-enter helix-enter-delay-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Continue learning" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDescription, { children: [
					"Lesson ",
					topic.number,
					" · ",
					topic.title
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: topic.blurb
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: topics[current].score }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/learn/$topicId",
								params: { topicId: current },
								children: ["Open lesson", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})
						})
					]
				})]
			}),
			due.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Due for revision"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Short return visits keep older material alive."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2 sm:grid-cols-2",
						children: due.slice(0, 4).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/learn/$topicId",
							params: { topicId: id },
							className: "tap-card min-h-11 rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
							children: TOPIC_BY_ID[id].title
						}, id))
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/practice",
						icon: Sun,
						title: "Daily practice",
						body: "A set generated from your path."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/learn",
						icon: BookOpen,
						title: "Learn",
						body: "Full curriculum with exercises."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/code",
						icon: Terminal,
						title: "Code",
						body: "Isolated Python playground."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/games",
						icon: Puzzle,
						title: "Games",
						body: "Fix, predict, order, debug, build."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/typing",
						icon: Keyboard,
						title: "Typing",
						body: "Accuracy first, then speed."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/tutor",
						icon: MessageSquare,
						title: "AI tutor",
						body: "Gemini chat with your progress."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jump, {
						to: "/live-tutor",
						icon: Phone,
						title: "Live tutor",
						body: "Speak with Gemini Live."
					})
				]
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-2xl tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
function Jump({ to, icon: Icon, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "tap-card rounded-xl bg-card p-4 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: body
			})
		]
	});
}
//#endregion
export { Home as component };
