import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { h as MicOff, m as Mic, p as PhoneOff, u as Radio } from "../_libs/lucide-react.mjs";
import { c as useHelix, s as progressSummary, v as Button } from "./router-C24WQtVx.mjs";
import { r as tutorAvailability, t as createLiveSessionToken } from "./tutor-live-maIQ3Z4s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tutor.live-XLHRrcFc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LiveTutorSession() {
	const [avail, setAvail] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [heard, setHeard] = (0, import_react.useState)("");
	const [said, setSaid] = (0, import_react.useState)("");
	const wsRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const ctxRef = (0, import_react.useRef)(null);
	const playCtxRef = (0, import_react.useRef)(null);
	const playTimeRef = (0, import_react.useRef)(0);
	const mutedRef = (0, import_react.useRef)(false);
	const audioReadyRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		tutorAvailability().then(setAvail).catch(() => setAvail({ live: false }));
		return () => teardown();
	}, []);
	function teardown() {
		wsRef.current?.close();
		wsRef.current = null;
		streamRef.current?.getTracks().forEach((t) => t.stop());
		streamRef.current = null;
		ctxRef.current?.close();
		ctxRef.current = null;
		playCtxRef.current?.close();
		playCtxRef.current = null;
		playTimeRef.current = 0;
		audioReadyRef.current = false;
	}
	async function start() {
		setError("");
		setStatus("connecting");
		try {
			const tokenRes = await createLiveSessionToken({ data: { progressSummary: progressSummary(useHelix.getState()) } });
			if (!tokenRes.ok) {
				setError(tokenRes.error);
				setStatus("error");
				return;
			}
			const stream = await navigator.mediaDevices.getUserMedia({ audio: {
				echoCancellation: true,
				noiseSuppression: true
			} });
			streamRef.current = stream;
			const model = tokenRes.model.startsWith("models/") ? tokenRes.model : `models/${tokenRes.model}`;
			const token = tokenRes.token;
			const ws = await openSocket(`wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContentConstrained?access_token=${encodeURIComponent(token)}`, `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained?access_token=${encodeURIComponent(token)}`);
			wsRef.current = ws;
			ws.onmessage = async (ev) => {
				const raw = typeof ev.data === "string" ? ev.data : await ev.data.text();
				let msg;
				try {
					msg = JSON.parse(raw);
				} catch {
					return;
				}
				if (msg.setupComplete) {
					audioReadyRef.current = true;
					setStatus("live");
				}
				const sc = msg.serverContent;
				if (sc?.inputTranscription?.text) setHeard((h) => h + sc.inputTranscription.text);
				if (sc?.outputTranscription?.text) setSaid((h) => h + sc.outputTranscription.text);
				const parts = sc?.modelTurn?.parts ?? [];
				for (const p of parts) {
					if (p.text) setSaid((h) => h + p.text);
					if (p.inlineData?.data) playPcm24(p.inlineData.data);
				}
				if (msg.error) {
					const err = msg.error;
					setError(err.message || "Live session error");
				}
			};
			ws.onerror = () => {
				setError("The live connection failed.");
				setStatus("error");
			};
			ws.onclose = () => {
				if (status === "live" || status === "connecting") setStatus("idle");
			};
			ws.send(JSON.stringify({ setup: {
				model,
				generationConfig: {
					responseModalities: ["AUDIO"],
					speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } } }
				},
				systemInstruction: { parts: [{ text: tokenRes.instruction }] },
				inputAudioTranscription: {},
				outputAudioTranscription: {}
			} }));
			const ctx = new AudioContext({ sampleRate: 16e3 });
			ctxRef.current = ctx;
			const source = ctx.createMediaStreamSource(stream);
			const proc = ctx.createScriptProcessor(4096, 1, 1);
			proc.onaudioprocess = (e) => {
				if (!audioReadyRef.current || mutedRef.current || ws.readyState !== WebSocket.OPEN) return;
				const pcm = floatTo16(e.inputBuffer.getChannelData(0));
				ws.send(JSON.stringify({ realtimeInput: { audio: {
					data: u8ToB64(pcm),
					mimeType: "audio/pcm;rate=16000"
				} } }));
			};
			const gain = ctx.createGain();
			gain.gain.value = 0;
			source.connect(proc);
			proc.connect(gain);
			gain.connect(ctx.destination);
			setStatus("live");
		} catch (err) {
			const name = err instanceof DOMException ? err.name : "";
			if (name === "NotAllowedError" || name === "PermissionDeniedError") setError("Microphone permission was denied. Allow the mic in the browser, then start again.");
			else setError(err instanceof Error ? err.message : "Could not start the live session.");
			setStatus("error");
			teardown();
		}
	}
	function playPcm24(b64) {
		const bytes = b64ToU8(b64);
		const ctx = playCtxRef.current ?? new AudioContext({ sampleRate: 24e3 });
		playCtxRef.current = ctx;
		const frames = bytes.byteLength / 2;
		const buf = ctx.createBuffer(1, frames, 24e3);
		const ch = buf.getChannelData(0);
		const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
		for (let i = 0; i < frames; i++) ch[i] = view.getInt16(i * 2, true) / 32768;
		const src = ctx.createBufferSource();
		src.buffer = buf;
		src.connect(ctx.destination);
		const now = ctx.currentTime;
		const startAt = Math.max(now, playTimeRef.current);
		src.start(startAt);
		playTimeRef.current = startAt + buf.duration;
	}
	function end() {
		teardown();
		setStatus("idle");
	}
	if (avail && !avail.live) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]",
		children: [
			"Live Tutor needs a server-side ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
				className: "font-mono text-foreground",
				children: "GEMINI_API_KEY"
			}),
			". Copy ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-foreground",
				children: ".env.example"
			}),
			" to",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-foreground",
				children: ".env"
			}),
			", add the key, and restart. The permanent key never leaves the server — the browser only receives a short-lived Live token."
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: status === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: muted ? "secondary" : "default",
						onClick: () => {
							mutedRef.current = !mutedRef.current;
							setMuted(mutedRef.current);
							streamRef.current?.getAudioTracks().forEach((t) => {
								t.enabled = !mutedRef.current;
							});
						},
						children: [muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" }), muted ? "Unmute" : "Mute"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "destructive",
						onClick: end,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneOff, { className: "size-4" }), "End session"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 text-xs text-success",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-3.5" }), " Live"]
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => void start(),
					disabled: status === "connecting",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" }), status === "connecting" ? "Connecting…" : "Start live session"]
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Gemini Live, voice to voice. Allow the microphone. Speak a Python question; wait for the reply. This is not a text-chat API with a fake voice — it uses Gemini's Live WebSocket."
			}),
			heard || said ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-secondary p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-xs uppercase tracking-wider text-muted-foreground",
						children: "You"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap",
						children: heard || "…"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-card p-3 text-sm shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-xs uppercase tracking-wider text-muted-foreground",
						children: "PyDuke"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap",
						children: said || "…"
					})]
				})]
			}) : null
		]
	});
}
function openSocket(url, fallback) {
	return new Promise((resolve, reject) => {
		const ws = new WebSocket(url);
		let settled = false;
		ws.onopen = () => {
			settled = true;
			resolve(ws);
		};
		ws.onerror = () => {
			if (settled) return;
			const alt = new WebSocket(fallback);
			alt.onopen = () => resolve(alt);
			alt.onerror = () => reject(/* @__PURE__ */ new Error("Could not open the Gemini Live socket."));
		};
	});
}
function floatTo16(input) {
	const buf = /* @__PURE__ */ new ArrayBuffer(input.length * 2);
	const view = new DataView(buf);
	for (let i = 0; i < input.length; i++) {
		const s = Math.max(-1, Math.min(1, input[i]));
		view.setInt16(i * 2, s < 0 ? s * 32768 : s * 32767, true);
	}
	return new Uint8Array(buf);
}
function u8ToB64(bytes) {
	let bin = "";
	const chunk = 32768;
	for (let i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
	return btoa(bin);
}
function b64ToU8(b64) {
	const bin = atob(b64);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}
function LivePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/tutor",
				className: "text-xs text-muted-foreground hover:text-foreground",
				children: "Tutor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-medium tracking-tight",
				children: "Live Tutor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Speak with PyDuke over Gemini Live. The permanent API key stays on the server; this page only uses a short-lived session token."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveTutorSession, {})]
	});
}
//#endregion
export { LivePage as component };
