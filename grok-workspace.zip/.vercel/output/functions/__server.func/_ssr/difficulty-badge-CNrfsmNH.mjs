import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Badge } from "./badge-BwiWryF0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/difficulty-badge-CNrfsmNH.js
var import_jsx_runtime = require_jsx_runtime();
var map = {
	easy: {
		variant: "easy",
		label: "Easy"
	},
	medium: {
		variant: "medium",
		label: "Medium"
	},
	hard: {
		variant: "hard",
		label: "Hard"
	},
	advanced: {
		variant: "advanced",
		label: "Advanced"
	}
};
function DifficultyBadge({ value }) {
	const m = map[value];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: m.variant,
		children: m.label
	});
}
//#endregion
export { DifficultyBadge as t };
