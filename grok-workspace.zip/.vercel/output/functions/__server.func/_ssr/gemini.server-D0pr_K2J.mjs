//#region node_modules/.nitro/vite/services/ssr/assets/gemini.server-D0pr_K2J.js
function env(key) {
	return process.env[key]?.trim() || void 0;
}
function geminiApiKey() {
	return env("GEMINI_API_KEY");
}
function geminiChatModel() {
	return env("GEMINI_MODEL") || "gemini-flash-latest";
}
function geminiLiveModel() {
	return env("GEMINI_LIVE_MODEL") || "gemini-3.8-live";
}
async function geminiGenerate(opts) {
	const key = geminiApiKey();
	if (!key) return {
		ok: false,
		error: "missing-key"
	};
	const contents = opts.messages.filter((m) => m.role === "user" || m.role === "assistant").map((m) => ({
		role: m.role === "assistant" ? "model" : "user",
		parts: [{ text: m.content.slice(0, 6e3) }]
	}));
	if (contents.length === 0) return {
		ok: false,
		error: "empty"
	};
	const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${geminiChatModel()}:generateContent`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"x-goog-api-key": key
		},
		body: JSON.stringify({
			systemInstruction: { parts: [{ text: opts.system }] },
			contents,
			generationConfig: {
				temperature: .4,
				maxOutputTokens: 900
			}
		})
	});
	if (!res.ok) {
		const detail = await res.text().catch(() => "");
		return {
			ok: false,
			error: `gemini ${res.status}${detail.slice(0, 180)}`
		};
	}
	const text = (await res.json()).candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("").trim() ?? "";
	if (!text) return {
		ok: false,
		error: "empty-response"
	};
	return {
		ok: true,
		text
	};
}
async function mintLiveToken() {
	const key = geminiApiKey();
	if (!key) return {
		ok: false,
		error: "missing-key"
	};
	const model = geminiLiveModel();
	const now = Date.now();
	const expireTime = new Date(now + 18e5).toISOString();
	const newSessionExpireTime = new Date(now + 12e4).toISOString();
	const modelPath = model.startsWith("models/") ? model : `models/${model}`;
	const bodies = [{
		uses: 1,
		expireTime,
		newSessionExpireTime,
		bidiGenerateContentSetup: {
			model: modelPath,
			generationConfig: { responseModalities: ["AUDIO"] }
		}
	}, {
		uses: 1,
		expireTime,
		newSessionExpireTime,
		liveConnectConstraints: {
			model: modelPath,
			config: { responseModalities: ["AUDIO"] }
		}
	}];
	let last = "live-token-empty";
	for (const body of bodies) {
		const res = await fetch("https://generativelanguage.googleapis.com/v1beta/auth_tokens", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": key
			},
			body: JSON.stringify(body)
		});
		if (!res.ok) {
			last = `live-token ${res.status}${(await res.text().catch(() => "")).slice(0, 180)}`;
			continue;
		}
		const json = await res.json();
		const token = json.name || json.token || json.authToken?.name;
		if (token) return {
			ok: true,
			token,
			model
		};
		last = "live-token-empty";
	}
	return {
		ok: false,
		error: last
	};
}
//#endregion
export { geminiGenerate as n, mintLiveToken as r, env as t };
