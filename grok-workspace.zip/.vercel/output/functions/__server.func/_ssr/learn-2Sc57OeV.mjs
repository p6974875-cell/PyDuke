import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cn } from "./utils-fNW1Yxkl.mjs";
import { c as useHelix, i as TOPICS, o as dueTopicIds } from "./store-CUZplCsw.mjs";
import { s as Progress } from "./router-CYzlBSjl.mjs";
import { t as Input } from "./input-CNyMxTaJ.mjs";
import { t as Badge } from "./badge-BBFGGQJQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-2Sc57OeV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_LABEL = {
	mastered: "Mastered",
	in_progress: "In progress",
	review: "Review",
	available: "Open",
	locked: "Open"
};
function LearnIndex() {
	const topics = useHelix((s) => s.topics);
	const due = (0, import_react.useMemo)(() => dueTopicIds(topics), [topics]);
	const [q, setQ] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const query = q.trim().toLowerCase();
	const list = TOPICS.filter((t) => {
		const p = topics[t.id];
		const status = p?.status === "locked" ? "available" : p?.status;
		if (filter === "open" && status === "mastered") return false;
		if (filter === "done" && status !== "mastered") return false;
		if (!query) return true;
		return `${t.title} ${t.subtitle} ${t.blurb}`.toLowerCase().includes(query);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Learn"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-medium tracking-tight",
					children: "Curriculum"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Every lesson is open. Search, then open one — explanation, examples, mistakes, and a live coding task that is actually graded."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search lessons — try “loop”",
					className: "h-11 sm:max-w-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: [
						"all",
						"open",
						"done"
					].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(f),
						className: cn("tap-card h-11 rounded-md px-3 text-sm capitalize", filter === f ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
						children: f
					}, f))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "grid gap-2 sm:grid-cols-2",
				children: list.map((t) => {
					const p = topics[t.id];
					const status = p?.status === "locked" ? "available" : p?.status ?? "available";
					const isDue = due.includes(t.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/learn/$topicId",
						params: { topicId: t.id },
						className: "tap-card block rounded-xl bg-card p-4 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-muted-foreground",
									children: String(t.number).padStart(2, "0")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: status === "mastered" ? "success" : "outline",
									children: isDue ? "Review due" : STATUS_LABEL[status]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-lg font-medium",
								children: t.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: t.blurb
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
								value: p?.score ?? 0,
								className: "mt-4"
							})
						]
					}) }, t.id);
				})
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No lessons match that search."
			}) : null
		]
	});
}
//#endregion
export { LearnIndex as component };
