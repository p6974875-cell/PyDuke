import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as TOPIC_BY_ID, c as useHelix, i as TOPICS, n as LESSONS } from "./store-CUZplCsw.mjs";
import { D as ArrowRight, w as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as Button, f as GAME_META, r as Route$3, s as Progress } from "./router-CYzlBSjl.mjs";
import { t as CodeBlock } from "./code-block-BWDjmpSd.mjs";
import { t as ExercisePanel } from "./exercise-panel-CLzinCJq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn._topicId-1cDX6PrS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TOPIC_GAMES = {
	intro: ["predict", "fixer"],
	variables: ["fixer", "predict"],
	comments: ["fixer"],
	io: ["fixer", "build"],
	conversion: ["fixer", "predict"],
	operators: ["predict", "fixer"],
	conditions: ["predict", "ordering"],
	loops: ["ordering", "debug"],
	range: ["predict", "ordering"],
	lists: [
		"build",
		"predict",
		"ordering"
	],
	tuples: ["predict", "fixer"],
	sets: ["predict", "build"],
	dictionaries: ["build", "debug"],
	strings: ["typing", "predict"],
	functions: ["build", "debug"],
	scope: ["debug", "predict"],
	errors: ["debug", "fixer"],
	modules: ["build"],
	files: ["build"],
	json: ["build", "predict"],
	oop: ["build", "boss"],
	stdlib: ["build"],
	apis: ["build"],
	projects: ["boss", "build"],
	advanced: ["boss"]
};
function LessonView({ topicId }) {
	const lesson = LESSONS[topicId];
	const topic = TOPIC_BY_ID[topicId];
	const progress = useHelix((s) => s.topics[topicId]);
	const completeLesson = useHelix((s) => s.completeLesson);
	const [thinkOpen, setThinkOpen] = (0, import_react.useState)(false);
	const required = (0, import_react.useMemo)(() => lesson.exercises.filter((e) => !e.optional), [lesson]);
	const ready = required.filter((e) => progress.completedExercises.includes(e.id)).length >= Math.min(2, required.length) || required.length === 0;
	const next = TOPICS[TOPICS.findIndex((t) => t.id === topicId) + 1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "space-y-3 helix-enter",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: [
							"Lesson ",
							topic.number,
							" · ",
							topic.subtitle
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight sm:text-4xl",
						children: topic.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: topic.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: progress.score,
							className: "max-w-xs"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs tabular-nums text-muted-foreground",
							children: [progress.score, "%"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-secondary p-5 helix-enter helix-enter-delay-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: lesson.revision.heading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[15px] leading-relaxed text-muted-foreground",
						children: lesson.revision.body
					}),
					lesson.revision.code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
						code: lesson.revision.code,
						className: "mt-4"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 helix-enter helix-enter-delay-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: lesson.concept.heading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[15px] leading-relaxed text-foreground/90",
						children: lesson.concept.explanation
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
						className: "rounded-lg border-l-2 border-accent/50 bg-card py-3 pl-4 pr-4 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-foreground",
							children: "Definition. "
						}), lesson.concept.definition]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[15px] leading-relaxed text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-foreground",
							children: "Analogy. "
						}), lesson.concept.analogy]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Examples"
				}), lesson.examples.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: ex.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
							code: ex.code,
							runnable: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm leading-relaxed text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: "Why this works. "
							}), ex.why]
						})
					]
				}, ex.title))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Common mistakes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: lesson.mistakes.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1 text-xs uppercase tracking-wider text-destructive",
								children: "Avoid"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code: m.wrong })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1 text-xs uppercase tracking-wider text-success",
								children: "Prefer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code: m.right })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground sm:col-span-2",
								children: m.why
							})
						]
					}, m.wrong))
				})]
			}),
			lesson.think ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Pause and think"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[15px]",
						children: lesson.think.question
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						className: "mt-3",
						onClick: () => setThinkOpen((v) => !v),
						children: thinkOpen ? "Hide" : "Reveal"
					}),
					thinkOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted-foreground",
						children: lesson.think.answer
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Write it"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Mini exercise, then a practical one. The last is optional if marked harder."
				})] }), lesson.exercises.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExercisePanel, {
					exercise: ex,
					topicId
				}, ex.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Practice this idea as a game"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: TOPIC_GAMES[topicId].map((gid) => {
						const g = GAME_META.find((m) => m.id === gid);
						if (!g) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/games/$gameId",
							params: { gameId: gid },
							className: "tap-card rounded-xl bg-card px-4 py-3 shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: g.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: g.blurb
							})]
						}, gid);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "flex flex-wrap items-center gap-3 border-t border-border pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						disabled: !ready || progress.status === "mastered",
						onClick: () => {
							completeLesson(topicId);
							toast("Lesson marked complete");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), progress.status === "mastered" ? "Mastered" : "Mark lesson complete"]
					}),
					next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/learn/$topicId",
							params: { topicId: next.id },
							children: [
								"Next: ",
								next.title,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
							]
						})
					}) : null,
					!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Complete at least two required exercises to finish."
					}) : null
				]
			})
		]
	});
}
function LessonPage() {
	const { topicId } = Route$3.useParams();
	const topic = TOPIC_BY_ID[topicId];
	if (!topic) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-muted-foreground",
		children: ["Unknown lesson. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/learn",
			children: "Back to curriculum"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonView, { topicId: topic.id });
}
//#endregion
export { LessonPage as component };
