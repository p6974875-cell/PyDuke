//#region node_modules/.nitro/vite/services/ssr/assets/game-ids-Dqoi2Xic.js
var ALIAS = {
	fixer: "fixer",
	"code-fixer": "fixer",
	predict: "predict",
	"predict-output": "predict",
	"predict-the-output": "predict",
	ordering: "ordering",
	"code-ordering": "ordering",
	typing: "typing",
	"typing-sprint": "typing",
	debug: "debug",
	debugging: "debug",
	"debugging-challenge": "debug",
	build: "build",
	"build-it": "build",
	boss: "boss",
	"boss-battle": "boss"
};
var GAME_SLUG = {
	fixer: "code-fixer",
	predict: "predict",
	ordering: "code-ordering",
	typing: "typing-sprint",
	debug: "debugging-challenge",
	build: "build-it",
	boss: "boss-battle"
};
function resolveGameId(raw) {
	return ALIAS[raw];
}
//#endregion
export { resolveGameId as n, GAME_SLUG as t };
