import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { n as geminiGenerate, t as env } from "./gemini.server-D0pr_K2J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ask-tutor-APldEwxg.js
var askTutor_createServerFn_handler = createServerRpc({
	id: "005cf77f41977c3a9940172397204cd8178325a30898c634bb4f5a2fb3176776",
	name: "askTutor",
	filename: "src/lib/ask-tutor.ts"
}, (opts) => askTutor.__executeServer(opts));
var askTutor = createServerFn({ method: "POST" }).validator((input) => input).handler(askTutor_createServerFn_handler, async ({ data }) => {
	const system = `You are PyDuke, a Python teacher in a learning app.

Teaching:
- Answer ANY Python question — beginner through advanced (classes, recursion, decorators, async, generators, memory, typing, metaclasses). Never refuse a topic because it is "ahead of the current lesson".
- Current lesson context is background only. If they ask about something else, teach that.
- For a concept: definition, simple explanation, a short code example, expected output, one common mistake.
- For exercise help: hint first, then a stronger hint, then a worked explanation if they ask to see it.
- Never execute OS or network calls. Never claim their code works unless they pasted a successful run.
- Stay on Python and programming. Short, clear replies. Use fenced Python code.

Learner progress (context, not a fence):
${data.progressSummary.slice(0, 1800)}
${data.context ? `\nWorkspace context:\n${data.context.slice(0, 1500)}` : ""}`;
	const gemini = await geminiGenerate({
		system,
		messages: data.messages.slice(-8)
	});
	if (gemini.ok) return gemini;
	const xaiKey = env("XAI_API_KEY");
	if (xaiKey && gemini.error === "missing-key") {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${xaiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .4,
				max_tokens: 700,
				messages: [{
					role: "system",
					content: system
				}, ...data.messages.slice(-8).map((m) => ({
					role: m.role,
					content: m.content.slice(0, 4e3)
				}))]
			})
		});
		if (res.ok) {
			const text = (await res.json()).choices[0]?.message.content ?? "";
			if (text.trim()) return {
				ok: true,
				text
			};
		}
	}
	return {
		ok: false,
		error: gemini.error
	};
});
var tutorStatus_createServerFn_handler = createServerRpc({
	id: "cc2b7974a77f3d6d9dcff60efc204684f1a0e724fe02801a850cf40857acc44a",
	name: "tutorStatus",
	filename: "src/lib/ask-tutor.ts"
}, (opts) => tutorStatus.__executeServer(opts));
var tutorStatus = createServerFn({ method: "GET" }).handler(tutorStatus_createServerFn_handler, async () => {
	return {
		gemini: Boolean(env("GEMINI_API_KEY")),
		live: Boolean(env("GEMINI_API_KEY")),
		model: env("GEMINI_MODEL") || "gemini-flash-latest",
		liveModel: env("GEMINI_LIVE_MODEL") || "gemini-3.8-live"
	};
});
//#endregion
export { askTutor_createServerFn_handler, tutorStatus_createServerFn_handler };
