import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as GripVertical, I as ArrowDown, N as ArrowUp, T as Eye, f as Play, l as RotateCcw, y as Lightbulb } from "../_libs/lucide-react.mjs";
import { m as outputsMatch, v as Button, y as cn } from "./router-C24WQtVx.mjs";
import { t as Input } from "./input-CrCa6m5Z.mjs";
import { n as PythonOutput, t as CodeEditor } from "./python-output-BJIiscp_.mjs";
import { s as shuffle } from "./game-engine-CQ7mU7b7.mjs";
import { t as CodeBlock } from "./code-block-BCNFtjit.mjs";
import { t as gradeCode } from "./grade-cXt9EkQb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/game-challenges-CPLS4CNL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function itemKind(item) {
	if (item.kind) return item.kind;
	if (item.choices && item.answer) return "mcq";
	if (item.lines?.length) return "order";
	if (item.code && item.expected !== void 0) return "predict";
	return "code";
}
function ChallengeCard({ item, onResult }) {
	const kind = itemKind(item);
	if (kind === "mcq") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(McqCard, {
		item,
		onResult
	}, item.id);
	if (kind === "predict") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PredictCard, {
		item,
		onResult
	}, item.id);
	if (kind === "order") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
		item,
		onResult
	}, item.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FixCard, {
		item,
		onResult
	}, item.id);
}
function FixCard({ item, onResult }) {
	const [code, setCode] = (0, import_react.useState)(item.starter ?? "");
	const [result, setResult] = (0, import_react.useState)(null);
	const [msg, setMsg] = (0, import_react.useState)("");
	const [ok, setOk] = (0, import_react.useState)(false);
	const [attempted, setAttempted] = (0, import_react.useState)(false);
	const [show, setShow] = (0, import_react.useState)(false);
	const [hint, setHint] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [locked, setLocked] = (0, import_react.useState)(false);
	async function runOnly() {
		setRunning(true);
		try {
			const g = await gradeCode(code, item.checks ?? []);
			setResult(g.run);
			setMsg(g.passed ? "Looks right — submit to score it." : g.message);
			setOk(g.passed);
		} finally {
			setRunning(false);
		}
	}
	async function submit() {
		if (locked) return;
		setRunning(true);
		try {
			const g = await gradeCode(code, item.checks ?? []);
			setResult(g.run);
			setMsg(g.message);
			setOk(g.passed);
			setAttempted(true);
			setLocked(g.passed);
			onResult(g.passed);
		} finally {
			setRunning(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
				value: code,
				onChange: setCode,
				onRun: runOnly,
				minHeight: 200
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => void runOnly(),
						disabled: running,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Run"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => void submit(),
						disabled: running || locked,
						children: "Submit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => {
							setCode(item.starter ?? "");
							setResult(null);
							setMsg("");
							setOk(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset"]
					}),
					item.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setHint((v) => !v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-4" }), "Hint"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						disabled: !attempted,
						onClick: () => setShow(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }), "Compare"]
					})
				]
			}),
			hint && item.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: item.hint
			}) : null,
			msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: ok ? "text-sm text-success" : "text-sm text-destructive",
				children: msg
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonOutput, {
				result,
				code
			}),
			show && item.solution ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-secondary p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code: item.solution }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: item.explanation
				})]
			}) : null
		]
	});
}
function PredictCard({ item, onResult }) {
	const [guess, setGuess] = (0, import_react.useState)("");
	const [revealed, setRevealed] = (0, import_react.useState)(false);
	const choices = item.choices ?? [];
	const correct = outputsMatch(guess, item.expected ?? "");
	function lock(value) {
		if (revealed) return;
		setGuess(value);
		setRevealed(true);
		onResult(outputsMatch(value, item.expected ?? ""));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code: item.code ?? "" }),
			choices.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: choices.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: revealed,
					onClick: () => lock(c),
					className: cn("min-h-11 rounded-lg bg-secondary px-3 py-2 text-left font-mono text-sm", revealed && outputsMatch(c, item.expected ?? "") && "text-success", revealed && guess === c && !outputsMatch(c, item.expected ?? "") && "text-destructive"),
					children: c
				}, c))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: guess,
					onChange: (e) => setGuess(e.target.value),
					placeholder: "Or type the exact output",
					disabled: revealed
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					disabled: revealed || !guess.trim(),
					onClick: () => lock(guess),
					children: "Lock in"
				})]
			}),
			revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-lg bg-secondary p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: correct ? "text-success" : "text-destructive",
						children: correct ? "Your prediction matched." : "Not quite."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-foreground",
						children: ["Actual: ", item.expected]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: item.explanation
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Predict before you see the output. One shot."
			})
		]
	});
}
function McqCard({ item, onResult }) {
	const [picked, setPicked] = (0, import_react.useState)("");
	const [revealed, setRevealed] = (0, import_react.useState)(false);
	const options = (0, import_react.useMemo)(() => shuffle(item.choices ?? []), [item.id, item.choices]);
	const answer = item.answer ?? item.expected ?? "";
	function lock(value) {
		if (revealed) return;
		setPicked(value);
		setRevealed(true);
		onResult(value === answer);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			item.code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code: item.code }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: options.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: revealed,
					onClick: () => lock(c),
					className: cn("min-h-11 rounded-lg bg-secondary px-3 py-2 text-left text-sm", revealed && c === answer && "text-success", revealed && picked === c && c !== answer && "text-destructive"),
					children: c
				}, c))
			}),
			revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: item.explanation
			}) : null
		]
	});
}
function OrderCard({ item, onResult }) {
	const [lines, setLines] = (0, import_react.useState)(() => shuffle(item.lines ?? []));
	const [drag, setDrag] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const [ok, setOk] = (0, import_react.useState)(false);
	const [show, setShow] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [locked, setLocked] = (0, import_react.useState)(false);
	function move(i, dir) {
		if (locked) return;
		const j = i + dir;
		if (j < 0 || j >= lines.length) return;
		const next = lines.slice();
		[next[i], next[j]] = [next[j], next[i]];
		setLines(next);
	}
	function onDrop(i) {
		if (drag === null || drag === i || locked) {
			setDrag(null);
			return;
		}
		const next = lines.slice();
		const [row] = next.splice(drag, 1);
		next.splice(i, 0, row);
		setLines(next);
		setDrag(null);
	}
	async function check() {
		if (locked) return;
		setRunning(true);
		try {
			const g = await gradeCode(lines.join("\n"), [{
				kind: "stdout",
				expected: item.expected
			}]);
			setResult(g.run);
			setOk(g.passed);
			setLocked(g.passed);
			onResult(g.passed);
			if (g.passed) setShow(true);
		} finally {
			setRunning(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					draggable: !locked,
					onDragStart: () => setDrag(i),
					onDragOver: (e) => e.preventDefault(),
					onDrop: () => onDrop(i),
					className: cn("flex items-stretch gap-2 rounded-lg bg-code px-2 py-1 font-mono text-[13px]", drag === i && "opacity-60"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex cursor-grab items-center px-1 text-muted-foreground",
							"aria-hidden": true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "flex h-7 w-8 items-center justify-center text-muted-foreground",
								onClick: () => move(i, -1),
								"aria-label": "Move up",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3.5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "flex h-7 w-8 items-center justify-center text-muted-foreground",
								onClick: () => move(i, 1),
								"aria-label": "Move down",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 whitespace-pre py-2",
							children: line
						})
					]
				}, `${line}-${i}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				onClick: () => void check(),
				disabled: running || locked,
				children: "Run in order"
			}),
			ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-success",
				children: "That order works."
			}) : null,
			!ok && locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: "That order does not produce the expected output."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonOutput, {
				result,
				code: lines.join("\n")
			}),
			show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: item.explanation
			}) : null
		]
	});
}
function McqPrompt({ question, choices, answer, explanation, onResult }) {
	const options = (0, import_react.useMemo)(() => shuffle(choices), [choices]);
	const [picked, setPicked] = (0, import_react.useState)("");
	const [revealed, setRevealed] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: question
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: options.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: revealed,
					onClick: () => {
						if (revealed) return;
						setPicked(c);
						setRevealed(true);
						onResult(c === answer);
					},
					className: cn("min-h-11 rounded-lg bg-secondary px-3 py-2 text-left text-sm", revealed && c === answer && "text-success", revealed && picked === c && c !== answer && "text-destructive"),
					children: c
				}, c))
			}),
			revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: explanation
			}) : null
		]
	});
}
//#endregion
export { McqPrompt as n, ChallengeCard as t };
