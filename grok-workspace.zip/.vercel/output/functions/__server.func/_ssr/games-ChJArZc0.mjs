//#region node_modules/.nitro/vite/services/ssr/assets/games-ChJArZc0.js
var GAME_META = [
	{
		id: "fixer",
		title: "Code Fixer",
		blurb: "A short program is broken. Find the fault and make it run.",
		topicHint: "Syntax and names"
	},
	{
		id: "predict",
		title: "Predict the output",
		blurb: "Read the program. Say what it prints before you run it.",
		topicHint: "Mental execution"
	},
	{
		id: "ordering",
		title: "Code ordering",
		blurb: "The lines work — they are just in the wrong order.",
		topicHint: "Control flow"
	},
	{
		id: "typing",
		title: "Python typing sprint",
		blurb: "Type the snippet exactly. Accuracy first, then speed.",
		topicHint: "Syntax muscle memory"
	},
	{
		id: "debug",
		title: "Debugging challenge",
		blurb: "It runs, but the answer is wrong. Repair the logic.",
		topicHint: "Logic bugs"
	},
	{
		id: "build",
		title: "Build it",
		blurb: "A goal, a blank editor. You write the program.",
		topicHint: "From spec to code"
	},
	{
		id: "boss",
		title: "Boss battle",
		blurb: "Eight levels. Concepts stack. XP unlocks the next door.",
		topicHint: "Mixed mastery"
	}
];
var GAMES = {
	fixer: [
		{
			id: "fx-1",
			difficulty: "easy",
			title: "Missing colon",
			prompt: "This if-statement never even starts. Fix the syntax.",
			starter: "n = 3\nif n > 0\n    print('yes')",
			solution: "n = 3\nif n > 0:\n    print('yes')",
			explanation: "Compound statements in Python end their header with a colon.",
			checks: [{
				kind: "stdout",
				expected: "yes"
			}]
		},
		{
			id: "fx-2",
			difficulty: "easy",
			title: "String concat",
			prompt: "Python refuses to add a string to an int. Make it print 7.",
			starter: "n = \"3\"\nprint(n + 4)",
			solution: "n = \"3\"\nprint(int(n) + 4)",
			explanation: "Convert the string to int before arithmetic. The other option is str(4), which would print 34.",
			checks: [{
				kind: "stdout",
				expected: "7"
			}]
		},
		{
			id: "fx-3",
			difficulty: "medium",
			title: "Tuple comma",
			prompt: "This should be a one-element tuple with length 1. Right now it is an int.",
			starter: "t = (5)\nprint(type(t).__name__)\nprint(len(t) if type(t) is tuple else 'not-tuple')",
			solution: "t = (5,)\nprint(type(t).__name__)\nprint(len(t) if type(t) is tuple else 'not-tuple')",
			explanation: "The comma constructs the tuple. Parentheses only group.",
			checks: [{
				kind: "stdout",
				expected: "tuple\n1"
			}]
		},
		{
			id: "fx-4",
			difficulty: "medium",
			title: "Dict iteration",
			prompt: "This loop was meant to print each value. It crashes or prints letters. Fix it so it prints 1 then 2.",
			starter: "d = {'a': 1, 'b': 2}\nfor k, v in d:\n    print(v)",
			solution: "d = {'a': 1, 'b': 2}\nfor k, v in d.items():\n    print(v)",
			explanation: "A dict iterates keys. .items() yields (key, value) pairs you can unpack.",
			checks: [{
				kind: "stdout",
				expected: "1\n2"
			}]
		},
		{
			id: "fx-5",
			difficulty: "hard",
			title: "Shared row",
			prompt: "grid should be 2x2 zeros with only grid[0][0] = 1. It currently paints both rows. Fix construction.",
			starter: "grid = [[0] * 2] * 2\ngrid[0][0] = 1\nprint(grid)",
			solution: "grid = [[0] * 2 for _ in range(2)]\ngrid[0][0] = 1\nprint(grid)",
			explanation: "Multiplying a list of lists reuses the inner list. A comprehension makes a fresh row each time.",
			checks: [{
				kind: "stdout",
				expected: "[[1, 0], [0, 0]]"
			}]
		},
		{
			id: "fx-6",
			difficulty: "hard",
			title: "Mutable default",
			prompt: "Two independent calls should not share a list. Fix the default.",
			starter: "def bag(item, items=[]):\n    items.append(item)\n    return items\n\nprint(bag('a'))\nprint(bag('b'))",
			solution: "def bag(item, items=None):\n    if items is None:\n        items = []\n    items.append(item)\n    return items\n\nprint(bag('a'))\nprint(bag('b'))",
			explanation: "Default values are evaluated once. None is safe; create the list in the body.",
			checks: [{
				kind: "stdout",
				expected: "['a']\n['b']"
			}]
		},
		{
			id: "fx-7",
			difficulty: "easy",
			title: "Divide by zero",
			prompt: "This crashes when y is 0. Print 'cannot divide' instead of raising.",
			starter: "x = 10\ny = 0\nprint(x / y)",
			solution: "x = 10\ny = 0\nif y == 0:\n    print('cannot divide')\nelse:\n    print(x / y)",
			explanation: "Division by zero is ZeroDivisionError. Guard the denominator before you divide.",
			hint: "Test y == 0 before the division.",
			checks: [{
				kind: "stdout",
				expected: "cannot divide"
			}]
		},
		{
			id: "fx-8",
			difficulty: "medium",
			title: "Quotes",
			prompt: "This string is not closed. Make it print hello.",
			starter: "print('hello)",
			solution: "print('hello')",
			explanation: "A string literal needs matching quotes. SyntaxError until they pair.",
			checks: [{
				kind: "stdout",
				expected: "hello"
			}]
		}
	],
	predict: [
		{
			id: "pr-1",
			difficulty: "easy",
			title: "Slice",
			prompt: "What does this print?",
			kind: "predict",
			code: "print([10, 20, 30, 40][1:3])",
			expected: "[20, 30]",
			choices: [
				"[10, 20, 30]",
				"[20, 30]",
				"[20, 30, 40]",
				"30"
			],
			explanation: "Slices are half-open: start at 1, stop before 3."
		},
		{
			id: "pr-2",
			difficulty: "easy",
			title: "Truth of empty",
			prompt: "What does this print?",
			kind: "predict",
			code: "xs = []\nif xs:\n    print('yes')\nelse:\n    print('no')",
			expected: "no",
			choices: [
				"yes",
				"no",
				"[]",
				"Error"
			],
			explanation: "An empty list is falsy, so the else branch runs."
		},
		{
			id: "pr-3",
			difficulty: "medium",
			title: "Alias",
			prompt: "What does this print?",
			kind: "predict",
			code: "a = [1]\nb = a\nb.append(2)\nprint(a)",
			expected: "[1, 2]",
			choices: [
				"[1]",
				"[1, 2]",
				"[2]",
				"Error"
			],
			explanation: "b is another name for the same list. append mutates that object."
		},
		{
			id: "pr-4",
			difficulty: "medium",
			title: "Remainder loop",
			prompt: "What does this print?",
			kind: "predict",
			code: "out = []\nfor n in range(5):\n    if n % 2 == 0:\n        out.append(n)\nprint(out)",
			expected: "[0, 2, 4]",
			choices: [
				"[1, 3]",
				"[0, 2, 4]",
				"[2, 4]",
				"[0, 1, 2, 3, 4]"
			],
			explanation: "range(5) is 0..4. Even numbers pass the filter, including 0."
		},
		{
			id: "pr-5",
			difficulty: "hard",
			title: "Comprehension scope",
			prompt: "What does this print?",
			kind: "predict",
			code: "x = 9\nprint([x for x in range(3)])\nprint(x)",
			expected: "[0, 1, 2]\n9",
			choices: [
				"[0, 1, 2]\n2",
				"[0, 1, 2]\n9",
				"[9, 9, 9]\n9",
				"Error"
			],
			explanation: "A comprehension has its own scope. The loop variable does not leak and does not overwrite the outer x."
		},
		{
			id: "pr-6",
			difficulty: "hard",
			title: "Short-circuit",
			prompt: "What does this print?",
			kind: "predict",
			code: "def boom():\n    print('boom')\n    return True\n\nprint(False and boom())",
			expected: "False",
			choices: [
				"boom\nFalse",
				"False",
				"True",
				"boom\nTrue"
			],
			explanation: "`and` stops at the first falsy value. boom() is never called, so 'boom' is not printed."
		},
		{
			id: "pr-7",
			difficulty: "easy",
			title: "Plus-equals",
			prompt: "What does this print?",
			kind: "predict",
			code: "x = 5\nx += 2\nprint(x)",
			expected: "7",
			choices: [
				"5",
				"2",
				"7",
				"52"
			],
			explanation: "x += 2 means x = x + 2. 5 + 2 is 7."
		},
		{
			id: "pr-8",
			difficulty: "medium",
			title: "Join",
			prompt: "What does this print?",
			kind: "predict",
			code: "print('-'.join(['a', 'b', 'c']))",
			expected: "a-b-c",
			choices: [
				"a, b, c",
				"abc",
				"a-b-c",
				"['a', 'b', 'c']"
			],
			explanation: "str.join inserts the separator between items of an iterable of strings."
		}
	],
	ordering: [
		{
			id: "or-1",
			difficulty: "easy",
			title: "Total",
			prompt: "Arrange the lines so the program prints 6.",
			lines: [
				"total = 0",
				"for n in [1, 2, 3]:",
				"    total += n",
				"print(total)"
			],
			expected: "6",
			explanation: "Initialise the accumulator, loop, then print once after the loop."
		},
		{
			id: "or-2",
			difficulty: "medium",
			title: "Swap",
			prompt: "Print 2 1 using an unpacking swap.",
			lines: [
				"a = 1",
				"b = 2",
				"a, b = b, a",
				"print(a, b)"
			],
			expected: "2 1",
			explanation: "Bind both names first. Then unpack. Then print."
		},
		{
			id: "or-3",
			difficulty: "medium",
			title: "Dict count",
			prompt: "Count letters in abba and print the count of a.",
			lines: [
				"text = 'abba'",
				"counts = {}",
				"for ch in text:",
				"    counts[ch] = counts.get(ch, 0) + 1",
				"print(counts['a'])"
			],
			expected: "2",
			explanation: "Create the dict before the loop. Print after the loop."
		},
		{
			id: "or-4",
			difficulty: "hard",
			title: "Function then call",
			prompt: "Define then use is_even so it prints True.",
			lines: [
				"def is_even(n):",
				"    return n % 2 == 0",
				"print(is_even(8))"
			],
			expected: "True",
			explanation: "A function must be defined before the call that uses it in this simple script."
		},
		{
			id: "or-5",
			difficulty: "hard",
			title: "File round trip",
			prompt: "Write, then read, then print Ada.",
			lines: [
				"with open('n.txt', 'w') as f:",
				"    f.write('Ada')",
				"with open('n.txt') as f:",
				"    print(f.read())"
			],
			expected: "Ada",
			explanation: "Write mode first, then a separate with-block to read."
		},
		{
			id: "or-6",
			difficulty: "easy",
			title: "Add then print",
			prompt: "Arrange so the program prints 15.",
			kind: "order",
			lines: [
				"a = 5",
				"b = 10",
				"result = a + b",
				"print(result)"
			],
			expected: "15",
			explanation: "Bind both numbers, add, then print. Printing first would name result before it exists."
		},
		{
			id: "or-7",
			difficulty: "medium",
			title: "Filter then sum",
			prompt: "Print the sum of positives in the list: 6.",
			kind: "order",
			lines: [
				"xs = [3, -1, 3]",
				"total = 0",
				"for n in xs:",
				"    if n > 0:",
				"        total += n",
				"print(total)"
			],
			expected: "6",
			explanation: "Initialise total, loop, filter, then print once after the loop."
		}
	],
	debug: [
		{
			id: "db-1",
			difficulty: "easy",
			title: "Off-by-one",
			prompt: "This should print 1 2 3 4 5. It stops early.",
			starter: "for i in range(1, 5):\n    print(i, end=' ' if i < 4 else '')\n",
			solution: "for i in range(1, 6):\n    print(i, end=' ' if i < 5 else '')\n",
			explanation: "range stop is exclusive. To include 5, stop at 6. The separator also needs to know the last number.",
			checks: [{
				kind: "stdout",
				expected: "1 2 3 4 5"
			}]
		},
		{
			id: "db-2",
			difficulty: "medium",
			title: "Wrong accumulator",
			prompt: "Mean of [2, 4, 6] should print 4.0. It does not.",
			starter: "xs = [2, 4, 6]\ntotal = 1\nfor x in xs:\n    total += x\nprint(total / len(xs))",
			solution: "xs = [2, 4, 6]\ntotal = 0\nfor x in xs:\n    total += x\nprint(total / len(xs))",
			explanation: "An accumulator for a sum starts at 0, not 1.",
			checks: [{
				kind: "stdout",
				expected: "4.0"
			}]
		},
		{
			id: "db-3",
			difficulty: "medium",
			title: "Inclusive filter",
			prompt: "Print numbers in [3, 10, 15, 7] that are >= 10. Currently it uses >.",
			starter: "for n in [3, 10, 15, 7]:\n    if n > 10:\n        print(n)",
			solution: "for n in [3, 10, 15, 7]:\n    if n >= 10:\n        print(n)",
			explanation: "The spec said at least 10, which includes 10. Use >=.",
			checks: [{
				kind: "stdout",
				expected: "10\n15"
			}]
		},
		{
			id: "db-4",
			difficulty: "hard",
			title: "Shallow copy needed",
			prompt: "Keep original as [1, 2] while extra becomes [1, 2, 3].",
			starter: "original = [1, 2]\nextra = original\nextra.append(3)\nprint(original)\nprint(extra)",
			solution: "original = [1, 2]\nextra = original[:]\nextra.append(3)\nprint(original)\nprint(extra)",
			explanation: "Assignment aliases. A slice copy makes extra independent.",
			checks: [{
				kind: "stdout",
				expected: "[1, 2]\n[1, 2, 3]"
			}]
		},
		{
			id: "db-5",
			difficulty: "easy",
			title: "Wrong name",
			prompt: "This should print 9. A name is misspelled.",
			starter: "width = 3\nheight = 3\nprint(widht * height)",
			solution: "width = 3\nheight = 3\nprint(width * height)",
			explanation: "NameError: widht was never bound. Names are case-sensitive and must match.",
			checks: [{
				kind: "stdout",
				expected: "9"
			}]
		},
		{
			id: "db-6",
			difficulty: "easy",
			title: "Indentation",
			prompt: "The print belongs inside the loop. It should print 0 1 2, each on its own line.",
			starter: "for i in range(3):\nprint(i)",
			solution: "for i in range(3):\n    print(i)",
			explanation: "The suite of a for-loop is the indented block. Unindenting makes a SyntaxError.",
			checks: [{
				kind: "stdout",
				expected: "0\n1\n2"
			}]
		},
		{
			id: "db-7",
			difficulty: "medium",
			title: "Type mix",
			prompt: "Print 15, not a concatenation. The digits arrived as strings.",
			starter: "a = \"7\"\nb = \"8\"\nprint(a + b)",
			solution: "a = \"7\"\nb = \"8\"\nprint(int(a) + int(b))",
			explanation: "str + str concatenates. Convert both to int before adding.",
			checks: [{
				kind: "stdout",
				expected: "15"
			}]
		},
		{
			id: "db-8",
			difficulty: "medium",
			title: "Wrong return",
			prompt: "area(3, 4) should print 12. It currently prints None.",
			starter: "def area(w, h):\n    w * h\n\nprint(area(3, 4))",
			solution: "def area(w, h):\n    return w * h\n\nprint(area(3, 4))",
			explanation: "A computation that is not returned is discarded. The function then yields None.",
			checks: [{
				kind: "stdout",
				expected: "12"
			}]
		},
		{
			id: "db-9",
			difficulty: "hard",
			title: "Loop never stops",
			prompt: "Print 1, 2, 3 then stop. The while currently never ends.",
			starter: "n = 0\nwhile True:\n    n += 1\n    print(n)",
			solution: "n = 0\nwhile True:\n    n += 1\n    print(n)\n    if n >= 3:\n        break",
			explanation: "A while True needs a break (or a condition that becomes false). Stop after 3.",
			checks: [{
				kind: "stdout",
				expected: "1\n2\n3"
			}]
		},
		{
			id: "db-10",
			difficulty: "hard",
			title: "Off-by-index",
			prompt: "Print the last item of xs, which is 9. It currently raises IndexError.",
			starter: "xs = [3, 6, 9]\nprint(xs[3])",
			solution: "xs = [3, 6, 9]\nprint(xs[-1])",
			explanation: "Valid indexes are 0..len-1. xs[3] is past the end. xs[-1] is the last item.",
			checks: [{
				kind: "stdout",
				expected: "9"
			}]
		}
	],
	build: [
		{
			id: "bd-1",
			difficulty: "easy",
			title: "Teenager?",
			prompt: "Set age = 15. Print 'teen' if 13 <= age <= 19, otherwise 'not'. Do not use input().",
			starter: "age = 15\n",
			solution: "age = 15\nif 13 <= age <= 19:\n    print('teen')\nelse:\n    print('not')",
			explanation: "Chained comparison reads as a range check. 15 is inside 13–19.",
			checks: [{
				kind: "stdout",
				expected: "teen"
			}]
		},
		{
			id: "bd-2",
			difficulty: "medium",
			title: "Fizz-ish",
			prompt: "For n in 1..6, print 'x' if n is divisible by 3, otherwise n. Each on its own line.",
			starter: "",
			solution: "for n in range(1, 7):\n    if n % 3 == 0:\n        print('x')\n    else:\n        print(n)",
			explanation: "Modulo tests divisibility. range(1, 7) covers 1 through 6.",
			checks: [{
				kind: "stdout",
				expected: "1\n2\nx\n4\n5\nx"
			}]
		},
		{
			id: "bd-3",
			difficulty: "medium",
			title: "Word lengths",
			prompt: "words = ['py', 'tutor', 'ok']. Print a dict of word -> length.",
			starter: "words = ['py', 'tutor', 'ok']\n",
			solution: "words = ['py', 'tutor', 'ok']\nprint({w: len(w) for w in words})",
			explanation: "A dict comprehension maps each word to len(w).",
			checks: [{
				kind: "stdout",
				expected: "{'py': 2, 'tutor': 5, 'ok': 2}"
			}]
		},
		{
			id: "bd-4",
			difficulty: "hard",
			title: "Palindrome check",
			prompt: "Define pal(s) that returns True if s equals its reverse. Print pal('level') and pal('helix').",
			starter: "def pal(s):\n    ...\n",
			solution: "def pal(s):\n    return s == s[::-1]\n\nprint(pal('level'))\nprint(pal('helix'))",
			explanation: "s[::-1] is the reversed string. Equality is the palindrome test.",
			checks: [{
				kind: "stdout",
				expected: "True\nFalse"
			}]
		},
		{
			id: "bd-5",
			difficulty: "easy",
			title: "Two numbers",
			prompt: "Bind a = 4 and b = 9. Print their sum. Do not use input() — the values are already known.",
			starter: "a = 4\nb = 9\n",
			solution: "a = 4\nb = 9\nprint(a + b)",
			explanation: "The spec is addition. input() is not required when the numbers are given.",
			hint: "print(a + b)",
			checks: [{
				kind: "stdout",
				expected: "13"
			}]
		},
		{
			id: "bd-6",
			difficulty: "hard",
			title: "Largest in a list",
			prompt: "xs = [3, 9, 2, 9, 1]. Print the largest number without using max().",
			starter: "xs = [3, 9, 2, 9, 1]\n",
			solution: "xs = [3, 9, 2, 9, 1]\nbest = xs[0]\nfor n in xs:\n    if n > best:\n        best = n\nprint(best)",
			explanation: "Walk the list keeping a running best. Start from the first item so an empty-list bug is visible.",
			hint: "Keep a best so far; update when n is larger.",
			checks: [{
				kind: "stdout",
				expected: "9"
			}]
		}
	],
	boss: [
		{
			id: "boss-1",
			difficulty: "easy",
			title: "Level 1 — Variables",
			prompt: "Bind a = 2, b = 5. Print their product.",
			starter: "",
			solution: "a = 2\nb = 5\nprint(a * b)",
			explanation: "Names bound, then an operator. Foundation.",
			checks: [{
				kind: "stdout",
				expected: "10"
			}]
		},
		{
			id: "boss-2",
			difficulty: "easy",
			title: "Level 2 — Conditions",
			prompt: "n = 11. Print 'odd' or 'even'.",
			starter: "n = 11\n",
			solution: "n = 11\nprint('even' if n % 2 == 0 else 'odd')",
			explanation: "A conditional expression is a compact if/else that yields a value.",
			checks: [{
				kind: "stdout",
				expected: "odd"
			}]
		},
		{
			id: "boss-3",
			difficulty: "medium",
			title: "Level 3 — Loops",
			prompt: "Print the sum of 1..10.",
			starter: "",
			solution: "print(sum(range(1, 11)))",
			explanation: "range(1, 11) is 1 through 10. sum walks it.",
			checks: [{
				kind: "stdout",
				expected: "55"
			}]
		},
		{
			id: "boss-4",
			difficulty: "medium",
			title: "Level 4 — Lists",
			prompt: "xs = [5, 1, 5, 3, 5]. Print how many times 5 appears.",
			starter: "xs = [5, 1, 5, 3, 5]\n",
			solution: "xs = [5, 1, 5, 3, 5]\nprint(xs.count(5))",
			explanation: "list.count is the direct method. A loop would also work.",
			checks: [{
				kind: "stdout",
				expected: "3"
			}]
		},
		{
			id: "boss-5",
			difficulty: "medium",
			title: "Level 5 — Functions",
			prompt: "Write twice(s) that returns s concatenated with itself. Print twice('go').",
			starter: "def twice(s):\n    ...\n",
			solution: "def twice(s):\n    return s + s\n\nprint(twice('go'))",
			explanation: "String addition concatenates. Return the result.",
			checks: [{
				kind: "stdout",
				expected: "gogo"
			}]
		},
		{
			id: "boss-6",
			difficulty: "hard",
			title: "Level 6 — Dictionaries",
			prompt: "grades = {'A': 2, 'B': 1, 'C': 0}. Print the key with the highest value.",
			starter: "grades = {'A': 2, 'B': 1, 'C': 0}\n",
			solution: "grades = {'A': 2, 'B': 1, 'C': 0}\nprint(max(grades, key=grades.get))",
			explanation: "max on a dict walks keys. key=grades.get compares by value.",
			checks: [{
				kind: "stdout",
				expected: "A"
			}]
		},
		{
			id: "boss-7",
			difficulty: "hard",
			title: "Level 7 — Mixed",
			prompt: "words = ['to', 'helix', 'py', 'tutor']. Print a sorted list of words longer than 2.",
			starter: "words = ['to', 'helix', 'py', 'tutor']\n",
			solution: "words = ['to', 'helix', 'py', 'tutor']\nprint(sorted(w for w in words if len(w) > 2))",
			explanation: "Filter with a generator expression, sort for a stable result.",
			checks: [{
				kind: "stdout",
				expected: "['helix', 'tutor']"
			}]
		},
		{
			id: "boss-8",
			difficulty: "advanced",
			title: "Level 8 — Mini-project",
			prompt: "Implement a tiny inventory: start empty dict. add(name, n) increases count. Use it to add torch 1, rope 2, torch 1. Print the dict.",
			starter: "inv = {}\n\ndef add(name, n):\n    ...\n",
			solution: "inv = {}\n\ndef add(name, n):\n    inv[name] = inv.get(name, 0) + n\n\nadd('torch', 1)\nadd('rope', 2)\nadd('torch', 1)\nprint(inv)",
			explanation: "A dict as inventory. get + add is the merge. Two torch adds become 2.",
			checks: [{
				kind: "stdout",
				expected: "{'torch': 2, 'rope': 2}"
			}]
		},
		{
			id: "boss-mcq",
			difficulty: "medium",
			title: "Level — Concept",
			prompt: "Which expression is a one-element tuple holding 5?",
			kind: "mcq",
			choices: [
				"(5)",
				"[5]",
				"(5,)",
				"tuple(5)"
			],
			answer: "(5,)",
			expected: "(5,)",
			explanation: "The comma constructs the tuple. (5) is grouped int 5. tuple(5) tries to iterate 5 and fails."
		},
		{
			id: "boss-pred",
			difficulty: "medium",
			title: "Level — Predict",
			prompt: "What does this print?",
			kind: "predict",
			code: "print(list(range(3)))",
			expected: "[0, 1, 2]",
			choices: [
				"[1, 2, 3]",
				"[0, 1, 2]",
				"[0, 1, 2, 3]",
				"3"
			],
			explanation: "range(3) is 0, 1, 2. list() materialises it."
		},
		{
			id: "boss-ord",
			difficulty: "hard",
			title: "Level — Order",
			prompt: "Arrange so it prints 9.",
			kind: "order",
			lines: [
				"n = 0",
				"for _ in range(3):",
				"    n += 3",
				"print(n)"
			],
			expected: "9",
			explanation: "Start at 0, add 3 three times, print after the loop."
		}
	]
};
//#endregion
export { GAME_META as n, GAMES as t };
