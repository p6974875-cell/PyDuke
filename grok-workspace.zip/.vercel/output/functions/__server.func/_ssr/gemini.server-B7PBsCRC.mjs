import { n as TSS_SERVER_FUNCTION } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gemini.server-B7PBsCRC.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/** Server-only Gemini config. Never import this from client components. */
function geminiKey() {
	return process.env.GEMINI_API_KEY?.trim() || void 0;
}
function geminiChatModel() {
	return process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash";
}
function geminiLiveModel() {
	return process.env.GEMINI_LIVE_MODEL?.trim() || "gemini-3.8-live";
}
async function generateGeminiText(opts) {
	const apiKey = geminiKey();
	if (!apiKey) return {
		ok: false,
		error: "unavailable"
	};
	const model = geminiChatModel();
	const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"x-goog-api-key": apiKey
		},
		body: JSON.stringify({
			system_instruction: { parts: [{ text: opts.system }] },
			contents: opts.messages.map((m) => ({
				role: m.role === "assistant" ? "model" : "user",
				parts: [{ text: m.content }]
			})),
			generationConfig: {
				temperature: .4,
				maxOutputTokens: 800
			}
		})
	});
	if (!res.ok) {
		const body = await res.text().catch(() => "");
		return {
			ok: false,
			error: `Gemini API error ${res.status}${body ? `: ${body.slice(0, 180)}` : ""}`
		};
	}
	const text = (await res.json()).candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
	if (!text.trim()) return {
		ok: false,
		error: "empty"
	};
	return {
		ok: true,
		text
	};
}
//#endregion
export { generateGeminiText as i, geminiKey as n, geminiLiveModel as r, createServerRpc as t };
