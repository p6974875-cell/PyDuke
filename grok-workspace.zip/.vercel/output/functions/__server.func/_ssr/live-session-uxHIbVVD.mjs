import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { r as mintLiveToken } from "./gemini.server-D0pr_K2J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/live-session-uxHIbVVD.js
var createLiveSession_createServerFn_handler = createServerRpc({
	id: "8b824254135f9704073530ef4543a53ef3fc8f9bcb373093acaecbfdf14ddcf4",
	name: "createLiveSession",
	filename: "src/lib/live-session.ts"
}, (opts) => createLiveSession.__executeServer(opts));
var createLiveSession = createServerFn({ method: "POST" }).handler(createLiveSession_createServerFn_handler, async () => {
	const minted = await mintLiveToken();
	if (!minted.ok) return {
		ok: false,
		error: minted.error === "missing-key" ? "missing-key" : minted.error
	};
	return {
		ok: true,
		wsUrl: `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained?access_token=${encodeURIComponent(minted.token)}`,
		model: minted.model
	};
});
//#endregion
export { createLiveSession_createServerFn_handler };
