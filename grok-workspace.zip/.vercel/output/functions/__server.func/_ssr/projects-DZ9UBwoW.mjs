import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as TOPIC_BY_ID, c as useHelix } from "./store-CUZplCsw.mjs";
import { t as Badge } from "./badge-BBFGGQJQ.mjs";
import { t as DifficultyBadge } from "./difficulty-badge-cALuMwcu.mjs";
import { t as PROJECTS } from "./projects-MJ1LfonC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects-DZ9UBwoW.js
var import_jsx_runtime = require_jsx_runtime();
function ProjectsPage() {
	const done = useHelix((s) => s.projectsCompleted);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
				children: "Projects"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-medium tracking-tight",
				children: "Build something"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-muted-foreground",
				children: "Thin slices, not dumps of advanced code. Each project is a function you can test, then wrap with input later."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: PROJECTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/projects/$projectId",
				params: { projectId: p.id },
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DifficultyBadge, { value: p.difficulty }), done.includes(p.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "success",
							children: "Done"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-xl font-medium",
						children: p.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: p.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted-foreground",
						children: p.concepts.map((c) => TOPIC_BY_ID[c].title).join(" · ")
					})
				]
			}, p.id))
		})]
	});
}
//#endregion
export { ProjectsPage as component };
