import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as createServerFn } from "./ssr.mjs";
import { t as cn } from "./utils-fNW1Yxkl.mjs";
import { a as TOPIC_BY_ID, c as useHelix, s as progressSummary } from "./store-CUZplCsw.mjs";
import { S as Copy, o as Send, r as Trash2, w as Check } from "../_libs/lucide-react.mjs";
import { c as Button } from "./router-CYzlBSjl.mjs";
import { n as localTutorReply } from "./python-engine-DcCb1ULs.mjs";
import { t as CodeBlock } from "./code-block-BWDjmpSd.mjs";
import { n as createSsrRpc, t as LiveTutor } from "./live-tutor-DPjoIRlS.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tutor-IG1P8gqW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	className: cn("flex min-h-24 w-full rounded-md bg-secondary px-3 py-2 text-sm text-foreground shadow-[var(--shadow-border)] placeholder:text-muted-foreground focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Textarea.displayName = "Textarea";
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-11 items-center gap-1 rounded-lg bg-secondary p-1", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-md px-3 text-sm font-medium text-muted-foreground transition-colors duration-150 data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-[var(--shadow-border)]", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-4 outline-none", className),
	...props
}));
TabsContent.displayName = Content.displayName;
function TutorMessage({ content }) {
	const chunks = splitFences(content);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3 text-sm leading-relaxed",
		children: chunks.map((c, i) => c.type === "code" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyableCode, { code: c.text }, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "whitespace-pre-wrap",
			children: c.text
		}, i))
	});
}
function CopyableCode({ code }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			size: "icon-sm",
			variant: "ghost",
			className: "absolute right-2 top-2",
			onClick: async () => {
				await navigator.clipboard.writeText(code);
				setCopied(true);
				window.setTimeout(() => setCopied(false), 1200);
			},
			"aria-label": "Copy code",
			children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" })
		})]
	});
}
function splitFences(text) {
	return text.split(/```(?:python|py)?\n?([\s\S]*?)```/g).map((p, i) => ({
		type: i % 2 === 1 ? "code" : "text",
		text: p
	})).filter((p) => p.text.trim());
}
var askTutor = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("005cf77f41977c3a9940172397204cd8178325a30898c634bb4f5a2fb3176776"));
var tutorStatus = createServerFn({ method: "GET" }).handler(createSsrRpc("cc2b7974a77f3d6d9dcff60efc204684f1a0e724fe02801a850cf40857acc44a"));
var STARTERS = [
	"Explain this like a beginner.",
	"Why can't I modify this tuple?",
	"Give me a hint.",
	"Teach me loops.",
	"Give me a harder challenge.",
	"Why am I getting this error?"
];
function TutorPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-2xl flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
				children: "Tutor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-medium tracking-tight",
				children: "PyDuke tutor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Chat uses Gemini on the server. Live uses Gemini Live — a realtime voice session, not a text reply spoken by a fake voice."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "chat",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "chat",
					children: "Chat"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "live",
					children: "Live tutor"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "chat",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TutorChat, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "live",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveTutor, {})
				})
			]
		})]
	});
}
function TutorChat() {
	const messages = useHelix((s) => s.tutor);
	const push = useHelix((s) => s.pushTutor);
	const clear = useHelix((s) => s.clearTutor);
	const current = useHelix((s) => s.currentTopicId);
	const [text, setText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [backend, setBackend] = (0, import_react.useState)("unknown");
	(0, import_react.useEffect)(() => {
		tutorStatus().then((s) => setBackend(s.gemini ? "gemini" : "fallback"));
	}, []);
	async function send(content) {
		const q = content.trim();
		if (!q || busy) return;
		setText("");
		push({
			role: "user",
			content: q
		});
		setBusy(true);
		const state = useHelix.getState();
		const summary = progressSummary(state);
		const context = `Current lesson: ${TOPIC_BY_ID[state.currentTopicId]?.title ?? state.currentTopicId}. Difficulty: ${state.preferredDifficulty}.`;
		try {
			const res = await askTutor({ data: {
				messages: state.tutor.slice(-8).map((m) => ({
					role: m.role,
					content: m.content
				})),
				progressSummary: summary,
				context
			} });
			if (res.ok && res.text.trim()) push({
				role: "assistant",
				content: res.text.trim()
			});
			else {
				const local = localTutorReply(q, summary);
				const note = !res.ok && res.error === "missing-key" ? "\n\n(Gemini is not configured. Add GEMINI_API_KEY to the server .env to talk to the live model.)" : "\n\n(The hosted model was unavailable. This is a local fallback, not Gemini.)";
				push({
					role: "assistant",
					content: local + note
				});
			}
		} catch {
			push({
				role: "assistant",
				content: "AI Tutor is temporarily unavailable. Check your connection and try again.\n\n" + localTutorReply(q, summary)
			});
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: backend === "gemini" ? `Gemini is connected · current lesson ${TOPIC_BY_ID[current]?.title ?? current}` : backend === "fallback" ? "GEMINI_API_KEY is missing. Chat will use a local fallback until you add the key." : "Checking tutor backend…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: STARTERS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void send(s),
					className: "min-h-11 rounded-full bg-secondary px-3 py-2 text-left text-xs text-muted-foreground hover:text-foreground",
					children: s
				}, s))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]",
					children: "Ask about an error, a line of code, or the current lesson. Hints come before solutions."
				}) : messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: m.role === "user" ? "ml-8 rounded-xl bg-secondary px-4 py-3 text-sm" : "mr-8 rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-[11px] uppercase tracking-wider text-muted-foreground",
						children: m.role === "user" ? "You" : "PyDuke"
					}), m.role === "assistant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TutorMessage, { content: m.content }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap",
						children: m.content
					})]
				}, m.id)), busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Thinking…"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2 sm:flex-row",
				onSubmit: (e) => {
					e.preventDefault();
					send(text);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: "Why does this loop stop?",
					className: "min-h-20 flex-1",
					onKeyDown: (e) => {
						if (e.key === "Enter" && !e.shiftKey) {
							e.preventDefault();
							send(text);
						}
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 sm:flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: busy || !text.trim(),
						className: "sm:self-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), "Send"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "ghost",
						disabled: messages.length === 0,
						onClick: () => clear(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Clear"]
					})]
				})]
			})
		]
	});
}
//#endregion
export { TutorPage as component };
