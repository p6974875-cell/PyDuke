import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { T as Eye, f as Play, i as Trash2, l as RotateCcw, y as Lightbulb } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useHelix, v as Button } from "./router-C24WQtVx.mjs";
import { n as PythonOutput, t as CodeEditor } from "./python-output-BJIiscp_.mjs";
import { t as DifficultyBadge } from "./difficulty-badge-CNrfsmNH.mjs";
import { t as gradeCode } from "./grade-cXt9EkQb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exercise-panel-4x2yRSDF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ExercisePanel({ exercise, topicId, onPassed }) {
	const [code, setCode] = (0, import_react.useState)(exercise.starter);
	const [result, setResult] = (0, import_react.useState)(null);
	const [message, setMessage] = (0, import_react.useState)("");
	const [passed, setPassed] = (0, import_react.useState)(false);
	const [attempted, setAttempted] = (0, import_react.useState)(false);
	const [showHint, setShowHint] = (0, import_react.useState)(false);
	const [showSolution, setShowSolution] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	const recordExercise = useHelix((s) => s.recordExercise);
	async function submit() {
		setRunning(true);
		try {
			const g = await gradeCode(code, exercise.checks);
			setResult(g.run);
			setMessage(g.passed ? g.message : g.run.ok ? `Your code runs, but the output is wrong. ${g.message}` : g.message);
			setAttempted(true);
			setPassed(g.passed);
			recordExercise({
				topicId,
				exerciseId: exercise.id,
				ok: g.passed,
				difficulty: exercise.difficulty,
				note: g.passed ? void 0 : g.message.slice(0, 180),
				code
			});
			if (g.passed) {
				toast(`+XP · ${exercise.title}`);
				onPassed?.();
			}
		} finally {
			setRunning(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-medium",
					children: exercise.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: exercise.prompt
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DifficultyBadge, { value: exercise.difficulty })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
				value: code,
				onChange: setCode,
				onRun: submit,
				minHeight: 180
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: submit,
						disabled: running,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), running ? "Checking" : "Run & check"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => {
							setCode(exercise.starter);
							setResult(null);
							setMessage("");
							setPassed(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => {
							setCode("");
							setResult(null);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Clear"]
					}),
					exercise.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setShowHint((v) => !v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-4" }), "Hint"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						disabled: !attempted,
						onClick: () => setShowSolution(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }), "Compare"]
					})
				]
			}),
			showHint && exercise.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: exercise.hint
			}) : null,
			message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: passed ? "text-sm text-success" : "text-sm text-destructive",
				children: message
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonOutput, {
				result,
				code
			}),
			showSolution ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-lg bg-secondary p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
						children: "After your attempt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "overflow-x-auto font-mono text-[13px] text-foreground",
						children: exercise.solution
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-muted-foreground",
						children: exercise.explanation
					})
				]
			}) : !attempted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Write it first. Compare unlocks after you run a check."
			}) : null
		]
	});
}
//#endregion
export { ExercisePanel as t };
