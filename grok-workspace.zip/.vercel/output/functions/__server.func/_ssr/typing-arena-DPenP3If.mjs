import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { b as formatDuration, c as useHelix, v as Button, y as cn } from "./router-C24WQtVx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/typing-arena-DPenP3If.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TypingArena({ drills, timedSeconds, onComplete }) {
	const [idx, setIdx] = (0, import_react.useState)(0);
	const drill = drills[idx] ?? drills[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [drills.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: drills.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setIdx(i),
				className: cn("h-11 rounded-md px-3 text-xs", i === idx ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
				children: d.title
			}, d.id))
		}) : null, drill ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingRound, {
			drill,
			timedSeconds,
			onComplete
		}, `${drill.id}-${timedSeconds ?? 0}`) : null]
	});
}
function TypingRound({ drill, timedSeconds, onComplete }) {
	const target = drill.code;
	const [pos, setPos] = (0, import_react.useState)(0);
	const [errors, setErrors] = (0, import_react.useState)(0);
	const [started, setStarted] = (0, import_react.useState)(null);
	const [doneAt, setDoneAt] = (0, import_react.useState)(null);
	const [wrong, setWrong] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(Date.now());
	const record = useHelix((s) => s.recordTyping);
	const typingHistory = useHelix((s) => s.typingHistory);
	const history = (0, import_react.useMemo)(() => typingHistory.filter((h) => h.drillId === drill.id), [typingHistory, drill.id]);
	(0, import_react.useEffect)(() => {
		if (!started || doneAt) return;
		const t = window.setInterval(() => setNow(Date.now()), 200);
		return () => window.clearInterval(t);
	}, [started, doneAt]);
	(0, import_react.useEffect)(() => {
		if (!timedSeconds || !started || doneAt) return;
		if ((now - started) / 1e3 >= timedSeconds) finish(pos, errors, started);
	}, [
		now,
		timedSeconds,
		started,
		doneAt,
		pos,
		errors
	]);
	function finish(p, err, start) {
		if (doneAt) return;
		const end = Date.now();
		setDoneAt(end);
		const minutes = Math.max(.01, (end - start) / 6e4);
		const chars = Math.max(1, p);
		const cpm = Math.round(chars / minutes);
		const wpm = Math.round(chars / 5 / minutes);
		const accuracy = Math.round(p / (p + err || 1) * 1e3) / 10;
		record({
			at: end,
			wpm,
			cpm,
			accuracy,
			errors: err,
			chars: p,
			drillId: drill.id
		});
		onComplete?.();
	}
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if (doneAt) return;
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			if (e.ctrlKey || e.metaKey || e.altKey) return;
			if (e.key === "Tab") {
				e.preventDefault();
				feed("    ");
				return;
			}
			if (e.key === "Enter") {
				e.preventDefault();
				feed("\n");
				return;
			}
			if (e.key.length === 1) {
				e.preventDefault();
				feed(e.key);
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	function feed(chunk) {
		if (doneAt) return;
		const start = started ?? Date.now();
		if (!started) setStarted(start);
		let p = pos;
		let err = errors;
		for (const ch of chunk) {
			if (p >= target.length) break;
			if (target[p] === ch) p += 1;
			else {
				err += 1;
				setWrong(true);
				window.setTimeout(() => setWrong(false), 120);
				break;
			}
		}
		setPos(p);
		setErrors(err);
		if (p >= target.length) finish(p, err, start);
	}
	const elapsed = (doneAt ?? (started ? now : 0)) - (started ?? 0);
	const minutes = Math.max(.01, elapsed / 6e4);
	const liveWpm = started ? Math.round(pos / 5 / minutes) : 0;
	const liveCpm = started ? Math.round(pos / minutes) : 0;
	const acc = pos + errors === 0 ? 100 : Math.round(pos / (pos + errors) * 1e3) / 10;
	const remain = timedSeconds && started && !doneAt ? Math.max(0, timedSeconds - elapsed / 1e3) : timedSeconds && !started ? timedSeconds : null;
	const best = (0, import_react.useMemo)(() => {
		if (!history.length) return null;
		return history.reduce((a, b) => a.accuracy === b.accuracy ? a.wpm > b.wpm ? a : b : a.accuracy > b.accuracy ? a : b);
	}, [history]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Focus: ",
					drill.focus,
					". Type the snippet exactly. Wrong keys count; the cursor does not skip. Accuracy is the score. Speed is only useful once you are precise."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "WPM",
						value: started ? String(liveWpm) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "CPM",
						value: started ? String(liveCpm) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Accuracy",
						value: `${acc}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Errors",
						value: String(errors)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: remain !== null ? "Time left" : "Elapsed",
						value: remain !== null ? `${Math.ceil(remain)}s` : started ? formatDuration(elapsed) : "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: cn("overflow-x-auto whitespace-pre-wrap rounded-xl bg-code p-4 font-mono text-[13px] leading-relaxed sm:p-5", wrong && "shadow-[0_0_0_1px_var(--color-destructive)]"),
				tabIndex: 0,
				children: target.split("").map((ch, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn(i < pos && "text-success", i === pos && "bg-accent text-accent-foreground", i > pos && "text-muted-foreground"),
					children: ch === "\n" ? "↵\n" : ch === " " && i === pos ? "·" : ch
				}, i))
			}),
			doneAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg",
						children: "Results"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							acc,
							"% accuracy · ",
							liveWpm,
							" WPM · ",
							liveCpm,
							" CPM · ",
							errors,
							" misses · ",
							pos,
							"/",
							target.length,
							" ",
							"characters · ",
							formatDuration(elapsed)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							"Personal best on this drill:",
							" ",
							best ? `${best.accuracy}% · ${best.wpm} WPM` : "this run is the first."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: acc < 95 ? "text-sm text-muted-foreground" : "text-sm text-success",
						children: acc < 95 ? "Stay with accuracy before chasing WPM." : "Clean run."
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Click the snippet, then type. Tab inserts four spaces."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				size: "sm",
				onClick: () => {
					setPos(0);
					setErrors(0);
					setStarted(null);
					setDoneAt(null);
				},
				children: "Restart"
			})
		]
	});
}
function Metric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-card px-3 py-2 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-sm tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { TypingArena as t };
