import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { y as cn } from "./router-C24WQtVx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/python-output-BJIiscp_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CodeEditor(props) {
	const [Inner, setInner] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("./code-editor-inner-CtGKAbJm.mjs").then((m) => {
			if (live) setInner(() => m.CodeEditorInner);
		});
		return () => {
			live = false;
		};
	}, []);
	if (!Inner) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		value: props.value,
		onChange: (e) => props.onChange(e.target.value),
		onKeyDown: (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
				e.preventDefault();
				props.onRun?.();
			}
		},
		spellCheck: false,
		"aria-label": "Python editor",
		className: cn("w-full resize-y rounded-lg bg-code p-3 font-mono text-xs leading-relaxed text-foreground shadow-[var(--shadow-border)] outline-none", props.className),
		style: { minHeight: props.minHeight ?? 220 }
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inner, { ...props });
}
function explainError(error, code) {
	const e = error.trim();
	const steps = [];
	steps.push(`What you wrote is a program Python tried to compile and run.`);
	if (/SyntaxError/i.test(e)) {
		steps.push(`Python interpreted it as invalid syntax — the grammar of the language was broken.`);
		if (/colon/i.test(e) || /expected ':'/i.test(e)) {
			steps.push(`What went wrong: a header such as if, for, def, or while is missing its colon.`);
			steps.push(`How to fix it: end that line with \`:\` and indent the body.`);
		} else if (/EOL|unterminated/i.test(e)) {
			steps.push(`What went wrong: a string was opened and never closed on that line.`);
			steps.push(`How to fix it: match quotes — "..." or '...' — on the same line, or use a triple-quoted string.`);
		} else {
			steps.push(`What went wrong: ${e}`);
			steps.push(`How to fix it: read the caret in the traceback — it points at the first token Python could not accept.`);
		}
	} else if (/IndentationError|TabError/i.test(e)) {
		steps.push(`Python interpreted indentation as the block structure of the program.`);
		steps.push(`What went wrong: spaces and tabs mixed, or a line at the wrong indent level.`);
		steps.push(`How to fix it: indent with 4 spaces, consistently, one level per block.`);
	} else if (/NameError/i.test(e)) {
		const m = e.match(/name '([^']+)'/);
		steps.push(`Python looked up a name and did not find it in local, global, or builtin scope.`);
		steps.push(`What went wrong: ${m ? `\`${m[1]}\` was used before it was bound` : "an unbound name"}.`);
		steps.push(`How to fix it: bind the name first, or check spelling. Names are case-sensitive.`);
	} else if (/TypeError/i.test(e)) {
		steps.push(`Python applied an operation to a value whose type does not support it.`);
		if (/can only concatenate str/i.test(e) || /unsupported operand/i.test(e)) {
			steps.push(`What went wrong: two types were combined that do not share that operator (often str + int).`);
			steps.push(`How to fix it: convert with int(), str(), or float() so both sides match.`);
		} else if (/NoneType/i.test(e)) {
			steps.push(`What went wrong: a name holds None — often because a mutating method like append returned None.`);
			steps.push(`How to fix it: call the mutator, then use the object; do not assign the return value.`);
		} else {
			steps.push(`What went wrong: ${e}`);
			steps.push(`How to fix it: print(type(x)) for the values in the expression and convert as needed.`);
		}
	} else if (/KeyError/i.test(e)) {
		steps.push(`Python looked up a dictionary key that is not present.`);
		steps.push(`What went wrong: ${e}`);
		steps.push(`How to fix it: use d.get(key, default) when absence is normal, or test \`key in d\` first.`);
	} else if (/IndexError/i.test(e)) {
		steps.push(`Python asked for a sequence index that does not exist.`);
		steps.push(`What went wrong: ${e}`);
		steps.push(`How to fix it: valid indices are 0 .. len(seq)-1. Check length before indexing.`);
	} else if (/AttributeError/i.test(e)) {
		steps.push(`Python asked an object for an attribute or method it does not have.`);
		steps.push(`What went wrong: ${e}`);
		steps.push(`How to fix it: confirm the type (a list has append, a string does not in the same way you might think — strings use other methods).`);
	} else if (/ValueError/i.test(e)) {
		steps.push(`The type was right, the value was not (for example int('q')).`);
		steps.push(`What went wrong: ${e}`);
		steps.push(`How to fix it: validate or convert inside try/except ValueError.`);
	} else if (/ImportError|ModuleNotFoundError/i.test(e)) {
		steps.push(`Python could not load a module.`);
		steps.push(`What went wrong: ${e}`);
		steps.push(`How to fix it: in PyDuke, OS and network modules are blocked. Use math, json, random, datetime, collections, or pyduke_net.`);
	} else if (/Timed out/i.test(e)) {
		steps.push(`The program did not finish in time.`);
		steps.push(`What went wrong: a loop condition never became false, or work was unbounded.`);
		steps.push(`How to fix it: make sure a while-loop changes its condition, or use a for-loop over a finite iterable.`);
	} else {
		steps.push(`Python reported: ${e || "no error message"}`);
		steps.push(`What went wrong is in that message — it names the exception type.`);
		steps.push(`How to fix it: match the type to the object you passed, then change the value or the call.`);
	}
	const snippet = code.trim().split("\n").slice(0, 4).join(" / ");
	if (snippet) steps.unshift(`A look at the start of your code: ${snippet}${code.trim().split("\n").length > 4 ? " …" : ""}`);
	steps.push(`The corrected version works because it agrees with Python's rules for types, names, and syntax — not because of a special trick.`);
	return steps;
}
function PythonOutput({ result, code, className }) {
	if (!result) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-lg bg-code px-4 py-3 text-sm text-muted-foreground", className),
		children: "Output appears here after you run."
	});
	const hasOut = result.stdout.trim().length > 0;
	const err = result.error || result.stderr;
	const steps = err ? explainError(err, code ?? "") : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-3", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("pre", {
				className: "overflow-x-auto rounded-lg bg-code px-4 py-3 font-mono text-[13px] leading-relaxed text-foreground",
				children: [hasOut ? result.stdout : err ? "" : "(no output)", err ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block text-destructive",
					children: [hasOut ? "\n" : "", err]
				}) : null]
			}),
			steps ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-1.5 rounded-lg bg-secondary px-4 py-3 text-sm text-muted-foreground",
				children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "leading-relaxed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mr-2 font-mono text-xs text-accent",
						children: [i + 1, "."]
					}), s]
				}, i))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs tabular-nums text-muted-foreground",
				children: [result.durationMs, "ms"]
			})
		]
	});
}
//#endregion
export { PythonOutput as n, CodeEditor as t };
