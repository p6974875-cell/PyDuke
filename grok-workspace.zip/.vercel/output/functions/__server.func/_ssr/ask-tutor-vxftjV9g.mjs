import { t as createServerFn } from "./ssr.mjs";
import { i as generateGeminiText, t as createServerRpc } from "./gemini.server-B7PBsCRC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ask-tutor-vxftjV9g.js
var SYSTEM_PROMPT_HEADER = `You are PyDuke, a personal Python tutor.

Teaching rules:
- Use standard terms (mutable, iterable, hashable, suite, binding) and define them once.
- Prefer short examples the learner can type.
- Match the learner's current topic from the progress summary. Do not skip ahead.
- For exercises: hint first. If they say they are still stuck, give a stronger hint. Only show a full solution if they already attempted it or explicitly ask "show me".
- Never claim their code works unless they pasted a passing result.
- Never execute OS/network access or invent runtime output you did not see.
- If they paste an error, walk the exception type, then the fix.`;
var askTutor_createServerFn_handler = createServerRpc({
	id: "005cf77f41977c3a9940172397204cd8178325a30898c634bb4f5a2fb3176776",
	name: "askTutor",
	filename: "src/lib/ask-tutor.ts"
}, (opts) => askTutor.__executeServer(opts));
var askTutor = createServerFn({ method: "POST" }).validator((input) => input).handler(askTutor_createServerFn_handler, async ({ data }) => {
	const extra = [
		data.currentLesson ? `Current lesson: ${data.currentLesson}` : "",
		data.currentExercise ? `Current exercise: ${data.currentExercise}` : "",
		data.difficulty ? `Preferred difficulty: ${data.difficulty}` : "",
		data.submittedCode ? `Submitted code:\n${data.submittedCode.slice(0, 2500)}` : "",
		data.lastError ? `Last error:\n${data.lastError.slice(0, 800)}` : ""
	].filter(Boolean).join("\n");
	const system = `${SYSTEM_PROMPT_HEADER}\n\nLearner progress:\n${data.progressSummary.slice(0, 1800)}${extra ? `\n\nContext:\n${extra}` : ""}`;
	const trimmed = data.messages.filter((m) => m.role !== "system").slice(-8).map((m) => ({
		role: m.role,
		content: m.content.slice(0, 4e3)
	}));
	const gemini = await generateGeminiText({
		system,
		messages: trimmed
	});
	if (gemini.ok) return {
		ok: true,
		text: gemini.text,
		provider: "gemini"
	};
	const xaiKey = process.env.XAI_API_KEY;
	if ((gemini.error === "unavailable" || gemini.error === "empty") && xaiKey) {
		const xai = await askXai(xaiKey, system, trimmed);
		if (xai.ok) return {
			...xai,
			provider: "xai"
		};
		return xai;
	}
	if (xaiKey && gemini.error === "unavailable") {
		const xai = await askXai(xaiKey, system, trimmed);
		if (xai.ok) return {
			...xai,
			provider: "xai"
		};
	}
	if (gemini.error === "unavailable") return {
		ok: false,
		error: "unavailable"
	};
	return {
		ok: false,
		error: gemini.error
	};
});
async function askXai(apiKey, system, trimmed) {
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .4,
			max_tokens: 700,
			messages: [{
				role: "system",
				content: system
			}, ...trimmed]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI API error ${res.status}`
	};
	return {
		ok: true,
		text: (await res.json()).choices[0]?.message.content ?? ""
	};
}
//#endregion
export { askTutor_createServerFn_handler };
