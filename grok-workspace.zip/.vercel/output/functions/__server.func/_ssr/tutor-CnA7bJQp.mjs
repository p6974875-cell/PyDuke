import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as createServerFn } from "./ssr.mjs";
import { E as Copy, i as Trash2, k as Check, m as Mic, s as Send } from "../_libs/lucide-react.mjs";
import { c as useHelix, p as TOPIC_BY_ID, s as progressSummary, v as Button, y as cn } from "./router-C24WQtVx.mjs";
import { n as createSsrRpc, r as tutorAvailability } from "./tutor-live-maIQ3Z4s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tutor-CnA7bJQp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	className: cn("flex min-h-24 w-full rounded-md bg-secondary px-3 py-2 text-sm text-foreground shadow-[var(--shadow-border)] placeholder:text-muted-foreground focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Textarea.displayName = "Textarea";
function TutorMarkdown({ text }) {
	const parts = text.split(/```/);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2",
		children: parts.map((part, i) => {
			if (i % 2 === 1) {
				const nl = part.indexOf("\n");
				const lang = nl === -1 ? "" : part.slice(0, nl).trim();
				const code = nl === -1 ? part : part.slice(nl + 1).replace(/\n$/, "");
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, {
					code,
					lang
				}, i);
			}
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap leading-relaxed",
				children: part
			}, i);
		})
	});
}
function CopyBlock({ code, lang }) {
	const [ok, setOk] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-lg bg-code shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between px-3 py-1.5 text-xs text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang || "code" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: cn("inline-flex items-center gap-1 hover:text-foreground"),
				onClick: async () => {
					await navigator.clipboard.writeText(code);
					setOk(true);
					window.setTimeout(() => setOk(false), 1200);
				},
				children: [ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), ok ? "Copied" : "Copy"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "overflow-x-auto px-3 pb-3 font-mono text-xs leading-relaxed",
			children: code
		})]
	});
}
var askTutor = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("005cf77f41977c3a9940172397204cd8178325a30898c634bb4f5a2fb3176776"));
var STARTERS = [
	"Explain this like a beginner.",
	"Why am I getting this error?",
	"Give me a hint.",
	"Teach me loops.",
	"Give me a harder challenge.",
	"Explain this code."
];
function TutorPage() {
	const messages = useHelix((s) => s.tutor);
	const push = useHelix((s) => s.pushTutor);
	const clear = useHelix((s) => s.clearTutor);
	const current = useHelix((s) => s.currentTopicId);
	const lastCode = useHelix((s) => s.lastCode);
	const lastError = useHelix((s) => s.lastError);
	const lastExercise = useHelix((s) => s.lastExercise);
	const preferred = useHelix((s) => s.preferredDifficulty);
	const [text, setText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	const [avail, setAvail] = (0, import_react.useState)(null);
	const [provider, setProvider] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		tutorAvailability().then((a) => setAvail({
			gemini: a.gemini,
			xai: a.xai
		})).catch(() => setAvail({
			gemini: false,
			xai: false
		}));
	}, []);
	async function send(content) {
		const q = content.trim();
		if (!q || busy) return;
		setText("");
		setErr("");
		push({
			role: "user",
			content: q
		});
		setBusy(true);
		const state = useHelix.getState();
		const summary = progressSummary(state);
		try {
			const res = await askTutor({ data: {
				messages: state.tutor.slice(-8).map((m) => ({
					role: m.role,
					content: m.content
				})),
				progressSummary: summary,
				currentLesson: TOPIC_BY_ID[state.currentTopicId]?.title,
				currentExercise: lastExercise || void 0,
				submittedCode: lastCode || void 0,
				lastError: lastError || void 0,
				difficulty: preferred
			} });
			if (res.ok && res.text.trim()) {
				push({
					role: "assistant",
					content: res.text.trim()
				});
				if ("provider" in res && res.provider) setProvider(res.provider);
			} else setErr(res.ok ? "Empty reply." : res.error === "unavailable" ? "AI Tutor is temporarily unavailable. Check GEMINI_API_KEY and your connection, then try again." : res.error);
		} catch {
			setErr("AI Tutor is temporarily unavailable. Check your connection and try again.");
		} finally {
			setBusy(false);
		}
	}
	const online = Boolean(avail?.gemini || avail?.xai);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-2xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Tutor"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl font-medium tracking-tight",
						children: "Ask PyDuke"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: [
							"Gemini-backed Python teacher. Hints before solutions. Context:",
							" ",
							TOPIC_BY_ID[current]?.title ?? current,
							provider ? ` · last reply via ${provider === "gemini" ? "Gemini" : "xAI fallback"}` : "",
							"."
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "secondary",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/tutor/live",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" }), "Live Tutor"]
					})
				})]
			}),
			avail && !online ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-lg bg-secondary px-4 py-3 text-sm text-muted-foreground",
				children: [
					"No tutor key is configured. Add ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
						className: "font-mono text-foreground",
						children: "GEMINI_API_KEY"
					}),
					" ",
					"on the server (see SETUP.md). Offline canned replies are not used."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: STARTERS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => send(s),
					className: "rounded-full bg-secondary px-3 py-1.5 text-left text-xs text-muted-foreground hover:text-foreground",
					children: s
				}, s))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]",
						children: "Ask about the line you are on. If you have a traceback, paste it. I will not dump a full solution until you have tried."
					}) : messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: m.role === "user" ? "ml-8 rounded-xl bg-secondary px-4 py-3 text-sm" : "mr-8 rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 text-[11px] uppercase tracking-wider text-muted-foreground",
							children: m.role === "user" ? "You" : "PyDuke"
						}), m.role === "assistant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TutorMarkdown, { text: m.content }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-wrap leading-relaxed",
							children: m.content
						})]
					}, m.id)),
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Thinking…"
					}) : null,
					err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: err
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2 sm:flex-row",
				onSubmit: (e) => {
					e.preventDefault();
					send(text);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: "Why does this loop stop?",
					className: "min-h-20 flex-1",
					onKeyDown: (e) => {
						if (e.key === "Enter" && !e.shiftKey) {
							e.preventDefault();
							send(text);
						}
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 sm:flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: busy || !text.trim(),
						className: "sm:self-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), "Send"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						disabled: messages.length === 0,
						onClick: () => clear(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Clear"]
					})]
				})]
			})
		]
	});
}
//#endregion
export { TutorPage as component };
