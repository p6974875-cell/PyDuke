import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createRootRoute, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { A as ChartNoAxesColumn, D as CircleUser, M as BookOpen, _ as Menu, a as Terminal, b as Keyboard, d as Puzzle, g as MessageSquare, j as CalendarDays, r as TriangleAlert, t as X, w as FolderKanban, x as House } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { a as DialogOverlay, c as DialogTrigger, h as Slot, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as Root$1, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-BTWsHSvZ.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function todayKey(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function levelFromXp(xp) {
	return 1 + Math.floor(Math.max(0, xp) / 150);
}
function xpIntoLevel(xp) {
	return Math.max(0, xp) % 150;
}
function formatDuration(ms) {
	if (ms < 1e3) return `${ms}ms`;
	const s = ms / 1e3;
	if (s < 60) return `${s.toFixed(s < 10 ? 1 : 0)}s`;
	return `${Math.floor(s / 60)}m ${Math.round(s % 60)}s`;
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-C24WQtVx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function PyDukeMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: "/pyduke-mark.png",
		alt: "",
		className: cn("object-contain", className)
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[background-color,box-shadow,color,transform,opacity] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-[0_0_0_1px_rgb(255_255_255/0.06)] hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-foreground hover:bg-secondary",
			outline: "bg-transparent text-foreground shadow-[var(--shadow-border)] hover:bg-secondary hover:shadow-[var(--shadow-border-hover)]",
			destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
			link: "text-accent underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 rounded-lg px-5",
			icon: "size-11",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	ref,
	className: cn("relative h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full bg-accent transition-transform duration-200 ease-out",
		style: { transform: `translateX(-${100 - (value ?? 0)}%)` }
	})
}));
Progress.displayName = "Progress";
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	ref,
	className: cn("fixed inset-0 z-50 bg-background/70", className),
	...props
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var SheetContent = import_react.forwardRef(({ className, children, side = "right", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn("fixed z-50 bg-card text-card-foreground shadow-[var(--shadow-border),var(--shadow-lift)]", side === "right" && "inset-y-0 right-0 h-full w-[min(100%,22rem)] rounded-l-xl p-5", side === "left" && "inset-y-0 left-0 h-full w-[min(100%,22rem)] rounded-r-xl p-5", side === "bottom" && "inset-x-0 bottom-0 rounded-t-xl p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-3 top-3 rounded-sm p-2 text-muted-foreground hover:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
SheetContent.displayName = DialogContent.displayName;
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 pr-8", className),
		...props
	});
}
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("font-display text-lg font-medium", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var worker = null;
var ready = null;
var seq = 0;
var pending = /* @__PURE__ */ new Map();
var TIMEOUT_MS = 8e3;
function recreate() {
	if (worker) {
		worker.terminate();
		worker = null;
	}
	ready = null;
	for (const [id, p] of pending) {
		clearTimeout(p.timer);
		p.resolve({
			ok: false,
			stdout: "",
			stderr: "",
			error: "Python runtime was reset.",
			durationMs: Date.now() - p.started,
			timedOut: true
		});
		pending.delete(id);
	}
}
function ensureWorker() {
	if (typeof window === "undefined") return Promise.reject(/* @__PURE__ */ new Error("Python runs in the browser."));
	if (ready) return ready;
	worker = new Worker("/python-worker.js");
	ready = new Promise((resolve, reject) => {
		const w = worker;
		const failTimer = setTimeout(() => {
			reject(/* @__PURE__ */ new Error("Python runtime took too long to load."));
		}, 6e4);
		w.onmessage = (ev) => {
			const msg = ev.data;
			if (msg.type === "ready") {
				clearTimeout(failTimer);
				resolve();
				return;
			}
			if (msg.type === "error") {
				clearTimeout(failTimer);
				reject(new Error(msg.error || "Python failed to load"));
				return;
			}
			if (msg.type === "result") {
				const p = pending.get(msg.id);
				if (!p) return;
				clearTimeout(p.timer);
				pending.delete(msg.id);
				p.resolve({
					ok: Boolean(msg.ok),
					stdout: msg.stdout ?? "",
					stderr: msg.stderr ?? "",
					error: msg.error ?? "",
					durationMs: Date.now() - p.started
				});
			}
		};
		w.onerror = (e) => {
			clearTimeout(failTimer);
			reject(new Error(e.message || "Python worker error"));
		};
		w.postMessage({ type: "boot" });
	});
	return ready;
}
async function warmupPython() {
	await ensureWorker();
}
async function runPython(code, stdin = "") {
	const started = Date.now();
	await ensureWorker();
	const id = ++seq;
	return new Promise((resolve) => {
		const timer = setTimeout(() => {
			pending.delete(id);
			recreate();
			resolve({
				ok: false,
				stdout: "",
				stderr: "",
				error: "Timed out after 8 seconds. Check for an infinite loop.",
				durationMs: Date.now() - started,
				timedOut: true
			});
			ensureWorker();
		}, TIMEOUT_MS);
		pending.set(id, {
			resolve,
			started,
			timer
		});
		worker.postMessage({
			type: "run",
			id,
			code,
			stdin
		});
	});
}
function normalizeOutput(s) {
	return s.replace(/\r\n/g, "\n").replace(/\s+$/g, "").replace(/^\s+/g, "");
}
function outputsMatch(got, expected) {
	return normalizeOutput(got) === normalizeOutput(expected);
}
var LEVELS = [
	{
		id: 1,
		title: "Foundations",
		blurb: "Names, print, input, operators."
	},
	{
		id: 2,
		title: "Core Python",
		blurb: "Branches, loops, and collections."
	},
	{
		id: 3,
		title: "Functions and structure",
		blurb: "Reuse, scope, and errors."
	},
	{
		id: 4,
		title: "Practical Python",
		blurb: "Files, modules, data, APIs."
	},
	{
		id: 5,
		title: "Projects",
		blurb: "Design, classes, and the next layer."
	}
];
var TOPICS = [
	{
		id: "variables",
		number: 1,
		title: "Variables & data types",
		subtitle: "Names, values, types",
		blurb: "How Python stores values and why types matter.",
		level: 1
	},
	{
		id: "io",
		number: 2,
		title: "Input & output",
		subtitle: "print and input",
		blurb: "Talking to the user through the terminal.",
		level: 1
	},
	{
		id: "operators",
		number: 3,
		title: "Operators",
		subtitle: "Arithmetic, comparison, logic",
		blurb: "The symbols that compute and compare.",
		level: 1
	},
	{
		id: "conditions",
		number: 4,
		title: "Conditions",
		subtitle: "if, elif, else",
		blurb: "Making decisions in code.",
		level: 2
	},
	{
		id: "loops",
		number: 5,
		title: "Loops",
		subtitle: "for and while",
		blurb: "Repeating work without repeating yourself.",
		level: 2
	},
	{
		id: "lists",
		number: 6,
		title: "Lists, deeper",
		subtitle: "Mutability, copies, comprehensions",
		blurb: "You already know lists. Now we go further.",
		level: 2
	},
	{
		id: "tuples",
		number: 7,
		title: "Tuples",
		subtitle: "Immutable sequences",
		blurb: "When a collection should not change.",
		level: 2
	},
	{
		id: "sets",
		number: 8,
		title: "Sets",
		subtitle: "Unique unordered values",
		blurb: "Membership and uniqueness as first-class ideas.",
		level: 2
	},
	{
		id: "dictionaries",
		number: 9,
		title: "Dictionaries",
		subtitle: "Key and value maps",
		blurb: "Look things up by name, not by position.",
		level: 2
	},
	{
		id: "strings",
		number: 10,
		title: "Strings",
		subtitle: "Text as data",
		blurb: "Slicing, methods, and formatting with intent.",
		level: 2
	},
	{
		id: "functions",
		number: 11,
		title: "Functions",
		subtitle: "Named reusable work",
		blurb: "Package behaviour so you can call it again.",
		level: 3
	},
	{
		id: "scope",
		number: 12,
		title: "Scope",
		subtitle: "Where names live",
		blurb: "Why a variable in a function is not the same as one outside.",
		level: 3
	},
	{
		id: "errors",
		number: 13,
		title: "Error handling",
		subtitle: "try, except, raise",
		blurb: "Expecting failure and recovering cleanly.",
		level: 3
	},
	{
		id: "modules",
		number: 14,
		title: "Modules",
		subtitle: "import and __name__",
		blurb: "Splitting programs into reusable files.",
		level: 4
	},
	{
		id: "files",
		number: 15,
		title: "File handling",
		subtitle: "read, write, with",
		blurb: "Persisting data beyond a single run.",
		level: 4
	},
	{
		id: "oop",
		number: 16,
		title: "Object-oriented Python",
		subtitle: "classes and objects",
		blurb: "Bundling data and behaviour together.",
		level: 5
	},
	{
		id: "stdlib",
		number: 17,
		title: "Standard library",
		subtitle: "batteries included",
		blurb: "Useful modules you already have.",
		level: 4
	},
	{
		id: "apis",
		number: 18,
		title: "Working with APIs",
		subtitle: "HTTP and JSON",
		blurb: "Talking to other programs over the network — conceptually, then in code.",
		level: 4
	},
	{
		id: "projects",
		number: 19,
		title: "Project craft",
		subtitle: "Design before code",
		blurb: "How to break a real program into pieces you can finish.",
		level: 5
	},
	{
		id: "advanced",
		number: 20,
		title: "Advanced Python",
		subtitle: "generators, hints, decorators",
		blurb: "The next layer once the core is solid.",
		level: 5
	}
];
var TOPIC_BY_ID = Object.fromEntries(TOPICS.map((t) => [t.id, t]));
var MASTERED_ON_ARRIVAL = [];
var START_TOPIC = "variables";
var LESSONS = {
	variables: {
		topicId: "variables",
		revision: {
			heading: "What Python is doing",
			body: "Python is a programming language: you write statements, and the interpreter runs them in order. A comment starts with # and is ignored. print() writes text to the screen. A variable is a name bound to a value. Python figures out the type from the value, not from a declaration.",
			code: "# this line is a comment\nname = \"Ada\"\nage = 36\nprint(name, age)"
		},
		concept: {
			heading: "Names, objects, types",
			explanation: "In Python the name and the object are separate. The assignment `x = 3` means: create the integer object 3, then bind the name x to it. Reassigning `x = 'hi'` does not change 3 — it points the name at a new object. Types (`int`, `float`, `str`, `bool`, `NoneType`) describe the object, not the name.",
			definition: "A variable is a name bound to an object. A data type is the class of that object, which determines the operations it supports.",
			analogy: "A variable is a luggage tag. The suitcase can be swapped; the tag stays. The type is the kind of suitcase — you cannot pour tea into a guitar case and expect it to work."
		},
		examples: [{
			title: "Inspecting a type",
			code: "x = 10\nprint(type(x))\nx = x / 2\nprint(x, type(x))",
			why: "Integer division with `/` always produces a float in Python 3. The name `x` now refers to a different object with a different type."
		}, {
			title: "Multiple names, one object",
			code: "a = [1, 2]\nb = a\nb.append(3)\nprint(a)",
			why: "Assignment copies the reference, not the list. Both names point at the same mutable object, so mutating through `b` is visible through `a`."
		}],
		mistakes: [{
			wrong: "int x = 5",
			right: "x = 5",
			why: "Python does not declare types next to the name. You bind a name to a value."
		}, {
			wrong: "age = \"21\" + 1",
			right: "age = int(\"21\") + 1",
			why: "You cannot add a string to an integer. Convert first."
		}],
		exercises: [{
			id: "var-mini",
			title: "Swap with a temp",
			prompt: "Bind a to 3 and b to 7, swap their values using a temporary name, then print a and b on one line separated by a space.",
			difficulty: "easy",
			starter: "a = 3\nb = 7\n# swap, then print",
			solution: "a = 3\nb = 7\ntemp = a\na = b\nb = temp\nprint(a, b)",
			explanation: "A temporary name holds one value while the other overwrites it. Python also allows `a, b = b, a`, which unpacks a tuple.",
			checks: [{
				kind: "stdout",
				expected: "7 3"
			}]
		}, {
			id: "var-practical",
			title: "Name the types",
			prompt: "Bind n to 7, word to \"hi\", flag to False. Print type(n).__name__, type(word).__name__, and type(flag).__name__, each on its own line.",
			difficulty: "medium",
			starter: "n = 7\nword = \"hi\"\nflag = False\n",
			solution: "n = 7\nword = \"hi\"\nflag = False\nprint(type(n).__name__)\nprint(type(word).__name__)\nprint(type(flag).__name__)",
			explanation: "type(x) is the class. __name__ is the class name as a string: int, str, bool.",
			hint: "Call type(...) on each name, then print the .__name__ attribute.",
			checks: [{
				kind: "stdout",
				expected: "int\nstr\nbool"
			}]
		}]
	},
	io: {
		topicId: "io",
		revision: {
			heading: "Talking to the terminal",
			body: "`print` writes to standard output. `input` reads a line from standard input and always returns a string.",
			code: "print(\"Hello\")\n# name = input(\"Name: \")"
		},
		concept: {
			heading: "Streams, not magic",
			explanation: "Programs communicate through streams. Standard output is where `print` writes. Standard input is where `input` reads. Because `input` returns a `str`, numeric work needs `int(...)` or `float(...)`.",
			definition: "Standard input/output are character streams attached to the process. `print(*objects, sep=' ', end='\\n')` writes them; `input(prompt)` reads one line.",
			analogy: "Print is speaking. Input is listening. People always answer in words — you convert words into numbers when you need arithmetic."
		},
		examples: [{
			title: "sep and end",
			code: "print(\"A\", \"B\", sep=\"-\", end=\"!\")\nprint(\"done\")",
			why: "`sep` sits between arguments. `end` replaces the default newline, so the next print continues on the same visual line only if you want it to — here `end='!'` still needs a later newline from the next print."
		}],
		mistakes: [{
			wrong: "n = input(\"n: \")\nprint(n + 1)",
			right: "n = int(input(\"n: \"))\nprint(n + 1)",
			why: "`input` returns a string. Adding 1 requires an integer."
		}],
		exercises: [{
			id: "io-mini",
			title: "Formatted line",
			prompt: "Print exactly: PyDuke · Python  (middle dot with spaces, using sep)",
			difficulty: "easy",
			starter: "# use print with sep",
			solution: "print(\"PyDuke\", \"Python\", sep=\" · \")",
			explanation: "sep is inserted between arguments, so one print builds the whole line.",
			checks: [{
				kind: "stdout",
				expected: "PyDuke · Python"
			}]
		}, {
			id: "io-practical",
			title: "Add two inputs",
			prompt: "Read two lines as integers and print their sum. The hidden test feeds 4 then 9.",
			difficulty: "medium",
			starter: "# read two integers, print the sum",
			solution: "a = int(input())\nb = int(input())\nprint(a + b)",
			explanation: "input() always returns a string. Convert both, then add.",
			hint: "int(input()) twice, then print a + b.",
			checks: [{
				kind: "stdout",
				expected: "13",
				stdin: "4\n9\n"
			}]
		}]
	},
	operators: {
		topicId: "operators",
		revision: {
			heading: "Arithmetic you already know",
			body: "`+ - * / // % **` plus comparisons and `and` / `or` / `not`. `/` is true division. `//` is floor division.",
			code: "print(7 / 2)\nprint(7 // 2)\nprint(7 % 2)\nprint(2 ** 3)"
		},
		concept: {
			heading: "Operators are functions in disguise",
			explanation: "An operator is syntax for a function on one or two operands. Comparison operators return booleans. Logical operators short-circuit: `and` stops at the first falsy value, `or` at the first truthy one. Chained comparisons like `1 < x < 5` mean `1 < x and x < 5`.",
			definition: "An operator is a token that applies an operation to operands. Floor division `//` returns the greatest integer less than or equal to the algebraic quotient.",
			analogy: "A calculator key is an operator. Floor division is 'how many whole boxes fit', modulo is 'what is left over'."
		},
		examples: [{
			title: "Even test",
			code: "n = 8\nprint(n % 2 == 0)",
			why: "A number is even when dividing by 2 leaves remainder 0. `%` gives the remainder."
		}],
		mistakes: [{
			wrong: "if x = 3:",
			right: "if x == 3:",
			why: "`=` binds a name. `==` compares values."
		}],
		exercises: [{
			id: "op-mini",
			title: "Remainder",
			prompt: "Print the remainder of 29 divided by 5.",
			difficulty: "easy",
			starter: "",
			solution: "print(29 % 5)",
			explanation: "29 = 5*5 + 4, so the remainder is 4.",
			checks: [{
				kind: "stdout",
				expected: "4"
			}]
		}, {
			id: "op-practical",
			title: "Even test",
			prompt: "Set n = 17. Print True if n is even, False if it is odd.",
			difficulty: "medium",
			starter: "n = 17\n",
			solution: "n = 17\nprint(n % 2 == 0)",
			explanation: "A number is even when n % 2 is 0. 17 is odd, so the print is False.",
			hint: "Use the remainder operator % with 2.",
			checks: [{
				kind: "stdout",
				expected: "False"
			}]
		}]
	},
	conditions: {
		topicId: "conditions",
		revision: {
			heading: "Branching",
			body: "`if` / `elif` / `else` pick one path. The condition is any object; Python uses its truth value.",
			code: "n = 4\nif n > 5:\n    print('big')\nelif n > 0:\n    print('small')\nelse:\n    print('no')"
		},
		concept: {
			heading: "Truthiness",
			explanation: "A condition is converted with `bool()`. Empty containers, `0`, `0.0`, `''`, and `None` are falsy. Almost everything else is truthy. Only one branch runs. Indentation is the block — there are no braces.",
			definition: "A conditional statement evaluates a boolean expression and executes a suite of statements only when the expression is true.",
			analogy: "A fork in a path. You take one road. Python does not walk both and merge later unless you write two separate ifs."
		},
		examples: [{
			title: "Membership in a condition",
			code: "role = 'admin'\nif role in ('admin', 'editor'):\n    print('allowed')\nelse:\n    print('denied')",
			why: "`in` on a tuple is a clean way to spell 'one of these'. It reads like English and avoids a chain of `or`s."
		}],
		mistakes: [{
			wrong: "if n > 0 and < 10:",
			right: "if n > 0 and n < 10:",
			why: "Each comparison needs two operands. Or write `0 < n < 10`."
		}],
		exercises: [{
			id: "cond-mini",
			title: "Sign",
			prompt: "Set n = -2. Print 'neg', 'zero', or 'pos' depending on the sign.",
			difficulty: "easy",
			starter: "n = -2\n",
			solution: "n = -2\nif n < 0:\n    print('neg')\nelif n == 0:\n    print('zero')\nelse:\n    print('pos')",
			explanation: "Order matters. Check negative first, then zero; the rest is positive.",
			checks: [{
				kind: "stdout",
				expected: "neg"
			}]
		}, {
			id: "cond-practical",
			title: "Pass mark",
			prompt: "Set score = 73. Print pass if score is at least 50, otherwise fail.",
			difficulty: "medium",
			starter: "score = 73\n",
			solution: "score = 73\nif score >= 50:\n    print('pass')\nelse:\n    print('fail')",
			explanation: "One comparison, two branches. 73 clears 50 so the first suite runs.",
			hint: "if score >= 50: print('pass') else print('fail')",
			checks: [{
				kind: "stdout",
				expected: "pass"
			}]
		}]
	},
	loops: {
		topicId: "loops",
		revision: {
			heading: "Repeating work",
			body: "`for item in iterable` walks a collection. `while condition` repeats until the condition is false. `range(n)` yields 0 .. n-1.",
			code: "for i in range(3):\n    print(i)\n"
		},
		concept: {
			heading: "Iteration is a protocol",
			explanation: "A for-loop calls `iter()` on the object, then `next()` until `StopIteration`. That is why lists, strings, dicts, and files all loop. A while-loop is lower level: you own the condition and must make it false or `break`, or it never ends.",
			definition: "A loop repeatedly executes a suite. A for-loop iterates an iterable. A while-loop continues while its condition is true.",
			analogy: "For is walking every book on a shelf. While is 'keep walking until the street name changes' — you must notice the street."
		},
		examples: [{
			title: "Accumulator",
			code: "total = 0\nfor n in [3, 5, 7]:\n    total += n\nprint(total)",
			why: "An accumulator starts at a zero-like value and is updated each pass. This is the pattern behind `sum`."
		}],
		mistakes: [{
			wrong: "for i in 5:",
			right: "for i in range(5):",
			why: "An integer is not iterable. `range` is."
		}],
		exercises: [{
			id: "loop-mini",
			title: "Squares",
			prompt: "Print the squares of 1 through 4, each on its own line.",
			difficulty: "easy",
			starter: "",
			solution: "for n in range(1, 5):\n    print(n * n)",
			explanation: "range(1, 5) is 1,2,3,4. Multiply a number by itself for its square.",
			checks: [{
				kind: "stdout",
				expected: "1\n4\n9\n16"
			}]
		}, {
			id: "loop-practical",
			title: "Sum 1 to 10",
			prompt: "Print the sum of the integers from 1 through 10 inclusive.",
			difficulty: "medium",
			starter: "total = 0\n",
			solution: "total = 0\nfor n in range(1, 11):\n    total += n\nprint(total)",
			explanation: "range(1, 11) is 1..10. An accumulator starts at 0 and adds each n.",
			hint: "for n in range(1, 11): total += n, then print total. The answer is 55.",
			checks: [{
				kind: "stdout",
				expected: "55"
			}]
		}]
	},
	lists: {
		topicId: "lists",
		revision: {
			heading: "You already know lists",
			body: "A list is an ordered, mutable sequence. You index with `[0]`, slice with `[1:3]`, and change it in place with methods like `append`, `pop`, `insert`, and `sort`. We will not reteach that. We will look at the traps that show up once lists feel easy: shared references, copying, nested lists, and comprehensions.",
			code: "nums = [10, 20, 30]\nprint(nums[0], nums[-1])\nprint(nums[1:])\nnums.append(40)"
		},
		concept: {
			heading: "Lists as objects, not boxes of copies",
			explanation: "A list object holds references to other objects. `b = a` does not copy the list — it makes a second name for the same object. `a[:]` or `list(a)` copies the outer list (a shallow copy): new list, same inner objects. Nested lists need `copy.deepcopy` if you want a fully independent tree. A list comprehension `[expr for x in iterable if cond]` builds a new list by evaluating `expr` for each passing item. It is a loop compressed into an expression, not a different language.",
			definition: "A list is a mutable sequence. Indexing and slicing return items or a new list. Methods that mutate do so in place and often return None (for example `sort`). A shallow copy duplicates the container, not the contained objects.",
			analogy: "A playlist is a list of pointers to songs. Duplicating the playlist is not the same as duplicating every song file. Two playlists can still point at the same track — edit the track, both hear it."
		},
		examples: [
			{
				title: "The alias trap",
				code: "a = [1, 2, 3]\nb = a\nc = a[:]\nb.append(4)\nprint('a', a)\nprint('c', c)",
				why: "`b` is another name for `a`'s list, so `append` is visible through `a`. `c` is a new list built from a slice, so it stays `[1, 2, 3]`."
			},
			{
				title: "Comprehension vs loop",
				code: "words = ['py', 'helix', 'list']\nlengths = [len(w) for w in words if len(w) > 2]\nprint(lengths)",
				why: "Each `w` is tested by the `if`. Surviving items are transformed by `len(w)`. The result is a new list; `words` is untouched."
			},
			{
				title: "Nested lists and rows",
				code: "grid = [[0] * 3 for _ in range(2)]\ngrid[0][1] = 9\nprint(grid)",
				why: "`[[0] * 3] * 2` would reuse the same inner list twice. The comprehension creates a fresh inner list per row, so assigning `grid[0][1]` does not change row 1."
			}
		],
		mistakes: [
			{
				wrong: "result = nums.append(5)\nprint(result)",
				right: "nums.append(5)\nprint(nums)",
				why: "`append` mutates and returns None. Capturing the return value is a classic silent bug."
			},
			{
				wrong: "row = [0] * 3\ngrid = [row] * 3",
				right: "grid = [[0] * 3 for _ in range(3)]",
				why: "Multiplying a list of lists reuses one row object. Every 'row' is the same list."
			},
			{
				wrong: "for x in nums:\n    if x % 2:\n        nums.remove(x)",
				right: "nums = [x for x in nums if x % 2 == 0]",
				why: "Mutating a list while iterating it skips items. Build a new list instead."
			}
		],
		think: {
			question: "After `a = [1, [2]]; b = a[:]; b[1].append(3)` what is `a`?",
			answer: "`[1, [2, 3]]`. The slice copied the outer list, but the inner list is shared. Mutating that inner list is visible through `a`."
		},
		exercises: [
			{
				id: "lists-mini",
				title: "Evens only",
				prompt: "Start with nums = [3, 4, 8, 9, 12, 15]. Build a new list of the even numbers using a comprehension and print it.",
				difficulty: "easy",
				starter: "nums = [3, 4, 8, 9, 12, 15]\n",
				solution: "nums = [3, 4, 8, 9, 12, 15]\nprint([n for n in nums if n % 2 == 0])",
				hint: "n % 2 == 0 is the even test.",
				explanation: "The comprehension filters with `if` and keeps the original values. It does not mutate `nums`.",
				checks: [{
					kind: "stdout",
					expected: "[4, 8, 12]"
				}]
			},
			{
				id: "lists-practical",
				title: "Safe copy then edit",
				prompt: "Let source = ['a', 'b', 'c']. Make dest a shallow copy. Append 'd' to dest only. Print source, then dest, each on its own line.",
				difficulty: "medium",
				starter: "source = ['a', 'b', 'c']\n",
				solution: "source = ['a', 'b', 'c']\ndest = source[:]\ndest.append('d')\nprint(source)\nprint(dest)",
				hint: "Slice the whole list, or use list(source).",
				explanation: "A shallow copy is enough here because the items are immutable strings. Appending to dest leaves source alone.",
				checks: [{
					kind: "stdout",
					expected: "['a', 'b', 'c']\n['a', 'b', 'c', 'd']"
				}]
			},
			{
				id: "lists-hard",
				title: "Flatten one level",
				prompt: "nested = [[1, 2], [3], [4, 5, 6]]. Print a single list of all numbers in order, using a nested comprehension.",
				difficulty: "hard",
				starter: "nested = [[1, 2], [3], [4, 5, 6]]\n",
				solution: "nested = [[1, 2], [3], [4, 5, 6]]\nprint([n for row in nested for n in row])",
				optional: true,
				hint: "for row in nested, for n in row.",
				explanation: "A nested comprehension reads left-to-right like nested loops: outer `row`, inner `n`. The expression `n` is what gets collected.",
				checks: [{
					kind: "stdout",
					expected: "[1, 2, 3, 4, 5, 6]"
				}]
			}
		]
	},
	tuples: {
		topicId: "tuples",
		revision: {
			heading: "From lists to records",
			body: "Lists are for collections that grow and change. Tuples are for fixed records: a point, a pair, a row of a table. You already loop and index sequences. Tuples use the same sequence protocol — they just refuse mutation.",
			code: "point = (3, 4)\nprint(point[0], len(point))"
		},
		concept: {
			heading: "Immutability as a design choice",
			explanation: "A tuple is an immutable sequence. After you create it, you cannot append, pop, or assign to an index. Parentheses often create tuples, but the comma is the real constructor: `t = 1, 2`. A one-element tuple needs a trailing comma: `(1,)` not `(1)`. Immutability means the tuple's slots cannot be rebound. If a slot holds a list, that list can still mutate — the tuple only protects the binding. Tuples can be dictionary keys (when their items are hashable). Unpacking `x, y = point` is the everyday superpower.",
			definition: "A tuple is an immutable ordered sequence. It supports indexing, slicing, iteration, and unpacking, but not item assignment or in-place methods.",
			analogy: "A list is a whiteboard. A tuple is a printed label on a jar: ingredients, amount, date. You do not scribble extra ingredients on the label; you print a new one."
		},
		examples: [
			{
				title: "Packing and unpacking",
				code: "person = ('Ada', 36, 'math')\nname, age, field = person\nprint(name)\nprint(age)",
				why: "The tuple is a record. Unpacking names each field for the rest of the code, which is clearer than `person[0]`."
			},
			{
				title: "Single-element and empty",
				code: "one = (42,)\nempty = ()\nnot_a_tuple = (42)\nprint(type(one), type(not_a_tuple), len(empty))",
				why: "Parentheses alone group expressions. The comma makes a tuple. `(42)` is just the integer 42."
			},
			{
				title: "Returning two values",
				code: "def minmax(xs):\n    return min(xs), max(xs)\n\nlo, hi = minmax([3, 9, 1])\nprint(lo, hi)",
				why: "A function can return only one object. Returning two names really returns one tuple, which the caller unpacks."
			}
		],
		mistakes: [{
			wrong: "t = (1, 2, 3)\nt[0] = 9",
			right: "t = (9,) + t[1:]",
			why: "You cannot assign to a tuple index. You build a new tuple from pieces."
		}, {
			wrong: "singleton = (5)",
			right: "singleton = (5,)",
			why: "Without the comma, the parentheses do nothing. `type((5))` is `int`."
		}],
		think: {
			question: "Why can `(1, 2)` be a dict key but `[1, 2]` cannot?",
			answer: "Keys must be hashable. Immutability of the tuple (and its items) makes its hash stable. A list could change, which would break the dict's lookup structure."
		},
		exercises: [
			{
				id: "tup-mini",
				title: "Swap the Python way",
				prompt: "a is 1 and b is 2. Swap them using tuple unpacking and print a then b on one line.",
				difficulty: "easy",
				starter: "a = 1\nb = 2\n",
				solution: "a = 1\nb = 2\na, b = b, a\nprint(a, b)",
				explanation: "The right-hand side is packed into a tuple first, then unpacked into the left-hand names. No temporary is needed.",
				checks: [{
					kind: "stdout",
					expected: "2 1"
				}]
			},
			{
				id: "tup-practical",
				title: "First and rest",
				prompt: "data = ('ok', 200, 'saved'). Unpack into status, code, and extra. Print status and code separated by a colon and a space, like ok: 200",
				difficulty: "medium",
				starter: "data = ('ok', 200, 'saved')\n",
				solution: "data = ('ok', 200, 'saved')\nstatus, code, extra = data\nprint(f'{status}: {code}')",
				hint: "Three names on the left, or status, code, _ = data if you will not use extra.",
				explanation: "Unpacking documents the record shape. An f-string then formats the two fields you care about.",
				checks: [{
					kind: "stdout",
					expected: "ok: 200"
				}]
			},
			{
				id: "tup-hard",
				title: "Hashable pair",
				prompt: "Build a dict whose keys are tuples (name, year) and values are scores. Insert ('Ada', 2026) -> 98 and ('Lin', 2026) -> 91. Print the value for ('Ada', 2026).",
				difficulty: "hard",
				starter: "scores = {}\n",
				solution: "scores = {}\nscores[('Ada', 2026)] = 98\nscores[('Lin', 2026)] = 91\nprint(scores[('Ada', 2026)])",
				optional: true,
				explanation: "A tuple of strings and ints is hashable, so it can key a dict. This is how you store a composite lookup.",
				checks: [{
					kind: "stdout",
					expected: "98"
				}]
			}
		]
	},
	sets: {
		topicId: "sets",
		revision: {
			heading: "Uniqueness as a data structure",
			body: "Lists remember order and duplicates. When you only care whether something is in the collection, a set is the right tool. You already use `in` on lists — on a set it is the main operation, and it is fast.",
			code: "seen = {1, 2, 2, 3}\nprint(seen)"
		},
		concept: {
			heading: "Sets are bags of unique hashable items",
			explanation: "A set is an unordered collection of unique, hashable objects. Duplicates collapse. There is no index — `{1, 2}[0]` is an error. What you get instead are set operations: union `|`, intersection `&`, difference `-`, symmetric difference `^`. `add` and `discard` mutate. A set comprehension `{x for x in xs}` is the usual way to build one. `frozenset` is the immutable variant, usable as a dict key.",
			definition: "A set is an unordered collection of distinct hashable elements supporting membership tests and algebraic set operations.",
			analogy: "A guest list where each person appears once. You can ask 'is Sam here?' instantly. You cannot ask for 'the third guest' because there is no line — only presence."
		},
		examples: [{
			title: "Deduplicate, lose order",
			code: "names = ['ada', 'lin', 'ada', 'moe']\nprint(sorted(set(names)))",
			why: "`set(names)` drops duplicates. `sorted` turns the unordered set back into a stable list for display."
		}, {
			title: "Set algebra",
			code: "python = {'ada', 'lin', 'moe'}\njs = {'lin', 'kai'}\nprint(sorted(python & js))\nprint(sorted(python - js))",
			why: "Intersection is people in both. Difference is people in Python but not JS. Sorting makes the output deterministic."
		}],
		mistakes: [{
			wrong: "empty = {}",
			right: "empty = set()",
			why: "`{}` is an empty dict. The empty set is `set()`."
		}, {
			wrong: "s = {1, 2}\nprint(s[0])",
			right: "s = {1, 2}\nprint(1 in s)",
			why: "Sets are not sequences. Membership replaces indexing."
		}],
		exercises: [
			{
				id: "set-mini",
				title: "Unique letters",
				prompt: "s = \"balloon\". Print the number of unique letters.",
				difficulty: "easy",
				starter: "s = \"balloon\"\n",
				solution: "s = \"balloon\"\nprint(len(set(s)))",
				explanation: "A set of characters collapses repeats. Length is the unique count. 'balloon' has a, b, l, n, o → 5.",
				checks: [{
					kind: "stdout",
					expected: "5"
				}]
			},
			{
				id: "set-practical",
				title: "Shared skills",
				prompt: "a = {'python', 'git', 'sql'} and b = {'python', 'html', 'git'}. Print a sorted list of skills they share.",
				difficulty: "medium",
				starter: "a = {'python', 'git', 'sql'}\nb = {'python', 'html', 'git'}\n",
				solution: "a = {'python', 'git', 'sql'}\nb = {'python', 'html', 'git'}\nprint(sorted(a & b))",
				explanation: "Intersection `&` is the shared set. `sorted` gives a list Python will print the same way every time.",
				checks: [{
					kind: "stdout",
					expected: "['git', 'python']"
				}]
			},
			{
				id: "set-hard",
				title: "Only in the left",
				prompt: "Print a sorted list of items in [1, 2, 3, 3, 4] that are not in [3, 5].",
				difficulty: "hard",
				starter: "left = [1, 2, 3, 3, 4]\nright = [3, 5]\n",
				solution: "left = [1, 2, 3, 3, 4]\nright = [3, 5]\nprint(sorted(set(left) - set(right)))",
				optional: true,
				explanation: "Convert both to sets, then difference. Sorting for a stable print.",
				checks: [{
					kind: "stdout",
					expected: "[1, 2, 4]"
				}]
			}
		]
	},
	dictionaries: {
		topicId: "dictionaries",
		revision: {
			heading: "Lookup by name",
			body: "A list answers 'what is at position 3?'. A dictionary answers 'what is the score for Ada?'. Keys must be hashable. Values can be anything.",
			code: "user = {'name': 'Ada', 'year': 2026}\nprint(user['name'])"
		},
		concept: {
			heading: "Mappings, not sequences",
			explanation: "A dict maps keys to values. You insert and fetch with `d[key]`. Missing keys raise `KeyError` — use `d.get(key, default)` when absence is normal. Iteration walks keys by default; `.values()` and `.items()` give the rest. Since Python 3.7, insertion order is preserved, but a dict is still a mapping, not a list. Dict comprehensions `{k: v for ...}` build new mappings. Nesting dicts is how JSON-shaped data lives in Python.",
			definition: "A dictionary is a mutable mapping from hashable keys to values, providing average-case constant-time lookup.",
			analogy: "A dictionary is a labelled filing cabinet. You do not count drawers from the left; you ask for the folder named 'Ada'."
		},
		examples: [
			{
				title: "get versus index",
				code: "scores = {'Ada': 98}\nprint(scores.get('Lin', 0))\nprint('Ada' in scores)",
				why: "`get` returns the default instead of crashing. `in` on a dict checks keys, not values."
			},
			{
				title: "items and a running total",
				code: "cart = {'pen': 2, 'book': 5}\ntotal = 0\nfor item, price in cart.items():\n    total += price\nprint(total)",
				why: "`.items()` unpacks each pair. This is the standard loop over a mapping."
			},
			{
				title: "Comprehension",
				code: "names = ['Ada', 'Lin']\nprint({n: len(n) for n in names})",
				why: "Each name becomes a key; the value is derived. This is how you project a list into a lookup table."
			}
		],
		mistakes: [{
			wrong: "for k, v in scores:",
			right: "for k, v in scores.items():",
			why: "Iterating a dict yields keys only. Unpacking a string key into k, v is not what you wanted."
		}, {
			wrong: "d = {[1, 2]: 'ok'}",
			right: "d = {(1, 2): 'ok'}",
			why: "Lists are unhashable. Use a tuple for a composite key."
		}],
		exercises: [
			{
				id: "dict-mini",
				title: "Safe lookup",
				prompt: "ages = {'Ada': 36, 'Lin': 29}. Print ages.get('Moe', 'unknown').",
				difficulty: "easy",
				starter: "ages = {'Ada': 36, 'Lin': 29}\n",
				solution: "ages = {'Ada': 36, 'Lin': 29}\nprint(ages.get('Moe', 'unknown'))",
				explanation: "Moe is missing, so get returns the default instead of raising.",
				checks: [{
					kind: "stdout",
					expected: "unknown"
				}]
			},
			{
				id: "dict-practical",
				title: "Count letters",
				prompt: "Count characters in \"ababa\" using a dict. Print the count for \"a\".",
				difficulty: "medium",
				starter: "text = \"ababa\"\ncounts = {}\n",
				solution: "text = \"ababa\"\ncounts = {}\nfor ch in text:\n    counts[ch] = counts.get(ch, 0) + 1\nprint(counts[\"a\"])",
				hint: "get(ch, 0) + 1 is the usual increment.",
				explanation: "This is a frequency map. Each character is a key; the value is how often it appeared.",
				checks: [{
					kind: "stdout",
					expected: "3"
				}]
			},
			{
				id: "dict-hard",
				title: "Invert",
				prompt: "Given {'Ada': 'math', 'Lin': 'physics'}, print a new dict mapping field to name.",
				difficulty: "hard",
				starter: "fields = {'Ada': 'math', 'Lin': 'physics'}\n",
				solution: "fields = {'Ada': 'math', 'Lin': 'physics'}\nprint({v: k for k, v in fields.items()})",
				optional: true,
				explanation: "A dict comprehension swapping k and v inverts a one-to-one mapping.",
				checks: [{
					kind: "stdout",
					expected: "{'math': 'Ada', 'physics': 'Lin'}"
				}]
			}
		]
	},
	strings: {
		topicId: "strings",
		revision: {
			heading: "Text is a sequence",
			body: "Strings are immutable sequences of characters. You can index and slice them like lists, but you cannot assign to an index. Methods return new strings.",
			code: "s = \"Helix\"\nprint(s[0], s[-1], s[1:4])"
		},
		concept: {
			heading: "Methods, splits, and f-strings",
			explanation: "Because strings are immutable, `s.upper()` returns a new string; `s` is unchanged unless you rebind. `split` turns text into a list; `join` goes the other way — and `join` is called on the separator: `' '.join(words)`. `strip` removes surrounding whitespace. f-strings (`f'{name} is {age}'`) interpolate expressions. Prefer them over `+` chains. `in` tests substrings. `find` / `replace` cover search and substitute.",
			definition: "A string is an immutable sequence of Unicode characters. String methods return new strings; they do not mutate in place.",
			analogy: "A string is a printed sentence. You can copy it in capitals, but the original page does not change. `split` cuts the sentence into word cards; `join` tapes them back with a chosen glue."
		},
		examples: [{
			title: "split and join",
			code: "line = \"ada,lin,moe\"\nnames = line.split(\",\")\nprint(\" | \".join(names))",
			why: "split takes a separator and returns a list. join is a method of the glue string, not of the list."
		}, {
			title: "f-string with an expression",
			code: "n = 7\nprint(f'{n} squared is {n * n}')",
			why: "The braces hold any expression, not just a variable. Formatting happens at runtime."
		}],
		mistakes: [{
			wrong: "s = \"abc\"\ns[0] = \"A\"",
			right: "s = \"A\" + s[1:]",
			why: "Strings do not support item assignment. Build a new string."
		}, {
			wrong: "words.join(\",\")",
			right: "\",\" .join(words)",
			why: "join lives on the separator string."
		}],
		exercises: [
			{
				id: "str-mini",
				title: "Title case words",
				prompt: "text = \"pyduke python tutor\". Print it with each word capitalised (str.title).",
				difficulty: "easy",
				starter: "text = \"pyduke python tutor\"\n",
				solution: "text = \"pyduke python tutor\"\nprint(text.title())",
				explanation: "`title` capitalises the first character of each word.",
				checks: [{
					kind: "stdout",
					expected: "Pyduke Python Tutor"
				}]
			},
			{
				id: "str-practical",
				title: "CSV names",
				prompt: "raw = \" ada, lin, moe \". Split on commas, strip each name, and print the cleaned list.",
				difficulty: "medium",
				starter: "raw = \" ada, lin, moe \"\n",
				solution: "raw = \" ada, lin, moe \"\nprint([part.strip() for part in raw.split(\",\")])",
				explanation: "split gives pieces that still have spaces. strip on each piece is the usual cleanup.",
				checks: [{
					kind: "stdout",
					expected: "['ada', 'lin', 'moe']"
				}]
			},
			{
				id: "str-hard",
				title: "Initials",
				prompt: "name = \"Ada Lovelace\". Print initials joined by dots, like A.L.",
				difficulty: "hard",
				starter: "name = \"Ada Lovelace\"\n",
				solution: "name = \"Ada Lovelace\"\nparts = name.split()\nprint(\".\".join(p[0] for p in parts) + \".\")",
				optional: true,
				explanation: "Split into words, take the first character of each, join with dots, and add a trailing dot.",
				checks: [{
					kind: "stdout",
					expected: "A.L."
				}]
			}
		]
	},
	functions: {
		topicId: "functions",
		revision: {
			heading: "Name the work",
			body: "A function packages a suite of statements under a name. You call it with arguments. `return` hands a value back; without it the function returns None.",
			code: "def double(n):\n    return n * 2\n\nprint(double(5))"
		},
		concept: {
			heading: "Parameters, arguments, return",
			explanation: "Parameters are the names in the definition. Arguments are the values you pass at the call. Defaults (`def greet(name, punct='!')`) fill in missing arguments. A function should do one job. Return a value instead of printing when the caller might want to use the result. `*args` collects extra positional arguments into a tuple; `**kwargs` collects extra keywords into a dict. Docstrings are the first string in the body — they document, they are not comments.",
			definition: "A function is a callable object that executes a suite in its own frame, binding parameters to arguments, and returns a value (or None).",
			analogy: "A function is a recipe card: ingredients are parameters, the meal is the return value. Printing from a function is serving the meal in the kitchen — the dining room never sees it."
		},
		examples: [{
			title: "Return versus print",
			code: "def area(w, h):\n    return w * h\n\nprint(area(3, 4) + 1)",
			why: "Because area returns a number, the caller can add 1. If area printed instead, you could not compute with the result."
		}, {
			title: "Default argument",
			code: "def greet(name, title='friend'):\n    return f'Hello, {title} {name}'\n\nprint(greet('Ada'))\nprint(greet('Ada', 'Dr'))",
			why: "The default is used only when the caller omits the argument. Never use a mutable object as a default — we cover that in Scope."
		}],
		mistakes: [{
			wrong: "def add(a, b):\n    print(a + b)\n\nx = add(1, 2) + 3",
			right: "def add(a, b):\n    return a + b\n\nx = add(1, 2) + 3",
			why: "print does not return the sum. x would be None + 3, which crashes."
		}],
		exercises: [
			{
				id: "fn-mini",
				title: "is_even",
				prompt: "Define is_even(n) that returns True when n is even. Print is_even(6) and is_even(7) on two lines.",
				difficulty: "easy",
				starter: "def is_even(n):\n    ...\n",
				solution: "def is_even(n):\n    return n % 2 == 0\n\nprint(is_even(6))\nprint(is_even(7))",
				explanation: "Return the boolean expression directly. No if is required.",
				checks: [{
					kind: "stdout",
					expected: "True\nFalse"
				}]
			},
			{
				id: "fn-practical",
				title: "clamp",
				prompt: "Write clamp(n, lo, hi) that returns n limited to the inclusive range [lo, hi]. Print clamp(12, 0, 10), clamp(-3, 0, 10), clamp(7, 0, 10) on three lines.",
				difficulty: "medium",
				starter: "def clamp(n, lo, hi):\n    ...\n",
				solution: "def clamp(n, lo, hi):\n    if n < lo:\n        return lo\n    if n > hi:\n        return hi\n    return n\n\nprint(clamp(12, 0, 10))\nprint(clamp(-3, 0, 10))\nprint(clamp(7, 0, 10))",
				explanation: "Two guards, then the value itself. Equivalent: `max(lo, min(hi, n))`.",
				checks: [{
					kind: "stdout",
					expected: "10\n0\n7"
				}]
			},
			{
				id: "fn-hard",
				title: "average",
				prompt: "Write average(*nums) that returns the arithmetic mean as a float. Print average(2, 4, 6) and average(10).",
				difficulty: "hard",
				starter: "def average(*nums):\n    ...\n",
				solution: "def average(*nums):\n    return sum(nums) / len(nums)\n\nprint(average(2, 4, 6))\nprint(average(10))",
				optional: true,
				explanation: "*nums packs positional arguments into a tuple. Mean is total divided by count. 10/1 is 10.0 because `/` is true division.",
				checks: [{
					kind: "stdout",
					expected: "4.0\n10.0"
				}]
			}
		]
	},
	scope: {
		topicId: "scope",
		revision: {
			heading: "Names live somewhere",
			body: "A name bound inside a function is local. A name bound at the top of a file is global. Python looks up names using LEGB: Local, Enclosing, Global, Built-in.",
			code: "x = 1\n\ndef f():\n    x = 2\n    print(x)\n\nf()\nprint(x)"
		},
		concept: {
			heading: "LEGB and the mutable default trap",
			explanation: "When Python sees a name, it searches the local function, then any enclosing functions, then the module, then builtins. Assignment in a function makes the name local for the whole function, which is why `x = x + 1` can raise UnboundLocalError if x was only global. `global` and `nonlocal` rebind outer names — use them rarely. Default argument values are evaluated once, when `def` runs. A default of `[]` is the same list on every call, which leaks state. Use `None` and create the list inside the body.",
			definition: "Scope is the region of a program where a name is visible. Python uses lexical (static) scope with the LEGB lookup rule.",
			analogy: "A local variable is a sticky note on your desk. A global is a poster in the hallway. You can read the poster from your desk, but writing on a new sticky note does not change the poster."
		},
		examples: [{
			title: "UnboundLocalError",
			code: "n = 1\n\ndef bump():\n    print(n)\n\nbump()",
			why: "This works because bump only reads n. If bump contained `n = n + 1` without `global n`, the name n would be local and the read would fail."
		}, {
			title: "Safe default",
			code: "def add_item(item, box=None):\n    if box is None:\n        box = []\n    box.append(item)\n    return box\n\nprint(add_item('a'))\nprint(add_item('b'))",
			why: "Each call that omits box gets a fresh list. A default of `[]` would keep growing one shared list."
		}],
		mistakes: [{
			wrong: "def add(item, box=[]):\n    box.append(item)\n    return box",
			right: "def add(item, box=None):\n    if box is None:\n        box = []\n    box.append(item)\n    return box",
			why: "The empty list is created once. Later calls reuse it."
		}],
		exercises: [{
			id: "scope-mini",
			title: "Local versus global",
			prompt: "x = 10. Define f that binds a local x to 20 and prints it. Call f, then print the global x. Two lines: 20 then 10.",
			difficulty: "easy",
			starter: "x = 10\n\ndef f():\n    ...\n",
			solution: "x = 10\n\ndef f():\n    x = 20\n    print(x)\n\nf()\nprint(x)",
			explanation: "The assignment inside f is local. The global x is unchanged.",
			checks: [{
				kind: "stdout",
				expected: "20\n10"
			}]
		}, {
			id: "scope-practical",
			title: "Fresh list each call",
			prompt: "Write bag(item, items=None) that appends item to a new list when items is omitted. Print bag('a') and bag('b') on two lines.",
			difficulty: "medium",
			starter: "def bag(item, items=None):\n    ...\n",
			solution: "def bag(item, items=None):\n    if items is None:\n        items = []\n    items.append(item)\n    return items\n\nprint(bag('a'))\nprint(bag('b'))",
			explanation: "None is immutable, so it is a safe default. You create the list per call.",
			checks: [{
				kind: "stdout",
				expected: "['a']\n['b']"
			}]
		}]
	},
	errors: {
		topicId: "errors",
		revision: {
			heading: "Failures are values too",
			body: "When Python cannot continue, it raises an exception. If nothing handles it, the program stops and prints a traceback. You can handle exceptions with try/except.",
			code: "try:\n    int('q')\nexcept ValueError:\n    print('not a number')"
		},
		concept: {
			heading: "Catch specific, raise clearly",
			explanation: "A try suite is the risky work. except matches by type. Catch the narrowest type you can (`ValueError`, `KeyError`, `FileNotFoundError`) — a bare `except:` also swallows KeyboardInterrupt and bugs. `else` runs when no exception occurred. `finally` always runs (cleanup). `raise ValueError('msg')` starts an exception. Exceptions are for exceptional paths, not everyday branching.",
			definition: "An exception is an object signalling that a statement failed. Handling transfers control to a matching except clause.",
			analogy: "A fire alarm is an exception. You do not use it to announce lunch. You do install a sprinkler (except) for the fires you can handle, and you let the others reach the fire department (the traceback)."
		},
		examples: [{
			title: "else and finally",
			code: "def parse(s):\n    try:\n        n = int(s)\n    except ValueError:\n        return None\n    else:\n        return n * 2\n\nprint(parse('4'))\nprint(parse('x'))",
			why: "`else` runs only on success, so `n * 2` never sees a failed conversion. Returning None is one way to signal 'could not parse'."
		}],
		mistakes: [{
			wrong: "try:\n    risky()\nexcept:\n    pass",
			right: "try:\n    risky()\nexcept ValueError as e:\n    print(e)",
			why: "Bare except hides bugs. Name the exception you expect."
		}],
		exercises: [{
			id: "err-mini",
			title: "Safe int",
			prompt: "Write safe_int(s) that returns the integer or None if conversion fails. Print safe_int('9') and safe_int('q').",
			difficulty: "easy",
			starter: "def safe_int(s):\n    ...\n",
			solution: "def safe_int(s):\n    try:\n        return int(s)\n    except ValueError:\n        return None\n\nprint(safe_int('9'))\nprint(safe_int('q'))",
			explanation: "int('q') raises ValueError. Catching that type and returning None is a clean API for 'maybe a number'.",
			checks: [{
				kind: "stdout",
				expected: "9\nNone"
			}]
		}, {
			id: "err-practical",
			title: "Raise on bad age",
			prompt: "Write adult(age) that returns True if age >= 18, False if 0 <= age < 18, and raises ValueError if age is negative. Print adult(20) and adult(7), then try adult(-1) and print 'bad' in except ValueError.",
			difficulty: "medium",
			starter: "def adult(age):\n    ...\n",
			solution: "def adult(age):\n    if age < 0:\n        raise ValueError('age')\n    return age >= 18\n\nprint(adult(20))\nprint(adult(7))\ntry:\n    adult(-1)\nexcept ValueError:\n    print('bad')",
			explanation: "Invalid input is exceptional — raise. Valid ages return a boolean.",
			checks: [{
				kind: "stdout",
				expected: "True\nFalse\nbad"
			}]
		}]
	},
	modules: {
		topicId: "modules",
		revision: {
			heading: "Files as namespaces",
			body: "A module is a Python file. `import math` loads it and binds the name math. `from math import sqrt` binds sqrt directly. `if __name__ == '__main__'` is true only when the file is the program being run.",
			code: "import math\nprint(math.sqrt(16))"
		},
		concept: {
			heading: "import is execution plus a cache",
			explanation: "The first import executes the file from top to bottom and stores the module in `sys.modules`. Later imports reuse that object. Aliases (`import math as m`) change only the local name. `__name__` is `'__main__'` for the entry file and the module name otherwise — that is how you keep a file both importable and runnable. In this sandbox, `math`, `json`, `random`, `datetime`, and other stdlib modules work. Network and OS process modules are blocked.",
			definition: "A module is a unit of organisation: a file whose top-level names form a namespace, loaded with import.",
			analogy: "A module is a toolbox. `import math` puts the whole box on the bench. `from math import sqrt` takes one tool out. `__name__ == '__main__'` asks 'was this toolbox opened as the job, or borrowed by another job?'"
		},
		examples: [{
			title: "Alias and from-import",
			code: "import math as m\nfrom math import pi\nprint(m.ceil(2.1), round(pi, 2))",
			why: "Two styles, same module. The alias keeps the namespace. from-import copies a name into yours."
		}],
		mistakes: [{
			wrong: "from math import *",
			right: "from math import sqrt, pi",
			why: "Star imports dump unknown names into your scope and make collisions hard to see."
		}],
		exercises: [{
			id: "mod-mini",
			title: "Hypotenuse",
			prompt: "Use math.hypot to print the hypotenuse of a 3-4-5 triangle as an integer if it is whole, else as is. For 3 and 4 it is 5.0 — print it.",
			difficulty: "easy",
			starter: "import math\n",
			solution: "import math\nprint(math.hypot(3, 4))",
			explanation: "hypot(dx, dy) is the Euclidean length. 3-4-5 is the classic integer triangle, returned as 5.0.",
			checks: [{
				kind: "stdout",
				expected: "5.0"
			}]
		}, {
			id: "mod-practical",
			title: "Main guard demo",
			prompt: "Bind a function hello() that returns 'hi'. Under if __name__ == '__main__', print hello(). (In the playground the file is main, so it will print.)",
			difficulty: "medium",
			starter: "def hello():\n    return 'hi'\n",
			solution: "def hello():\n    return 'hi'\n\nif __name__ == '__main__':\n    print(hello())",
			explanation: "The guard runs here because the sandbox executes your file as the main program. If another module imported it, hello would exist but the print would not run.",
			checks: [{
				kind: "stdout",
				expected: "hi"
			}]
		}]
	},
	files: {
		topicId: "files",
		revision: {
			heading: "Data that outlives the run",
			body: "Files are how programs remember. `open(path)` returns a file object. Always close it — the `with` statement does that even if an error occurs. This playground uses a virtual disk: files you write are real inside the sandbox, not on a host machine.",
			code: "with open('note.txt', 'w') as f:\n    f.write('hello')\n"
		},
		concept: {
			heading: "Modes, context managers, paths",
			explanation: "`'r'` reads (default), `'w'` writes (truncates), `'a'` appends, `'rb'`/`'wb'` are binary. `read()` returns the whole text; `readline()` one line; iterating the file walks lines including newline characters — `strip()` them. `write` takes a string and does not add a newline for you. The `with` statement is a context manager: it enters (opens) and exits (closes) reliably. Paths can be relative; we start in a workspace folder.",
			definition: "A file object is a handle to a stream of bytes or text. A context manager (`with`) guarantees setup and teardown around a block.",
			analogy: "Opening a file is borrowing a book from a desk. `with` puts it back on the shelf even if you knock the lamp over mid-sentence."
		},
		examples: [{
			title: "Write then read",
			code: "with open('memo.txt', 'w') as f:\n    f.write('helix\\n')\nwith open('memo.txt') as f:\n    print(f.read().strip())",
			why: "Two with-blocks: one writes, one reads. strip removes the trailing newline so print does not add a blank line."
		}],
		mistakes: [{
			wrong: "f = open('a.txt', 'w')\nf.write('x')",
			right: "with open('a.txt', 'w') as f:\n    f.write('x')",
			why: "Without with (or close), data may not flush and the handle leaks."
		}],
		exercises: [{
			id: "file-mini",
			title: "Round trip",
			prompt: "Write 'Ada' to 'name.txt', read it back, and print the contents with no extra newline.",
			difficulty: "easy",
			starter: "",
			solution: "with open('name.txt', 'w') as f:\n    f.write('Ada')\nwith open('name.txt') as f:\n    print(f.read())",
			explanation: "write does not add a newline. read returns exactly what was written. print adds one newline at the end.",
			checks: [{
				kind: "stdout",
				expected: "Ada"
			}]
		}, {
			id: "file-practical",
			title: "Line count",
			prompt: "Write three lines 'a', 'b', 'c' (each ended by newline) to 'lines.txt'. Then print how many lines the file has.",
			difficulty: "medium",
			starter: "",
			solution: "with open('lines.txt', 'w') as f:\n    f.write('a\\nb\\nc\\n')\nwith open('lines.txt') as f:\n    print(len(f.readlines()))",
			explanation: "readlines returns a list of lines. Its length is the line count.",
			checks: [{
				kind: "stdout",
				expected: "3"
			}]
		}]
	},
	oop: {
		topicId: "oop",
		revision: {
			heading: "Data plus behaviour",
			body: "A class is a blueprint. An instance (object) is one concrete value of that blueprint. Methods are functions that receive the instance as `self`.",
			code: "class Point:\n    def __init__(self, x, y):\n        self.x = x\n        self.y = y"
		},
		concept: {
			heading: "Objects are namespaces you define",
			explanation: "`class Name:` creates a type. `__init__` initialises a new instance; it is not the constructor itself — `Point(1, 2)` constructs, then `__init__` fills in attributes. `self` is the instance, passed automatically on method calls. Attributes live on `self`. `__str__` is the human string (print); `__repr__` is the unambiguous developer string. Inheritance (`class Admin(User)`) reuses and extends. Start with one class that earns its keep — do not invent hierarchies for their own sake.",
			definition: "A class defines a type. An object is an instance of a class, combining state (attributes) with behaviour (methods).",
			analogy: "A class is the blueprint of a bicycle. Each bike in the rack is an instance. `self` is 'this bike'. A method like `brake` only makes sense on a particular bike."
		},
		examples: [{
			title: "A tiny counter",
			code: "class Counter:\n    def __init__(self):\n        self.n = 0\n    def inc(self):\n        self.n += 1\n\nc = Counter()\nc.inc()\nc.inc()\nprint(c.n)",
			why: "State lives on the instance. Two Counter() objects would not share n."
		}],
		mistakes: [{
			wrong: "def __init__(x, y):\n    self.x = x",
			right: "def __init__(self, x, y):\n    self.x = x\n    self.y = y",
			why: "The first parameter of an instance method is the instance. By convention it is named self."
		}],
		exercises: [{
			id: "oop-mini",
			title: "Rectangle area",
			prompt: "Write class Rect with __init__(self, w, h) and method area(self). Print Rect(3, 4).area().",
			difficulty: "easy",
			starter: "class Rect:\n    ...\n",
			solution: "class Rect:\n    def __init__(self, w, h):\n        self.w = w\n        self.h = h\n    def area(self):\n        return self.w * self.h\n\nprint(Rect(3, 4).area())",
			explanation: "Store width and height on self, then multiply in area.",
			checks: [{
				kind: "stdout",
				expected: "12"
			}]
		}, {
			id: "oop-practical",
			title: "Bank-ish",
			prompt: "Class Vault with balance starting at 0, methods deposit(n) and withdraw(n) that refuse to go negative (leave balance unchanged if n is too big). Deposit 50, withdraw 20, withdraw 100, print balance.",
			difficulty: "medium",
			starter: "class Vault:\n    ...\n",
			solution: "class Vault:\n    def __init__(self):\n        self.balance = 0\n    def deposit(self, n):\n        self.balance += n\n    def withdraw(self, n):\n        if n <= self.balance:\n            self.balance -= n\n\nv = Vault()\nv.deposit(50)\nv.withdraw(20)\nv.withdraw(100)\nprint(v.balance)",
			explanation: "The guard on withdraw is an invariant: balance never drops below zero. 50-20=30, the 100 is ignored.",
			checks: [{
				kind: "stdout",
				expected: "30"
			}]
		}]
	},
	stdlib: {
		topicId: "stdlib",
		revision: {
			heading: "Batteries included",
			body: "The standard library is the set of modules that ship with Python. You already used math. Next: datetime, random, json, collections.",
			code: "import json\nprint(json.dumps({'ok': True}))"
		},
		concept: {
			heading: "Prefer the stdlib until it hurts",
			explanation: "`datetime` handles dates. `random` samples (seed it in tests). `json` serialises dicts and lists to text. `collections.Counter` counts, `defaultdict` supplies missing keys. `pathlib.Path` is object-oriented paths. Read the docs for the module you import — do not guess method names. In this sandbox, `random` works; output that depends on randomness should be seeded.",
			definition: "The Python standard library is a collection of modules distributed with the interpreter, covering common tasks without third-party packages.",
			analogy: "The stdlib is the kitchen already in the apartment. You can cook a lot before you buy a specialty gadget (an external package)."
		},
		examples: [{
			title: "Counter and json",
			code: "from collections import Counter\nimport json\nc = Counter('ababa')\nprint(json.dumps({'a': c['a'], 'b': c['b']}))",
			why: "Counter is a dict specialised for counts. json.dumps turns a dict into a string that another program could parse."
		}, {
			title: "Seeded random",
			code: "import random\nrandom.seed(1)\nprint(random.randint(1, 6))",
			why: "A seed makes the sequence reproducible — essential for tests and lessons."
		}],
		mistakes: [{
			wrong: "import random\nprint(random.randint(1, 6))",
			right: "import random\nrandom.seed(0)\nprint(random.randint(1, 6))",
			why: "Unseeded random is correct in apps, but not in checks that need a fixed answer."
		}],
		exercises: [{
			id: "std-mini",
			title: "JSON round trip",
			prompt: "Dump {'n': 3} to a JSON string, load it back, print the n value.",
			difficulty: "easy",
			starter: "import json\n",
			solution: "import json\ntext = json.dumps({'n': 3})\ndata = json.loads(text)\nprint(data['n'])",
			explanation: "dumps is to text; loads is back to a dict. Keys in JSON objects become strings.",
			checks: [{
				kind: "stdout",
				expected: "3"
			}]
		}, {
			id: "std-practical",
			title: "Most common",
			prompt: "Use Counter on 'mississippi'. Print the count of s.",
			difficulty: "medium",
			starter: "from collections import Counter\n",
			solution: "from collections import Counter\nprint(Counter('mississippi')['s'])",
			explanation: "s appears four times in mississippi.",
			checks: [{
				kind: "stdout",
				expected: "4"
			}]
		}]
	},
	apis: {
		topicId: "apis",
		revision: {
			heading: "Programs talking to programs",
			body: "An API is a contract: you send a request, you get a structured response. On the web that is often HTTP plus JSON. This sandbox does not open the real network. We practise the shape with a tiny fake client.",
			code: "import json\nbody = json.dumps({'q': 'ada'})\nprint(json.loads(body)['q'])"
		},
		concept: {
			heading: "HTTP, status, JSON",
			explanation: "A client sends a method (GET to read, POST to create) to a URL. The server answers with a status code: 200 ok, 201 created, 400 bad request, 404 missing, 500 server error. The body is often JSON — the same dict/list structure you already know, serialised as text. You parse it, then use keys. Real code uses `urllib` or `requests`; here we inject `pyduke_net.fetch(url)` which returns a dict for a few teaching URLs and raises on unknown ones.",
			definition: "An application programming interface is a documented set of operations a program exposes. A web API typically uses HTTP methods, URLs, and JSON payloads.",
			analogy: "An API is a restaurant order slip. You do not walk into the kitchen (the other program's internals). You write the dish (the URL and body) and get a plate back (JSON) plus a note if the dish is off (status code)."
		},
		examples: [{
			title: "Fake GET",
			code: "from pyduke_net import fetch\nuser = fetch('/users/1')\nprint(user['name'])",
			why: "fetch hides HTTP. You still treat the result as a dict. That is the skill that transfers to real clients."
		}],
		mistakes: [{
			wrong: "data = fetch('/users/1')\nprint(data.name)",
			right: "data = fetch('/users/1')\nprint(data['name'])",
			why: "JSON objects become dicts, not attribute bags. Use brackets."
		}],
		exercises: [{
			id: "api-mini",
			title: "Read a user",
			prompt: "Use pyduke_net.fetch('/users/1') and print the email field.",
			difficulty: "easy",
			starter: "from pyduke_net import fetch\n",
			solution: "from pyduke_net import fetch\nprint(fetch('/users/1')['email'])",
			explanation: "The teaching server maps /users/1 to a dict with name, email, id.",
			checks: [{
				kind: "stdout",
				expected: "ada@pyduke.dev"
			}]
		}, {
			id: "api-practical",
			title: "List names",
			prompt: "fetch('/users') returns a list of user dicts. Print a comma-separated list of names in order.",
			difficulty: "medium",
			starter: "from pyduke_net import fetch\n",
			solution: "from pyduke_net import fetch\nusers = fetch('/users')\nprint(','.join(u['name'] for u in users))",
			explanation: "Walk the list, pick the name key, join. Same pattern as any list of dicts.",
			checks: [{
				kind: "stdout",
				expected: "Ada,Lin"
			}]
		}]
	},
	projects: {
		topicId: "projects",
		revision: {
			heading: "From exercises to programs",
			body: "A project is several ideas working together. You do not write it top to bottom in one breath. You split: data, input, logic, output. The Projects tab has full builds. Here we practise the split."
		},
		concept: {
			heading: "Design a thin slice",
			explanation: "Start with the smallest thing that runs: one function, one print, one test. Name the nouns (what data exists) and the verbs (what happens). Keep I/O at the edges so logic can be tested. A number-guessing game is: secret, guess, compare, repeat. A to-do list is: a list of strings, add, show, remove. Resist pasting a whole program you do not understand.",
			definition: "A software project is a program with a purpose, split into modules or functions, built in thin vertical slices that each run.",
			analogy: "You do not build a house by finishing every brick first. You build a room you can stand in, then another."
		},
		examples: [{
			title: "A slice: compare one guess",
			code: "def judge(secret, guess):\n    if guess == secret:\n        return 'match'\n    if guess < secret:\n        return 'low'\n    return 'high'\n\nprint(judge(7, 3))\nprint(judge(7, 7))",
			why: "The comparison is a function. The loop and input wrap it later. You can test judge without typing."
		}],
		mistakes: [{
			wrong: "one 200-line file, no functions",
			right: "small functions, then a main that calls them",
			why: "Without functions you cannot test or reuse a piece. The program becomes a script you are afraid to touch."
		}],
		exercises: [{
			id: "proj-mini",
			title: "Judge",
			prompt: "Write judge(secret, guess) returning 'low', 'high', or 'match'. Print judge(10, 4), judge(10, 12), judge(10, 10).",
			difficulty: "easy",
			starter: "def judge(secret, guess):\n    ...\n",
			solution: "def judge(secret, guess):\n    if guess == secret:\n        return 'match'\n    if guess < secret:\n        return 'low'\n    return 'high'\n\nprint(judge(10, 4))\nprint(judge(10, 12))\nprint(judge(10, 10))",
			explanation: "This is the core of a guessing game, isolated from input. Three paths, three prints.",
			checks: [{
				kind: "stdout",
				expected: "low\nhigh\nmatch"
			}]
		}, {
			id: "proj-practical",
			title: "Todo add",
			prompt: "todos = []. Write add(todos, item) that appends and returns todos. Add 'read' and 'run', print the list.",
			difficulty: "medium",
			starter: "todos = []\n\ndef add(todos, item):\n    ...\n",
			solution: "todos = []\n\ndef add(todos, item):\n    todos.append(item)\n    return todos\n\nadd(todos, 'read')\nadd(todos, 'run')\nprint(todos)",
			explanation: "Passing the list in keeps add testable. Mutating and returning is a simple API for a first project.",
			checks: [{
				kind: "stdout",
				expected: "['read', 'run']"
			}]
		}]
	},
	advanced: {
		topicId: "advanced",
		revision: {
			heading: "The next layer",
			body: "You can write real programs now. Advanced Python is not a new language — it is better ways to express iteration, contracts, and wrapping behaviour: generators, type hints, and a first look at decorators."
		},
		concept: {
			heading: "Lazy sequences, hints, wrappers",
			explanation: "A generator function uses `yield`. It produces a stream without building the whole list. Type hints (`def f(n: int) -> str`) document contracts; Python does not enforce them at runtime unless a checker does. A decorator is a callable that takes a function and returns a wrapped function — `@decorator` is sugar for `f = decorator(f)`. Use these when they remove noise, not as decoration.",
			definition: "A generator is an iterator defined by a function that yields values. A type hint is an annotation of expected types. A decorator is a function that wraps another function.",
			analogy: "A list is a baked loaf. A generator is slicing bread as people eat. A type hint is the label on the bag. A decorator is a sleeve you slip the loaf into — same bread, extra wrapping."
		},
		examples: [{
			title: "A generator",
			code: "def squares(n):\n    for i in range(n):\n        yield i * i\n\nprint(list(squares(4)))",
			why: "yield pauses the function and hands back a value. list() consumes the generator to show the values."
		}, {
			title: "A hint",
			code: "def shout(text: str) -> str:\n    return text.upper()\n\nprint(shout('ok'))",
			why: "The hints tell humans (and type checkers) the contract. The body is ordinary Python."
		}],
		mistakes: [{
			wrong: "return i  # inside a supposed generator loop",
			right: "yield i",
			why: "return stops the function. yield produces the next item."
		}],
		exercises: [{
			id: "adv-mini",
			title: "Countdown generator",
			prompt: "Write countdown(n) that yields n, n-1, ... 1. Print list(countdown(3)).",
			difficulty: "medium",
			starter: "def countdown(n):\n    ...\n",
			solution: "def countdown(n):\n    while n > 0:\n        yield n\n        n -= 1\n\nprint(list(countdown(3)))",
			explanation: "Each yield emits the current n, then n moves down. When n is 0 the function ends and the generator stops.",
			checks: [{
				kind: "stdout",
				expected: "[3, 2, 1]"
			}]
		}, {
			id: "adv-practical",
			title: "Typed join",
			prompt: "Write def label(name: str, n: int) -> str that returns 'name: n'. Print label('Ada', 3).",
			difficulty: "easy",
			starter: "def label(name: str, n: int) -> str:\n    ...\n",
			solution: "def label(name: str, n: int) -> str:\n    return f'{name}: {n}'\n\nprint(label('Ada', 3))",
			explanation: "Hints do not change runtime. The f-string builds the contract you promised.",
			checks: [{
				kind: "stdout",
				expected: "Ada: 3"
			}]
		}]
	}
};
var ACHIEVEMENTS = [
	{
		id: "first-lesson",
		title: "First Lesson",
		blurb: "Complete your first lesson.",
		xp: 20,
		earned: (s) => s.lessonsCompleted.length >= 1
	},
	{
		id: "five-lessons",
		title: "Getting fluent",
		blurb: "Master five lessons.",
		xp: 40,
		earned: (s) => s.lessonsCompleted.length >= 5
	},
	{
		id: "bug-hunter",
		title: "Bug Hunter",
		blurb: "Fix 10 debugging challenges.",
		xp: 50,
		earned: (s) => (s.games.debug?.completed.length ?? 0) >= 10
	},
	{
		id: "python-typist",
		title: "Python Typist",
		blurb: "Complete 5 typing sessions.",
		xp: 30,
		earned: (s) => s.typingHistory.length >= 5
	},
	{
		id: "code-runner",
		title: "Code Runner",
		blurb: "Pass 10 coding exercises.",
		xp: 40,
		earned: (s) => Object.values(s.topics).reduce((n, t) => n + t.completedExercises.length, 0) >= 10
	},
	{
		id: "seven-day",
		title: "7 Day Streak",
		blurb: "Study for 7 consecutive days.",
		xp: 60,
		earned: (s) => s.streak >= 7
	},
	{
		id: "fixer-five",
		title: "Syntax surgeon",
		blurb: "Clear 5 Code Fixer challenges.",
		xp: 25,
		earned: (s) => (s.games.fixer?.completed.length ?? 0) >= 5
	},
	{
		id: "boss-clear",
		title: "Boss down",
		blurb: "Finish the boss battle.",
		xp: 80,
		earned: (s) => (s.games.boss?.completed.length ?? 0) >= 8
	},
	{
		id: "first-project",
		title: "Builder",
		blurb: "Complete a guided project.",
		xp: 35,
		earned: (s) => s.projectsCompleted.length >= 1
	},
	{
		id: "daily-three",
		title: "Showed up",
		blurb: "Finish daily practice 3 times.",
		xp: 30,
		earned: (s) => s.dailyCompletions >= 3
	}
];
var XP_FOR = {
	easy: 12,
	medium: 20,
	hard: 32,
	advanced: 48
};
function emptyGame() {
	return {
		completed: [],
		best: {},
		attempts: 0,
		correct: 0,
		streak: 0,
		bestStreak: 0,
		lastScore: 0,
		bestScore: 0
	};
}
function emptyTopics() {
	const now = Date.now();
	const out = {};
	for (const t of TOPICS) {
		let status = "locked";
		if (MASTERED_ON_ARRIVAL.includes(t.id)) status = "mastered";
		else if (t.id === "variables") status = "in_progress";
		out[t.id] = {
			status,
			score: status === "mastered" ? 100 : 0,
			attempts: 0,
			lastSeenAt: status === "mastered" ? now : 0,
			completedExercises: [],
			mistakes: []
		};
	}
	return out;
}
var EMPTY_IDS = [];
function dueTopicIds(topics) {
	const now = Date.now();
	const due = [];
	for (const t of TOPICS) {
		const p = topics[t.id];
		if (!p || p.status !== "mastered") continue;
		if (now - (p.lastSeenAt || 0) > 1296e5) due.push(t.id);
	}
	return due;
}
var initialSlice = () => ({
	name: "",
	xp: 0,
	streak: 0,
	lastActiveDate: todayKey(),
	currentTopicId: START_TOPIC,
	preferredDifficulty: "medium",
	recentResults: [],
	topics: emptyTopics(),
	games: {},
	projectsCompleted: [],
	typingHistory: [],
	snippets: [],
	tutor: [],
	lessonsCompleted: [...MASTERED_ON_ARRIVAL],
	achievements: [],
	dailyDate: todayKey(),
	dailyDone: [],
	dailyCompletions: 0,
	lastCode: "",
	lastError: "",
	lastExercise: "",
	hydrated: false
});
var storage = createJSONStorage(() => {
	if (typeof window === "undefined") return {
		getItem: () => null,
		setItem: () => {},
		removeItem: () => {}
	};
	return localStorage;
});
function grantAchievements(set, get) {
	const s = get();
	const have = new Set(s.achievements);
	const next = [...s.achievements];
	let xp = 0;
	for (const a of ACHIEVEMENTS) {
		if (have.has(a.id)) continue;
		if (a.earned(s)) {
			next.push(a.id);
			xp += a.xp;
		}
	}
	if (next.length !== s.achievements.length) set({
		achievements: next,
		xp: get().xp + xp
	});
}
var useHelix = create()(persist((set, get) => ({
	...initialSlice(),
	setHydrated: (v) => set({ hydrated: v }),
	setName: (name) => set({ name }),
	tickStreak: () => {
		const today = todayKey();
		const last = get().lastActiveDate;
		if (last === today) {
			if (get().dailyDate !== today) set({
				dailyDate: today,
				dailyDone: []
			});
			return;
		}
		const yest = /* @__PURE__ */ new Date();
		yest.setDate(yest.getDate() - 1);
		set({
			lastActiveDate: today,
			streak: last === todayKey(yest) ? get().streak + 1 : 1,
			dailyDate: today,
			dailyDone: []
		});
		grantAchievements(set, get);
	},
	awardXp: (n) => set({ xp: get().xp + n }),
	recordExercise: ({ topicId, exerciseId, ok, difficulty, note, code }) => {
		const topics = { ...get().topics };
		const t = { ...topics[topicId] };
		t.attempts += 1;
		t.lastSeenAt = Date.now();
		if (ok && !t.completedExercises.includes(exerciseId)) {
			t.completedExercises = [...t.completedExercises, exerciseId];
			t.score = Math.min(100, t.score + (difficulty === "easy" ? 15 : difficulty === "medium" ? 22 : 30));
		}
		if (!ok && note) t.mistakes = [...t.mistakes.slice(-11), {
			exerciseId,
			note,
			at: Date.now()
		}];
		if (t.status === "locked" || t.status === "available") t.status = "in_progress";
		topics[topicId] = t;
		const recent = [...get().recentResults, ok].slice(-6);
		let preferred = get().preferredDifficulty;
		const last3 = recent.slice(-3);
		if (last3.length === 3 && last3.every(Boolean)) preferred = preferred === "easy" ? "medium" : preferred === "medium" ? "hard" : "advanced";
		if (last3.length === 3 && last3.every((x) => !x)) preferred = preferred === "advanced" ? "hard" : preferred === "hard" ? "medium" : "easy";
		set({
			topics,
			recentResults: recent,
			preferredDifficulty: preferred,
			currentTopicId: topicId,
			xp: get().xp + (ok ? XP_FOR[difficulty] : 4),
			lastCode: code ?? get().lastCode,
			lastError: ok ? "" : note ?? get().lastError,
			lastExercise: exerciseId
		});
		grantAchievements(set, get);
	},
	completeLesson: (topicId) => {
		const topics = { ...get().topics };
		topics[topicId] = {
			...topics[topicId],
			status: "mastered",
			score: 100,
			lastSeenAt: Date.now()
		};
		set({
			topics,
			lessonsCompleted: get().lessonsCompleted.includes(topicId) ? get().lessonsCompleted : [...get().lessonsCompleted, topicId],
			xp: get().xp + 40,
			currentTopicId: topicId
		});
		get().unlockNext(topicId);
		grantAchievements(set, get);
	},
	unlockNext: (topicId) => {
		const next = TOPICS[TOPICS.findIndex((t) => t.id === topicId) + 1];
		if (!next) return;
		const topics = { ...get().topics };
		const cur = topics[next.id];
		if (cur.status === "locked") {
			topics[next.id] = {
				...cur,
				status: "available"
			};
			set({ topics });
		}
	},
	completeGameItem: (gameId, itemId, ok, score = 1) => {
		const games = { ...get().games };
		const prev = games[gameId];
		const already = Boolean(ok && prev?.completed.includes(itemId));
		const g = {
			...emptyGame(),
			...prev ?? {}
		};
		g.attempts += 1;
		if (ok) {
			g.completed = g.completed.includes(itemId) ? g.completed : [...g.completed, itemId];
			g.correct += 1;
			g.streak += 1;
			g.bestStreak = Math.max(g.bestStreak, g.streak);
			g.best = {
				...g.best,
				[itemId]: Math.max(g.best[itemId] ?? 0, score)
			};
		} else g.streak = 0;
		games[gameId] = g;
		set({
			games,
			xp: get().xp + (ok ? already ? 4 : 18 : 2)
		});
		grantAchievements(set, get);
	},
	finishGameSession: (gameId, score) => {
		const games = { ...get().games };
		const g = {
			...emptyGame(),
			...games[gameId] ?? {}
		};
		g.lastScore = score;
		g.bestScore = Math.max(g.bestScore ?? 0, score);
		games[gameId] = g;
		set({ games });
	},
	completeProject: (projectId) => {
		if (get().projectsCompleted.includes(projectId)) {
			set({ xp: get().xp + 8 });
			return;
		}
		set({
			projectsCompleted: [...get().projectsCompleted, projectId],
			xp: get().xp + 80
		});
		grantAchievements(set, get);
	},
	recordTyping: (rec) => {
		const xp = rec.accuracy >= 95 ? 16 : rec.accuracy >= 85 ? 10 : 4;
		set({
			typingHistory: [...get().typingHistory.slice(-79), rec],
			xp: get().xp + xp
		});
		grantAchievements(set, get);
	},
	saveSnippet: (title, code) => {
		set({ snippets: [{
			id: `${Date.now()}`,
			title: title.trim() || "Untitled",
			code,
			at: Date.now()
		}, ...get().snippets].slice(0, 40) });
	},
	deleteSnippet: (id) => set({ snippets: get().snippets.filter((s) => s.id !== id) }),
	pushTutor: (msg) => {
		const item = {
			...msg,
			id: `${Date.now()}-${Math.random()}`,
			at: Date.now()
		};
		set({ tutor: [...get().tutor, item].slice(-40) });
	},
	clearTutor: () => set({ tutor: [] }),
	markDaily: (slot) => {
		const today = todayKey();
		let date = get().dailyDate;
		let done = get().dailyDone;
		if (date !== today) {
			date = today;
			done = [];
		}
		if (done.includes(slot)) return;
		const next = [...done, slot];
		const finished = next.length >= 7;
		set({
			dailyDate: date,
			dailyDone: next,
			dailyCompletions: get().dailyCompletions + (finished ? 1 : 0),
			xp: get().xp + (finished ? 25 : 6)
		});
		grantAchievements(set, get);
	},
	resetProgress: () => {
		const keepName = get().name;
		set({
			...initialSlice(),
			name: keepName,
			hydrated: true
		});
	},
	dueRevision: () => dueTopicIds(get().topics)
}), {
	name: "pyduke-progress-v3",
	skipHydration: true,
	storage,
	partialize: (s) => ({
		name: s.name,
		xp: s.xp,
		streak: s.streak,
		lastActiveDate: s.lastActiveDate,
		currentTopicId: s.currentTopicId,
		preferredDifficulty: s.preferredDifficulty,
		recentResults: s.recentResults,
		topics: s.topics,
		games: s.games,
		projectsCompleted: s.projectsCompleted,
		typingHistory: s.typingHistory,
		snippets: s.snippets,
		tutor: s.tutor,
		lessonsCompleted: s.lessonsCompleted,
		achievements: s.achievements,
		dailyDate: s.dailyDate,
		dailyDone: s.dailyDone,
		dailyCompletions: s.dailyCompletions,
		lastCode: s.lastCode,
		lastError: s.lastError,
		lastExercise: s.lastExercise
	}),
	onRehydrateStorage: () => (state) => {
		state?.setHydrated(true);
	}
}));
function progressSummary(s) {
	const mastered = TOPICS.filter((t) => s.topics[t.id]?.status === "mastered").map((t) => t.title);
	const current = TOPICS.find((t) => t.id === s.currentTopicId)?.title ?? s.currentTopicId;
	const mistakes = Object.entries(s.topics).flatMap(([id, p]) => p.mistakes.slice(-2).map((m) => `${id}: ${m.note}`)).slice(-6);
	const lesson = LESSONS[s.currentTopicId];
	return [
		`Learner name: ${s.name || "(not set)"}`,
		`XP: ${s.xp}, level: ${levelFromXp(s.xp)}, streak: ${s.streak}`,
		`Current topic: ${current}`,
		`Mastered: ${mastered.join(", ") || "none"}`,
		`Preferred difficulty: ${s.preferredDifficulty}`,
		`Typing last WPM: ${s.typingHistory.at(-1)?.wpm ?? "n/a"} accuracy ${s.typingHistory.at(-1)?.accuracy ?? "n/a"}`,
		`Recent mistakes: ${mistakes.join(" | ") || "none recorded"}`,
		`Lesson heading: ${lesson?.concept.heading ?? ""}`,
		`Last exercise: ${s.lastExercise || "none"}`,
		`Last error: ${s.lastError || "none"}`
	].join("\n");
}
var PRIMARY = [
	{
		to: "/",
		label: "Home",
		icon: House
	},
	{
		to: "/learn",
		label: "Learn",
		icon: BookOpen
	},
	{
		to: "/practice",
		label: "Practice",
		icon: CalendarDays
	},
	{
		to: "/games",
		label: "Games",
		icon: Puzzle
	}
];
var MORE = [
	{
		to: "/code",
		label: "Code",
		icon: Terminal
	},
	{
		to: "/typing",
		label: "Typing",
		icon: Keyboard
	},
	{
		to: "/projects",
		label: "Projects",
		icon: FolderKanban
	},
	{
		to: "/progress",
		label: "Progress",
		icon: ChartNoAxesColumn
	},
	{
		to: "/tutor",
		label: "Tutor",
		icon: MessageSquare
	},
	{
		to: "/profile",
		label: "Profile",
		icon: CircleUser
	}
];
var ALL = [...PRIMARY, ...MORE];
function NavLink({ to, label, icon: Icon, onClick }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const active = to === "/" ? pathname === "/" : pathname === to || pathname.startsWith(`${to}/`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		onClick,
		className: cn("flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors duration-150", active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }), label]
	});
}
function AppShell({ children }) {
	const xp = useHelix((s) => s.xp);
	const streak = useHelix((s) => s.streak);
	const [moreOpen, setMoreOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		const finish = () => {
			useHelix.getState().setHydrated(true);
			useHelix.getState().tickStreak();
		};
		const unsub = useHelix.persist.onFinishHydration(finish);
		useHelix.persist.rehydrate();
		if (useHelix.persist.hasHydrated()) finish();
		warmupPython().catch(() => {});
		return unsub;
	}, []);
	const level = levelFromXp(xp);
	const into = xpIntoLevel(xp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border bg-sidebar px-3 py-5 md:flex",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "mb-6 flex items-center gap-2.5 px-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PyDukeMark, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg font-medium tracking-tight",
						children: "PyDuke"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-1 flex-col gap-0.5",
					children: ALL.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, { ...item }, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-2 rounded-lg bg-secondary p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: ["Level ", level]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums text-foreground",
								children: [into, "/150"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: into / 150 * 100 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: ["Streak ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-foreground",
								children: streak
							})]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-3 border-b border-border px-4 py-3 md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PyDukeMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-base font-medium",
							children: "PyDuke"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs tabular-nums text-muted-foreground",
						children: [
							"Lv ",
							level,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
								open: moreOpen,
								onOpenChange: setMoreOpen,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon-sm",
										"aria-label": "Menu",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
									side: "bottom",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "PyDuke" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
										className: "grid grid-cols-2 gap-1 pb-4",
										children: ALL.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
											...item,
											onClick: () => setMoreOpen(false)
										}, item.to))
									})]
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto w-full max-w-6xl flex-1 px-4 py-6 pb-24 md:px-8 md:py-8 md:pb-8",
					children
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-sidebar/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm md:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-5",
						children: [PRIMARY.map((item) => {
							const active = item.to === "/" ? pathname === "/" : pathname === item.to || pathname.startsWith(`${item.to}/`);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("flex h-14 flex-col items-center justify-center gap-1 text-[11px]", active ? "text-foreground" : "text-muted-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4" }), item.label]
							}, item.to);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setMoreOpen(true),
							className: "flex h-14 flex-col items-center justify-center gap-1 text-[11px] text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" }), "More"]
						})]
					})
				})
			]
		})]
	});
}
var TooltipProvider = Provider;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-sm bg-popover px-2.5 py-1.5 text-xs text-popover-foreground shadow-[var(--shadow-border)]", className),
	...props
}) }));
TooltipContent.displayName = Content2.displayName;
var styles_default = "/assets/styles-BzW475JB.css";
var APP_NAME = "PyDuke";
var Route$14 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "A personal Python tutor that remembers where you left off."
			},
			{
				name: "theme-color",
				content: "#111b27"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=IBM+Plex+Mono:wght@400;500&family=Outfit:wght@400;500;600&display=swap"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, {
				delayDuration: 200,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "bottom-right",
					toastOptions: { className: "bg-popover text-popover-foreground border-border" }
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$13 = () => import("./routes-CJh7Ckoo.mjs");
var Route$13 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./code-DvEgDG8J.mjs");
var Route$12 = createFileRoute("/code")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./games-Drj7ozvq.mjs");
var Route$11 = createFileRoute("/games")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./learn-D9nY5iwj.mjs");
var Route$10 = createFileRoute("/learn")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./practice-nFNDVBZS.mjs");
var Route$9 = createFileRoute("/practice")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./profile-DdcuCWd8.mjs");
var Route$8 = createFileRoute("/profile")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./progress-Ckm1Dv77.mjs");
var Route$7 = createFileRoute("/progress")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./projects-Cjq0i4Qr.mjs");
var Route$6 = createFileRoute("/projects")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./tutor-CnA7bJQp.mjs");
var Route$5 = createFileRoute("/tutor")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./typing-CUDwYTSU.mjs");
var Route$4 = createFileRoute("/typing")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./games._gameId-_y1maEF1.mjs");
var Route$3 = createFileRoute("/games/$gameId")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./learn._topicId-D0eHc53X.mjs");
var Route$2 = createFileRoute("/learn/$topicId")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./projects._projectId-l9_Zx7UL.mjs");
var Route$1 = createFileRoute("/projects/$projectId")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./tutor.live-XLHRrcFc.mjs");
var Route = createFileRoute("/tutor/live")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$14
});
var CodeRoute = Route$12.update({
	id: "/code",
	path: "/code",
	getParentRoute: () => Route$14
});
var GamesRoute = Route$11.update({
	id: "/games",
	path: "/games",
	getParentRoute: () => Route$14
});
var LearnRoute = Route$10.update({
	id: "/learn",
	path: "/learn",
	getParentRoute: () => Route$14
});
var PracticeRoute = Route$9.update({
	id: "/practice",
	path: "/practice",
	getParentRoute: () => Route$14
});
var ProfileRoute = Route$8.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => Route$14
});
var ProgressRoute = Route$7.update({
	id: "/progress",
	path: "/progress",
	getParentRoute: () => Route$14
});
var ProjectsRoute = Route$6.update({
	id: "/projects",
	path: "/projects",
	getParentRoute: () => Route$14
});
var TutorRoute = Route$5.update({
	id: "/tutor",
	path: "/tutor",
	getParentRoute: () => Route$14
});
var TypingRoute = Route$4.update({
	id: "/typing",
	path: "/typing",
	getParentRoute: () => Route$14
});
var GamesGameIdRoute = Route$3.update({
	id: "/$gameId",
	path: "/$gameId",
	getParentRoute: () => GamesRoute
});
var LearnTopicIdRoute = Route$2.update({
	id: "/$topicId",
	path: "/$topicId",
	getParentRoute: () => LearnRoute
});
var ProjectsProjectIdRoute = Route$1.update({
	id: "/$projectId",
	path: "/$projectId",
	getParentRoute: () => ProjectsRoute
});
var TutorLiveRoute = Route.update({
	id: "/live",
	path: "/live",
	getParentRoute: () => TutorRoute
});
var GamesRouteChildren = { GamesGameIdRoute };
var GamesRouteWithChildren = GamesRoute._addFileChildren(GamesRouteChildren);
var LearnRouteChildren = { LearnTopicIdRoute };
var LearnRouteWithChildren = LearnRoute._addFileChildren(LearnRouteChildren);
var ProjectsRouteChildren = { ProjectsProjectIdRoute };
var ProjectsRouteWithChildren = ProjectsRoute._addFileChildren(ProjectsRouteChildren);
var TutorRouteChildren = { TutorLiveRoute };
var rootRouteChildren = {
	IndexRoute,
	CodeRoute,
	GamesRoute: GamesRouteWithChildren,
	LearnRoute: LearnRouteWithChildren,
	PracticeRoute,
	ProfileRoute,
	ProgressRoute,
	ProjectsRoute: ProjectsRouteWithChildren,
	TutorRoute: TutorRoute._addFileChildren(TutorRouteChildren),
	TypingRoute
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { xpIntoLevel as C, todayKey as S, Progress as _, EMPTY_IDS as a, formatDuration as b, useHelix as c, LEVELS as d, TOPICS as f, warmupPython as g, runPython as h, Route$3 as i, ACHIEVEMENTS as l, outputsMatch as m, Route$1 as n, dueTopicIds as o, TOPIC_BY_ID as p, Route$2 as r, progressSummary as s, router_exports as t, LESSONS as u, Button as v, levelFromXp as x, cn as y };
