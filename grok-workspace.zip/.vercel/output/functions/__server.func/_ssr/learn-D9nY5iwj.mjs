import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { v as Lock } from "../_libs/lucide-react.mjs";
import { _ as Progress, c as useHelix, d as LEVELS, f as TOPICS, o as dueTopicIds, y as cn } from "./router-C24WQtVx.mjs";
import { t as Input } from "./input-CrCa6m5Z.mjs";
import { t as Badge } from "./badge-BwiWryF0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-D9nY5iwj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_LABEL = {
	mastered: "Mastered",
	in_progress: "In progress",
	review: "Review",
	available: "Available",
	locked: "Locked"
};
function LearnIndex() {
	const topics = useHelix((s) => s.topics);
	const due = (0, import_react.useMemo)(() => dueTopicIds(topics), [topics]);
	const [q, setQ] = (0, import_react.useState)("");
	const [level, setLevel] = (0, import_react.useState)("all");
	const [status, setStatus] = (0, import_react.useState)("all");
	const filtered = (0, import_react.useMemo)(() => {
		const needle = q.trim().toLowerCase();
		return TOPICS.filter((t) => {
			const p = topics[t.id];
			if (level !== "all" && t.level !== level) return false;
			if (status !== "all" && p.status !== status) return false;
			if (!needle) return true;
			return `${t.title} ${t.subtitle} ${t.blurb} ${t.number}`.toLowerCase().includes(needle);
		});
	}, [
		q,
		level,
		status,
		topics
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Learn"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-medium tracking-tight",
					children: "Curriculum"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Twenty topics across five levels. Finish a lesson to unlock the next. Search, filter by level or status, then open the actual lesson."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Search lessons — lists, loops, files…",
						"aria-label": "Search lessons"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
							active: level === "all",
							onClick: () => setLevel("all"),
							label: "All levels"
						}), LEVELS.map((lv) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
							active: level === lv.id,
							onClick: () => setLevel(lv.id),
							label: `L${lv.id} ${lv.title}`
						}, lv.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
							active: status === "all",
							onClick: () => setStatus("all"),
							label: "Any status"
						}), Object.keys(STATUS_LABEL).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
							active: status === s,
							onClick: () => setStatus(s),
							label: STATUS_LABEL[s]
						}, s))]
					})
				]
			}),
			LEVELS.filter((lv) => level === "all" || level === lv.id).map((lv) => {
				const group = filtered.filter((t) => t.level === lv.id);
				if (!group.length) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-xl font-medium",
						children: [
							"Level ",
							lv.id,
							" — ",
							lv.title
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: lv.blurb
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "grid gap-2 sm:grid-cols-2",
						children: group.map((t) => {
							const p = topics[t.id];
							const locked = p.status === "locked";
							const isDue = due.includes(t.id);
							const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-muted-foreground",
										children: String(t.number).padStart(2, "0")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: p.status === "mastered" ? "success" : "outline",
										children: isDue ? "Review due" : STATUS_LABEL[p.status]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-display text-lg font-medium",
									children: t.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: t.blurb
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
									value: p.score,
									className: "mt-4"
								})
							] });
							if (locked) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-xl bg-card/50 p-4 text-muted-foreground shadow-[var(--shadow-border)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }), "Complete the previous lesson to unlock"]
								}), inner]
							}, t.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/learn/$topicId",
								params: { topicId: t.id },
								className: cn("block rounded-xl bg-card p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"),
								children: inner
							}) }, t.id);
						})
					})]
				}, lv.id);
			}),
			filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No lessons match that search."
			}) : null
		]
	});
}
function FilterChip({ active, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-11 rounded-full px-3 text-xs", active ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
		children: label
	});
}
//#endregion
export { LearnIndex as component };
