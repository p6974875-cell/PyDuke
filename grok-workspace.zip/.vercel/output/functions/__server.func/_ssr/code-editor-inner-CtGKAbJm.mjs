import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { y as cn } from "./router-C24WQtVx.mjs";
import { A as EditorView, U as keymap, it as Prec } from "../_libs/@codemirror/autocomplete+[...].mjs";
import { t as python } from "../_libs/@codemirror/lang-python+[...].mjs";
import { t as ReactCodeMirror } from "../_libs/uiw__react-codemirror.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/code-editor-inner-CtGKAbJm.js
var import_jsx_runtime = require_jsx_runtime();
var helixTheme = EditorView.theme({
	"&": {
		backgroundColor: "transparent",
		color: "#eee6d4",
		fontSize: "13.5px",
		height: "100%"
	},
	".cm-content": {
		caretColor: "#c4a15a",
		fontFamily: "var(--font-mono)",
		padding: "12px 0"
	},
	".cm-gutters": {
		backgroundColor: "transparent",
		color: "#8e8778",
		border: "none"
	},
	".cm-activeLine": { backgroundColor: "rgba(196,161,90,0.08)" },
	".cm-activeLineGutter": { backgroundColor: "transparent" },
	".cm-selectionBackground, &.cm-focused .cm-selectionBackground": { backgroundColor: "rgba(196,161,90,0.28) !important" },
	".cm-cursor": { borderLeftColor: "#c4a15a" },
	".cm-line": { padding: "0 14px" }
}, { dark: true });
function CodeEditorInner({ value, onChange, onRun, className, minHeight = 220 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("overflow-hidden rounded-lg bg-code shadow-[var(--shadow-border)]", className),
		style: { minHeight },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactCodeMirror, {
			value,
			height: "100%",
			minHeight: `${minHeight}px`,
			theme: helixTheme,
			extensions: [python(), Prec.highest(keymap.of([{
				key: "Mod-Enter",
				run: () => {
					onRun?.();
					return true;
				}
			}]))],
			onChange,
			basicSetup: {
				foldGutter: false,
				highlightActiveLine: true,
				lineNumbers: true,
				tabSize: 4
			}
		})
	});
}
//#endregion
export { CodeEditorInner };
