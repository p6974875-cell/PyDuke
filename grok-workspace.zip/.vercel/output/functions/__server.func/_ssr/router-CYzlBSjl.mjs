import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createRootRoute, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as geminiGenerate, r as mintLiveToken } from "./gemini.server-D0pr_K2J.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as xpIntoLevel, n as levelFromXp, t as cn } from "./utils-fNW1Yxkl.mjs";
import { c as useHelix, r as MASTERED_ON_ARRIVAL } from "./store-CUZplCsw.mjs";
import { C as CircleUser, E as BookOpen, T as ChartNoAxesColumn, a as Sun, b as FolderKanban, d as Phone, g as Menu, h as MessageSquare, i as Terminal, l as Puzzle, n as TriangleAlert, t as X, v as Keyboard, y as House } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { a as DialogOverlay, c as DialogTrigger, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as Root$1, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
import { n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/games-BS5d1k8X.js
var GAME_META = [
	{
		id: "fixer",
		title: "Code Fixer",
		blurb: "A short program is broken. Find the fault and make it run.",
		topicHint: "Syntax and names"
	},
	{
		id: "predict",
		title: "Predict the output",
		blurb: "Read the program. Say what it prints before you run it.",
		topicHint: "Mental execution"
	},
	{
		id: "ordering",
		title: "Code ordering",
		blurb: "The lines work — they are just in the wrong order.",
		topicHint: "Control flow"
	},
	{
		id: "typing",
		title: "Python typing sprint",
		blurb: "Type the snippet exactly. Accuracy first, then speed.",
		topicHint: "Syntax muscle memory"
	},
	{
		id: "debug",
		title: "Debugging challenge",
		blurb: "It runs, but the answer is wrong. Repair the logic.",
		topicHint: "Logic bugs"
	},
	{
		id: "build",
		title: "Build it",
		blurb: "A goal, a blank editor. You write the program.",
		topicHint: "From spec to code"
	},
	{
		id: "boss",
		title: "Boss battle",
		blurb: "Eight levels. Concepts stack. Three lives.",
		topicHint: "Mixed mastery"
	}
];
var FIXER = [
	{
		id: "fx-1",
		difficulty: "easy",
		title: "Missing colon",
		prompt: "This if-statement never even starts. Fix the syntax.",
		starter: "n = 3\nif n > 0\n    print('yes')",
		solution: "n = 3\nif n > 0:\n    print('yes')",
		explanation: "Compound statements in Python end their header with a colon.",
		checks: [{
			kind: "stdout",
			expected: "yes"
		}]
	},
	{
		id: "fx-2",
		difficulty: "easy",
		title: "String concat",
		prompt: "Python refuses to add a string to an int. Make it print 7.",
		starter: "n = \"3\"\nprint(n + 4)",
		solution: "n = \"3\"\nprint(int(n) + 4)",
		explanation: "Convert the string to int before arithmetic. The other option is str(4), which would print 34.",
		checks: [{
			kind: "stdout",
			expected: "7"
		}]
	},
	{
		id: "fx-3",
		difficulty: "medium",
		title: "Tuple comma",
		prompt: "This should be a one-element tuple with length 1. Right now it is an int.",
		starter: "t = (5)\nprint(type(t).__name__)\nprint(len(t) if type(t) is tuple else 'not-tuple')",
		solution: "t = (5,)\nprint(type(t).__name__)\nprint(len(t) if type(t) is tuple else 'not-tuple')",
		explanation: "The comma constructs the tuple. Parentheses only group.",
		checks: [{
			kind: "stdout",
			expected: "tuple\n1"
		}]
	},
	{
		id: "fx-4",
		difficulty: "medium",
		title: "Dict iteration",
		prompt: "This loop was meant to print each value. It crashes or prints letters. Fix it so it prints 1 then 2.",
		starter: "d = {'a': 1, 'b': 2}\nfor k, v in d:\n    print(v)",
		solution: "d = {'a': 1, 'b': 2}\nfor k, v in d.items():\n    print(v)",
		explanation: "A dict iterates keys. .items() yields (key, value) pairs you can unpack.",
		checks: [{
			kind: "stdout",
			expected: "1\n2"
		}]
	},
	{
		id: "fx-5",
		difficulty: "hard",
		title: "Shared row",
		prompt: "grid should be 2x2 zeros with only grid[0][0] = 1. It currently paints both rows. Fix construction.",
		starter: "grid = [[0] * 2] * 2\ngrid[0][0] = 1\nprint(grid)",
		solution: "grid = [[0] * 2 for _ in range(2)]\ngrid[0][0] = 1\nprint(grid)",
		explanation: "Multiplying a list of lists reuses the inner list. A comprehension makes a fresh row each time.",
		checks: [{
			kind: "stdout",
			expected: "[[1, 0], [0, 0]]"
		}]
	},
	{
		id: "fx-6",
		difficulty: "hard",
		title: "Mutable default",
		prompt: "Two independent calls should not share a list. Fix the default.",
		starter: "def bag(item, items=[]):\n    items.append(item)\n    return items\n\nprint(bag('a'))\nprint(bag('b'))",
		solution: "def bag(item, items=None):\n    if items is None:\n        items = []\n    items.append(item)\n    return items\n\nprint(bag('a'))\nprint(bag('b'))",
		explanation: "Default values are evaluated once. None is safe; create the list in the body.",
		checks: [{
			kind: "stdout",
			expected: "['a']\n['b']"
		}]
	}
];
var PREDICT = [
	{
		id: "pr-1",
		difficulty: "easy",
		title: "Slice",
		prompt: "What does this print?",
		code: "print([10, 20, 30, 40][1:3])",
		expected: "[20, 30]",
		explanation: "Slices are half-open: start at 1, stop before 3."
	},
	{
		id: "pr-2",
		difficulty: "easy",
		title: "Truth of empty",
		prompt: "What does this print?",
		code: "xs = []\nif xs:\n    print('yes')\nelse:\n    print('no')",
		expected: "no",
		explanation: "An empty list is falsy, so the else branch runs."
	},
	{
		id: "pr-3",
		difficulty: "medium",
		title: "Alias",
		prompt: "What does this print?",
		code: "a = [1]\nb = a\nb.append(2)\nprint(a)",
		expected: "[1, 2]",
		explanation: "b is another name for the same list. append mutates that object."
	},
	{
		id: "pr-4",
		difficulty: "medium",
		title: "Remainder loop",
		prompt: "What does this print?",
		code: "out = []\nfor n in range(5):\n    if n % 2 == 0:\n        out.append(n)\nprint(out)",
		expected: "[0, 2, 4]",
		explanation: "range(5) is 0..4. Even numbers pass the filter, including 0."
	},
	{
		id: "pr-5",
		difficulty: "hard",
		title: "Comprehension scope",
		prompt: "What does this print?",
		code: "x = 9\nprint([x for x in range(3)])\nprint(x)",
		expected: "[0, 1, 2]\n9",
		explanation: "A comprehension has its own scope. The loop variable does not leak and does not overwrite the outer x."
	},
	{
		id: "pr-6",
		difficulty: "hard",
		title: "Short-circuit",
		prompt: "What does this print?",
		code: "def boom():\n    print('boom')\n    return True\n\nprint(False and boom())",
		expected: "False",
		explanation: "`and` stops at the first falsy value. boom() is never called, so 'boom' is not printed."
	}
];
var ORDERING = [
	{
		id: "or-1",
		difficulty: "easy",
		title: "Total",
		prompt: "Arrange the lines so the program prints 6.",
		lines: [
			"total = 0",
			"for n in [1, 2, 3]:",
			"    total += n",
			"print(total)"
		],
		expected: "6",
		explanation: "Initialise the accumulator, loop, then print once after the loop."
	},
	{
		id: "or-2",
		difficulty: "medium",
		title: "Swap",
		prompt: "Print 2 1 using an unpacking swap.",
		lines: [
			"a = 1",
			"b = 2",
			"a, b = b, a",
			"print(a, b)"
		],
		expected: "2 1",
		explanation: "Bind both names first. Then unpack. Then print."
	},
	{
		id: "or-3",
		difficulty: "medium",
		title: "Dict count",
		prompt: "Count letters in abba and print the count of a.",
		lines: [
			"text = 'abba'",
			"counts = {}",
			"for ch in text:",
			"    counts[ch] = counts.get(ch, 0) + 1",
			"print(counts['a'])"
		],
		expected: "2",
		explanation: "Create the dict before the loop. Print after the loop."
	},
	{
		id: "or-4",
		difficulty: "hard",
		title: "Function then call",
		prompt: "Define then use is_even so it prints True.",
		lines: [
			"def is_even(n):",
			"    return n % 2 == 0",
			"print(is_even(8))"
		],
		expected: "True",
		explanation: "A function must be defined before the call that uses it in this simple script."
	},
	{
		id: "or-5",
		difficulty: "hard",
		title: "File round trip",
		prompt: "Write, then read, then print Ada.",
		lines: [
			"with open('n.txt', 'w') as f:",
			"    f.write('Ada')",
			"with open('n.txt') as f:",
			"    print(f.read())"
		],
		expected: "Ada",
		explanation: "Write mode first, then a separate with-block to read."
	}
];
var DEBUG = [
	{
		id: "db-1",
		difficulty: "easy",
		title: "Off-by-one",
		prompt: "This should print 1 2 3 4 5. It stops early.",
		starter: "for i in range(1, 5):\n    print(i, end=' ' if i < 4 else '')\n",
		solution: "for i in range(1, 6):\n    print(i, end=' ' if i < 5 else '')\n",
		explanation: "range stop is exclusive. To include 5, stop at 6. The separator also needs to know the last number.",
		checks: [{
			kind: "stdout",
			expected: "1 2 3 4 5"
		}]
	},
	{
		id: "db-2",
		difficulty: "medium",
		title: "Wrong accumulator",
		prompt: "Mean of [2, 4, 6] should print 4.0. It does not.",
		starter: "xs = [2, 4, 6]\ntotal = 1\nfor x in xs:\n    total += x\nprint(total / len(xs))",
		solution: "xs = [2, 4, 6]\ntotal = 0\nfor x in xs:\n    total += x\nprint(total / len(xs))",
		explanation: "An accumulator for a sum starts at 0, not 1.",
		checks: [{
			kind: "stdout",
			expected: "4.0"
		}]
	},
	{
		id: "db-3",
		difficulty: "medium",
		title: "Inclusive filter",
		prompt: "Print numbers in [3, 10, 15, 7] that are >= 10. Currently it uses >.",
		starter: "for n in [3, 10, 15, 7]:\n    if n > 10:\n        print(n)",
		solution: "for n in [3, 10, 15, 7]:\n    if n >= 10:\n        print(n)",
		explanation: "The spec said at least 10, which includes 10. Use >=.",
		checks: [{
			kind: "stdout",
			expected: "10\n15"
		}]
	},
	{
		id: "db-4",
		difficulty: "hard",
		title: "Shallow copy needed",
		prompt: "Keep original as [1, 2] while extra becomes [1, 2, 3].",
		starter: "original = [1, 2]\nextra = original\nextra.append(3)\nprint(original)\nprint(extra)",
		solution: "original = [1, 2]\nextra = original[:]\nextra.append(3)\nprint(original)\nprint(extra)",
		explanation: "Assignment aliases. A slice copy makes extra independent.",
		checks: [{
			kind: "stdout",
			expected: "[1, 2]\n[1, 2, 3]"
		}]
	}
];
var BUILD = [
	{
		id: "bd-1",
		difficulty: "easy",
		title: "Teenager?",
		prompt: "Set age = 15. Print 'teen' if 13 <= age <= 19, otherwise 'not'. Do not use input().",
		starter: "age = 15\n",
		solution: "age = 15\nif 13 <= age <= 19:\n    print('teen')\nelse:\n    print('not')",
		explanation: "Chained comparison reads as a range check. 15 is inside 13–19.",
		checks: [{
			kind: "stdout",
			expected: "teen"
		}]
	},
	{
		id: "bd-2",
		difficulty: "medium",
		title: "Fizz-ish",
		prompt: "For n in 1..6, print 'x' if n is divisible by 3, otherwise n. Each on its own line.",
		starter: "",
		solution: "for n in range(1, 7):\n    if n % 3 == 0:\n        print('x')\n    else:\n        print(n)",
		explanation: "Modulo tests divisibility. range(1, 7) covers 1 through 6.",
		checks: [{
			kind: "stdout",
			expected: "1\n2\nx\n4\n5\nx"
		}]
	},
	{
		id: "bd-3",
		difficulty: "medium",
		title: "Word lengths",
		prompt: "words = ['py', 'tutor', 'ok']. Print a dict of word -> length.",
		starter: "words = ['py', 'tutor', 'ok']\n",
		solution: "words = ['py', 'tutor', 'ok']\nprint({w: len(w) for w in words})",
		explanation: "A dict comprehension maps each word to len(w).",
		checks: [{
			kind: "stdout",
			expected: "{'py': 2, 'tutor': 5, 'ok': 2}"
		}]
	},
	{
		id: "bd-4",
		difficulty: "hard",
		title: "Palindrome check",
		prompt: "Define pal(s) that returns True if s equals its reverse. Print pal('level') and pal('helix').",
		starter: "def pal(s):\n    ...\n",
		solution: "def pal(s):\n    return s == s[::-1]\n\nprint(pal('level'))\nprint(pal('helix'))",
		explanation: "s[::-1] is the reversed string. Equality is the palindrome test.",
		checks: [{
			kind: "stdout",
			expected: "True\nFalse"
		}]
	}
];
var BOSS = [
	{
		id: "boss-1",
		difficulty: "easy",
		title: "Level 1 — Variables",
		prompt: "Bind a = 2, b = 5. Print their product.",
		starter: "",
		solution: "a = 2\nb = 5\nprint(a * b)",
		explanation: "Names bound, then an operator. Foundation.",
		checks: [{
			kind: "stdout",
			expected: "10"
		}]
	},
	{
		id: "boss-2",
		difficulty: "easy",
		title: "Level 2 — Conditions",
		prompt: "n = 11. Print 'odd' or 'even'.",
		starter: "n = 11\n",
		solution: "n = 11\nprint('even' if n % 2 == 0 else 'odd')",
		explanation: "A conditional expression is a compact if/else that yields a value.",
		checks: [{
			kind: "stdout",
			expected: "odd"
		}]
	},
	{
		id: "boss-3",
		difficulty: "medium",
		title: "Level 3 — Loops",
		prompt: "Print the sum of 1..10.",
		starter: "",
		solution: "print(sum(range(1, 11)))",
		explanation: "range(1, 11) is 1 through 10. sum walks it.",
		checks: [{
			kind: "stdout",
			expected: "55"
		}]
	},
	{
		id: "boss-4",
		difficulty: "medium",
		title: "Level 4 — Lists",
		prompt: "xs = [5, 1, 5, 3, 5]. Print how many times 5 appears.",
		starter: "xs = [5, 1, 5, 3, 5]\n",
		solution: "xs = [5, 1, 5, 3, 5]\nprint(xs.count(5))",
		explanation: "list.count is the direct method. A loop would also work.",
		checks: [{
			kind: "stdout",
			expected: "3"
		}]
	},
	{
		id: "boss-5",
		difficulty: "medium",
		title: "Level 5 — Functions",
		prompt: "Write twice(s) that returns s concatenated with itself. Print twice('go').",
		starter: "def twice(s):\n    ...\n",
		solution: "def twice(s):\n    return s + s\n\nprint(twice('go'))",
		explanation: "String addition concatenates. Return the result.",
		checks: [{
			kind: "stdout",
			expected: "gogo"
		}]
	},
	{
		id: "boss-6",
		difficulty: "hard",
		title: "Level 6 — Dictionaries",
		prompt: "grades = {'A': 2, 'B': 1, 'C': 0}. Print the key with the highest value.",
		starter: "grades = {'A': 2, 'B': 1, 'C': 0}\n",
		solution: "grades = {'A': 2, 'B': 1, 'C': 0}\nprint(max(grades, key=grades.get))",
		explanation: "max on a dict walks keys. key=grades.get compares by value.",
		checks: [{
			kind: "stdout",
			expected: "A"
		}]
	},
	{
		id: "boss-7",
		difficulty: "hard",
		title: "Level 7 — Mixed",
		prompt: "words = ['to', 'helix', 'py', 'tutor']. Print a sorted list of words longer than 2.",
		starter: "words = ['to', 'helix', 'py', 'tutor']\n",
		solution: "words = ['to', 'helix', 'py', 'tutor']\nprint(sorted(w for w in words if len(w) > 2))",
		explanation: "Filter with a generator expression, sort for a stable result.",
		checks: [{
			kind: "stdout",
			expected: "['helix', 'tutor']"
		}]
	},
	{
		id: "boss-8",
		difficulty: "advanced",
		title: "Level 8 — Mini-project",
		prompt: "Implement a tiny inventory: start empty dict. add(name, n) increases count. Use it to add torch 1, rope 2, torch 1. Print the dict.",
		starter: "inv = {}\n\ndef add(name, n):\n    ...\n",
		solution: "inv = {}\n\ndef add(name, n):\n    inv[name] = inv.get(name, 0) + n\n\nadd('torch', 1)\nadd('rope', 2)\nadd('torch', 1)\nprint(inv)",
		explanation: "A dict as inventory. get + add is the merge. Two torch adds become 2.",
		checks: [{
			kind: "stdout",
			expected: "{'torch': 2, 'rope': 2}"
		}]
	}
];
var GAMES = {
	fixer: FIXER,
	"code-fixer": FIXER,
	predict: PREDICT,
	"predict-output": PREDICT,
	ordering: ORDERING,
	"code-ordering": ORDERING,
	debug: DEBUG,
	"debugging-challenge": DEBUG,
	build: BUILD,
	"build-it": BUILD,
	boss: BOSS,
	"boss-battle": BOSS
};
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CYzlBSjl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function PyDukeMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: "/pyduke-mark.png",
		alt: "",
		className: cn("object-contain", className)
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[background-color,box-shadow,color,transform,opacity] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-[0_0_0_1px_rgb(255_255_255/0.06)] hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-foreground hover:bg-secondary",
			outline: "bg-transparent text-foreground shadow-[var(--shadow-border)] hover:bg-secondary hover:shadow-[var(--shadow-border-hover)]",
			destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
			link: "text-accent underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 rounded-lg px-5",
			icon: "size-11",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	ref,
	className: cn("relative h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full bg-accent transition-transform duration-200 ease-out",
		style: { transform: `translateX(-${100 - (value ?? 0)}%)` }
	})
}));
Progress.displayName = "Progress";
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	ref,
	className: cn("fixed inset-0 z-50 bg-background/70", className),
	...props
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var SheetContent = import_react.forwardRef(({ className, children, side = "right", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn("fixed z-50 bg-card text-card-foreground shadow-[var(--shadow-border),var(--shadow-lift)]", side === "right" && "inset-y-0 right-0 h-full w-[min(100%,22rem)] rounded-l-xl p-5", side === "left" && "inset-y-0 left-0 h-full w-[min(100%,22rem)] rounded-r-xl p-5", side === "bottom" && "inset-x-0 bottom-0 rounded-t-xl p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-3 top-3 rounded-sm p-2 text-muted-foreground hover:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
SheetContent.displayName = DialogContent.displayName;
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 pr-8", className),
		...props
	});
}
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("font-display text-lg font-medium", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var ACHIEVEMENTS = [
	{
		id: "first-lesson",
		title: "First Lesson",
		blurb: "Finish a lesson beyond the ones already marked mastered.",
		test: (s) => s.lessonsCompleted.some((id) => !MASTERED_ON_ARRIVAL.includes(id))
	},
	{
		id: "bug-hunter",
		title: "Bug Hunter",
		blurb: "Clear 10 debugging challenges.",
		test: (s) => (s.games.debug?.completed.length ?? 0) >= 10
	},
	{
		id: "python-typist",
		title: "Python Typist",
		blurb: "Complete 5 typing sessions.",
		test: (s) => s.typingHistory.length >= 5
	},
	{
		id: "code-runner",
		title: "Code Runner",
		blurb: "Pass 10 coding exercises.",
		test: (s) => Object.values(s.topics).reduce((n, t) => n + t.completedExercises.length, 0) >= 10
	},
	{
		id: "week-streak",
		title: "7 Day Streak",
		blurb: "Study on 7 consecutive days.",
		test: (s) => s.streak >= 7
	},
	{
		id: "fixer-six",
		title: "Code Surgeon",
		blurb: "Repair every Code Fixer challenge.",
		test: (s) => (s.games.fixer?.completed.length ?? 0) >= (GAMES.fixer?.length ?? 0)
	},
	{
		id: "project-one",
		title: "Shipped it",
		blurb: "Complete a project.",
		test: (s) => s.projectsCompleted.length >= 1
	},
	{
		id: "game-master",
		title: "Game Master",
		blurb: "Clear at least one challenge in every game type.",
		test: (s) => [
			"fixer",
			"predict",
			"ordering",
			"debug",
			"build",
			"boss"
		].every((id) => (s.games[id]?.completed.length ?? 0) >= 1) && s.typingHistory.length >= 1
	}
];
function unlockedAchievements(s) {
	return ACHIEVEMENTS.filter((a) => a.test(s));
}
var PRIMARY = [
	{
		to: "/",
		label: "Home",
		icon: House
	},
	{
		to: "/learn",
		label: "Learn",
		icon: BookOpen
	},
	{
		to: "/code",
		label: "Code",
		icon: Terminal
	},
	{
		to: "/games",
		label: "Games",
		icon: Puzzle
	}
];
var MORE = [
	{
		to: "/practice",
		label: "Daily",
		icon: Sun
	},
	{
		to: "/typing",
		label: "Typing",
		icon: Keyboard
	},
	{
		to: "/projects",
		label: "Projects",
		icon: FolderKanban
	},
	{
		to: "/progress",
		label: "Progress",
		icon: ChartNoAxesColumn
	},
	{
		to: "/tutor",
		label: "Tutor",
		icon: MessageSquare
	},
	{
		to: "/live-tutor",
		label: "Live",
		icon: Phone
	},
	{
		to: "/profile",
		label: "Profile",
		icon: CircleUser
	}
];
var ALL = [...PRIMARY, ...MORE];
function pathActive(pathname, to) {
	return to === "/" ? pathname === "/" : pathname === to || pathname.startsWith(`${to}/`);
}
function NavLink({ to, label, icon: Icon, onClick }) {
	const active = pathActive(useRouterState({ select: (s) => s.location.pathname }), to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		onClick,
		className: cn("tap-card flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium", active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }), label]
	});
}
function AppShell({ children }) {
	const xp = useHelix((s) => s.xp);
	const streak = useHelix((s) => s.streak);
	const [moreOpen, setMoreOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		const finish = () => {
			useHelix.getState().setHydrated(true);
			useHelix.getState().tickStreak();
		};
		const unsub = useHelix.persist.onFinishHydration(finish);
		useHelix.persist.rehydrate();
		if (useHelix.persist.hasHydrated()) finish();
		return unsub;
	}, []);
	(0, import_react.useEffect)(() => {
		return useHelix.subscribe((s) => {
			const unlocked = unlockedAchievements(s);
			const seen = s.seenAchievements ?? [];
			const fresh = unlocked.filter((a) => !seen.includes(a.id));
			if (!fresh.length) return;
			useHelix.setState({ seenAchievements: [...seen, ...fresh.map((a) => a.id)] });
			for (const a of fresh) toast(`${a.title} unlocked`);
		});
	}, []);
	const level = levelFromXp(xp);
	const into = xpIntoLevel(xp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border bg-sidebar px-3 py-5 md:flex",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "tap-card mb-6 flex items-center gap-2.5 px-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PyDukeMark, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg font-medium tracking-tight",
						children: "PyDuke"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-1 flex-col gap-0.5 overflow-y-auto",
					children: ALL.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, { ...item }, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-2 rounded-lg bg-secondary p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: ["Level ", level]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums text-foreground",
								children: [into, "/150"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: into / 150 * 100 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: ["Streak ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-foreground",
								children: streak
							})]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-3 border-b border-border px-4 py-3 md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "tap-card flex min-h-11 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PyDukeMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-base font-medium",
							children: "PyDuke"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs tabular-nums text-muted-foreground",
						children: [
							"Lv ",
							level,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
								open: moreOpen,
								onOpenChange: setMoreOpen,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": "Menu",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
									side: "bottom",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "PyDuke" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
										className: "grid grid-cols-2 gap-1 pb-4",
										children: ALL.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
											...item,
											onClick: () => setMoreOpen(false)
										}, item.to))
									})]
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "relative z-10 mx-auto w-full max-w-6xl flex-1 px-4 py-6 pb-24 md:px-8 md:py-8 md:pb-8",
					children
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-sidebar/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm md:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-5",
						children: [PRIMARY.map((item) => {
							const active = pathActive(pathname, item.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("tap-card flex h-14 flex-col items-center justify-center gap-1 text-xs", active ? "text-accent" : "text-muted-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5" }), item.label]
							}, item.to);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setMoreOpen(true),
							className: "tap-card flex h-14 flex-col items-center justify-center gap-1 text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" }), "More"]
						})]
					})
				})
			]
		})]
	});
}
var TooltipProvider = Provider;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-sm bg-popover px-2.5 py-1.5 text-xs text-popover-foreground shadow-[var(--shadow-border)]", className),
	...props
}) }));
TooltipContent.displayName = Content2.displayName;
var styles_default = "/assets/styles-DkIKFsQ7.css";
var APP_NAME = "PyDuke";
var Route$17 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "A personal Python tutor that remembers where you left off."
			},
			{
				name: "theme-color",
				content: "#111b27"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=IBM+Plex+Mono:wght@400;500&family=Outfit:wght@400;500;600&display=swap"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, {
				delayDuration: 200,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "bottom-right",
					toastOptions: { className: "bg-popover text-popover-foreground border-border" }
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$14 = () => import("./routes-DkixebfF.mjs");
var Route$16 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./code-CuqYtKuc.mjs");
var Route$15 = createFileRoute("/code")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./games-Ca8mmbVG.mjs");
var Route$14 = createFileRoute("/games")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./learn-2Sc57OeV.mjs");
var Route$13 = createFileRoute("/learn")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./live-Bfk8DxD5.mjs");
var Route$12 = createFileRoute("/live")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./live-tutor-DP2wcxCc.mjs");
var Route$11 = createFileRoute("/live-tutor")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./practice-UW4XK5Oj.mjs");
var Route$10 = createFileRoute("/practice")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./profile-Dg8n-IJ2.mjs");
var Route$9 = createFileRoute("/profile")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./progress-BUkSD4_x.mjs");
var Route$8 = createFileRoute("/progress")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./projects-DZ9UBwoW.mjs");
var Route$7 = createFileRoute("/projects")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./tutor-IG1P8gqW.mjs");
var Route$6 = createFileRoute("/tutor")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./typing-BM8LRi9k.mjs");
var Route$5 = createFileRoute("/typing")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./games._gameId-OlXblY_W.mjs");
var Route$4 = createFileRoute("/games/$gameId")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./learn._topicId-1cDX6PrS.mjs");
var Route$3 = createFileRoute("/learn/$topicId")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./projects._projectId-_Z0bAPMR.mjs");
var Route$2 = createFileRoute("/projects/$projectId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var Route$1 = createFileRoute("/api/ai/chat")({ server: { handlers: { POST: async ({ request }) => {
	let body;
	try {
		body = await request.json();
	} catch {
		return Response.json({
			ok: false,
			error: "invalid-json"
		}, { status: 400 });
	}
	const messages = (body.messages ?? []).slice(-8);
	if (!messages.length) return Response.json({
		ok: false,
		error: "empty"
	}, { status: 400 });
	const system = `You are PyDuke, a Python teacher. Answer any Python question. Hint before dumping exercise solutions.
${body.context ? `\nContext:\n${body.context.slice(0, 1500)}` : ""}`;
	const result = await geminiGenerate({
		system,
		messages
	});
	if (!result.ok) {
		const status = result.error === "missing-key" ? 503 : 502;
		return Response.json(result, { status });
	}
	return Response.json(result);
} } } });
var Route = createFileRoute("/api/ai/live")({ server: { handlers: { POST: async () => {
	const minted = await mintLiveToken();
	if (!minted.ok) {
		const status = minted.error === "missing-key" ? 503 : 502;
		return Response.json({
			ok: false,
			error: minted.error
		}, { status });
	}
	const wsUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained?access_token=${encodeURIComponent(minted.token)}`;
	return Response.json({
		ok: true,
		wsUrl,
		model: minted.model
	});
} } } });
var IndexRoute = Route$16.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$17
});
var CodeRoute = Route$15.update({
	id: "/code",
	path: "/code",
	getParentRoute: () => Route$17
});
var GamesRoute = Route$14.update({
	id: "/games",
	path: "/games",
	getParentRoute: () => Route$17
});
var LearnRoute = Route$13.update({
	id: "/learn",
	path: "/learn",
	getParentRoute: () => Route$17
});
var LiveRoute = Route$12.update({
	id: "/live",
	path: "/live",
	getParentRoute: () => Route$17
});
var LiveTutorRoute = Route$11.update({
	id: "/live-tutor",
	path: "/live-tutor",
	getParentRoute: () => Route$17
});
var PracticeRoute = Route$10.update({
	id: "/practice",
	path: "/practice",
	getParentRoute: () => Route$17
});
var ProfileRoute = Route$9.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => Route$17
});
var ProgressRoute = Route$8.update({
	id: "/progress",
	path: "/progress",
	getParentRoute: () => Route$17
});
var ProjectsRoute = Route$7.update({
	id: "/projects",
	path: "/projects",
	getParentRoute: () => Route$17
});
var TutorRoute = Route$6.update({
	id: "/tutor",
	path: "/tutor",
	getParentRoute: () => Route$17
});
var TypingRoute = Route$5.update({
	id: "/typing",
	path: "/typing",
	getParentRoute: () => Route$17
});
var GamesGameIdRoute = Route$4.update({
	id: "/$gameId",
	path: "/$gameId",
	getParentRoute: () => GamesRoute
});
var LearnTopicIdRoute = Route$3.update({
	id: "/$topicId",
	path: "/$topicId",
	getParentRoute: () => LearnRoute
});
var ProjectsProjectIdRoute = Route$2.update({
	id: "/$projectId",
	path: "/$projectId",
	getParentRoute: () => ProjectsRoute
});
var ApiAiChatRoute = Route$1.update({
	id: "/api/ai/chat",
	path: "/api/ai/chat",
	getParentRoute: () => Route$17
});
var ApiAiLiveRoute = Route.update({
	id: "/api/ai/live",
	path: "/api/ai/live",
	getParentRoute: () => Route$17
});
var GamesRouteChildren = { GamesGameIdRoute };
var GamesRouteWithChildren = GamesRoute._addFileChildren(GamesRouteChildren);
var LearnRouteChildren = { LearnTopicIdRoute };
var LearnRouteWithChildren = LearnRoute._addFileChildren(LearnRouteChildren);
var ProjectsRouteChildren = { ProjectsProjectIdRoute };
var rootRouteChildren = {
	IndexRoute,
	CodeRoute,
	GamesRoute: GamesRouteWithChildren,
	LearnRoute: LearnRouteWithChildren,
	LiveRoute,
	LiveTutorRoute,
	PracticeRoute,
	ProfileRoute,
	ProgressRoute,
	ProjectsRoute: ProjectsRoute._addFileChildren(ProjectsRouteChildren),
	TutorRoute,
	TypingRoute,
	ApiAiChatRoute,
	ApiAiLiveRoute
};
var routeTree = Route$17._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { ACHIEVEMENTS as a, Button as c, GAMES as d, GAME_META as f, Route$4 as i, DEBUG as l, Route$2 as n, unlockedAchievements as o, PREDICT as p, Route$3 as r, Progress as s, router_exports as t, FIXER as u };
