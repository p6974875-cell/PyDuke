import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { P as ArrowRight, T as Eye, f as Play, k as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as Progress, c as useHelix, f as TOPICS, h as runPython, p as TOPIC_BY_ID, r as Route$2, u as LESSONS, v as Button } from "./router-C24WQtVx.mjs";
import { n as PythonOutput } from "./python-output-BJIiscp_.mjs";
import { t as GAME_UNLOCKS } from "./game-engine-CQ7mU7b7.mjs";
import { t as CodeBlock } from "./code-block-BCNFtjit.mjs";
import { t as ExercisePanel } from "./exercise-panel-4x2yRSDF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn._topicId-D0eHc53X.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ExampleRunner({ title, code, why, output }) {
	const [result, setResult] = (0, import_react.useState)(null);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [showExpected, setShowExpected] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "secondary",
					disabled: running,
					onClick: async () => {
						setRunning(true);
						try {
							setResult(await runPython(code));
						} finally {
							setRunning(false);
						}
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Run example"]
				}), output ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => setShowExpected(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }), "Expected output"]
				}) : null]
			}),
			showExpected && output ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "overflow-x-auto rounded-lg bg-code px-4 py-3 font-mono text-[13px]",
				children: output
			}) : null,
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonOutput, {
				result,
				code
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-relaxed text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-foreground",
					children: "Why this works. "
				}), why]
			})
		]
	});
}
var LESSON_EXTRAS = {
	variables: {
		realWorld: {
			heading: "A receipt line",
			body: "A shop program binds a price and a count, then prints the line total. Names make the arithmetic readable tomorrow.",
			code: "item = \"tea\"\nprice = 2.5\nqty = 3\nprint(item, price * qty)"
		},
		review: [
			"A variable is a name bound to an object.",
			"The type lives on the object, not the name.",
			"Reassignment points the name at a new object; it does not mutate the old one unless that object is mutable and you mutate it.",
			"print() writes; a # comment is ignored; Python does not need a type declaration."
		],
		think: {
			question: "After a = 1; b = a; a = 2, what is b? Why?",
			answer: "b is still 1. Integers are immutable. b was bound to the object 1; rebinding a does not touch b."
		},
		outputs: ["<class 'int'>\n5.0 <class 'float'>", "[1, 2, 3]"]
	},
	io: {
		realWorld: {
			heading: "A login prompt",
			body: "Any program that asks for a name is using input(). Remember the result is always a string, even if the user types digits.",
			code: "name = \"Ada\"\nprint(\"hello\", name)"
		},
		review: [
			"print writes to standard output.",
			"input reads a line and always returns str.",
			"sep and end control how print joins and finishes a line.",
			"Convert with int() or float() before arithmetic."
		],
		think: {
			question: "Why does print(input() + 1) crash even if you type 4?",
			answer: "input() returns '4', a string. '4' + 1 is a TypeError. int(input()) + 1 works."
		},
		outputs: ["A-B!done"]
	},
	operators: {
		realWorld: {
			heading: "Even pages",
			body: "A printer that only duplexes even pages uses n % 2 == 0. Remainder is the everyday test for grouping.",
			code: "page = 8\nprint('even' if page % 2 == 0 else 'odd')"
		},
		review: [
			"/ is true division (float). // is floor division.",
			"% is remainder. ** is power.",
			"and / or short-circuit.",
			"1 < x < 5 means 1 < x and x < 5."
		],
		think: {
			question: "What is 7 // 2 and 7 / 2?",
			answer: "3 and 3.5. Floor versus true division."
		},
		outputs: ["True"]
	},
	conditions: {
		realWorld: {
			heading: "Ticket gate",
			body: "A gate lets you in if age >= 18 or you have a pass. One if/elif/else chain; only one branch runs.",
			code: "age = 16\nhas_pass = True\nif age >= 18 or has_pass:\n    print('enter')\nelse:\n    print('wait')"
		},
		review: [
			"if / elif / else: at most one suite runs.",
			"Empty, 0, '', None are falsy.",
			"Indentation is the block.",
			"Write both sides of a comparison: n > 0 and n < 10."
		],
		think: {
			question: "If two if statements (not elif) are both true, how many print?",
			answer: "Both. Separate ifs are independent. elif would skip the second."
		},
		outputs: ["allowed"]
	},
	loops: {
		realWorld: {
			heading: "Batch of invoices",
			body: "for walks a collection. while repeats until a condition fails. range(n) is 0 .. n-1.",
			code: "total = 0\nfor n in [10, 20, 5]:\n    total += n\nprint(total)"
		},
		review: [
			"for walks an iterable. while tests a condition.",
			"range(5) is 0,1,2,3,4 — stop is exclusive.",
			"break leaves the loop. continue skips the rest of this round.",
			"Do not write for i in 5 — an int is not iterable."
		],
		think: {
			question: "How many times does for i in range(1, 4): print(i) run, and what does it print?",
			answer: "Three times: 1, 2, 3. Stop 4 is exclusive."
		},
		outputs: ["0\n1\n2"]
	},
	lists: {
		realWorld: {
			heading: "A queue of names",
			body: "A waiting list is a list: append to the end, pop(0) from the front. Copies matter — aliasing shares the queue.",
			code: "q = ['Ada']\nq.append('Lin')\nprint(q.pop(0))\nprint(q)"
		},
		review: [
			"Lists are mutable sequences.",
			"b = a aliases; b = a[:] copies.",
			"Comprehensions build a new list.",
			"Index from 0. Negative indexes count from the end."
		],
		think: {
			question: "After a = [1]; b = a; b.append(2); what is a?",
			answer: "[1, 2]. Both names point at the same list."
		},
		outputs: ["[1, 4, 9]", "[1, 2]"]
	},
	tuples: {
		realWorld: {
			heading: "A point",
			body: "A coordinate (x, y) should not grow extra numbers by accident. A tuple is the right shape.",
			code: "point = (3, 4)\nprint(point[0], len(point))"
		},
		review: [
			"Tuples are immutable sequences.",
			"The comma constructs a tuple: (5,) is a one-element tuple; (5) is 5.",
			"You can unpack: x, y = point.",
			"Use a tuple for fixed records; a list for growing collections."
		],
		think: {
			question: "Why is t = (5) not a tuple?",
			answer: "Parentheses group. The comma makes the tuple: t = (5,)."
		},
		outputs: ["3 4"]
	},
	sets: {
		realWorld: {
			heading: "Unique visitors",
			body: "A set of user ids ignores duplicates. Membership tests are the point of a set.",
			code: "seen = {1, 2, 2, 3}\nprint(seen)\nprint(2 in seen)"
		},
		review: [
			"A set holds unique unordered hashable values.",
			"in is the membership test.",
			"|, &, - are union, intersection, difference.",
			"A list is not hashable; you cannot put a list in a set."
		],
		think: {
			question: "What does set('abba') contain?",
			answer: "The unique letters, typically {'a', 'b'}. Order is not guaranteed."
		},
		outputs: ["{1, 2, 3}\nTrue"]
	},
	dictionaries: {
		realWorld: {
			heading: "A stock count",
			body: "item -> quantity. Look up by name, not by position. .get avoids KeyError.",
			code: "stock = {'tea': 4, 'mug': 2}\nstock['tea'] = stock.get('tea', 0) + 1\nprint(stock['tea'])"
		},
		review: [
			"A dict maps keys to values.",
			"for x in d walks keys. Use .items() for pairs.",
			".get(k, default) is the safe lookup.",
			"Keys must be hashable."
		],
		think: {
			question: "What does for x in {'a': 1} yield?",
			answer: "The key 'a', not the value 1."
		},
		outputs: ["5"]
	},
	strings: {
		realWorld: {
			heading: "A slug",
			body: "Titles become URL slugs with lower(), split, and join. Strings are immutable — methods return new strings.",
			code: "title = 'Hello World'\nprint('-'.join(title.lower().split()))"
		},
		review: [
			"Strings are immutable sequences of characters.",
			"s[::-1] reverses. s.split() breaks on whitespace.",
			"f-strings interpolate values.",
			"Methods return new strings; they do not edit in place."
		],
		think: {
			question: "After s = 'ab'; s.upper(); what is s?",
			answer: "Still 'ab'. upper() returned a new string that was discarded."
		},
		outputs: ["hello-world"]
	},
	functions: {
		realWorld: {
			heading: "A tax helper",
			body: "Package 'add VAT' as a function so every screen uses the same rule. Return the number; let the caller print.",
			code: "def with_vat(p):\n    return round(p * 1.2, 2)\n\nprint(with_vat(10))"
		},
		review: [
			"Parameters are names; arguments are values you pass.",
			"return hands a value back. No return means None.",
			"Do one job. Prefer return over print inside helpers.",
			"Never use a mutable default argument."
		],
		think: {
			question: "What is x after def f(): print(3) then x = f()?",
			answer: "None. f printed 3 but returned None, which was bound to x."
		},
		outputs: ["13", "Hello, friend Ada\nHello, Dr Ada"]
	},
	scope: {
		realWorld: {
			heading: "A counter in a function",
			body: "A name assigned inside a function is local unless you declare otherwise. That is how two functions can both use i.",
			code: "def inc(n):\n    step = 1\n    return n + step\n\nprint(inc(4))"
		},
		review: [
			"Assignment in a function makes a local name.",
			"Reading an outer name is fine; assigning it needs nonlocal or global.",
			"Each call has its own frame.",
			"LEGB: local, enclosing, global, built-in."
		],
		think: {
			question: "Why does x = 1; def f(): x = x + 1 fail if you call f()?",
			answer: "x = makes x local for the whole function, so the right-hand x is an unbound local."
		},
		outputs: ["5"]
	},
	errors: {
		realWorld: {
			heading: "A form field",
			body: "Users type junk. int(text) can raise ValueError. Catch that one exception and ask again — do not bare except everything.",
			code: "text = '9'\ntry:\n    n = int(text)\nexcept ValueError:\n    n = 0\nprint(n)"
		},
		review: [
			"try / except catches named exceptions.",
			"raise starts an exception.",
			"ValueError: right type, wrong value. TypeError: wrong type. NameError: unbound name.",
			"A bare except hides bugs. Catch the error you expect."
		],
		think: {
			question: "int('q') — which exception?",
			answer: "ValueError. The argument is a str, which int accepts, but 'q' is not a number."
		},
		outputs: ["9"]
	},
	modules: {
		realWorld: {
			heading: "Reuse math",
			body: "import math gives you sqrt without copying the algorithm. from math import sqrt binds the name sqrt in your module.",
			code: "import math\nprint(math.sqrt(9))"
		},
		review: [
			"import module binds the module object.",
			"from module import name binds that name.",
			"__name__ == '__main__' is true for the file you ran.",
			"The standard library is already installed with Python."
		],
		think: {
			question: "What is the difference between import math and from math import sqrt?",
			answer: "import math means you call math.sqrt. from math import sqrt means you call sqrt."
		},
		outputs: ["3.0"]
	},
	files: {
		realWorld: {
			heading: "A notes file",
			body: "with open(path) as f: reads or writes and closes the file even if an error happens. That is the real-world pattern.",
			code: "with open('note.txt', 'w') as f:\n    f.write('hello')\nwith open('note.txt') as f:\n    print(f.read())"
		},
		review: [
			"open(path, mode) returns a file object.",
			"'r' read, 'w' write (truncates), 'a' append.",
			"with closes the file for you.",
			"read() is the whole text. readlines() is a list of lines."
		],
		think: {
			question: "Why prefer with open(...) as f over a bare open?",
			answer: "with guarantees close, including when an exception fires in the block."
		},
		outputs: ["hello"]
	},
	oop: {
		realWorld: {
			heading: "A bank account",
			body: "Balance and deposit belong together. A class is the bundle: data on self, behaviour as methods.",
			code: "class Account:\n    def __init__(self, bal):\n        self.bal = bal\n    def deposit(self, n):\n        self.bal += n\n\na = Account(10)\na.deposit(5)\nprint(a.bal)"
		},
		review: [
			"A class is a blueprint. An instance is one object.",
			"__init__ sets up the instance. self is that instance.",
			"Methods are functions on the class that receive self.",
			"Attribute access is name lookup on the object, then the class."
		],
		think: {
			question: "What is self?",
			answer: "The instance the method was called on. a.deposit(5) is Account.deposit(a, 5)."
		},
		outputs: ["15"]
	},
	stdlib: {
		realWorld: {
			heading: "Today's date stamp",
			body: "datetime and random and json live in the standard library. You import them; you do not download them.",
			code: "from datetime import date\nprint(date(2026, 1, 1).isoformat())"
		},
		review: [
			"The standard library ships with Python.",
			"datetime, math, random, json, os, pathlib, collections are everyday modules.",
			"random.seed makes a sequence repeatable for tests.",
			"json.dumps / json.loads convert between dicts and text."
		],
		think: {
			question: "Why seed random in a lesson?",
			answer: "So the output is checkable. Without a seed, choice() would not match a fixed expected string."
		},
		outputs: ["2026-01-01"]
	},
	apis: {
		realWorld: {
			heading: "A weather payload",
			body: "APIs send JSON: a dict on the wire. You parse it, then pick fields. PyDuke fakes the network; the shape is the same.",
			code: "payload = {'temp': 12, 'city': 'York'}\nprint(payload['city'], payload['temp'])"
		},
		review: [
			"JSON is text. json.loads turns it into dicts and lists.",
			"HTTP GET fetches; the body is often JSON.",
			"Always check the keys you use exist.",
			"This playground cannot hit the real internet — use the fake fetch where provided."
		],
		think: {
			question: "If a response is the string '{\"n\": 1}', what do you call to get a dict?",
			answer: "json.loads. json.load is for a file object."
		},
		outputs: ["York 12"]
	},
	projects: {
		realWorld: {
			heading: "Slice a guessing game",
			body: "Do not write the whole game at once. First a function that judges low/high/match. Then a loop around input. Then random. Each slice is testable.",
			code: "def judge(secret, guess):\n    if guess == secret:\n        return 'match'\n    return 'low' if guess < secret else 'high'\n\nprint(judge(7, 2))"
		},
		review: [
			"Name the data, then the verbs, then the I/O.",
			"A function you can test is a finished slice.",
			"Keep input() at the edge, not inside helpers.",
			"Build the smallest program that could work, then wrap it."
		],
		think: {
			question: "Why test judge() without input()?",
			answer: "Because you can call it with known numbers and check the string it returns. input() makes that noisy."
		},
		outputs: ["low"]
	},
	advanced: {
		realWorld: {
			heading: "A stream of records",
			body: "A generator yields rows as you need them instead of loading a million-line file into a list.",
			code: "def countdown(n):\n    while n > 0:\n        yield n\n        n -= 1\n\nprint(list(countdown(3)))"
		},
		review: [
			"yield produces the next value and pauses the function.",
			"Type hints document contracts; they are not runtime checks.",
			"A decorator wraps a function: @dec is f = dec(f).",
			"Use these when they remove noise, not as decoration."
		],
		think: {
			question: "What is the difference between return and yield inside a loop?",
			answer: "return stops the function for good. yield hands back a value and continues later."
		},
		outputs: ["[0, 1, 4, 9]", "OK"]
	}
};
function LessonView({ topicId }) {
	const lesson = LESSONS[topicId];
	const extra = LESSON_EXTRAS[topicId];
	const topic = TOPIC_BY_ID[topicId];
	const progress = useHelix((s) => s.topics[topicId]);
	const completeLesson = useHelix((s) => s.completeLesson);
	const [thinkOpen, setThinkOpen] = (0, import_react.useState)(false);
	const think = lesson.think ?? extra.think;
	const realWorld = lesson.realWorld ?? extra.realWorld;
	const review = lesson.review ?? extra.review;
	const required = (0, import_react.useMemo)(() => lesson.exercises.filter((e) => !e.optional), [lesson]);
	const ready = required.filter((e) => progress.completedExercises.includes(e.id)).length >= Math.min(2, required.length) || required.length === 0;
	const next = TOPICS[TOPICS.findIndex((t) => t.id === topicId) + 1];
	const unlocks = Object.entries(GAME_UNLOCKS).filter(([, v]) => v.topic === topicId).map(([id]) => id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "space-y-3 helix-enter",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: [
							"Lesson ",
							topic.number,
							" · Level ",
							topic.level,
							" · ",
							topic.subtitle
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight sm:text-4xl",
						children: topic.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: topic.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: progress.score,
							className: "max-w-xs"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs tabular-nums text-muted-foreground",
							children: [progress.score, "%"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-secondary p-5 helix-enter helix-enter-delay-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted-foreground",
						children: "1. Introduction"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-xl font-medium",
						children: lesson.revision.heading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[15px] leading-relaxed text-muted-foreground",
						children: lesson.revision.body
					}),
					lesson.revision.code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
						code: lesson.revision.code,
						className: "mt-4"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 helix-enter helix-enter-delay-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted-foreground",
						children: "2. Explanation"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: lesson.concept.heading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[15px] leading-relaxed text-foreground/90",
						children: lesson.concept.explanation
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-wider text-muted-foreground",
					children: "3. Standard terminology"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
					className: "rounded-lg border-l-2 border-accent/50 bg-card py-3 pl-4 pr-4 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: "Definition. "
					}), lesson.concept.definition]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-wider text-muted-foreground",
					children: "4. Simple explanation"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[15px] leading-relaxed text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: "Analogy. "
					}), lesson.concept.analogy]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-wider text-muted-foreground",
					children: "5–7. Examples, lines, expected output"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Examples"
				})] }), lesson.examples.map((ex, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExampleRunner, {
					title: ex.title,
					code: ex.code,
					why: ex.why,
					output: ex.output ?? extra.outputs[i]
				}, ex.title))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted-foreground",
						children: "8. Common mistakes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Common mistakes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: lesson.mistakes.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-1 text-xs uppercase tracking-wider text-destructive",
									children: "Avoid"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code: m.wrong })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-1 text-xs uppercase tracking-wider text-success",
									children: "Prefer"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code: m.right })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground sm:col-span-2",
									children: m.why
								})
							]
						}, m.wrong))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted-foreground",
						children: "9. Real-world example"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: realWorld.heading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[15px] leading-relaxed text-muted-foreground",
						children: realWorld.body
					}),
					realWorld.code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
						code: realWorld.code,
						className: "mt-3"
					}) : null
				]
			}),
			think ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted-foreground",
						children: "10. Practice task"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Pause and think"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[15px]",
						children: think.question
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						className: "mt-3",
						onClick: () => setThinkOpen((v) => !v),
						children: thinkOpen ? "Hide" : "Reveal"
					}),
					thinkOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted-foreground",
						children: think.answer
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted-foreground",
						children: "11. Interactive coding"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Write it"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Mini exercise, then a practical one. Optional items are marked harder. Run & check grades against real Python output."
					})
				] }), lesson.exercises.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExercisePanel, {
					exercise: ex,
					topicId
				}, ex.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-secondary p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted-foreground",
						children: "12. Short review"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Take with you"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 list-disc space-y-1 pl-5 text-sm text-muted-foreground",
						children: review.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "flex flex-wrap items-center gap-3 border-t border-border pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "w-full text-xs uppercase tracking-wider text-muted-foreground",
						children: "13. Completion"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						disabled: !ready || progress.status === "mastered",
						onClick: () => {
							completeLesson(topicId);
							toast("Lesson marked complete");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), progress.status === "mastered" ? "Mastered" : "Mark lesson complete"]
					}),
					next && progress.status === "mastered" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/learn/$topicId",
							params: { topicId: next.id },
							children: [
								"Next: ",
								next.title,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
							]
						})
					}) : next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"Mark this lesson complete to unlock ",
							next.title,
							"."
						]
					}) : null,
					!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Complete at least two required exercises to finish."
					}) : null,
					unlocks.length > 0 && progress.status === "mastered" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "w-full text-sm text-muted-foreground",
						children: [
							"Unlocked game",
							unlocks.length > 1 ? "s" : "",
							":",
							" ",
							unlocks.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/games/$gameId",
								params: { gameId: id },
								className: "mr-2 underline",
								children: id
							}, id))
						]
					}) : null
				]
			})
		]
	});
}
function LessonPage() {
	const { topicId } = Route$2.useParams();
	const topic = TOPIC_BY_ID[topicId];
	const status = useHelix((s) => s.topics[topicId]?.status);
	if (!topic) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-muted-foreground",
		children: ["Unknown lesson. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/learn",
			children: "Back to curriculum"
		})]
	});
	if (status === "locked") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-lg space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl",
				children: topic.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "This lesson unlocks when you finish the one before it. Work in order — each topic builds on the last."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/learn",
				className: "text-sm text-accent",
				children: "View curriculum"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonView, { topicId: topic.id });
}
//#endregion
export { LessonPage as component };
