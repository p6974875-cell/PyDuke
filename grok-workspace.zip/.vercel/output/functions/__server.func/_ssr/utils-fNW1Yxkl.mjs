import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-fNW1Yxkl.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function todayKey(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function levelFromXp(xp) {
	return 1 + Math.floor(Math.max(0, xp) / 150);
}
function xpIntoLevel(xp) {
	return Math.max(0, xp) % 150;
}
//#endregion
export { xpIntoLevel as i, levelFromXp as n, todayKey as r, cn as t };
