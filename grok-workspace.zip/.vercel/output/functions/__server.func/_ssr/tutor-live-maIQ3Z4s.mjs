import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tutor-live-maIQ3Z4s.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var tutorAvailability = createServerFn({ method: "GET" }).handler(createSsrRpc("d73755459d855b99f2bfa661dba42d0bbfd1519de20ede3c61cb21b56c0e28fb"));
var createLiveSessionToken = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("e65d0b9be3c7ad82c7ea679765d35f5ae3406968e6ce60b92d56f734068054bb"));
//#endregion
export { createSsrRpc as n, tutorAvailability as r, createLiveSessionToken as t };
