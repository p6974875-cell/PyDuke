import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as useHelix } from "./store-CUZplCsw.mjs";
import { d as GAMES, f as GAME_META, s as Progress } from "./router-CYzlBSjl.mjs";
import { t as GAME_SLUG } from "./game-ids-Dqoi2Xic.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/games-Ca8mmbVG.js
var import_jsx_runtime = require_jsx_runtime();
function GamesPage() {
	const games = useHelix((s) => s.games);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
				children: "Games"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-medium tracking-tight",
				children: "Play to learn"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-muted-foreground",
				children: "Each game runs real Python in the browser. Difficulty climbs. Boss battle is sequential."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: GAME_META.map((g) => {
				const items = g.id === "typing" ? 10 : GAMES[g.id]?.length ?? 0;
				const done = games[g.id]?.completed.length ?? 0;
				const pct = items ? Math.round(done / items * 100) : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/games/$gameId",
					params: { gameId: GAME_SLUG[g.id] },
					className: "tap-card rounded-xl bg-card p-5 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: g.topicHint
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-xl font-medium",
							children: g.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: g.blurb
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: pct,
							className: "mt-4"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs tabular-nums text-muted-foreground",
							children: [
								done,
								"/",
								items || "—"
							]
						})
					]
				}, g.id);
			})
		})]
	});
}
//#endregion
export { GamesPage as component };
