import { t as createServerFn } from "./ssr.mjs";
import { n as geminiKey, r as geminiLiveModel, t as createServerRpc } from "./gemini.server-B7PBsCRC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tutor-live-BX6oeYw6.js
var tutorAvailability_createServerFn_handler = createServerRpc({
	id: "d73755459d855b99f2bfa661dba42d0bbfd1519de20ede3c61cb21b56c0e28fb",
	name: "tutorAvailability",
	filename: "src/lib/tutor-live.ts"
}, (opts) => tutorAvailability.__executeServer(opts));
var tutorAvailability = createServerFn({ method: "GET" }).handler(tutorAvailability_createServerFn_handler, async () => {
	const gemini = Boolean(geminiKey());
	return {
		gemini,
		live: gemini,
		xai: Boolean(process.env.XAI_API_KEY?.trim()),
		chatModel: process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash",
		liveModel: geminiLiveModel()
	};
});
var createLiveSessionToken_createServerFn_handler = createServerRpc({
	id: "e65d0b9be3c7ad82c7ea679765d35f5ae3406968e6ce60b92d56f734068054bb",
	name: "createLiveSessionToken",
	filename: "src/lib/tutor-live.ts"
}, (opts) => createLiveSessionToken.__executeServer(opts));
var createLiveSessionToken = createServerFn({ method: "POST" }).validator((input) => input).handler(createLiveSessionToken_createServerFn_handler, async ({ data }) => {
	const apiKey = geminiKey();
	if (!apiKey) return {
		ok: false,
		error: "GEMINI_API_KEY is not configured on the server."
	};
	const model = geminiLiveModel();
	const expire = new Date(Date.now() + 18e5).toISOString();
	const newSession = new Date(Date.now() + 6e4).toISOString();
	const res = await fetch("https://generativelanguage.googleapis.com/v1alpha/auth_tokens", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"x-goog-api-key": apiKey
		},
		body: JSON.stringify({
			uses: 1,
			expireTime: expire,
			newSessionExpireTime: newSession,
			liveConnectConstraints: {
				model: model.startsWith("models/") ? model : `models/${model}`,
				config: { responseModalities: ["AUDIO"] }
			}
		})
	});
	if (!res.ok) {
		const retry = await fetch("https://generativelanguage.googleapis.com/v1beta/auth_tokens", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": apiKey
			},
			body: JSON.stringify({
				uses: 1,
				expireTime: expire,
				newSessionExpireTime: newSession
			})
		});
		if (!retry.ok) {
			const detail = await retry.text().catch(() => "");
			return {
				ok: false,
				error: `Could not mint a Live session token (${retry.status}). ${detail.slice(0, 200)}`
			};
		}
		const body = await retry.json();
		const token = body.name || body.authToken?.name;
		if (!token) return {
			ok: false,
			error: "Live token response was empty."
		};
		return {
			ok: true,
			token,
			model,
			instruction: liveSystem(data.progressSummary ?? "")
		};
	}
	const body = await res.json();
	const token = body.name || body.authToken?.name;
	if (!token) return {
		ok: false,
		error: "Live token response was empty."
	};
	return {
		ok: true,
		token,
		model,
		instruction: liveSystem(data.progressSummary ?? "")
	};
});
function liveSystem(progress) {
	return `You are PyDuke, a live spoken Python tutor. Keep replies short enough to say aloud (about 20–40 seconds). Teach; do not dump full exercise solutions unless the learner has already tried and asks to see one. Use standard terms once, then plain language. Learner progress:\n${progress.slice(0, 1200)}`;
}
//#endregion
export { createLiveSessionToken_createServerFn_handler, tutorAvailability_createServerFn_handler };
