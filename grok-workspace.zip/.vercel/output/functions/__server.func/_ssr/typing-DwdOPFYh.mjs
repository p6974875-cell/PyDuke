import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cn } from "./utils-fNW1Yxkl.mjs";
import { c as useHelix } from "./store-CUZplCsw.mjs";
import { c as Button } from "./router-CYzlBSjl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/typing-DwdOPFYh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TypingArena({ drills }) {
	const [idx, setIdx] = (0, import_react.useState)(0);
	const drill = drills[idx] ?? drills[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: drills.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setIdx(i),
				className: cn("h-11 rounded-md px-3 text-xs", i === idx ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
				children: d.title
			}, d.id))
		}), drill ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingRound, { drill }, drill.id) : null]
	});
}
function TypingRound({ drill }) {
	const target = drill.code;
	const [pos, setPos] = (0, import_react.useState)(0);
	const [errors, setErrors] = (0, import_react.useState)(0);
	const [started, setStarted] = (0, import_react.useState)(null);
	const [doneAt, setDoneAt] = (0, import_react.useState)(null);
	const [wrong, setWrong] = (0, import_react.useState)(false);
	const record = useHelix((s) => s.recordTyping);
	const typingHistory = useHelix((s) => s.typingHistory);
	const history = (0, import_react.useMemo)(() => typingHistory.filter((h) => h.drillId === drill.id), [typingHistory, drill.id]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if (doneAt) return;
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			if (e.ctrlKey || e.metaKey || e.altKey) return;
			if (e.key === "Tab") {
				e.preventDefault();
				feed("    ");
				return;
			}
			if (e.key === "Enter") {
				e.preventDefault();
				feed("\n");
				return;
			}
			if (e.key.length === 1) {
				e.preventDefault();
				feed(e.key);
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	function feed(chunk) {
		if (doneAt) return;
		const start = started ?? Date.now();
		if (!started) setStarted(start);
		let p = pos;
		let err = errors;
		for (const ch of chunk) {
			if (p >= target.length) break;
			if (target[p] === ch) p += 1;
			else {
				err += 1;
				setWrong(true);
				window.setTimeout(() => setWrong(false), 120);
				break;
			}
		}
		setPos(p);
		setErrors(err);
		if (p >= target.length) {
			const end = Date.now();
			setDoneAt(end);
			const minutes = Math.max(.01, (end - start) / 6e4);
			const chars = target.length;
			const cpm = Math.round(chars / minutes);
			const wpm = Math.round(chars / 5 / minutes);
			const accuracy = Math.round(chars / (chars + err) * 1e3) / 10;
			record({
				at: end,
				wpm,
				cpm,
				accuracy,
				errors: err,
				chars,
				drillId: drill.id
			});
		}
	}
	const elapsed = (doneAt ?? (started ? Date.now() : 0)) - (started ?? 0);
	const minutes = Math.max(.01, elapsed / 6e4);
	const liveWpm = started ? Math.round(pos / 5 / minutes) : 0;
	const acc = pos + errors === 0 ? 100 : Math.round(pos / (pos + errors) * 1e3) / 10;
	const best = (0, import_react.useMemo)(() => {
		if (!history.length) return null;
		return history.reduce((a, b) => a.accuracy === b.accuracy ? a.wpm > b.wpm ? a : b : a.accuracy > b.accuracy ? a : b);
	}, [history]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Focus: ",
					drill.focus,
					". Type the snippet exactly. Wrong keys count; the cursor does not skip. Accuracy is the score. Speed is only useful once you are precise."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "WPM",
						value: started ? String(liveWpm) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Accuracy",
						value: `${acc}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Errors",
						value: String(errors)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Best acc",
						value: best ? `${best.accuracy}% · ${best.wpm} wpm` : "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: cn("overflow-x-auto whitespace-pre-wrap rounded-xl bg-code p-4 font-mono text-[13px] leading-relaxed sm:p-5", wrong && "shadow-[0_0_0_1px_var(--color-destructive)]"),
				tabIndex: 0,
				children: target.split("").map((ch, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn(i < pos && "text-success", i === pos && "bg-accent text-accent-foreground", i > pos && "text-muted-foreground"),
					children: ch === "\n" ? "↵\n" : ch === " " && i === pos ? "·" : ch
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "sm",
					onClick: () => {
						setPos(0);
						setErrors(0);
						setStarted(null);
						setDoneAt(null);
					},
					children: "Restart"
				}), doneAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "self-center text-sm text-success",
					children: ["Logged. ", acc < 95 ? "Stay with accuracy before chasing WPM." : "Clean run."]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "self-center text-xs text-muted-foreground",
					children: "Click the snippet, then type. Tab inserts four spaces."
				})]
			})
		]
	});
}
function Metric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-card px-3 py-2 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-sm tabular-nums",
			children: value
		})]
	});
}
var TYPING_DRILLS = [
	{
		id: "kw-1",
		title: "Keywords",
		focus: "Common keywords",
		code: "def if elif else for while return True False None and or not in is pass"
	},
	{
		id: "syn-1",
		title: "Brackets and colons",
		focus: "(), [], {}, :",
		code: "data = {'ok': [1, 2, 3], 'n': (4, 5)}\nfor k, v in data.items():\n    print(k, v)"
	},
	{
		id: "syn-2",
		title: "Quotes and commas",
		focus: "quotes, commas",
		code: "names = [\"Ada\", \"Lin\", \"Moe\"]\nprint(\", \".join(names))"
	},
	{
		id: "ind-1",
		title: "Indentation",
		focus: "4-space blocks",
		code: "def grade(n):\n    if n >= 10:\n        return 'high'\n    return 'low'"
	},
	{
		id: "op-1",
		title: "Operators",
		focus: "arithmetic and compare",
		code: "n = 7\nprint(n // 2, n % 2, n ** 2, n != 0, n <= 10)"
	},
	{
		id: "und-1",
		title: "Underscores",
		focus: "snake_case names",
		code: "user_name = 'ada_lovelace'\nmax_count = 3\nprint(user_name, max_count)"
	},
	{
		id: "fn-1",
		title: "A small function",
		focus: "def, return, f-string",
		code: "def label(name, year):\n    return f'{name}_{year}'\n\nprint(label('helix', 2026))"
	},
	{
		id: "lc-1",
		title: "Comprehension",
		focus: "list comprehension syntax",
		code: "nums = [1, 2, 3, 4]\nsquares = [n * n for n in nums if n % 2 == 0]\nprint(squares)"
	},
	{
		id: "cls-1",
		title: "A tiny class",
		focus: "class, self, init",
		code: "class Point:\n    def __init__(self, x, y):\n        self.x = x\n        self.y = y"
	},
	{
		id: "err-1",
		title: "try / except",
		focus: "error handling layout",
		code: "try:\n    n = int('8')\nexcept ValueError:\n    n = 0\nprint(n)"
	}
];
//#endregion
export { TypingArena as n, TYPING_DRILLS as t };
