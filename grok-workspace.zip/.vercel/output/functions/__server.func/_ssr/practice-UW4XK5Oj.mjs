import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as useHelix, n as LESSONS } from "./store-CUZplCsw.mjs";
import { w as Check } from "../_libs/lucide-react.mjs";
import { l as DEBUG, p as PREDICT, s as Progress, u as FIXER } from "./router-CYzlBSjl.mjs";
import { r as PredictCard, t as FixCard } from "./game-cards-DX94gmXo.mjs";
import { n as TypingArena, t as TYPING_DRILLS } from "./typing-DwdOPFYh.mjs";
import { t as ExercisePanel } from "./exercise-panel-CLzinCJq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/practice-UW4XK5Oj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function hash(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return Math.abs(h);
}
function pick(list, seed, offset) {
	return list[(seed + offset) % list.length];
}
function dailyKey(d = /* @__PURE__ */ new Date()) {
	return d.toISOString().slice(0, 10);
}
function dailyPack(date, topicId) {
	const seed = hash(date);
	const lesson = LESSONS[topicId] ?? LESSONS.lists;
	const exercises = lesson.exercises.length ? lesson.exercises : LESSONS.lists.exercises;
	return {
		date,
		predicts: [pick(PREDICT, seed, 0), pick(PREDICT, seed, 3)].filter((p, i, arr) => arr.findIndex((x) => x.id === p.id) === i),
		debug: pick([...DEBUG, ...FIXER], seed, 1),
		exercise: pick(exercises, seed, 2),
		typing: pick(TYPING_DRILLS, seed, 4)
	};
}
function PracticePage() {
	const current = useHelix((s) => s.currentTopicId);
	const dailyDate = useHelix((s) => s.dailyDate);
	const dailyDone = useHelix((s) => s.dailyDone);
	const completeDaily = useHelix((s) => s.completeDaily);
	const today = dailyKey();
	const done = dailyDate === today ? dailyDone : [];
	const pack = (0, import_react.useMemo)(() => dailyPack(today, current), [today, current]);
	const items = [
		...pack.predicts.map((p) => `predict:${p.id}`),
		`debug:${pack.debug.id}`,
		`ex:${pack.exercise.id}`,
		`type:${pack.typing.id}`
	];
	const cleared = items.filter((id) => done.includes(id)).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Daily"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-medium tracking-tight",
					children: "Today's practice"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: [
						"A set generated from your current path for ",
						today,
						". Completing an item awards XP and stays done if you refresh."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					value: items.length ? cleared / items.length * 100 : 0,
					className: "mt-4 max-w-sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs tabular-nums text-muted-foreground",
					children: [
						cleared,
						"/",
						items.length,
						" complete"
					]
				})
			] }),
			pack.predicts.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
					n: i + 1,
					title: "Predict the output",
					done: done.includes(`predict:${item.id}`)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PredictCard, {
					item,
					onResult: (ok) => {
						if (ok) completeDaily(`predict:${item.id}`);
					}
				})]
			}, item.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
						n: pack.predicts.length + 1,
						title: "Debug / fix",
						done: done.includes(`debug:${pack.debug.id}`)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: pack.debug.prompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FixCard, {
						item: pack.debug,
						onResult: (ok) => {
							if (ok) completeDaily(`debug:${pack.debug.id}`);
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
						n: pack.predicts.length + 2,
						title: "Coding exercise",
						done: done.includes(`ex:${pack.exercise.id}`)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExercisePanel, {
						exercise: pack.exercise,
						topicId: current
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkWhen, {
						done: done.includes(`ex:${pack.exercise.id}`),
						onDone: () => completeDaily(`ex:${pack.exercise.id}`)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
						n: pack.predicts.length + 3,
						title: "Two-minute typing",
						done: done.includes(`type:${pack.typing.id}`)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingArena, { drills: [pack.typing] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-md bg-secondary px-4 text-sm",
						onClick: () => completeDaily(`type:${pack.typing.id}`),
						children: "Mark typing complete"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Want a full lesson instead?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/learn/$topicId",
						params: { topicId: current },
						className: "text-accent",
						children: ["Continue ", current]
					})
				]
			})
		]
	});
}
function Head({ n, title, done }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "font-display text-xl font-medium",
			children: [
				n,
				". ",
				title
			]
		}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-1 text-xs text-success",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), " Done"]
		}) : null]
	});
}
function MarkWhen({ done, onDone }) {
	if (done) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "h-11 rounded-md bg-secondary px-4 text-sm",
		onClick: onDone,
		children: "Mark this exercise done for today"
	});
}
//#endregion
export { PracticePage as component };
