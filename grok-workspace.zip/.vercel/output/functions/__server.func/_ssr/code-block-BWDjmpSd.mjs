import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { u as Play } from "../_libs/lucide-react.mjs";
import { c as Button } from "./router-CYzlBSjl.mjs";
import { i as runPython } from "./python-engine-DcCb1ULs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/code-block-BWDjmpSd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEYWORDS = /\b(False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b/g;
function highlightPython(code) {
	return code.replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/(#.*)$/gm, "<span class=\"text-muted-foreground\">$1</span>").replace(/(".*?"|'.*?'|".*?"|'.*?')/g, "<span class=\"text-accent\">$1</span>").replace(KEYWORDS, "<span class=\"text-success\">$1</span>").replace(/\b(\d+(?:\.\d+)?)\b/g, "<span class=\"text-warning\">$1</span>");
}
function CodeBlock({ code, className, runnable }) {
	const [out, setOut] = (0, import_react.useState)(null);
	const [running, setRunning] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "overflow-x-auto rounded-lg bg-code p-4 font-mono text-sm leading-relaxed text-foreground shadow-[var(--shadow-border)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { dangerouslySetInnerHTML: { __html: highlightPython(code) } })
		}), runnable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 space-y-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "secondary",
				disabled: running,
				onClick: async () => {
					setRunning(true);
					try {
						const r = await runPython(code);
						setOut(r.error || r.stdout || "(no output)");
					} finally {
						setRunning(false);
					}
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Run example"]
			}), out ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap font-mono text-sm text-muted-foreground",
				children: out
			}) : null]
		}) : null]
	});
}
//#endregion
export { CodeBlock as t };
