import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { u as Play } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as Button } from "./router-CYzlBSjl.mjs";
import { t as Input } from "./input-CNyMxTaJ.mjs";
import { r as outputsMatch } from "./python-engine-DcCb1ULs.mjs";
import { n as PythonOutput, t as CodeEditor } from "./python-output-BpGgEqVn.mjs";
import { t as CodeBlock } from "./code-block-BWDjmpSd.mjs";
import { t as gradeCode } from "./grade-ATQFpinc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/game-cards-DX94gmXo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FixCard({ item, onResult }) {
	const [code, setCode] = (0, import_react.useState)(item.starter ?? "");
	const [result, setResult] = (0, import_react.useState)(null);
	const [msg, setMsg] = (0, import_react.useState)("");
	const [ok, setOk] = (0, import_react.useState)(false);
	const [attempted, setAttempted] = (0, import_react.useState)(false);
	const [show, setShow] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	async function run() {
		setRunning(true);
		try {
			const g = await gradeCode(code, item.checks ?? []);
			setResult(g.run);
			setMsg(g.message);
			setOk(g.passed);
			setAttempted(true);
			onResult(g.passed);
		} finally {
			setRunning(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
				value: code,
				onChange: setCode,
				onRun: run,
				minHeight: 200
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => void run(),
						disabled: running,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Check"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						disabled: !attempted,
						onClick: () => setShow(true),
						children: "Compare"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => {
							setCode(item.starter ?? "");
							setResult(null);
							setMsg("");
							setOk(false);
							setShow(false);
						},
						children: "Reset"
					})
				]
			}),
			msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: ok ? "text-sm text-success" : "text-sm text-destructive",
				children: msg
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonOutput, {
				result,
				code
			}),
			show && item.solution ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-secondary p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code: item.solution }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: item.explanation
				})]
			}) : null
		]
	});
}
function PredictCard({ item, onResult }) {
	const [guess, setGuess] = (0, import_react.useState)("");
	const [revealed, setRevealed] = (0, import_react.useState)(false);
	const correct = outputsMatch(guess, item.expected ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, { code: item.code ?? "" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: guess,
				onChange: (e) => setGuess(e.target.value),
				placeholder: "What does it print?",
				disabled: revealed,
				className: "h-11"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				disabled: revealed || !guess.trim(),
				onClick: () => {
					setRevealed(true);
					onResult(correct);
					if (!correct) toast("Not the output — read the explanation and try the next one.");
				},
				children: "Check prediction"
			}),
			revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-lg bg-secondary p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: correct ? "text-success" : "text-destructive",
						children: correct ? "Your prediction matched." : "Not quite."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-foreground",
						children: ["Actual: ", item.expected]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: item.explanation
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Predict before you see the output."
			})
		]
	});
}
function OrderCard({ item, onResult }) {
	const [lines, setLines] = (0, import_react.useState)(() => shuffle(item.lines ?? []));
	const [result, setResult] = (0, import_react.useState)(null);
	const [ok, setOk] = (0, import_react.useState)(false);
	const [show, setShow] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	function move(i, dir) {
		const j = i + dir;
		if (j < 0 || j >= lines.length) return;
		const next = lines.slice();
		[next[i], next[j]] = [next[j], next[i]];
		setLines(next);
		setOk(false);
	}
	async function check() {
		setRunning(true);
		try {
			const g = await gradeCode(lines.join("\n"), [{
				kind: "stdout",
				expected: item.expected
			}]);
			setResult(g.run);
			setOk(g.passed);
			onResult(g.passed);
			if (g.passed) setShow(true);
		} finally {
			setRunning(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-lg bg-code px-3 py-2 font-mono text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-11 items-center justify-center text-muted-foreground",
							onClick: () => move(i, -1),
							"aria-label": "Move up",
							children: "↑"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-11 items-center justify-center text-muted-foreground",
							onClick: () => move(i, 1),
							"aria-label": "Move down",
							children: "↓"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "whitespace-pre",
						children: line
					})]
				}, `${line}-${i}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				onClick: () => void check(),
				disabled: running,
				children: "Run in order"
			}),
			ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-success",
				children: "That order works."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonOutput, {
				result,
				code: lines.join("\n")
			}),
			show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: item.explanation
			}) : null
		]
	});
}
function shuffle(arr) {
	const a = arr.slice();
	for (let i = a.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[a[i], a[j]] = [a[j], a[i]];
	}
	return a;
}
//#endregion
export { OrderCard as n, PredictCard as r, FixCard as t };
