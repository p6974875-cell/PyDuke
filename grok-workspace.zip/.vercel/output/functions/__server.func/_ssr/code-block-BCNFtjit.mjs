import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { y as cn } from "./router-C24WQtVx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/code-block-BCNFtjit.js
var import_jsx_runtime = require_jsx_runtime();
var KEYWORDS = /* @__PURE__ */ new Set([
	"False",
	"None",
	"True",
	"and",
	"as",
	"assert",
	"async",
	"await",
	"break",
	"class",
	"continue",
	"def",
	"del",
	"elif",
	"else",
	"except",
	"finally",
	"for",
	"from",
	"global",
	"if",
	"import",
	"in",
	"is",
	"lambda",
	"nonlocal",
	"not",
	"or",
	"pass",
	"raise",
	"return",
	"try",
	"while",
	"with",
	"yield"
]);
function escapeHtml(s) {
	return s.replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">");
}
var TOKEN = /(#.*)|("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|(\b[A-Za-z_]\w*\b)|(\b\d+(?:\.\d+)?\b)|(\s+)|(.)/g;
function highlightPython(code) {
	let html = "";
	const src = code.replace(/\n$/, "");
	for (const match of src.matchAll(TOKEN)) {
		const [raw, comment, str, ident, num] = match;
		if (comment) html += `<span class="text-muted-foreground">${escapeHtml(comment)}</span>`;
		else if (str) html += `<span class="text-accent">${escapeHtml(str)}</span>`;
		else if (ident && KEYWORDS.has(ident)) html += `<span class="text-success">${ident}</span>`;
		else if (num) html += `<span class="text-warning">${num}</span>`;
		else html += escapeHtml(raw);
	}
	return html;
}
function CodeBlock({ code, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
		className: cn("overflow-x-auto rounded-lg bg-code p-4 text-xs leading-relaxed text-foreground shadow-[var(--shadow-border)]", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "font-mono",
			dangerouslySetInnerHTML: { __html: highlightPython(code) }
		})
	});
}
//#endregion
export { CodeBlock as t };
