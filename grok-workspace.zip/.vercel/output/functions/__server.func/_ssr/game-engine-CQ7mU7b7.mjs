//#region node_modules/.nitro/vite/services/ssr/assets/game-engine-CQ7mU7b7.js
var GAME_UNLOCKS = {
	fixer: {
		topic: "variables",
		label: "Complete Variables & data types"
	},
	predict: {
		topic: "operators",
		label: "Complete Operators"
	},
	ordering: {
		topic: "conditions",
		label: "Complete Conditions"
	},
	typing: {
		topic: null,
		label: "Always open"
	},
	debug: {
		topic: "loops",
		label: "Complete Loops"
	},
	build: {
		topic: "functions",
		label: "Complete Functions"
	},
	boss: {
		topic: "loops",
		label: "Complete Loops"
	}
};
var DIFF_POINTS = {
	easy: 80,
	medium: 110,
	hard: 150,
	advanced: 200
};
function isGameUnlocked(gameId, topics) {
	const req = GAME_UNLOCKS[gameId];
	if (!req.topic) return true;
	const st = topics[req.topic]?.status;
	return st === "mastered" || st === "review";
}
function livesFor(gameId) {
	if (gameId === "boss") return 3;
	if (gameId === "fixer" || gameId === "debug") return 5;
	return null;
}
function pointsFor(difficulty, streak) {
	const base = DIFF_POINTS[difficulty] ?? 80;
	return streak >= 3 ? Math.round(base * 1.25) : base;
}
function pickPlayOrder(items, completed) {
	const undone = items.filter((it) => !completed.includes(it.id));
	const done = items.filter((it) => completed.includes(it.id));
	return [...shuffle(undone), ...shuffle(done)];
}
function shuffle(arr) {
	const a = arr.slice();
	for (let i = a.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[a[i], a[j]] = [a[j], a[i]];
	}
	return a;
}
function seeded(seed) {
	let s = seed % 2147483647;
	if (s <= 0) s += 2147483646;
	return () => {
		s = s * 16807 % 2147483647;
		return (s - 1) / 2147483646;
	};
}
//#endregion
export { pointsFor as a, pickPlayOrder as i, isGameUnlocked as n, seeded as o, livesFor as r, shuffle as s, GAME_UNLOCKS as t };
