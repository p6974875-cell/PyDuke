import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { c as useHelix, s as progressSummary } from "./store-CUZplCsw.mjs";
import { d as Phone, f as PhoneOff, m as MicOff, p as Mic } from "../_libs/lucide-react.mjs";
import { c as Button } from "./router-CYzlBSjl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/live-tutor-DPjoIRlS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var createLiveSession = createServerFn({ method: "POST" }).handler(createSsrRpc("8b824254135f9704073530ef4543a53ef3fc8f9bcb373093acaecbfdf14ddcf4"));
function floatToPcm16(input, fromRate, toRate) {
	const ratio = fromRate / toRate;
	const outLen = Math.max(1, Math.floor(input.length / ratio));
	const out = new Int16Array(outLen);
	for (let i = 0; i < outLen; i++) {
		const s = Math.max(-1, Math.min(1, input[Math.min(input.length - 1, Math.floor(i * ratio))] ?? 0));
		out[i] = s < 0 ? s * 32768 : s * 32767;
	}
	return out;
}
function pcm16ToFloat(bytes) {
	const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	const n = Math.floor(bytes.byteLength / 2);
	const out = new Float32Array(n);
	for (let i = 0; i < n; i++) out[i] = view.getInt16(i * 2, true) / 32768;
	return out;
}
function toB64(pcm) {
	const u8 = new Uint8Array(pcm.buffer, pcm.byteOffset, pcm.byteLength);
	let s = "";
	const chunk = 32768;
	for (let i = 0; i < u8.length; i += chunk) s += String.fromCharCode(...u8.subarray(i, i + chunk));
	return btoa(s);
}
function fromB64(b64) {
	const bin = atob(b64);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}
var GeminiLiveSession = class {
	events;
	system;
	model;
	ws = null;
	recCtx = null;
	playCtx = null;
	stream = null;
	worklet = null;
	sources = [];
	nextPlay = 0;
	muted = false;
	closed = false;
	constructor(events, system, model) {
		this.events = events;
		this.system = system;
		this.model = model;
	}
	async start(wsUrl) {
		this.closed = false;
		this.events.onStatus("connecting");
		this.ws = new WebSocket(wsUrl);
		this.ws.addEventListener("open", () => {
			this.ws?.send(JSON.stringify({ setup: {
				model: `models/${this.model}`,
				generationConfig: {
					responseModalities: ["AUDIO"],
					speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } } }
				},
				systemInstruction: { parts: [{ text: this.system }] },
				inputAudioTranscription: {},
				outputAudioTranscription: {}
			} }));
		});
		this.ws.addEventListener("message", (ev) => {
			this.onMessage(ev.data);
		});
		this.ws.addEventListener("error", () => {
			if (!this.closed) this.events.onStatus("error", "The live connection dropped.");
		});
		this.ws.addEventListener("close", () => {
			if (!this.closed) this.events.onStatus("ended");
		});
		await this.startMic();
		this.events.onStatus("live");
	}
	setMuted(muted) {
		this.muted = muted;
		this.stream?.getAudioTracks().forEach((t) => {
			t.enabled = !muted;
		});
	}
	stop() {
		this.closed = true;
		this.worklet?.port.close();
		this.worklet?.disconnect();
		this.stream?.getTracks().forEach((t) => t.stop());
		this.sources.forEach((s) => {
			try {
				s.stop();
			} catch {}
		});
		this.sources = [];
		this.recCtx?.close();
		this.playCtx?.close();
		this.recCtx = null;
		this.playCtx = null;
		this.stream = null;
		this.worklet = null;
		try {
			this.ws?.close();
		} catch {}
		this.ws = null;
		this.events.onStatus("ended");
	}
	async startMic() {
		this.stream = await navigator.mediaDevices.getUserMedia({
			audio: {
				echoCancellation: true,
				noiseSuppression: true,
				channelCount: 1
			},
			video: false
		});
		this.recCtx = new AudioContext();
		const src = this.recCtx.createMediaStreamSource(this.stream);
		const blob = new Blob([`
      class Cap extends AudioWorkletProcessor {
        process(inputs) {
          const ch = inputs[0] && inputs[0][0];
          if (ch && ch.length) this.port.postMessage(ch);
          return true;
        }
      }
      registerProcessor('pyduke-cap', Cap);
    `], { type: "application/javascript" });
		const url = URL.createObjectURL(blob);
		await this.recCtx.audioWorklet.addModule(url);
		URL.revokeObjectURL(url);
		this.worklet = new AudioWorkletNode(this.recCtx, "pyduke-cap");
		this.worklet.port.onmessage = (ev) => {
			if (this.muted || this.ws?.readyState !== WebSocket.OPEN) return;
			const pcm = floatToPcm16(ev.data, this.recCtx?.sampleRate ?? 48e3, 16e3);
			this.ws.send(JSON.stringify({ realtimeInput: { audio: {
				data: toB64(pcm),
				mimeType: "audio/pcm;rate=16000"
			} } }));
		};
		src.connect(this.worklet);
		const mute = this.recCtx.createGain();
		mute.gain.value = 0;
		this.worklet.connect(mute);
		mute.connect(this.recCtx.destination);
	}
	async onMessage(raw) {
		let text = "";
		if (typeof raw === "string") text = raw;
		else if (raw instanceof Blob) text = await raw.text();
		else if (raw instanceof ArrayBuffer) text = new TextDecoder().decode(raw);
		else return;
		let msg;
		try {
			msg = JSON.parse(text);
		} catch {
			return;
		}
		if (msg.setupComplete) this.events.onStatus("live");
		const server = msg.serverContent;
		if (server?.interrupted) this.flushPlayback();
		const input = server?.inputTranscription?.text;
		if (input) this.events.onTranscript("you", input);
		const output = server?.outputTranscription?.text;
		if (output) this.events.onTranscript("tutor", output);
		const parts = server?.modelTurn?.parts ?? [];
		for (const part of parts) {
			if (part.text) this.events.onTranscript("tutor", part.text);
			const data = part.inlineData?.data;
			if (data) {
				const mime = part.inlineData?.mimeType ?? "audio/pcm;rate=24000";
				const rateMatch = /rate=(\d+)/.exec(mime);
				const rate = rateMatch ? Number(rateMatch[1]) : 24e3;
				this.playPcm(fromB64(data), rate);
			}
		}
	}
	playPcm(bytes, rate) {
		if (!this.playCtx) this.playCtx = new AudioContext({ sampleRate: rate });
		const ctx = this.playCtx;
		const samples = pcm16ToFloat(bytes);
		const buf = ctx.createBuffer(1, samples.length, rate);
		buf.getChannelData(0).set(samples);
		const src = ctx.createBufferSource();
		src.buffer = buf;
		src.connect(ctx.destination);
		const now = ctx.currentTime;
		const start = Math.max(now, this.nextPlay);
		src.start(start);
		this.nextPlay = start + buf.duration;
		this.sources.push(src);
		src.onended = () => {
			this.sources = this.sources.filter((s) => s !== src);
			if (this.sources.length === 0) this.events.onSpeaking(false);
		};
		this.events.onSpeaking(true);
	}
	flushPlayback() {
		this.sources.forEach((s) => {
			try {
				s.stop();
			} catch {}
		});
		this.sources = [];
		this.nextPlay = this.playCtx?.currentTime ?? 0;
		this.events.onSpeaking(false);
	}
};
function LiveTutor() {
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [detail, setDetail] = (0, import_react.useState)("");
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [speaking, setSpeaking] = (0, import_react.useState)(false);
	const [lines, setLines] = (0, import_react.useState)([]);
	const session = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		return () => session.current?.stop();
	}, []);
	async function start() {
		if (status === "connecting" || status === "live") return;
		setDetail("");
		setLines([]);
		setStatus("connecting");
		try {
			const minted = await createLiveSession();
			if (!minted.ok) {
				setStatus("error");
				setDetail(minted.error === "missing-key" ? "Live Tutor needs GEMINI_API_KEY in the server .env. The key stays on the server — PyDuke only mints a short-lived session token." : "Gemini Live could not start. Check GEMINI_API_KEY and GEMINI_LIVE_MODEL, then try again.");
				return;
			}
			const snap = progressSummary(useHelix.getState());
			const live = new GeminiLiveSession({
				onStatus: (s, d) => {
					setStatus(s);
					if (d) setDetail(d);
				},
				onTranscript: (who, text) => {
					setLines((prev) => {
						const last = prev[prev.length - 1];
						if (last && last.who === who) return [...prev.slice(0, -1), {
							who,
							text: last.text + text
						}];
						return [...prev, {
							who,
							text
						}];
					});
				},
				onSpeaking: setSpeaking
			}, `You are PyDuke, a live spoken Python tutor. Answer any Python question — beginner or advanced. Keep answers short enough to say aloud. Hint before giving full solutions. Current progress:\n${snap}`, minted.model);
			session.current = live;
			await live.start(minted.wsUrl);
		} catch (err) {
			const name = err instanceof DOMException ? err.name : "";
			setStatus("error");
			if (name === "NotAllowedError" || name === "PermissionDeniedError") setDetail("Microphone permission was denied. Allow the mic for this site, then tap Start live session again.");
			else if (name === "NotFoundError") setDetail("No microphone was found on this device.");
			else setDetail("Could not open a live session. Check your connection and try again.");
		}
	}
	function end() {
		session.current?.stop();
		session.current = null;
		setSpeaking(false);
		setStatus("ended");
	}
	function toggleMute() {
		const next = !muted;
		setMuted(next);
		session.current?.setMuted(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "This is Gemini Live — a realtime voice session, not a text chat read aloud. PyDuke mints a short-lived token on the server. Your API key never enters the browser."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs uppercase tracking-wider text-muted-foreground",
					children: statusLabel(status, speaking, muted)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: status === "live" || status === "connecting" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "secondary",
						onClick: toggleMute,
						disabled: status !== "live",
						children: [muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" }), muted ? "Unmute" : "Mute"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "destructive",
						onClick: end,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneOff, { className: "size-4" }), "End session"]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						onClick: () => void start(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), "Start live session"]
					})
				}),
				detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-destructive",
					children: detail
				}) : null
			]
		}), lines.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: line.who === "you" ? "rounded-lg bg-secondary px-3 py-2 text-sm" : "rounded-lg bg-card px-3 py-2 text-sm shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mr-2 text-xs uppercase tracking-wider text-muted-foreground",
					children: line.who === "you" ? "You" : "PyDuke"
				}), line.text]
			}, `${line.who}-${i}`))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "After you start, speak a Python question. The tutor answers in voice. You can mute or end at any time."
		})]
	});
}
function statusLabel(status, speaking, muted) {
	if (status === "connecting") return "Connecting to Gemini Live…";
	if (status === "live" && muted) return "Muted — tap unmute to keep talking";
	if (status === "live" && speaking) return "PyDuke is speaking";
	if (status === "live") return "Listening";
	if (status === "error") return "Session failed";
	if (status === "ended") return "Session ended";
	return "Idle";
}
//#endregion
export { createSsrRpc as n, LiveTutor as t };
