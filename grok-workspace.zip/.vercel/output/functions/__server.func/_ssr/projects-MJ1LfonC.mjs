//#region node_modules/.nitro/vite/services/ssr/assets/projects-MJ1LfonC.js
var PROJECTS = [
	{
		id: "guess",
		title: "Number judge",
		blurb: "The comparison heart of a guessing game, without random input.",
		concepts: [
			"conditions",
			"functions",
			"loops"
		],
		difficulty: "easy",
		steps: [
			{
				title: "Name the data",
				body: "A secret integer and a guess integer."
			},
			{
				title: "Name the verb",
				body: "judge(secret, guess) returns low, high, or match."
			},
			{
				title: "Drive it",
				body: "Call it three times so you can see every branch."
			}
		],
		starter: "def judge(secret, guess):\n    # return 'low', 'high', or 'match'\n    ...\n\n# prints: low / high / match\n",
		solution: "def judge(secret, guess):\n    if guess == secret:\n        return 'match'\n    if guess < secret:\n        return 'low'\n    return 'high'\n\nprint(judge(7, 2))\nprint(judge(7, 9))\nprint(judge(7, 7))",
		checks: [{
			kind: "stdout",
			expected: "low\nhigh\nmatch"
		}],
		explanation: "Keep I/O out of the function. Three calls cover the three paths. A full game would loop input() around this."
	},
	{
		id: "calc",
		title: "Tiny calculator",
		blurb: "Apply +, -, *, / to two numbers with a function.",
		concepts: [
			"functions",
			"operators",
			"conditions"
		],
		difficulty: "easy",
		steps: [
			{
				title: "Signature",
				body: "calc(op, a, b) where op is a string."
			},
			{
				title: "Branch",
				body: "One branch per operator. Division uses /."
			},
			{
				title: "Show",
				body: "Print four results for 8 and 2."
			}
		],
		starter: "def calc(op, a, b):\n    ...\n",
		solution: "def calc(op, a, b):\n    if op == '+':\n        return a + b\n    if op == '-':\n        return a - b\n    if op == '*':\n        return a * b\n    if op == '/':\n        return a / b\n    return None\n\nprint(calc('+', 8, 2))\nprint(calc('-', 8, 2))\nprint(calc('*', 8, 2))\nprint(calc('/', 8, 2))",
		checks: [{
			kind: "stdout",
			expected: "10\n6\n16\n4.0"
		}],
		explanation: "A dispatch on the operator string. `/` yields a float, so 4.0 is correct."
	},
	{
		id: "quiz",
		title: "Quiz scorer",
		blurb: "Score a list of (answer, expected) pairs.",
		concepts: [
			"lists",
			"tuples",
			"loops",
			"functions"
		],
		difficulty: "medium",
		steps: [
			{
				title: "Data",
				body: "A list of tuples: (given, expected)."
			},
			{
				title: "Score",
				body: "Count exact matches, case-sensitive."
			},
			{
				title: "Report",
				body: "Print correct/total like 2/3."
			}
		],
		starter: "pairs = [('paris', 'paris'), ('lima', 'lyon'), ('rome', 'rome')]\n\ndef score(pairs):\n    ...\n",
		solution: "pairs = [('paris', 'paris'), ('lima', 'lyon'), ('rome', 'rome')]\n\ndef score(pairs):\n    ok = 0\n    for given, expected in pairs:\n        if given == expected:\n            ok += 1\n    return ok\n\nprint(f'{score(pairs)}/{len(pairs)}')",
		checks: [{
			kind: "stdout",
			expected: "2/3"
		}],
		explanation: "Unpack each tuple in the loop. The function returns a count; the f-string formats the report."
	},
	{
		id: "todo",
		title: "To-do list",
		blurb: "Add, list, and remove items from a list.",
		concepts: ["lists", "functions"],
		difficulty: "medium",
		steps: [
			{
				title: "Store",
				body: "A list of strings."
			},
			{
				title: "API",
				body: "add, remove_at, show via print of the list."
			},
			{
				title: "Script",
				body: "Add two, remove index 0, print."
			}
		],
		starter: "todos = []\n\ndef add(item):\n    ...\n\ndef remove_at(i):\n    ...\n",
		solution: "todos = []\n\ndef add(item):\n    todos.append(item)\n\ndef remove_at(i):\n    todos.pop(i)\n\nadd('read')\nadd('code')\nremove_at(0)\nprint(todos)",
		checks: [{
			kind: "stdout",
			expected: "['code']"
		}],
		explanation: "append grows, pop(i) removes by position. After dropping 'read', only 'code' remains."
	},
	{
		id: "password",
		title: "Password generator",
		blurb: "Build a password from a pool with a seed so the result is checkable.",
		concepts: [
			"strings",
			"loops",
			"stdlib"
		],
		difficulty: "medium",
		steps: [
			{
				title: "Seed",
				body: "random.seed(2) so the sequence is fixed."
			},
			{
				title: "Pool",
				body: "letters + digits."
			},
			{
				title: "Draw",
				body: "Eight characters, print the joined string."
			}
		],
		starter: "import random\nimport string\nrandom.seed(2)\n",
		solution: "import random\nimport string\nrandom.seed(2)\npool = string.ascii_letters + string.digits\nchars = [random.choice(pool) for _ in range(8)]\nprint(''.join(chars))",
		checks: [{
			kind: "stdout",
			expected: "9382dffx"
		}],
		explanation: "Seeding makes random teaching-testable. choice picks from the pool; join concatenates."
	},
	{
		id: "expense",
		title: "Expense tracker",
		blurb: "Sum a dict of category -> amount and print the total.",
		concepts: ["dictionaries", "loops"],
		difficulty: "medium",
		steps: [
			{
				title: "Data",
				body: "A dict of named costs."
			},
			{
				title: "Total",
				body: "Sum the values."
			},
			{
				title: "Print",
				body: "The integer total."
			}
		],
		starter: "costs = {'rent': 400, 'food': 120, 'train': 30}\n",
		solution: "costs = {'rent': 400, 'food': 120, 'train': 30}\nprint(sum(costs.values()))",
		checks: [{
			kind: "stdout",
			expected: "550"
		}],
		explanation: "values() is the amounts. sum walks them. 400+120+30=550."
	},
	{
		id: "contacts",
		title: "Contact book",
		blurb: "Map names to emails; look up with get.",
		concepts: ["dictionaries", "functions"],
		difficulty: "medium",
		steps: [
			{
				title: "Store",
				body: "name -> email."
			},
			{
				title: "Lookup",
				body: "find(name) returns email or 'missing'."
			},
			{
				title: "Call",
				body: "Print Ada's email and Moe's miss."
			}
		],
		starter: "book = {'Ada': 'ada@pyduke.dev', 'Lin': 'lin@pyduke.dev'}\n\ndef find(name):\n    ...\n",
		solution: "book = {'Ada': 'ada@pyduke.dev', 'Lin': 'lin@pyduke.dev'}\n\ndef find(name):\n    return book.get(name, 'missing')\n\nprint(find('Ada'))\nprint(find('Moe'))",
		checks: [{
			kind: "stdout",
			expected: "ada@pyduke.dev\nmissing"
		}],
		explanation: "get with a default is the safe lookup. Missing keys should not crash a contact book."
	},
	{
		id: "adventure",
		title: "Text room",
		blurb: "A dict of rooms and a move() that follows exits.",
		concepts: ["dictionaries", "functions"],
		difficulty: "hard",
		steps: [
			{
				title: "Map",
				body: "Each room has a dict of direction -> room."
			},
			{
				title: "State",
				body: "current is a room name."
			},
			{
				title: "Move",
				body: "If the exit exists, go; else stay. Print the room after two moves."
			}
		],
		starter: "rooms = {\n    'hall': {'n': 'kitchen'},\n    'kitchen': {'s': 'hall', 'e': 'garden'},\n    'garden': {'w': 'kitchen'},\n}\ncurrent = 'hall'\n\ndef move(direction):\n    global current\n    ...\n",
		solution: "rooms = {\n    'hall': {'n': 'kitchen'},\n    'kitchen': {'s': 'hall', 'e': 'garden'},\n    'garden': {'w': 'kitchen'},\n}\ncurrent = 'hall'\n\ndef move(direction):\n    global current\n    nxt = rooms[current].get(direction)\n    if nxt:\n        current = nxt\n\nmove('n')\nmove('e')\nprint(current)",
		checks: [{
			kind: "stdout",
			expected: "garden"
		}],
		explanation: "The map is data. move is one verb. hall --n--> kitchen --e--> garden."
	},
	{
		id: "organizer",
		title: "File organizer",
		blurb: "Write two files, then list how many .txt files exist in the workspace.",
		concepts: ["files", "stdlib"],
		difficulty: "hard",
		steps: [
			{
				title: "Create",
				body: "Write a.txt and b.txt with any content."
			},
			{
				title: "Scan",
				body: "os.listdir('.') and keep a.txt and b.txt."
			},
			{
				title: "Count",
				body: "Print the sorted list of those two names."
			}
		],
		starter: "import os\n",
		solution: "import os\nfor name in ('a.txt', 'b.txt'):\n    with open(name, 'w') as f:\n        f.write('x')\nprint(sorted(n for n in os.listdir('.') if n in ('a.txt', 'b.txt')))",
		checks: [{
			kind: "stdout",
			expected: "['a.txt', 'b.txt']"
		}],
		explanation: "The sandbox disk is real inside the worker. Create both files, then filter listdir to those names so leftover files from other runs do not matter."
	},
	{
		id: "api",
		title: "API digest",
		blurb: "Pull fake users and print a sorted name list.",
		concepts: [
			"apis",
			"lists",
			"strings"
		],
		difficulty: "hard",
		steps: [
			{
				title: "Fetch",
				body: "pyduke_net.fetch('/users') returns a list of dicts."
			},
			{
				title: "Project",
				body: "Collect the name field."
			},
			{
				title: "Present",
				body: "Sort and join with commas."
			}
		],
		starter: "from pyduke_net import fetch\n",
		solution: "from pyduke_net import fetch\nnames = [u['name'] for u in fetch('/users')]\nprint(','.join(sorted(names)))",
		checks: [{
			kind: "stdout",
			expected: "Ada,Lin"
		}],
		explanation: "Same as any list of dicts. The network is faked; the data shape is real."
	}
];
//#endregion
export { PROJECTS as t };
