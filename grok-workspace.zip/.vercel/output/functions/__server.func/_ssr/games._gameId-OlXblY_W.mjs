import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as useHelix, t as EMPTY_IDS } from "./store-CUZplCsw.mjs";
import { D as ArrowRight, O as ArrowLeft, w as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as Button, d as GAMES, f as GAME_META, i as Route$4 } from "./router-CYzlBSjl.mjs";
import { n as resolveGameId } from "./game-ids-Dqoi2Xic.mjs";
import { t as DifficultyBadge } from "./difficulty-badge-cALuMwcu.mjs";
import { n as OrderCard, r as PredictCard, t as FixCard } from "./game-cards-DX94gmXo.mjs";
import { n as TypingArena, t as TYPING_DRILLS } from "./typing-DwdOPFYh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/games._gameId-OlXblY_W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function shuffle(list) {
	const a = [...list];
	for (let i = a.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[a[i], a[j]] = [a[j], a[i]];
	}
	return a;
}
function GamePage() {
	const { gameId: raw } = Route$4.useParams();
	const gameId = resolveGameId(raw);
	const meta = GAME_META.find((g) => g.id === gameId);
	if (!gameId || !meta) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Unknown game. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/games",
		children: "Back"
	})] });
	if (gameId === "typing") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, { meta }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingArena, { drills: TYPING_DRILLS })]
	});
	const pool = GAMES[gameId] ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, { meta }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameRunner, {
			gameId,
			items: pool
		})]
	});
}
function Head({ meta }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/games",
			className: "text-xs text-muted-foreground hover:text-foreground",
			children: "Games"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-3xl font-medium tracking-tight",
			children: meta.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm text-muted-foreground",
			children: meta.blurb
		})
	] });
}
function GameRunner({ gameId, items }) {
	const completed = useHelix((s) => s.games[gameId]?.completed ?? EMPTY_IDS);
	const complete = useHelix((s) => s.completeGameItem);
	const deck = (0, import_react.useMemo)(() => gameId === "boss" ? items : shuffle(items), [gameId, items]);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [lives, setLives] = (0, import_react.useState)(3);
	const unlockedIndex = (0, import_react.useMemo)(() => {
		if (gameId !== "boss") return deck.length;
		let u = 0;
		for (const it of deck) if (completed.includes(it.id)) u += 1;
		else break;
		return Math.min(deck.length, u + 1);
	}, [
		gameId,
		deck,
		completed
	]);
	const safeIndex = Math.min(index, Math.max(0, unlockedIndex - 1));
	const item = deck[safeIndex];
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children: "No challenges yet."
	});
	function mark(ok) {
		if (ok) {
			complete(gameId, item.id);
			toast("Challenge cleared");
			return;
		}
		if (gameId === "boss") setLives((n) => Math.max(0, n - 1));
	}
	const dead = gameId === "boss" && lives <= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			gameId === "boss" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Lives ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-foreground",
						children: lives
					}),
					" / 3"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: deck.map((it, i) => {
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: i >= unlockedIndex || dead,
						onClick: () => setIndex(i),
						className: `tap-card h-11 min-w-11 rounded-md px-2 text-xs tabular-nums ${i === safeIndex ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"} disabled:opacity-30`,
						children: i + 1
					}, it.id);
				})
			}),
			dead ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl",
						children: "The boss stands."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Three misses. Retry from the last cleared level."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: () => {
							setLives(3);
							setIndex(Math.max(0, unlockedIndex - 1));
						},
						children: "Retry"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DifficultyBadge, { value: item.difficulty }),
						completed.includes(item.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 text-xs text-success",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), " Done"]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: item.prompt
				}),
				item.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: ["Hint: ", item.hint]
				}) : null,
				gameId === "predict" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PredictCard, {
					item,
					onResult: mark
				}, item.id) : gameId === "ordering" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderCard, {
					item,
					onResult: mark
				}, item.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FixCard, {
					item,
					onResult: mark
				}, item.id)
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					size: "sm",
					disabled: safeIndex === 0,
					onClick: () => setIndex((i) => Math.max(0, i - 1)),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Prev"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					size: "sm",
					disabled: safeIndex >= unlockedIndex - 1 || dead,
					onClick: () => setIndex((i) => i + 1),
					children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
				})]
			})
		]
	});
}
//#endregion
export { GamePage as component };
