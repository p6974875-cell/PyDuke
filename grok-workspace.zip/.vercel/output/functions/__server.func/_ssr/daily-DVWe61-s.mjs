import { f as TOPICS, u as LESSONS } from "./router-C24WQtVx.mjs";
import { o as seeded } from "./game-engine-CQ7mU7b7.mjs";
import { t as GAMES } from "./games-ChJArZc0.mjs";
import { t as TYPING_DRILLS } from "./typing-4BhAJFpN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/daily-DVWe61-s.js
var CONCEPTS = [
	{
		id: "cq-var",
		topicId: "variables",
		question: "What does `x = 3` do in Python?",
		choices: [
			"Declares that x will always be an integer",
			"Creates the integer 3 and binds the name x to it",
			"Copies the number 3 into a typed box named x",
			"Reserves 3 bytes named x"
		],
		answer: "Creates the integer 3 and binds the name x to it",
		explanation: "Assignment binds a name to an object. The type lives on the object, not the name."
	},
	{
		id: "cq-io",
		topicId: "io",
		question: "What type does input() always return?",
		choices: [
			"int if you type digits",
			"str",
			"the type you asked for",
			"bytes"
		],
		answer: "str",
		explanation: "input() reads a line and returns a string. Convert with int() or float() if you need a number."
	},
	{
		id: "cq-op",
		topicId: "operators",
		question: "What is 7 // 2 in Python 3?",
		choices: [
			"3.5",
			"3",
			"4",
			"2"
		],
		answer: "3",
		explanation: "// is floor division. 7 / 2 is 3.5; 7 // 2 is 3."
	},
	{
		id: "cq-if",
		topicId: "conditions",
		question: "How many branches of an if / elif / else chain run?",
		choices: [
			"All that are true",
			"All of them",
			"At most one",
			"The last one always"
		],
		answer: "At most one",
		explanation: "Python picks the first true condition and skips the rest."
	},
	{
		id: "cq-loop",
		topicId: "loops",
		question: "Why does `for i in 5:` fail?",
		choices: [
			"5 is too small",
			"You must use while",
			"An int is not iterable",
			"i is reserved"
		],
		answer: "An int is not iterable",
		explanation: "for walks an iterable. Use range(5) to get 0..4."
	},
	{
		id: "cq-list",
		topicId: "lists",
		question: "After `b = a` where a is a list, `b.append(1)` will:",
		choices: [
			"Leave a unchanged",
			"Change a as well",
			"Copy a then change b",
			"Raise TypeError"
		],
		answer: "Change a as well",
		explanation: "b = a aliases. Both names point at the same list."
	},
	{
		id: "cq-tup",
		topicId: "tuples",
		question: "How do you write a one-element tuple holding 5?",
		choices: [
			"(5)",
			"[5]",
			"tuple(5)",
			"(5,)"
		],
		answer: "(5,)",
		explanation: "The comma constructs the tuple. (5) is just the integer 5."
	},
	{
		id: "cq-dict",
		topicId: "dictionaries",
		question: "Iterating `for x in d` on a dict yields:",
		choices: [
			"values",
			"keys",
			"(key, value) pairs",
			"indexes"
		],
		answer: "keys",
		explanation: "Use .values() or .items() if you need those."
	},
	{
		id: "cq-fn",
		topicId: "functions",
		question: "What does a function return if it has no return statement?",
		choices: [
			"0",
			"False",
			"None",
			"It cannot be called"
		],
		answer: "None",
		explanation: "Falling off the end returns None. Mutators like list.append also return None."
	},
	{
		id: "cq-err",
		topicId: "errors",
		question: "Which exception is raised by int('q')?",
		choices: [
			"TypeError",
			"NameError",
			"ValueError",
			"SyntaxError"
		],
		answer: "ValueError",
		explanation: "The type is right (str), the value is not a number."
	},
	{
		id: "cq-str",
		topicId: "strings",
		question: "After s = 'ab'; s.upper(); what is s?",
		choices: [
			"'AB'",
			"'ab'",
			"None",
			"It raises"
		],
		answer: "'ab'",
		explanation: "Strings are immutable. upper() returns a new string that was discarded."
	},
	{
		id: "cq-set",
		topicId: "sets",
		question: "What is the point of a set?",
		choices: [
			"Keep insertion order of duplicates",
			"Unique membership tests",
			"Index by position",
			"Store lists as elements"
		],
		answer: "Unique membership tests",
		explanation: "Sets drop duplicates and make `in` cheap. Elements must be hashable."
	},
	{
		id: "cq-file",
		topicId: "files",
		question: "Why use `with open(path) as f`?",
		choices: [
			"It is faster",
			"It encrypts the file",
			"It closes the file even if an error happens",
			"It only works for reading"
		],
		answer: "It closes the file even if an error happens",
		explanation: "The context manager closes the file on the way out, including after exceptions."
	},
	{
		id: "cq-mod",
		topicId: "modules",
		question: "What does `import math` bind?",
		choices: [
			"Every name from math into your file",
			"The module object named math",
			"Only sqrt",
			"Nothing until you call it"
		],
		answer: "The module object named math",
		explanation: "You then write math.sqrt. from math import sqrt binds sqrt instead."
	},
	{
		id: "cq-scope",
		topicId: "scope",
		question: "A name assigned inside a function is, by default:",
		choices: [
			"global",
			"local to that call",
			"shared across calls",
			"a class attribute"
		],
		answer: "local to that call",
		explanation: "Each call gets its own frame. Assignment makes a local unless you declare global/nonlocal."
	},
	{
		id: "cq-oop",
		topicId: "oop",
		question: "In a method, self is:",
		choices: [
			"The class object",
			"The instance the method was called on",
			"A reserved keyword you must not use",
			"Always None"
		],
		answer: "The instance the method was called on",
		explanation: "a.deposit(5) is Account.deposit(a, 5). self is a."
	}
];
function dateSeed(date) {
	return date.split("-").reduce((n, p) => n * 31 + Number(p), 7);
}
function pick(rng, arr, n) {
	const a = arr.slice();
	for (let i = a.length - 1; i > 0; i--) {
		const j = Math.floor(rng() * (i + 1));
		[a[i], a[j]] = [a[j], a[i]];
	}
	return a.slice(0, n);
}
function buildDaily(date, topics) {
	const rng = seeded(dateSeed(date));
	const open = TOPICS.filter((t) => topics[t.id]?.status !== "locked").map((t) => t.id);
	const weak = open.filter((id) => (topics[id]?.mistakes.length ?? 0) > 0);
	const poolTopics = weak.length ? [...weak, ...open] : open;
	const concepts = pick(rng, CONCEPTS.filter((c) => poolTopics.includes(c.topicId) || open.includes(c.topicId)), 2);
	const predicts = pick(rng, GAMES.predict ?? [], 2);
	const debugItems = GAMES.debug ?? [];
	const debug = debugItems[Math.floor(rng() * debugItems.length)] ?? null;
	const lessonPool = open.map((id) => {
		const ex = LESSONS[id]?.exercises[0];
		return ex ? {
			topicId: id,
			exercise: ex
		} : null;
	}).filter((x) => Boolean(x));
	return {
		date,
		concepts,
		predicts,
		debug,
		exercise: lessonPool[Math.floor(rng() * Math.max(1, lessonPool.length))] ?? null,
		typing: TYPING_DRILLS[Math.floor(rng() * TYPING_DRILLS.length)] ?? TYPING_DRILLS[0]
	};
}
var DAILY_SLOTS = [
	"concept-0",
	"concept-1",
	"predict-0",
	"predict-1",
	"debug",
	"code",
	"typing"
];
//#endregion
export { buildDaily as n, DAILY_SLOTS as t };
