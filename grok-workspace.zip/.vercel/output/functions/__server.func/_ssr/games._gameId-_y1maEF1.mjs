import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { F as ArrowLeft, P as ArrowRight, S as Heart, k as Check, l as RotateCcw, n as Trophy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as EMPTY_IDS, c as useHelix, i as Route$3, v as Button } from "./router-C24WQtVx.mjs";
import { a as pointsFor, i as pickPlayOrder, n as isGameUnlocked, r as livesFor } from "./game-engine-CQ7mU7b7.mjs";
import { n as GAME_META, t as GAMES } from "./games-ChJArZc0.mjs";
import { t as TYPING_DRILLS } from "./typing-4BhAJFpN.mjs";
import { t as DifficultyBadge } from "./difficulty-badge-CNrfsmNH.mjs";
import { t as ChallengeCard } from "./game-challenges-CPLS4CNL.mjs";
import { t as TypingArena } from "./typing-arena-DPenP3If.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/games._gameId-_y1maEF1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GamePage() {
	const { gameId } = Route$3.useParams();
	const meta = GAME_META.find((g) => g.id === gameId);
	const topics = useHelix((s) => s.topics);
	if (!meta) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
		"Unknown game.",
		" ",
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/games",
			className: "underline",
			children: "Back"
		})
	] });
	if (!isGameUnlocked(gameId, topics)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, { meta }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]",
				children: "This game unlocks after you finish the matching lesson. Keep going in Learn."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "secondary",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/learn",
					children: "Open curriculum"
				})
			})
		]
	});
	if (gameId === "typing") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, { meta }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingArena, { drills: TYPING_DRILLS })]
	});
	const items = GAMES[gameId] ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, { meta }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameRunner, {
			gameId,
			items
		}, gameId)]
	});
}
function Head({ meta }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/games",
			className: "text-xs text-muted-foreground hover:text-foreground",
			children: "Games"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-3xl font-medium tracking-tight",
			children: meta.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm text-muted-foreground",
			children: meta.blurb
		})
	] });
}
function GameRunner({ gameId, items }) {
	const completed = useHelix((s) => s.games[gameId]?.completed ?? EMPTY_IDS);
	const bestScore = useHelix((s) => s.games[gameId]?.bestScore ?? 0);
	const complete = useHelix((s) => s.completeGameItem);
	const finish = useHelix((s) => s.finishGameSession);
	const maxLives = livesFor(gameId);
	const sequential = gameId === "boss";
	const deck = (0, import_react.useMemo)(() => sequential ? items : pickPlayOrder(items, completed), [gameId, items]);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [lives, setLives] = (0, import_react.useState)(maxLives ?? 99);
	const [score, setScore] = (0, import_react.useState)(0);
	const [streak, setStreak] = (0, import_react.useState)(0);
	const [correct, setCorrect] = (0, import_react.useState)(0);
	const [wrong, setWrong] = (0, import_react.useState)(0);
	const [answered, setAnswered] = (0, import_react.useState)({});
	const [over, setOver] = (0, import_react.useState)(false);
	const [seed, setSeed] = (0, import_react.useState)(0);
	const unlockedIndex = sequential ? Math.min(items.length, completed.filter((id) => items.some((it) => it.id === id)).length + 1) : deck.length;
	const safeIndex = Math.min(index, Math.max(0, (sequential ? unlockedIndex : deck.length) - 1));
	const item = deck[safeIndex];
	function mark(ok) {
		if (!item || answered[item.id] === true) return;
		const pts = ok ? pointsFor(item.difficulty, streak + 1) : 0;
		complete(gameId, item.id, ok, pts);
		const nextAnswered = {
			...answered,
			[item.id]: ok
		};
		setAnswered(nextAnswered);
		let nextScore = score;
		let nextLives = lives;
		if (ok) {
			nextScore = score + pts;
			setScore(nextScore);
			setStreak((s) => s + 1);
			setCorrect((n) => n + 1);
			toast(`+${pts}`);
		} else {
			setStreak(0);
			setWrong((n) => n + 1);
			nextLives = lives - 1;
			setLives(nextLives);
		}
		const unique = Object.keys(nextAnswered).length;
		if (maxLives !== null && nextLives <= 0 || unique >= deck.length) {
			finish(gameId, nextScore);
			setOver(true);
		} else if (ok) setIndex((i) => Math.min(i + 1, deck.length - 1));
	}
	function replay() {
		setIndex(0);
		setLives(maxLives ?? 99);
		setScore(0);
		setStreak(0);
		setCorrect(0);
		setWrong(0);
		setAnswered({});
		setOver(false);
		setSeed((n) => n + 1);
	}
	if (!item && !over) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children: "No challenges yet."
	});
	if (over) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-5 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Session results"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Score",
						v: String(score)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Best",
						v: String(Math.max(bestScore, score))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Correct",
						v: String(correct)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Missed",
						v: String(wrong)
					})
				]
			}),
			maxLives !== null && lives <= 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: "Out of lives. Replay to try the remaining challenges."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Deck complete. XP is already on your profile."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: replay,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Replay"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/games",
						children: "Games"
					})
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: ["Score ", score]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-muted-foreground",
						children: ["Streak ", streak]
					}),
					maxLives !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 tabular-nums",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-3.5 text-destructive" }),
							lives,
							"/",
							maxLives
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto text-xs tabular-nums text-muted-foreground",
						children: [
							safeIndex + 1,
							"/",
							deck.length
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: deck.map((it, i) => {
					const locked = sequential && i >= unlockedIndex;
					const done = answered[it.id] ?? completed.includes(it.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: locked,
						onClick: () => setIndex(i),
						className: `h-11 min-w-11 rounded-md px-2 text-xs tabular-nums ${i === safeIndex ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"} disabled:opacity-30`,
						children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mx-auto size-3.5" }) : i + 1
					}, it.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: item.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DifficultyBadge, { value: item.difficulty }),
					completed.includes(item.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 text-xs text-success",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), " Cleared before"]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: item.prompt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChallengeCard, {
				item,
				onResult: mark
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					size: "sm",
					disabled: safeIndex === 0,
					onClick: () => setIndex((i) => Math.max(0, i - 1)),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Prev"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					size: "sm",
					disabled: safeIndex >= (sequential ? unlockedIndex : deck.length) - 1,
					onClick: () => setIndex((i) => i + 1),
					children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
				})]
			})
		]
	}, `${seed}-${item.id}`);
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-secondary px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted-foreground",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-display text-xl tabular-nums",
			children: v
		})]
	});
}
//#endregion
export { GamePage as component };
