import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as xpIntoLevel, n as levelFromXp } from "./utils-fNW1Yxkl.mjs";
import { c as useHelix, i as TOPICS } from "./store-CUZplCsw.mjs";
import { a as ACHIEVEMENTS, d as GAMES, f as GAME_META, o as unlockedAchievements, s as Progress } from "./router-CYzlBSjl.mjs";
import { t as PROJECTS } from "./projects-MJ1LfonC.mjs";
import { a as ResponsiveContainer, i as Line, n as YAxis, o as Tooltip, r as XAxis, t as LineChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-BUkSD4_x.js
var import_jsx_runtime = require_jsx_runtime();
function ProgressPage() {
	const s = useHelix();
	const mastered = TOPICS.filter((t) => s.topics[t.id].status === "mastered");
	const review = s.dueRevision();
	const gamesDone = GAME_META.reduce((n, g) => n + (s.games[g.id]?.completed.length ?? 0), 0);
	const gamesTotal = GAME_META.reduce((n, g) => n + (g.id === "typing" ? 10 : GAMES[g.id]?.length ?? 0), 0);
	const lastType = s.typingHistory.at(-1);
	const avgAcc = s.typingHistory.length === 0 ? 0 : Math.round(s.typingHistory.reduce((a, h) => a + h.accuracy, 0) / s.typingHistory.length * 10) / 10;
	const debugScore = Math.round((s.games.debug?.completed.length ?? 0) / Math.max(1, GAMES.debug.length) * 100);
	const typeData = s.typingHistory.slice(-12).map((h, i) => ({
		i: i + 1,
		wpm: h.wpm,
		accuracy: h.accuracy
	}));
	const unlocked = unlockedAchievements(s);
	const unlockedIds = new Set(unlocked.map((a) => a.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
				children: "Progress"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-medium tracking-tight",
				children: "Where you stand"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Python level",
						value: `Lv ${levelFromXp(s.xp)}`,
						hint: `${s.xp} XP`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Streak",
						value: String(s.streak),
						hint: "consecutive days"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Lessons completed",
						value: String(s.lessonsCompleted.length),
						hint: `${TOPICS.length} in path`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Projects",
						value: `${s.projectsCompleted.length}/${PROJECTS.length}`,
						hint: "builds finished"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "XP in this level"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: xpIntoLevel(s.xp) / 150 * 100,
							className: "mt-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs tabular-nums text-muted-foreground",
							children: [xpIntoLevel(s.xp), " / 150"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Games completed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: gamesTotal ? gamesDone / gamesTotal * 100 : 0,
							className: "mt-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs tabular-nums text-muted-foreground",
							children: [
								gamesDone,
								"/",
								gamesTotal
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Typing speed",
						value: lastType ? `${lastType.wpm} WPM` : "—",
						hint: "last run"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Typing accuracy",
						value: `${avgAcc}%`,
						hint: "average"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Debugging score",
						value: `${debugScore}%`,
						hint: "debug game"
					})
				]
			}),
			typeData.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "h-48 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs text-muted-foreground",
					children: "Typing over recent runs (accuracy + WPM)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "85%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
						data: typeData,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "i",
								hide: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "#172333",
								border: "1px solid rgba(238,230,212,0.1)",
								borderRadius: 8,
								fontSize: 12
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "accuracy",
								stroke: "#c4a15a",
								dot: false,
								strokeWidth: 1.5
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "wpm",
								stroke: "#6fbf9a",
								dot: false,
								strokeWidth: 1.5
							})
						]
					})
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-medium",
				children: "Achievements"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-2 sm:grid-cols-2",
				children: ACHIEVEMENTS.map((a) => {
					const on = unlockedIds.has(a.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: on ? "font-medium text-accent" : "font-medium text-muted-foreground",
							children: [on ? "Unlocked · " : "Locked · ", a.title]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: a.blurb
						})]
					}, a.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-medium",
				children: "Topics mastered"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex flex-wrap gap-2",
				children: mastered.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "rounded-full bg-secondary px-3 py-1 text-xs",
					children: t.title
				}, t.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-medium",
				children: "Needs revision"
			}), review.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Nothing is due. Keep moving forward."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: review.map((id) => {
					const t = TOPICS.find((x) => x.id === id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/learn/$topicId",
						params: { topicId: id },
						className: "text-sm hover:underline",
						children: t.title
					}) }, id);
				})
			})] })
		]
	});
}
function Tile({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-2xl tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
//#endregion
export { ProgressPage as component };
