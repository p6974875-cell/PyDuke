import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cn } from "./utils-fNW1Yxkl.mjs";
import { t as explainError } from "./python-engine-DcCb1ULs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/python-output-BpGgEqVn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CodeEditor(props) {
	const [Inner, setInner] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("./code-editor-inner-7sOa2O6W.mjs").then((m) => {
			if (live) setInner(() => m.CodeEditorInner);
		});
		return () => {
			live = false;
		};
	}, []);
	if (!Inner) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-lg bg-code shadow-[var(--shadow-border)]", props.className),
		style: { minHeight: props.minHeight ?? 220 }
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inner, { ...props });
}
function PythonOutput({ result, code, className }) {
	if (!result) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-lg bg-code px-4 py-3 text-sm text-muted-foreground", className),
		children: "Output appears here after you run."
	});
	const hasOut = result.stdout.trim().length > 0;
	const err = result.error || result.stderr;
	const steps = err ? explainError(err, code ?? "") : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-3", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("pre", {
				className: "overflow-x-auto rounded-lg bg-code px-4 py-3 font-mono text-[13px] leading-relaxed text-foreground",
				children: [hasOut ? result.stdout : err ? "" : "(no output)", err ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block text-destructive",
					children: [hasOut ? "\n" : "", err]
				}) : null]
			}),
			steps ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-1.5 rounded-lg bg-secondary px-4 py-3 text-sm text-muted-foreground",
				children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "leading-relaxed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mr-2 font-mono text-xs text-accent",
						children: [i + 1, "."]
					}), s]
				}, i))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs tabular-nums text-muted-foreground",
				children: [result.durationMs, "ms"]
			})
		]
	});
}
//#endregion
export { PythonOutput as n, CodeEditor as t };
