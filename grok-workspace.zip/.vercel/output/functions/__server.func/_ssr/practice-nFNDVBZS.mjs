import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { k as Check } from "../_libs/lucide-react.mjs";
import { S as todayKey, _ as Progress, c as useHelix } from "./router-C24WQtVx.mjs";
import { n as McqPrompt, t as ChallengeCard } from "./game-challenges-CPLS4CNL.mjs";
import { t as TypingArena } from "./typing-arena-DPenP3If.mjs";
import { t as ExercisePanel } from "./exercise-panel-4x2yRSDF.mjs";
import { n as buildDaily, t as DAILY_SLOTS } from "./daily-DVWe61-s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/practice-nFNDVBZS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PracticePage() {
	const topics = useHelix((s) => s.topics);
	const dailyDate = useHelix((s) => s.dailyDate);
	const dailyDone = useHelix((s) => s.dailyDone);
	const markDaily = useHelix((s) => s.markDaily);
	const today = todayKey();
	const done = dailyDate === today ? dailyDone : [];
	const set = (0, import_react.useMemo)(() => buildDaily(today, topics), [today, topics]);
	const pct = Math.round(done.length / DAILY_SLOTS.length * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Daily practice"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-medium tracking-tight",
					children: "Today’s set"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Two concepts, two output predictions, one debug, one coding exercise, and a typing sprint. Seeded by the date — same day, same set. Weak topics you missed before are preferred."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: pct,
						className: "max-w-xs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs tabular-nums text-muted-foreground",
						children: [
							done.length,
							"/",
							DAILY_SLOTS.length
						]
					})]
				})
			] }),
			set.concepts.map((c, i) => {
				const slot = `concept-${i}`;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
					title: `Concept ${i + 1}`,
					done: done.includes(slot),
					children: done.includes(slot) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-success",
						children: "Logged for today."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(McqPrompt, {
						question: c.question,
						choices: c.choices,
						answer: c.answer,
						explanation: c.explanation,
						onResult: () => markDaily(slot)
					})
				}, c.id);
			}),
			set.predicts.map((item, i) => {
				const slot = `predict-${i}`;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
					title: `Predict ${i + 1}: ${item.title}`,
					done: done.includes(slot),
					children: done.includes(slot) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-success",
						children: "Logged for today."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChallengeCard, {
						item,
						onResult: () => markDaily(slot)
					})
				}, item.id);
			}),
			set.debug ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
				title: `Debug: ${set.debug.title}`,
				done: done.includes("debug"),
				children: done.includes("debug") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-success",
					children: "Logged for today."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChallengeCard, {
					item: set.debug,
					onResult: () => markDaily("debug")
				})
			}) : null,
			set.exercise ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
				title: `Code: ${set.exercise.exercise.title}`,
				done: done.includes("code"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExercisePanel, {
					exercise: set.exercise.exercise,
					topicId: set.exercise.topicId,
					onPassed: () => markDaily("code")
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slot, {
				title: `Typing · ${set.typing.title}`,
				done: done.includes("typing"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Two-minute sprint. Accuracy first."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingArena, {
					drills: [set.typing],
					timedSeconds: 120,
					onComplete: () => markDaily("typing")
				})]
			}),
			done.length >= DAILY_SLOTS.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl bg-card p-5 text-sm shadow-[var(--shadow-border)]",
				children: [
					"Daily set complete. Come back tomorrow for a new seed.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/progress",
						className: "underline",
						children: "See progress"
					})
				]
			}) : null
		]
	});
}
function Slot({ title, done, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-medium",
				children: title
			}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 text-xs text-success",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), " Done"]
			}) : null]
		}), children]
	});
}
//#endregion
export { PracticePage as component };
