import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Save, f as Play, i as Trash2, l as RotateCcw } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useHelix, g as warmupPython, h as runPython, v as Button } from "./router-C24WQtVx.mjs";
import { t as Input } from "./input-CrCa6m5Z.mjs";
import { t as Label } from "./label-BROiwAnn.mjs";
import { n as PythonOutput, t as CodeEditor } from "./python-output-BJIiscp_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/code-DvEgDG8J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULT = `# PyDuke playground
# Ctrl/⌘ + Enter to run. Isolated Python — no OS, no network.

names = ["Ada", "Lin"]
print("hello", ", ".join(names))
`;
function Playground({ initial, onResult }) {
	const [code, setCode] = (0, import_react.useState)(initial ?? DEFAULT);
	const [stdin, setStdin] = (0, import_react.useState)("");
	const [running, setRunning] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	const [engine, setEngine] = (0, import_react.useState)("loading");
	const [title, setTitle] = (0, import_react.useState)("");
	const saveSnippet = useHelix((s) => s.saveSnippet);
	(0, import_react.useEffect)(() => {
		if (initial != null) setCode(initial);
	}, [initial]);
	(0, import_react.useEffect)(() => {
		warmupPython().then(() => setEngine("ready")).catch(() => setEngine("error"));
	}, []);
	async function run() {
		setRunning(true);
		try {
			const r = await runPython(code, stdin);
			setResult(r);
			onResult?.(r);
		} finally {
			setRunning(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-col gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: run,
							disabled: running || engine !== "ready",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), running ? "Running" : "Run"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => {
								setCode(initial ?? DEFAULT);
								setResult(null);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => {
								setCode("");
								setResult(null);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Clear"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-auto flex min-w-0 items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Save as…",
								value: title,
								onChange: (e) => setTitle(e.target.value),
								className: "h-9 w-36"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => {
									saveSnippet(title, code);
									toast("Saved to your notebook");
									setTitle("");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "Save"]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: engine === "loading" ? "Loading the Python runtime (first visit only)…" : engine === "error" ? "Could not load Python. Check your connection and retry." : "Sandbox ready. No files leave this browser."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
					value: code,
					onChange: setCode,
					onRun: run,
					minHeight: 280,
					className: "flex-1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "stdin",
						className: "text-xs text-muted-foreground",
						children: "Standard input for input()"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "stdin",
						value: stdin,
						onChange: (e) => setStdin(e.target.value),
						placeholder: "Lines the program can read"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonOutput, {
			result,
			code
		})]
	});
}
function CodePage() {
	const snippets = useHelix((s) => s.snippets);
	const deleteSnippet = useHelix((s) => s.deleteSnippet);
	const [load, setLoad] = (0, import_react.useState)(void 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Code"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-medium tracking-tight",
					children: "Playground"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Write Python, run it in an isolated engine, and read what went wrong in plain language. Saved snippets stay on this device."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Playground, { initial: load }),
			snippets.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Saved"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: snippets.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "min-w-0 text-left",
							onClick: () => setLoad(s.code),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: s.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("pre", {
								className: "mt-2 overflow-x-auto font-mono text-xs text-muted-foreground",
								children: [s.code.slice(0, 200), s.code.length > 200 ? "…" : ""]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": "Delete",
							onClick: () => deleteSnippet(s.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})]
					}, s.id))
				})]
			}) : null
		]
	});
}
//#endregion
export { CodePage as component };
