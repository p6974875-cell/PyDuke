import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { v as Lock } from "../_libs/lucide-react.mjs";
import { _ as Progress, c as useHelix } from "./router-C24WQtVx.mjs";
import { n as isGameUnlocked, t as GAME_UNLOCKS } from "./game-engine-CQ7mU7b7.mjs";
import { n as GAME_META, t as GAMES } from "./games-ChJArZc0.mjs";
import { t as TYPING_DRILLS } from "./typing-4BhAJFpN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/games-Drj7ozvq.js
var import_jsx_runtime = require_jsx_runtime();
function GamesPage() {
	const games = useHelix((s) => s.games);
	const topics = useHelix((s) => s.topics);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
				children: "Games"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-medium tracking-tight",
				children: "Play to learn"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-muted-foreground",
				children: "Each game grades real Python. Finish the matching lesson to unlock it. Challenges shuffle; scores and XP persist on this device."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: GAME_META.map((g) => {
				const items = g.id === "typing" ? TYPING_DRILLS.length : GAMES[g.id]?.length ?? 0;
				const done = games[g.id]?.completed.length ?? 0;
				const pct = items ? Math.round(done / items * 100) : 0;
				const open = isGameUnlocked(g.id, topics);
				const req = GAME_UNLOCKS[g.id];
				const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: g.topicHint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-xl font-medium",
						children: g.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: g.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: open ? pct : 0,
						className: "mt-4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs tabular-nums text-muted-foreground",
						children: open ? `${done}/${items || "—"} · best ${games[g.id]?.bestScore ?? 0}` : req.label
					})
				] });
				if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-card/60 p-5 text-muted-foreground shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 inline-flex items-center gap-1 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }), "Locked"]
					}), inner]
				}, g.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/games/$gameId",
					params: { gameId: g.id },
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
					children: inner
				}, g.id);
			})
		})]
	});
}
//#endregion
export { GamesPage as component };
