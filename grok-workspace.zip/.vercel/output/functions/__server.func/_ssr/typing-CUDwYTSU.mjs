import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { O as CircleCheck, o as Target } from "../_libs/lucide-react.mjs";
import { c as useHelix } from "./router-C24WQtVx.mjs";
import { t as TYPING_DRILLS } from "./typing-4BhAJFpN.mjs";
import { t as TypingArena } from "./typing-arena-DPenP3If.mjs";
import { a as ResponsiveContainer, i as Line, n as YAxis, o as Tooltip, r as XAxis, t as LineChart } from "../_libs/recharts+[...].mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-Be_eRrus.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/typing-CUDwYTSU.js
var import_jsx_runtime = require_jsx_runtime();
var TYPING_TECHNIQUES = [
	{
		id: "home-row",
		title: "1. Find the home position",
		goal: "Build a consistent starting position so your fingers stop hunting for keys.",
		steps: [
			"Rest your left fingers on A S D F and your right fingers on J K L ;.",
			"Keep both thumbs relaxed near the space bar.",
			"After every short phrase, return your fingers to the home position."
		],
		drill: "asdf jkl; asdf jkl; fdsa ;lkj",
		tip: "The F and J keys usually have small bumps. Use them as physical landmarks."
	},
	{
		id: "eyes-off",
		title: "2. Train without looking down",
		goal: "Turn common Python keys into muscle memory.",
		steps: [
			"Look at the code, not the keyboard.",
			"Slow down when you reach symbols such as :, _, (), [] and {}.",
			"If you make a mistake, correct it calmly instead of rushing."
		],
		drill: "name = 'Ada'\nif name:\n    print(name)",
		tip: "Accuracy creates reliable muscle memory. Speed comes later."
	},
	{
		id: "python-symbols",
		title: "3. Master Python symbols",
		goal: "Make punctuation feel automatic instead of interrupting your thinking.",
		steps: [
			"Practice colon + indentation together: if condition:",
			"Practice brackets as pairs: (), [], {}.",
			"Practice underscores in snake_case names."
		],
		drill: "user_name = {'scores': [10, 20, 30]}",
		tip: "Say the structure in your head: open bracket → content → close bracket."
	},
	{
		id: "indentation",
		title: "4. Make indentation automatic",
		goal: "Type Python blocks with clean four-space indentation.",
		steps: [
			"Type the colon at the end of a block header.",
			"Press Tab in this trainer to insert four spaces.",
			"Outdent when the block ends instead of adding random spaces."
		],
		drill: "for n in range(3):\n    if n > 0:\n        print(n)",
		tip: "Think of indentation as the shape of the program, not decoration."
	},
	{
		id: "accuracy",
		title: "5. Accuracy before speed",
		goal: "Reduce errors before trying to increase WPM.",
		steps: [
			"Aim for clean runs rather than a high first score.",
			"Notice which symbols or letters cause repeated mistakes.",
			"Repeat the same drill until your accuracy is stable."
		],
		drill: "def square(n):\n    return n ** 2",
		tip: "A useful target is consistent accuracy; speed can be trained afterward."
	},
	{
		id: "rhythm",
		title: "6. Build typing rhythm",
		goal: "Keep your hands moving smoothly through short Python statements.",
		steps: [
			"Type in small groups instead of hitting each key with a separate pause.",
			"Keep your shoulders and hands relaxed.",
			"Use short daily sessions and increase difficulty gradually."
		],
		drill: "numbers = [n * 2 for n in range(1, 6)]\nprint(numbers)",
		tip: "Smooth and controlled beats frantic. Let familiar syntax become a rhythm."
	}
];
function TypingPage() {
	const history = useHelix((s) => s.typingHistory);
	const avgAcc = history.length === 0 ? 0 : Math.round(history.reduce((a, h) => a + h.accuracy, 0) / history.length * 10) / 10;
	const avgWpm = history.length === 0 ? 0 : Math.round(history.reduce((a, h) => a + h.wpm, 0) / history.length);
	const data = history.slice(-12).map((h, i) => ({
		i: i + 1,
		wpm: h.wpm,
		accuracy: h.accuracy
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Typing"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-medium tracking-tight",
					children: "Python typing trainer"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Parentheses, colons, underscores, indentation. Do not trade accuracy for speed — a fast wrong program is still wrong."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Runs",
						value: String(history.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Average accuracy",
						value: `${avgAcc}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Average WPM",
						value: String(avgWpm)
					})
				]
			}),
			data.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-48 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
						data,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "i",
								hide: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "#17181c",
								border: "1px solid rgba(255,255,255,0.08)",
								borderRadius: 8,
								fontSize: 12
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "accuracy",
								stroke: "#c8ccd4",
								dot: false,
								strokeWidth: 1.5
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "wpm",
								stroke: "#6fbf9a",
								dot: false,
								strokeWidth: 1.5
							})
						]
					})
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Typing techniques"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Learn the technique, then use the arena to turn it into muscle memory."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: TYPING_TECHNIQUES.map((lesson) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: lesson.title
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "space-y-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: lesson.goal
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2",
								children: lesson.steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 size-4 shrink-0 text-success" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: step })]
								}, step))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-code p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-1 flex items-center gap-2 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-3.5" }), " Practice"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "whitespace-pre-wrap font-mono text-xs leading-relaxed",
									children: lesson.drill
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground",
										children: "Tip:"
									}),
									" ",
									lesson.tip
								]
							})
						]
					})] }, lesson.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Typing arena"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Choose a drill and type the code exactly. Your attempts are saved locally."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingArena, { drills: TYPING_DRILLS })]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { TypingPage as component };
