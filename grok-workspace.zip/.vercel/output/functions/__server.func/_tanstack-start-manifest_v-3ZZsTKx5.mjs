//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-3ZZsTKx5.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/code",
			"/games",
			"/learn",
			"/live",
			"/live-tutor",
			"/practice",
			"/profile",
			"/progress",
			"/projects",
			"/tutor",
			"/typing",
			"/api/ai/chat",
			"/api/ai/live"
		],
		preloads: [
			"/assets/index-12Wi-JoZ.js",
			"/assets/utils-CbUJ5KFk.js",
			"/assets/react-dom-B-lyp-gs.js",
			"/assets/invariant-DVltax7q.js",
			"/assets/link-CGNtQlsF.js",
			"/assets/lazyRouteComponent-Cv0G85Uv.js",
			"/assets/redirect-Bis1Jk_h.js",
			"/assets/createLucideIcon-asAAvpAT.js",
			"/assets/preload-helper-Dcg1J5XG.js",
			"/assets/dist--X_X-96y.js",
			"/assets/dist-Cz3rU7tk.js",
			"/assets/dist-Cjs3egtv.js",
			"/assets/dist-CjAPMWJ8.js",
			"/assets/games-Br_GaaP-.js",
			"/assets/store-B2Tjz47n.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-12Wi-JoZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C8FKHY0d.js", "/assets/arrow-right-BCa-2XcL.js"]
	},
	"/code": {
		filePath: "/workspace/src/routes/code.tsx",
		children: void 0,
		preloads: [
			"/assets/code-ZxhP2G60.js",
			"/assets/python-engine-RwDNKqIx.js",
			"/assets/trash-2-CcNlyCbD.js",
			"/assets/input-PVP-nrC-.js",
			"/assets/label-B-7Zo7Qr.js",
			"/assets/python-output-CjPsJy80.js"
		]
	},
	"/games": {
		filePath: "/workspace/src/routes/games.tsx",
		children: ["/games/$gameId"],
		preloads: ["/assets/games-C0pz3a4e.js", "/assets/game-ids-J_-u-KiM.js"]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: ["/learn/$topicId"],
		preloads: [
			"/assets/learn-DvccEEy2.js",
			"/assets/input-PVP-nrC-.js",
			"/assets/badge-BsyhKEVw.js"
		]
	},
	"/live": {
		filePath: "/workspace/src/routes/live.tsx",
		children: void 0,
		preloads: ["/assets/live-r8VxWLz5.js", "/assets/live-tutor-BtD0Z5Cd.js"]
	},
	"/live-tutor": {
		filePath: "/workspace/src/routes/live-tutor.tsx",
		children: void 0,
		preloads: ["/assets/live-tutor-3qeTOzIU.js", "/assets/live-tutor-BtD0Z5Cd.js"]
	},
	"/practice": {
		filePath: "/workspace/src/routes/practice.tsx",
		children: void 0,
		preloads: [
			"/assets/practice-CFg6b6DX.js",
			"/assets/code-block-BixUNpKq.js",
			"/assets/exercise-panel-BfES6IGA.js",
			"/assets/game-cards-iz0jwKvc.js",
			"/assets/typing-D0WepI2o.js"
		]
	},
	"/profile": {
		filePath: "/workspace/src/routes/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-CIiqCgOL.js",
			"/assets/input-PVP-nrC-.js",
			"/assets/label-B-7Zo7Qr.js"
		]
	},
	"/progress": {
		filePath: "/workspace/src/routes/progress.tsx",
		children: void 0,
		preloads: [
			"/assets/progress-CHT6fbEU.js",
			"/assets/projects-DE61N85B.js",
			"/assets/LineChart-DuFn2-wF.js"
		]
	},
	"/projects": {
		filePath: "/workspace/src/routes/projects.tsx",
		children: ["/projects/$projectId"],
		preloads: [
			"/assets/projects-5GtNyj6i.js",
			"/assets/badge-BsyhKEVw.js",
			"/assets/difficulty-badge-BMydJ0fm.js",
			"/assets/projects-DE61N85B.js"
		]
	},
	"/tutor": {
		filePath: "/workspace/src/routes/tutor.tsx",
		children: void 0,
		preloads: [
			"/assets/tutor-DnGuwNKU.js",
			"/assets/live-tutor-BtD0Z5Cd.js",
			"/assets/code-block-BixUNpKq.js",
			"/assets/python-engine-RwDNKqIx.js",
			"/assets/trash-2-CcNlyCbD.js"
		]
	},
	"/typing": {
		filePath: "/workspace/src/routes/typing.tsx",
		children: void 0,
		preloads: [
			"/assets/typing-0k6hX8IO.js",
			"/assets/typing-D0WepI2o.js",
			"/assets/LineChart-DuFn2-wF.js"
		]
	},
	"/games/$gameId": {
		filePath: "/workspace/src/routes/games.$gameId.tsx",
		children: void 0,
		preloads: [
			"/assets/games._gameId-DZeklRBk.js",
			"/assets/arrow-right-BCa-2XcL.js",
			"/assets/code-block-BixUNpKq.js",
			"/assets/difficulty-badge-BMydJ0fm.js",
			"/assets/game-cards-iz0jwKvc.js",
			"/assets/typing-D0WepI2o.js"
		]
	},
	"/learn/$topicId": {
		filePath: "/workspace/src/routes/learn.$topicId.tsx",
		children: void 0,
		preloads: [
			"/assets/learn._topicId-BsAWH_bR.js",
			"/assets/arrow-right-BCa-2XcL.js",
			"/assets/code-block-BixUNpKq.js",
			"/assets/exercise-panel-BfES6IGA.js"
		]
	},
	"/projects/$projectId": {
		filePath: "/workspace/src/routes/projects.$projectId.tsx",
		children: void 0,
		preloads: [
			"/assets/projects._projectId-DpZTCoJJ.js",
			"/assets/python-engine-RwDNKqIx.js",
			"/assets/python-output-CjPsJy80.js",
			"/assets/grade-DztbwbB9.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
