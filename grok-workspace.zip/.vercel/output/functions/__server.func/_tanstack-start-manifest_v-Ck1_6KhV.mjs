//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ck1_6KhV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/code",
			"/games",
			"/learn",
			"/practice",
			"/profile",
			"/progress",
			"/projects",
			"/tutor",
			"/typing"
		],
		preloads: [
			"/assets/index-DnlaAqD2.js",
			"/assets/utils-C7Ci00GQ.js",
			"/assets/react-dom-B5sF1NtH.js",
			"/assets/link-lkaQqbjR.js",
			"/assets/lazyRouteComponent-DUVZZdkL.js",
			"/assets/redirect-DfaQTnMO.js",
			"/assets/createLucideIcon-LYnstJpA.js",
			"/assets/dist-b6P-ca8E.js",
			"/assets/dist-vsNLnCjF.js",
			"/assets/dist-BtA1WQwp.js",
			"/assets/dist-BHo-5Xxz.js",
			"/assets/preload-helper-CFMDq2sH.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DnlaAqD2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D0cF23Nl.js",
			"/assets/arrow-right-wQiMNK4S.js",
			"/assets/mic-CazF-D49.js",
			"/assets/input-CVL_OxJ_.js",
			"/assets/card-CCpwD4vo.js",
			"/assets/daily-C6nrFHko.js"
		]
	},
	"/code": {
		filePath: "/workspace/src/routes/code.tsx",
		children: void 0,
		preloads: [
			"/assets/code-B3HBp5Mv.js",
			"/assets/python-output-CcAifjTi.js",
			"/assets/rotate-ccw-BSmc2Di0.js",
			"/assets/trash-2-B_HTc10u.js",
			"/assets/input-CVL_OxJ_.js",
			"/assets/label-9AHDBD_g.js"
		]
	},
	"/games": {
		filePath: "/workspace/src/routes/games.tsx",
		children: ["/games/$gameId"],
		preloads: [
			"/assets/games-DZEPf1M2.js",
			"/assets/lock-CatCb5Xk.js",
			"/assets/game-engine-8UtWSCwp.js",
			"/assets/games-DPGkbbRU.js",
			"/assets/typing-NiWYRW60.js"
		]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: ["/learn/$topicId"],
		preloads: [
			"/assets/learn-DcJY9h2K.js",
			"/assets/lock-CatCb5Xk.js",
			"/assets/input-CVL_OxJ_.js",
			"/assets/badge-CQU8ekSY.js"
		]
	},
	"/practice": {
		filePath: "/workspace/src/routes/practice.tsx",
		children: void 0,
		preloads: [
			"/assets/practice-D_rikegS.js",
			"/assets/game-challenges-zTWiMQeA.js",
			"/assets/check-OiBBuqMj.js",
			"/assets/typing-arena-Co_DDex3.js",
			"/assets/daily-C6nrFHko.js",
			"/assets/exercise-panel-DE05BQ-z.js"
		]
	},
	"/profile": {
		filePath: "/workspace/src/routes/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-DTvXkDYj.js",
			"/assets/input-CVL_OxJ_.js",
			"/assets/label-9AHDBD_g.js"
		]
	},
	"/progress": {
		filePath: "/workspace/src/routes/progress.tsx",
		children: void 0,
		preloads: [
			"/assets/progress-BhjjXn3x.js",
			"/assets/games-DPGkbbRU.js",
			"/assets/projects-DE61N85B.js",
			"/assets/LineChart-HUst1Jm9.js"
		]
	},
	"/projects": {
		filePath: "/workspace/src/routes/projects.tsx",
		children: ["/projects/$projectId"],
		preloads: [
			"/assets/projects-CaqV0HGk.js",
			"/assets/badge-CQU8ekSY.js",
			"/assets/difficulty-badge-hgCwXOA4.js",
			"/assets/projects-DE61N85B.js"
		]
	},
	"/tutor": {
		filePath: "/workspace/src/routes/tutor.tsx",
		children: ["/tutor/live"],
		preloads: [
			"/assets/tutor-By5UCzbY.js",
			"/assets/tutor-live-D8PQUqmN.js",
			"/assets/check-OiBBuqMj.js",
			"/assets/mic-CazF-D49.js",
			"/assets/trash-2-B_HTc10u.js"
		]
	},
	"/typing": {
		filePath: "/workspace/src/routes/typing.tsx",
		children: void 0,
		preloads: [
			"/assets/typing-BOtJ0w0l.js",
			"/assets/typing-arena-Co_DDex3.js",
			"/assets/typing-NiWYRW60.js",
			"/assets/card-CCpwD4vo.js",
			"/assets/LineChart-HUst1Jm9.js"
		]
	},
	"/games/$gameId": {
		filePath: "/workspace/src/routes/games.$gameId.tsx",
		children: void 0,
		preloads: [
			"/assets/games._gameId-CAc53HjL.js",
			"/assets/game-challenges-zTWiMQeA.js",
			"/assets/arrow-right-wQiMNK4S.js",
			"/assets/check-OiBBuqMj.js",
			"/assets/rotate-ccw-BSmc2Di0.js",
			"/assets/difficulty-badge-hgCwXOA4.js",
			"/assets/typing-arena-Co_DDex3.js"
		]
	},
	"/learn/$topicId": {
		filePath: "/workspace/src/routes/learn.$topicId.tsx",
		children: void 0,
		preloads: [
			"/assets/learn._topicId-BnFvwtJJ.js",
			"/assets/arrow-right-wQiMNK4S.js",
			"/assets/check-OiBBuqMj.js",
			"/assets/code-block-BxcYxquW.js",
			"/assets/python-output-CcAifjTi.js",
			"/assets/game-engine-8UtWSCwp.js",
			"/assets/exercise-panel-DE05BQ-z.js"
		]
	},
	"/projects/$projectId": {
		filePath: "/workspace/src/routes/projects.$projectId.tsx",
		children: void 0,
		preloads: [
			"/assets/projects._projectId-CDgGBXTP.js",
			"/assets/python-output-CcAifjTi.js",
			"/assets/grade-DtNCh4rt.js"
		]
	},
	"/tutor/live": {
		filePath: "/workspace/src/routes/tutor.live.tsx",
		children: void 0,
		preloads: ["/assets/tutor.live-DivU0qYI.js"]
	}
} });
//#endregion
export { tsrStartManifest };
