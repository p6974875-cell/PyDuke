var e=[{id:`fixer`,title:`Code Fixer`,blurb:`A short program is broken. Find the fault and make it run.`,topicHint:`Syntax and names`},{id:`predict`,title:`Predict the output`,blurb:`Read the program. Say what it prints before you run it.`,topicHint:`Mental execution`},{id:`ordering`,title:`Code ordering`,blurb:`The lines work — they are just in the wrong order.`,topicHint:`Control flow`},{id:`typing`,title:`Python typing sprint`,blurb:`Type the snippet exactly. Accuracy first, then speed.`,topicHint:`Syntax muscle memory`},{id:`debug`,title:`Debugging challenge`,blurb:`It runs, but the answer is wrong. Repair the logic.`,topicHint:`Logic bugs`},{id:`build`,title:`Build it`,blurb:`A goal, a blank editor. You write the program.`,topicHint:`From spec to code`},{id:`boss`,title:`Boss battle`,blurb:`Eight levels. Concepts stack. Three lives.`,topicHint:`Mixed mastery`}],t=[{id:`fx-1`,difficulty:`easy`,title:`Missing colon`,prompt:`This if-statement never even starts. Fix the syntax.`,starter:`n = 3
if n > 0
    print('yes')`,solution:`n = 3
if n > 0:
    print('yes')`,explanation:`Compound statements in Python end their header with a colon.`,checks:[{kind:`stdout`,expected:`yes`}]},{id:`fx-2`,difficulty:`easy`,title:`String concat`,prompt:`Python refuses to add a string to an int. Make it print 7.`,starter:`n = "3"
print(n + 4)`,solution:`n = "3"
print(int(n) + 4)`,explanation:`Convert the string to int before arithmetic. The other option is str(4), which would print 34.`,checks:[{kind:`stdout`,expected:`7`}]},{id:`fx-3`,difficulty:`medium`,title:`Tuple comma`,prompt:`This should be a one-element tuple with length 1. Right now it is an int.`,starter:`t = (5)
print(type(t).__name__)
print(len(t) if type(t) is tuple else 'not-tuple')`,solution:`t = (5,)
print(type(t).__name__)
print(len(t) if type(t) is tuple else 'not-tuple')`,explanation:`The comma constructs the tuple. Parentheses only group.`,checks:[{kind:`stdout`,expected:`tuple
1`}]},{id:`fx-4`,difficulty:`medium`,title:`Dict iteration`,prompt:`This loop was meant to print each value. It crashes or prints letters. Fix it so it prints 1 then 2.`,starter:`d = {'a': 1, 'b': 2}
for k, v in d:
    print(v)`,solution:`d = {'a': 1, 'b': 2}
for k, v in d.items():
    print(v)`,explanation:`A dict iterates keys. .items() yields (key, value) pairs you can unpack.`,checks:[{kind:`stdout`,expected:`1
2`}]},{id:`fx-5`,difficulty:`hard`,title:`Shared row`,prompt:`grid should be 2x2 zeros with only grid[0][0] = 1. It currently paints both rows. Fix construction.`,starter:`grid = [[0] * 2] * 2
grid[0][0] = 1
print(grid)`,solution:`grid = [[0] * 2 for _ in range(2)]
grid[0][0] = 1
print(grid)`,explanation:`Multiplying a list of lists reuses the inner list. A comprehension makes a fresh row each time.`,checks:[{kind:`stdout`,expected:`[[1, 0], [0, 0]]`}]},{id:`fx-6`,difficulty:`hard`,title:`Mutable default`,prompt:`Two independent calls should not share a list. Fix the default.`,starter:`def bag(item, items=[]):
    items.append(item)
    return items

print(bag('a'))
print(bag('b'))`,solution:`def bag(item, items=None):
    if items is None:
        items = []
    items.append(item)
    return items

print(bag('a'))
print(bag('b'))`,explanation:`Default values are evaluated once. None is safe; create the list in the body.`,checks:[{kind:`stdout`,expected:`['a']
['b']`}]}],n=[{id:`pr-1`,difficulty:`easy`,title:`Slice`,prompt:`What does this print?`,code:`print([10, 20, 30, 40][1:3])`,expected:`[20, 30]`,explanation:`Slices are half-open: start at 1, stop before 3.`},{id:`pr-2`,difficulty:`easy`,title:`Truth of empty`,prompt:`What does this print?`,code:`xs = []
if xs:
    print('yes')
else:
    print('no')`,expected:`no`,explanation:`An empty list is falsy, so the else branch runs.`},{id:`pr-3`,difficulty:`medium`,title:`Alias`,prompt:`What does this print?`,code:`a = [1]
b = a
b.append(2)
print(a)`,expected:`[1, 2]`,explanation:`b is another name for the same list. append mutates that object.`},{id:`pr-4`,difficulty:`medium`,title:`Remainder loop`,prompt:`What does this print?`,code:`out = []
for n in range(5):
    if n % 2 == 0:
        out.append(n)
print(out)`,expected:`[0, 2, 4]`,explanation:`range(5) is 0..4. Even numbers pass the filter, including 0.`},{id:`pr-5`,difficulty:`hard`,title:`Comprehension scope`,prompt:`What does this print?`,code:`x = 9
print([x for x in range(3)])
print(x)`,expected:`[0, 1, 2]
9`,explanation:`A comprehension has its own scope. The loop variable does not leak and does not overwrite the outer x.`},{id:`pr-6`,difficulty:`hard`,title:`Short-circuit`,prompt:`What does this print?`,code:`def boom():
    print('boom')
    return True

print(False and boom())`,expected:`False`,explanation:"`and` stops at the first falsy value. boom() is never called, so 'boom' is not printed."}],r=[{id:`or-1`,difficulty:`easy`,title:`Total`,prompt:`Arrange the lines so the program prints 6.`,lines:[`total = 0`,`for n in [1, 2, 3]:`,`    total += n`,`print(total)`],expected:`6`,explanation:`Initialise the accumulator, loop, then print once after the loop.`},{id:`or-2`,difficulty:`medium`,title:`Swap`,prompt:`Print 2 1 using an unpacking swap.`,lines:[`a = 1`,`b = 2`,`a, b = b, a`,`print(a, b)`],expected:`2 1`,explanation:`Bind both names first. Then unpack. Then print.`},{id:`or-3`,difficulty:`medium`,title:`Dict count`,prompt:`Count letters in abba and print the count of a.`,lines:[`text = 'abba'`,`counts = {}`,`for ch in text:`,`    counts[ch] = counts.get(ch, 0) + 1`,`print(counts['a'])`],expected:`2`,explanation:`Create the dict before the loop. Print after the loop.`},{id:`or-4`,difficulty:`hard`,title:`Function then call`,prompt:`Define then use is_even so it prints True.`,lines:[`def is_even(n):`,`    return n % 2 == 0`,`print(is_even(8))`],expected:`True`,explanation:`A function must be defined before the call that uses it in this simple script.`},{id:`or-5`,difficulty:`hard`,title:`File round trip`,prompt:`Write, then read, then print Ada.`,lines:[`with open('n.txt', 'w') as f:`,`    f.write('Ada')`,`with open('n.txt') as f:`,`    print(f.read())`],expected:`Ada`,explanation:`Write mode first, then a separate with-block to read.`}],i=[{id:`db-1`,difficulty:`easy`,title:`Off-by-one`,prompt:`This should print 1 2 3 4 5. It stops early.`,starter:`for i in range(1, 5):
    print(i, end=' ' if i < 4 else '')
`,solution:`for i in range(1, 6):
    print(i, end=' ' if i < 5 else '')
`,explanation:`range stop is exclusive. To include 5, stop at 6. The separator also needs to know the last number.`,checks:[{kind:`stdout`,expected:`1 2 3 4 5`}]},{id:`db-2`,difficulty:`medium`,title:`Wrong accumulator`,prompt:`Mean of [2, 4, 6] should print 4.0. It does not.`,starter:`xs = [2, 4, 6]
total = 1
for x in xs:
    total += x
print(total / len(xs))`,solution:`xs = [2, 4, 6]
total = 0
for x in xs:
    total += x
print(total / len(xs))`,explanation:`An accumulator for a sum starts at 0, not 1.`,checks:[{kind:`stdout`,expected:`4.0`}]},{id:`db-3`,difficulty:`medium`,title:`Inclusive filter`,prompt:`Print numbers in [3, 10, 15, 7] that are >= 10. Currently it uses >.`,starter:`for n in [3, 10, 15, 7]:
    if n > 10:
        print(n)`,solution:`for n in [3, 10, 15, 7]:
    if n >= 10:
        print(n)`,explanation:`The spec said at least 10, which includes 10. Use >=.`,checks:[{kind:`stdout`,expected:`10
15`}]},{id:`db-4`,difficulty:`hard`,title:`Shallow copy needed`,prompt:`Keep original as [1, 2] while extra becomes [1, 2, 3].`,starter:`original = [1, 2]
extra = original
extra.append(3)
print(original)
print(extra)`,solution:`original = [1, 2]
extra = original[:]
extra.append(3)
print(original)
print(extra)`,explanation:`Assignment aliases. A slice copy makes extra independent.`,checks:[{kind:`stdout`,expected:`[1, 2]
[1, 2, 3]`}]}],a=[{id:`bd-1`,difficulty:`easy`,title:`Teenager?`,prompt:`Set age = 15. Print 'teen' if 13 <= age <= 19, otherwise 'not'. Do not use input().`,starter:`age = 15
`,solution:`age = 15
if 13 <= age <= 19:
    print('teen')
else:
    print('not')`,explanation:`Chained comparison reads as a range check. 15 is inside 13–19.`,checks:[{kind:`stdout`,expected:`teen`}]},{id:`bd-2`,difficulty:`medium`,title:`Fizz-ish`,prompt:`For n in 1..6, print 'x' if n is divisible by 3, otherwise n. Each on its own line.`,starter:``,solution:`for n in range(1, 7):
    if n % 3 == 0:
        print('x')
    else:
        print(n)`,explanation:`Modulo tests divisibility. range(1, 7) covers 1 through 6.`,checks:[{kind:`stdout`,expected:`1
2
x
4
5
x`}]},{id:`bd-3`,difficulty:`medium`,title:`Word lengths`,prompt:`words = ['py', 'tutor', 'ok']. Print a dict of word -> length.`,starter:`words = ['py', 'tutor', 'ok']
`,solution:`words = ['py', 'tutor', 'ok']
print({w: len(w) for w in words})`,explanation:`A dict comprehension maps each word to len(w).`,checks:[{kind:`stdout`,expected:`{'py': 2, 'tutor': 5, 'ok': 2}`}]},{id:`bd-4`,difficulty:`hard`,title:`Palindrome check`,prompt:`Define pal(s) that returns True if s equals its reverse. Print pal('level') and pal('helix').`,starter:`def pal(s):
    ...
`,solution:`def pal(s):
    return s == s[::-1]

print(pal('level'))
print(pal('helix'))`,explanation:`s[::-1] is the reversed string. Equality is the palindrome test.`,checks:[{kind:`stdout`,expected:`True
False`}]}],o=[{id:`boss-1`,difficulty:`easy`,title:`Level 1 — Variables`,prompt:`Bind a = 2, b = 5. Print their product.`,starter:``,solution:`a = 2
b = 5
print(a * b)`,explanation:`Names bound, then an operator. Foundation.`,checks:[{kind:`stdout`,expected:`10`}]},{id:`boss-2`,difficulty:`easy`,title:`Level 2 — Conditions`,prompt:`n = 11. Print 'odd' or 'even'.`,starter:`n = 11
`,solution:`n = 11
print('even' if n % 2 == 0 else 'odd')`,explanation:`A conditional expression is a compact if/else that yields a value.`,checks:[{kind:`stdout`,expected:`odd`}]},{id:`boss-3`,difficulty:`medium`,title:`Level 3 — Loops`,prompt:`Print the sum of 1..10.`,starter:``,solution:`print(sum(range(1, 11)))`,explanation:`range(1, 11) is 1 through 10. sum walks it.`,checks:[{kind:`stdout`,expected:`55`}]},{id:`boss-4`,difficulty:`medium`,title:`Level 4 — Lists`,prompt:`xs = [5, 1, 5, 3, 5]. Print how many times 5 appears.`,starter:`xs = [5, 1, 5, 3, 5]
`,solution:`xs = [5, 1, 5, 3, 5]
print(xs.count(5))`,explanation:`list.count is the direct method. A loop would also work.`,checks:[{kind:`stdout`,expected:`3`}]},{id:`boss-5`,difficulty:`medium`,title:`Level 5 — Functions`,prompt:`Write twice(s) that returns s concatenated with itself. Print twice('go').`,starter:`def twice(s):
    ...
`,solution:`def twice(s):
    return s + s

print(twice('go'))`,explanation:`String addition concatenates. Return the result.`,checks:[{kind:`stdout`,expected:`gogo`}]},{id:`boss-6`,difficulty:`hard`,title:`Level 6 — Dictionaries`,prompt:`grades = {'A': 2, 'B': 1, 'C': 0}. Print the key with the highest value.`,starter:`grades = {'A': 2, 'B': 1, 'C': 0}
`,solution:`grades = {'A': 2, 'B': 1, 'C': 0}
print(max(grades, key=grades.get))`,explanation:`max on a dict walks keys. key=grades.get compares by value.`,checks:[{kind:`stdout`,expected:`A`}]},{id:`boss-7`,difficulty:`hard`,title:`Level 7 — Mixed`,prompt:`words = ['to', 'helix', 'py', 'tutor']. Print a sorted list of words longer than 2.`,starter:`words = ['to', 'helix', 'py', 'tutor']
`,solution:`words = ['to', 'helix', 'py', 'tutor']
print(sorted(w for w in words if len(w) > 2))`,explanation:`Filter with a generator expression, sort for a stable result.`,checks:[{kind:`stdout`,expected:`['helix', 'tutor']`}]},{id:`boss-8`,difficulty:`advanced`,title:`Level 8 — Mini-project`,prompt:`Implement a tiny inventory: start empty dict. add(name, n) increases count. Use it to add torch 1, rope 2, torch 1. Print the dict.`,starter:`inv = {}

def add(name, n):
    ...
`,solution:`inv = {}

def add(name, n):
    inv[name] = inv.get(name, 0) + n

add('torch', 1)
add('rope', 2)
add('torch', 1)
print(inv)`,explanation:`A dict as inventory. get + add is the merge. Two torch adds become 2.`,checks:[{kind:`stdout`,expected:`{'torch': 2, 'rope': 2}`}]}],s={fixer:t,"code-fixer":t,predict:n,"predict-output":n,ordering:r,"code-ordering":r,debug:i,"debugging-challenge":i,build:a,"build-it":a,boss:o,"boss-battle":o};export{n as a,e as i,t as n,s as r,i as t};