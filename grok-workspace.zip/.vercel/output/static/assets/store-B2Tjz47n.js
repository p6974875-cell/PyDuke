import{n as e,r as t,s as n,u as r}from"./utils-CbUJ5KFk.js";var i=r(n(),1),a=[{id:`intro`,number:1,title:`What Python is`,subtitle:`A language for getting work done`,blurb:`Why Python exists and how a program actually runs.`},{id:`variables`,number:2,title:`Variables & data types`,subtitle:`Names, values, types`,blurb:`How Python stores values and why types matter.`},{id:`comments`,number:3,title:`Comments`,subtitle:`Notes for humans`,blurb:`How to leave intent in the source without changing behaviour.`},{id:`io`,number:4,title:`Input & output`,subtitle:`print and input`,blurb:`Talking to the user through the terminal.`},{id:`conversion`,number:5,title:`Type conversion`,subtitle:`int, float, str, bool`,blurb:`Turning text into numbers and back, on purpose.`},{id:`operators`,number:6,title:`Operators`,subtitle:`Arithmetic, comparison, logic`,blurb:`The symbols that compute and compare.`},{id:`conditions`,number:7,title:`Conditions`,subtitle:`if, elif, else`,blurb:`Making decisions in code.`},{id:`loops`,number:8,title:`Loops`,subtitle:`for and while`,blurb:`Repeating work without repeating yourself.`},{id:`range`,number:9,title:`range()`,subtitle:`Counting without a list of numbers`,blurb:`How for-loops count, slice, and step.`},{id:`lists`,number:10,title:`Lists, deeper`,subtitle:`Mutability, copies, comprehensions`,blurb:`You already know lists. Now we go further.`},{id:`tuples`,number:11,title:`Tuples`,subtitle:`Immutable sequences`,blurb:`When a collection should not change.`},{id:`sets`,number:12,title:`Sets`,subtitle:`Unique unordered values`,blurb:`Membership and uniqueness as first-class ideas.`},{id:`dictionaries`,number:13,title:`Dictionaries`,subtitle:`Key and value maps`,blurb:`Look things up by name, not by position.`},{id:`strings`,number:14,title:`Strings`,subtitle:`Text as data`,blurb:`Slicing, methods, and formatting with intent.`},{id:`functions`,number:15,title:`Functions`,subtitle:`Named reusable work`,blurb:`Package behaviour so you can call it again.`},{id:`scope`,number:16,title:`Scope`,subtitle:`Where names live`,blurb:`Why a variable in a function is not the same as one outside.`},{id:`errors`,number:17,title:`Error handling`,subtitle:`try, except, raise`,blurb:`Expecting failure and recovering cleanly.`},{id:`modules`,number:18,title:`Modules`,subtitle:`import and __name__`,blurb:`Splitting programs into reusable files.`},{id:`files`,number:19,title:`File handling`,subtitle:`read, write, with`,blurb:`Persisting data beyond a single run.`},{id:`json`,number:20,title:`JSON`,subtitle:`Data as text`,blurb:`How Python dicts and lists travel as JSON.`},{id:`oop`,number:21,title:`Object-oriented Python`,subtitle:`classes and objects`,blurb:`Bundling data and behaviour together.`},{id:`stdlib`,number:22,title:`Standard library`,subtitle:`batteries included`,blurb:`Useful modules you already have.`},{id:`apis`,number:23,title:`Working with APIs`,subtitle:`HTTP and JSON`,blurb:`Talking to other programs over the network — conceptually, then in code.`},{id:`projects`,number:24,title:`Project craft`,subtitle:`Design before code`,blurb:`How to break a real program into pieces you can finish.`},{id:`advanced`,number:25,title:`Advanced Python`,subtitle:`generators, hints, decorators`,blurb:`The next layer once the core is solid.`}],o=Object.fromEntries(a.map(e=>[e.id,e])),s=[`variables`,`io`,`operators`,`conditions`,`loops`],c=`lists`,l=e=>{let t,n=new Set,r=(e,r)=>{let i=typeof e==`function`?e(t):e;if(!Object.is(i,t)){let e=t;t=r??(typeof i!=`object`||!i)?i:Object.assign({},t,i),n.forEach(n=>n(t,e))}},i=()=>t,a={setState:r,getState:i,getInitialState:()=>o,subscribe:e=>(n.add(e),()=>n.delete(e))},o=t=e(r,i,a);return a},u=(e=>e?l(e):l),d=e=>e;function f(e,t=d){let n=i.useSyncExternalStore(e.subscribe,i.useCallback(()=>t(e.getState()),[e,t]),i.useCallback(()=>t(e.getInitialState()),[e,t]));return i.useDebugValue(n),n}var p=e=>{let t=u(e),n=e=>f(t,e);return Object.assign(n,t),n},m=(e=>e?p(e):p);function h(e,t){let n;try{n=e()}catch{return}return{getItem:e=>{let r=e=>e===null?null:JSON.parse(e,t?.reviver),i=n.getItem(e)??null;return i instanceof Promise?i.then(r):r(i)},setItem:(e,r)=>n.setItem(e,JSON.stringify(r,t?.replacer)),removeItem:e=>n.removeItem(e)}}var g=e=>t=>{try{let n=e(t);return n instanceof Promise?n:{then(e){return g(e)(n)},catch(e){return this}}}catch(e){return{then(e){return this},catch(t){return g(t)(e)}}}},_=(e,t)=>(n,r,i)=>{let a={storage:h(()=>window.localStorage),partialize:e=>e,version:0,merge:(e,t)=>({...t,...e}),...t},o=!1,s=0,c=new Set,l=new Set,u=a.storage;if(!u)return e((...e)=>{console.warn(`[zustand persist middleware] Unable to update item '${a.name}', the given storage is currently unavailable.`),n(...e)},r,i);let d=()=>{let e=a.partialize({...r()});return u.setItem(a.name,{state:e,version:a.version})},f=i.setState;i.setState=(e,t)=>(f(e,t),d());let p=e((...e)=>(n(...e),d()),r,i);i.getInitialState=()=>p;let m,_=()=>{if(!u)return;let e=++s;o=!1,c.forEach(e=>e(r()??p));let t=a.onRehydrateStorage?.call(a,r()??p)||void 0;return g(u.getItem.bind(u))(a.name).then(e=>{if(e){if(typeof e.version==`number`&&e.version!==a.version){if(a.migrate){let t=a.migrate(e.state,e.version);return t instanceof Promise?t.then(e=>[!0,e]):[!0,t]}console.error(`State loaded from storage couldn't be migrated since no migrate function was provided`)}else return[!1,e.state]}return[!1,void 0]}).then(t=>{if(e!==s)return;let[i,o]=t;if(m=a.merge(o,r()??p),n(m,!0),i)return d()}).then(()=>{e===s&&(t?.(r(),void 0),m=r(),o=!0,l.forEach(e=>e(m)))}).catch(n=>{e===s&&t?.(void 0,n)})};return i.persist={setOptions:e=>{a={...a,...e},e.storage&&(u=e.storage)},clearStorage:()=>{++s,u?.removeItem(a.name)},getOptions:()=>a,rehydrate:()=>_(),hasHydrated:()=>o,onHydrate:e=>(c.add(e),()=>{c.delete(e)}),onFinishHydration:e=>(l.add(e),()=>{l.delete(e)})},a.skipHydration||_(),m||p},v={intro:{topicId:`intro`,revision:{heading:`Start here`,body:`Python is a programming language. You write source as text. The Python interpreter reads it, line by line, and carries out the instructions.`,code:`print("hello")`},concept:{heading:`Programs are instructions`,explanation:'A Python program is a sequence of statements. `print` is a built-in function: you call it with parentheses. The string "hello" is an argument. Python executes top to bottom unless a loop, a condition, or a function call sends it elsewhere.',definition:`Python is an interpreted language: source is executed by the CPython interpreter (or another implementation) rather than compiled to a native binary first.`,analogy:`A recipe is not dinner. The cook (the interpreter) reads each step and does it. If a step is misspelled, cooking stops there.`},examples:[{title:`A one-line program`,code:`print("PyDuke")`,why:`The interpreter evaluates the call and writes the text to standard output, then a newline.`},{title:`Two statements, in order`,code:`print(1)
print(2)`,why:`Order is the program. The second print runs only after the first finishes.`}],mistakes:[{wrong:`Print(hello)`,right:`print("hello")`,why:"Names are case-sensitive. `print` is lowercase. hello without quotes is a name, not text."}],think:{question:`What actually runs your .py file?`,answer:`The Python interpreter. It reads the source and executes statements in order.`},exercises:[{id:`intro-print`,title:`Say hello`,prompt:`Print exactly: hello python`,difficulty:`easy`,starter:``,solution:`print("hello python")`,explanation:`One print, one string, lowercase.`,checks:[{kind:`stdout`,expected:`hello python`}]},{id:`intro-two`,title:`Two lines`,prompt:`Print 1 then 2 on separate lines.`,difficulty:`easy`,starter:``,solution:`print(1)
print(2)`,explanation:`Two statements, two lines of output.`,checks:[{kind:`stdout`,expected:`1
2`}]}]},comments:{topicId:`comments`,revision:{heading:`Notes that Python ignores`,body:`A comment starts with #. Python does not execute it. Use comments for why, not for restating what the next line already says.`,code:`n = 3  # number of lives remaining`},concept:{heading:`Hash comments and docstrings`,explanation:"Everything after # on a line is a comment. A string sitting alone as the first statement in a module, class, or function is a docstring — documentation the interpreter stores on `__doc__`. Comments do not change runtime behaviour.",definition:`A comment is source text the tokenizer discards. A docstring is a string literal used as documentation.`,analogy:`Sticky notes on a recipe. The cook does not eat them. A docstring is the printed introduction at the top of the cookbook.`},examples:[{title:`A useful comment`,code:`timeout = 8  # seconds the sandbox waits before killing a loop
print(timeout)`,why:`The comment records the unit. The print still prints 8.`},{title:`A docstring`,code:`def twice(n):
    """Return n + n."""
    return n + n

print(twice(4))
print(twice.__doc__)`,why:`The docstring is stored on the function. The return is the behaviour.`}],mistakes:[{wrong:`// increment`,right:`# increment`,why:`Python does not use C-style // comments.`}],exercises:[{id:`com-1`,title:`Keep the print`,prompt:`Print ok. You may add a comment on the same line.`,difficulty:`easy`,starter:`# write below
`,solution:`print("ok")  # status`,explanation:`The comment is ignored. print still runs.`,checks:[{kind:`stdout`,expected:`ok`}]}]},conversion:{topicId:`conversion`,revision:{heading:`Types do not mix themselves`,body:`input() always returns a str. Arithmetic needs int or float. Convert on purpose with int(), float(), str(), bool().`,code:`n = int("7")
print(n + 1)`},concept:{heading:`Constructors as converters`,explanation:"`int(\"7\")` parses a digit string. `int(3.9)` truncates toward zero. `float(\"1.5\")` parses a decimal. `str(9)` produces '9'. `bool(0)` is False; any non-empty string is True — including `'0'`. Failed parses raise ValueError.",definition:`Type conversion (casting) constructs a new object of another type from an existing value.`,analogy:`Pouring water into a measuring cup labelled millilitres. The water is the same stuff; the reading is a different representation. Some pours do not fit — that is ValueError.`},examples:[{title:`String to int`,code:`print(int("12") + 3)`,why:`Without int, '12' + 3 is a TypeError. With int, you get 15.`},{title:`Truncation`,code:`print(int(3.9))
print(int(-1.2))`,why:`int on a float drops the fraction toward zero, not round().`}],mistakes:[{wrong:`int("3.2")`,right:`int(float("3.2"))`,why:`int() does not parse a decimal string. Go through float first.`}],exercises:[{id:`conv-1`,title:`Add one`,prompt:`text = "8". Print that value plus 1 as a number (9).`,difficulty:`easy`,starter:`text = "8"
`,solution:`text = "8"
print(int(text) + 1)`,explanation:`Convert, then add.`,checks:[{kind:`stdout`,expected:`9`}]},{id:`conv-2`,title:`From input`,prompt:`Read a number from input and print its square.`,difficulty:`medium`,starter:``,solution:`n = int(input())
print(n * n)`,explanation:`input is str. int it before multiplying.`,checks:[{kind:`stdout`,expected:`25`,stdin:`5
`},{kind:`stdout`,expected:`0`,stdin:`0
`}]}]},range:{topicId:`range`,revision:{heading:`Counting without a list`,body:`range(n) produces 0, 1, …, n-1. range(a, b) starts at a and stops before b. range(a, b, s) steps by s.`,code:`print(list(range(3)))
print(list(range(2, 6)))
print(list(range(5, 0, -1)))`},concept:{heading:`A lazy sequence of ints`,explanation:"range is not a list. It is an immutable sequence that yields ints on demand. `for i in range(n)` is the ordinary counted loop. The stop value is excluded — that is why range(3) is 0, 1, 2. A negative step walks backward. `list(range(...))` materialises the values when you need to print them.",definition:`range(start, stop, step) is an immutable sequence of integers from start toward stop, excluding stop, stepping by step.`,analogy:`A numbered ticket dispenser. It does not print every ticket in advance. It knows the next number when you ask.`},examples:[{title:`Counted loop`,code:`for i in range(3):
    print(i)`,why:`i takes 0, then 1, then 2. The body runs three times.`},{title:`Stride`,code:`print(list(range(0, 8, 2)))`,why:`Start 0, stop before 8, step 2 → 0, 2, 4, 6.`}],mistakes:[{wrong:`for i in range(1, 3):  # expecting 1,2,3`,right:`for i in range(1, 4):`,why:`Stop is exclusive. To include 3, stop at 4.`}],exercises:[{id:`range-1`,title:`0 to 4`,prompt:`Print the numbers 0 through 4, each on its own line, using range.`,difficulty:`easy`,starter:``,solution:`for i in range(5):
    print(i)`,explanation:`range(5) is 0..4.`,checks:[{kind:`stdout`,expected:`0
1
2
3
4`}]},{id:`range-2`,title:`Odds`,prompt:`Print a list of odd numbers from 1 through 7 using range.`,difficulty:`medium`,starter:``,solution:`print(list(range(1, 8, 2)))`,explanation:`Start 1, stop 8, step 2.`,checks:[{kind:`stdout`,expected:`[1, 3, 5, 7]`}]}]},json:{topicId:`json`,revision:{heading:`Dicts that can travel`,body:`JSON is a text format: objects, arrays, strings, numbers, true/false/null. Python's json module dumps dicts/lists to that text and loads them back.`,code:`import json
print(json.dumps({"n": 3}))
print(json.loads('{"n": 3}'))`},concept:{heading:`dumps and loads`,explanation:"`json.dumps(obj)` serialises a Python object to a JSON string. `json.loads(text)` parses a JSON string to Python. Mapping: dict↔object, list↔array, str↔string, int/float↔number, True/False↔true/false, None↔null. Tuples dump as arrays. Keys in JSON objects are always strings.",definition:`JSON (JavaScript Object Notation) is a language-independent text encoding of nested maps and lists. dumps writes it; loads reads it.`,analogy:`Packing a suitcase (dumps) and unpacking it at the other end (loads). The clothes are your dict. The suitcase is the string you can email.`},examples:[{title:`Round trip`,code:`import json
data = {"ok": True, "n": 2}
text = json.dumps(data)
print(text)
print(json.loads(text)["n"])`,why:`dumps produces text. loads rebuilds a dict. True becomes JSON true.`}],mistakes:[{wrong:`json.dumps({1: 'a'})  # non-string key`,right:`json.dumps({"1": "a"})`,why:`JSON object keys must be strings. dumps will coerce int keys to strings, which surprises lookups later.`}],exercises:[{id:`json-1`,title:`Dump a dict`,prompt:`Dump {"a": 1} with json.dumps and print the result.`,difficulty:`easy`,starter:`import json
`,solution:`import json
print(json.dumps({"a": 1}))`,explanation:`dumps returns a string. print it.`,checks:[{kind:`stdout`,expected:`{"a": 1}`}]},{id:`json-2`,title:`Read a field`,prompt:`Load '{"x": 9}' and print the x value.`,difficulty:`medium`,starter:`import json
`,solution:`import json
print(json.loads('{"x": 9}')['x'])`,explanation:`loads returns a dict. Index with 'x'.`,checks:[{kind:`stdout`,expected:`9`}]}]},variables:{topicId:`variables`,revision:{heading:`You already use this`,body:`A variable is a name bound to a value. Python figures out the type from the value, not from a declaration.`,code:`name = "Ada"
age = 36
pi = 3.14
ready = True`},concept:{heading:`Names, objects, types`,explanation:"In Python the name and the object are separate. The assignment `x = 3` means: create the integer object 3, then bind the name x to it. Reassigning `x = 'hi'` does not change 3 — it points the name at a new object. Types (`int`, `float`, `str`, `bool`, `NoneType`) describe the object, not the name.",definition:`A variable is a name bound to an object. A data type is the class of that object, which determines the operations it supports.`,analogy:`A variable is a luggage tag. The suitcase can be swapped; the tag stays. The type is the kind of suitcase — you cannot pour tea into a guitar case and expect it to work.`},examples:[{title:`Inspecting a type`,code:`x = 10
print(type(x))
x = x / 2
print(x, type(x))`,why:"Integer division with `/` always produces a float in Python 3. The name `x` now refers to a different object with a different type."},{title:`Multiple names, one object`,code:`a = [1, 2]
b = a
b.append(3)
print(a)`,why:"Assignment copies the reference, not the list. Both names point at the same mutable object, so mutating through `b` is visible through `a`."}],mistakes:[{wrong:`int x = 5`,right:`x = 5`,why:`Python does not declare types next to the name. You bind a name to a value.`},{wrong:`age = "21" + 1`,right:`age = int("21") + 1`,why:`You cannot add a string to an integer. Convert first.`}],exercises:[{id:`var-mini`,title:`Swap with a temp`,prompt:`Bind a to 3 and b to 7, swap their values using a temporary name, then print a and b on one line separated by a space.`,difficulty:`easy`,starter:`a = 3
b = 7
# swap, then print`,solution:`a = 3
b = 7
temp = a
a = b
b = temp
print(a, b)`,explanation:"A temporary name holds one value while the other overwrites it. Python also allows `a, b = b, a`, which unpacks a tuple.",checks:[{kind:`stdout`,expected:`7 3`}]}]},io:{topicId:`io`,revision:{heading:`Talking to the terminal`,body:"`print` writes to standard output. `input` reads a line from standard input and always returns a string.",code:`print("Hello")
# name = input("Name: ")`},concept:{heading:`Streams, not magic`,explanation:"Programs communicate through streams. Standard output is where `print` writes. Standard input is where `input` reads. Because `input` returns a `str`, numeric work needs `int(...)` or `float(...)`.",definition:"Standard input/output are character streams attached to the process. `print(*objects, sep=' ', end='\\n')` writes them; `input(prompt)` reads one line.",analogy:`Print is speaking. Input is listening. People always answer in words — you convert words into numbers when you need arithmetic.`},examples:[{title:`sep and end`,code:`print("A", "B", sep="-", end="!")
print("done")`,why:"`sep` sits between arguments. `end` replaces the default newline, so the next print continues on the same visual line only if you want it to — here `end='!'` still needs a later newline from the next print."}],mistakes:[{wrong:`n = input("n: ")
print(n + 1)`,right:`n = int(input("n: "))
print(n + 1)`,why:"`input` returns a string. Adding 1 requires an integer."}],exercises:[{id:`io-mini`,title:`Formatted line`,prompt:`Print exactly: PyDuke · Python  (middle dot with spaces, using sep)`,difficulty:`easy`,starter:`# use print with sep`,solution:`print("PyDuke", "Python", sep=" · ")`,explanation:`sep is inserted between arguments, so one print builds the whole line.`,checks:[{kind:`stdout`,expected:`PyDuke · Python`}]}]},operators:{topicId:`operators`,revision:{heading:`Arithmetic you already know`,body:"`+ - * / // % **` plus comparisons and `and` / `or` / `not`. `/` is true division. `//` is floor division.",code:`print(7 / 2)
print(7 // 2)
print(7 % 2)
print(2 ** 3)`},concept:{heading:`Operators are functions in disguise`,explanation:"An operator is syntax for a function on one or two operands. Comparison operators return booleans. Logical operators short-circuit: `and` stops at the first falsy value, `or` at the first truthy one. Chained comparisons like `1 < x < 5` mean `1 < x and x < 5`.",definition:"An operator is a token that applies an operation to operands. Floor division `//` returns the greatest integer less than or equal to the algebraic quotient.",analogy:`A calculator key is an operator. Floor division is 'how many whole boxes fit', modulo is 'what is left over'.`},examples:[{title:`Even test`,code:`n = 8
print(n % 2 == 0)`,why:"A number is even when dividing by 2 leaves remainder 0. `%` gives the remainder."}],mistakes:[{wrong:`if x = 3:`,right:`if x == 3:`,why:"`=` binds a name. `==` compares values."}],exercises:[{id:`op-mini`,title:`Remainder`,prompt:`Print the remainder of 29 divided by 5.`,difficulty:`easy`,starter:``,solution:`print(29 % 5)`,explanation:`29 = 5*5 + 4, so the remainder is 4.`,checks:[{kind:`stdout`,expected:`4`}]}]},conditions:{topicId:`conditions`,revision:{heading:`Branching`,body:"`if` / `elif` / `else` pick one path. The condition is any object; Python uses its truth value.",code:`n = 4
if n > 5:
    print('big')
elif n > 0:
    print('small')
else:
    print('no')`},concept:{heading:`Truthiness`,explanation:"A condition is converted with `bool()`. Empty containers, `0`, `0.0`, `''`, and `None` are falsy. Almost everything else is truthy. Only one branch runs. Indentation is the block — there are no braces.",definition:`A conditional statement evaluates a boolean expression and executes a suite of statements only when the expression is true.`,analogy:`A fork in a path. You take one road. Python does not walk both and merge later unless you write two separate ifs.`},examples:[{title:`Membership in a condition`,code:`role = 'admin'
if role in ('admin', 'editor'):
    print('allowed')
else:
    print('denied')`,why:"`in` on a tuple is a clean way to spell 'one of these'. It reads like English and avoids a chain of `or`s."}],mistakes:[{wrong:`if n > 0 and < 10:`,right:`if n > 0 and n < 10:`,why:"Each comparison needs two operands. Or write `0 < n < 10`."}],exercises:[{id:`cond-mini`,title:`Sign`,prompt:`Set n = -2. Print 'neg', 'zero', or 'pos' depending on the sign.`,difficulty:`easy`,starter:`n = -2
`,solution:`n = -2
if n < 0:
    print('neg')
elif n == 0:
    print('zero')
else:
    print('pos')`,explanation:`Order matters. Check negative first, then zero; the rest is positive.`,checks:[{kind:`stdout`,expected:`neg`}]}]},loops:{topicId:`loops`,revision:{heading:`Repeating work`,body:"`for item in iterable` walks a collection. `while condition` repeats until the condition is false. `range(n)` yields 0 .. n-1.",code:`for i in range(3):
    print(i)
`},concept:{heading:`Iteration is a protocol`,explanation:"A for-loop calls `iter()` on the object, then `next()` until `StopIteration`. That is why lists, strings, dicts, and files all loop. A while-loop is lower level: you own the condition and must make it false or `break`, or it never ends.",definition:`A loop repeatedly executes a suite. A for-loop iterates an iterable. A while-loop continues while its condition is true.`,analogy:`For is walking every book on a shelf. While is 'keep walking until the street name changes' — you must notice the street.`},examples:[{title:`Accumulator`,code:`total = 0
for n in [3, 5, 7]:
    total += n
print(total)`,why:"An accumulator starts at a zero-like value and is updated each pass. This is the pattern behind `sum`."}],mistakes:[{wrong:`for i in 5:`,right:`for i in range(5):`,why:"An integer is not iterable. `range` is."}],exercises:[{id:`loop-mini`,title:`Squares`,prompt:`Print the squares of 1 through 4, each on its own line.`,difficulty:`easy`,starter:``,solution:`for n in range(1, 5):
    print(n * n)`,explanation:`range(1, 5) is 1,2,3,4. Multiply a number by itself for its square.`,checks:[{kind:`stdout`,expected:`1
4
9
16`}]}]},lists:{topicId:`lists`,revision:{heading:`You already know lists`,body:"A list is an ordered, mutable sequence. You index with `[0]`, slice with `[1:3]`, and change it in place with methods like `append`, `pop`, `insert`, and `sort`. We will not reteach that. We will look at the traps that show up once lists feel easy: shared references, copying, nested lists, and comprehensions.",code:`nums = [10, 20, 30]
print(nums[0], nums[-1])
print(nums[1:])
nums.append(40)`},concept:{heading:`Lists as objects, not boxes of copies`,explanation:"A list object holds references to other objects. `b = a` does not copy the list — it makes a second name for the same object. `a[:]` or `list(a)` copies the outer list (a shallow copy): new list, same inner objects. Nested lists need `copy.deepcopy` if you want a fully independent tree. A list comprehension `[expr for x in iterable if cond]` builds a new list by evaluating `expr` for each passing item. It is a loop compressed into an expression, not a different language.",definition:"A list is a mutable sequence. Indexing and slicing return items or a new list. Methods that mutate do so in place and often return None (for example `sort`). A shallow copy duplicates the container, not the contained objects.",analogy:`A playlist is a list of pointers to songs. Duplicating the playlist is not the same as duplicating every song file. Two playlists can still point at the same track — edit the track, both hear it.`},examples:[{title:`The alias trap`,code:`a = [1, 2, 3]
b = a
c = a[:]
b.append(4)
print('a', a)
print('c', c)`,why:"`b` is another name for `a`'s list, so `append` is visible through `a`. `c` is a new list built from a slice, so it stays `[1, 2, 3]`."},{title:`Comprehension vs loop`,code:`words = ['py', 'helix', 'list']
lengths = [len(w) for w in words if len(w) > 2]
print(lengths)`,why:"Each `w` is tested by the `if`. Surviving items are transformed by `len(w)`. The result is a new list; `words` is untouched."},{title:`Nested lists and rows`,code:`grid = [[0] * 3 for _ in range(2)]
grid[0][1] = 9
print(grid)`,why:"`[[0] * 3] * 2` would reuse the same inner list twice. The comprehension creates a fresh inner list per row, so assigning `grid[0][1]` does not change row 1."}],mistakes:[{wrong:`result = nums.append(5)
print(result)`,right:`nums.append(5)
print(nums)`,why:"`append` mutates and returns None. Capturing the return value is a classic silent bug."},{wrong:`row = [0] * 3
grid = [row] * 3`,right:`grid = [[0] * 3 for _ in range(3)]`,why:`Multiplying a list of lists reuses one row object. Every 'row' is the same list.`},{wrong:`for x in nums:
    if x % 2:
        nums.remove(x)`,right:`nums = [x for x in nums if x % 2 == 0]`,why:`Mutating a list while iterating it skips items. Build a new list instead.`}],think:{question:"After `a = [1, [2]]; b = a[:]; b[1].append(3)` what is `a`?",answer:"`[1, [2, 3]]`. The slice copied the outer list, but the inner list is shared. Mutating that inner list is visible through `a`."},exercises:[{id:`lists-mini`,title:`Evens only`,prompt:`Start with nums = [3, 4, 8, 9, 12, 15]. Build a new list of the even numbers using a comprehension and print it.`,difficulty:`easy`,starter:`nums = [3, 4, 8, 9, 12, 15]
`,solution:`nums = [3, 4, 8, 9, 12, 15]
print([n for n in nums if n % 2 == 0])`,hint:`n % 2 == 0 is the even test.`,explanation:"The comprehension filters with `if` and keeps the original values. It does not mutate `nums`.",checks:[{kind:`stdout`,expected:`[4, 8, 12]`}]},{id:`lists-practical`,title:`Safe copy then edit`,prompt:`Let source = ['a', 'b', 'c']. Make dest a shallow copy. Append 'd' to dest only. Print source, then dest, each on its own line.`,difficulty:`medium`,starter:`source = ['a', 'b', 'c']
`,solution:`source = ['a', 'b', 'c']
dest = source[:]
dest.append('d')
print(source)
print(dest)`,hint:`Slice the whole list, or use list(source).`,explanation:`A shallow copy is enough here because the items are immutable strings. Appending to dest leaves source alone.`,checks:[{kind:`stdout`,expected:`['a', 'b', 'c']
['a', 'b', 'c', 'd']`}]},{id:`lists-hard`,title:`Flatten one level`,prompt:`nested = [[1, 2], [3], [4, 5, 6]]. Print a single list of all numbers in order, using a nested comprehension.`,difficulty:`hard`,starter:`nested = [[1, 2], [3], [4, 5, 6]]
`,solution:`nested = [[1, 2], [3], [4, 5, 6]]
print([n for row in nested for n in row])`,optional:!0,hint:`for row in nested, for n in row.`,explanation:"A nested comprehension reads left-to-right like nested loops: outer `row`, inner `n`. The expression `n` is what gets collected.",checks:[{kind:`stdout`,expected:`[1, 2, 3, 4, 5, 6]`}]}]},tuples:{topicId:`tuples`,revision:{heading:`From lists to records`,body:`Lists are for collections that grow and change. Tuples are for fixed records: a point, a pair, a row of a table. You already loop and index sequences. Tuples use the same sequence protocol — they just refuse mutation.`,code:`point = (3, 4)
print(point[0], len(point))`},concept:{heading:`Immutability as a design choice`,explanation:"A tuple is an immutable sequence. After you create it, you cannot append, pop, or assign to an index. Parentheses often create tuples, but the comma is the real constructor: `t = 1, 2`. A one-element tuple needs a trailing comma: `(1,)` not `(1)`. Immutability means the tuple's slots cannot be rebound. If a slot holds a list, that list can still mutate — the tuple only protects the binding. Tuples can be dictionary keys (when their items are hashable). Unpacking `x, y = point` is the everyday superpower.",definition:`A tuple is an immutable ordered sequence. It supports indexing, slicing, iteration, and unpacking, but not item assignment or in-place methods.`,analogy:`A list is a whiteboard. A tuple is a printed label on a jar: ingredients, amount, date. You do not scribble extra ingredients on the label; you print a new one.`},examples:[{title:`Packing and unpacking`,code:`person = ('Ada', 36, 'math')
name, age, field = person
print(name)
print(age)`,why:"The tuple is a record. Unpacking names each field for the rest of the code, which is clearer than `person[0]`."},{title:`Single-element and empty`,code:`one = (42,)
empty = ()
not_a_tuple = (42)
print(type(one), type(not_a_tuple), len(empty))`,why:"Parentheses alone group expressions. The comma makes a tuple. `(42)` is just the integer 42."},{title:`Returning two values`,code:`def minmax(xs):
    return min(xs), max(xs)

lo, hi = minmax([3, 9, 1])
print(lo, hi)`,why:`A function can return only one object. Returning two names really returns one tuple, which the caller unpacks.`}],mistakes:[{wrong:`t = (1, 2, 3)
t[0] = 9`,right:`t = (9,) + t[1:]`,why:`You cannot assign to a tuple index. You build a new tuple from pieces.`},{wrong:`singleton = (5)`,right:`singleton = (5,)`,why:"Without the comma, the parentheses do nothing. `type((5))` is `int`."}],think:{question:"Why can `(1, 2)` be a dict key but `[1, 2]` cannot?",answer:`Keys must be hashable. Immutability of the tuple (and its items) makes its hash stable. A list could change, which would break the dict's lookup structure.`},exercises:[{id:`tup-mini`,title:`Swap the Python way`,prompt:`a is 1 and b is 2. Swap them using tuple unpacking and print a then b on one line.`,difficulty:`easy`,starter:`a = 1
b = 2
`,solution:`a = 1
b = 2
a, b = b, a
print(a, b)`,explanation:`The right-hand side is packed into a tuple first, then unpacked into the left-hand names. No temporary is needed.`,checks:[{kind:`stdout`,expected:`2 1`}]},{id:`tup-practical`,title:`First and rest`,prompt:`data = ('ok', 200, 'saved'). Unpack into status, code, and extra. Print status and code separated by a colon and a space, like ok: 200`,difficulty:`medium`,starter:`data = ('ok', 200, 'saved')
`,solution:`data = ('ok', 200, 'saved')
status, code, extra = data
print(f'{status}: {code}')`,hint:`Three names on the left, or status, code, _ = data if you will not use extra.`,explanation:`Unpacking documents the record shape. An f-string then formats the two fields you care about.`,checks:[{kind:`stdout`,expected:`ok: 200`}]},{id:`tup-hard`,title:`Hashable pair`,prompt:`Build a dict whose keys are tuples (name, year) and values are scores. Insert ('Ada', 2026) -> 98 and ('Lin', 2026) -> 91. Print the value for ('Ada', 2026).`,difficulty:`hard`,starter:`scores = {}
`,solution:`scores = {}
scores[('Ada', 2026)] = 98
scores[('Lin', 2026)] = 91
print(scores[('Ada', 2026)])`,optional:!0,explanation:`A tuple of strings and ints is hashable, so it can key a dict. This is how you store a composite lookup.`,checks:[{kind:`stdout`,expected:`98`}]}]},sets:{topicId:`sets`,revision:{heading:`Uniqueness as a data structure`,body:"Lists remember order and duplicates. When you only care whether something is in the collection, a set is the right tool. You already use `in` on lists — on a set it is the main operation, and it is fast.",code:`seen = {1, 2, 2, 3}
print(seen)`},concept:{heading:`Sets are bags of unique hashable items`,explanation:"A set is an unordered collection of unique, hashable objects. Duplicates collapse. There is no index — `{1, 2}[0]` is an error. What you get instead are set operations: union `|`, intersection `&`, difference `-`, symmetric difference `^`. `add` and `discard` mutate. A set comprehension `{x for x in xs}` is the usual way to build one. `frozenset` is the immutable variant, usable as a dict key.",definition:`A set is an unordered collection of distinct hashable elements supporting membership tests and algebraic set operations.`,analogy:`A guest list where each person appears once. You can ask 'is Sam here?' instantly. You cannot ask for 'the third guest' because there is no line — only presence.`},examples:[{title:`Deduplicate, lose order`,code:`names = ['ada', 'lin', 'ada', 'moe']
print(sorted(set(names)))`,why:"`set(names)` drops duplicates. `sorted` turns the unordered set back into a stable list for display."},{title:`Set algebra`,code:`python = {'ada', 'lin', 'moe'}
js = {'lin', 'kai'}
print(sorted(python & js))
print(sorted(python - js))`,why:`Intersection is people in both. Difference is people in Python but not JS. Sorting makes the output deterministic.`}],mistakes:[{wrong:`empty = {}`,right:`empty = set()`,why:"`{}` is an empty dict. The empty set is `set()`."},{wrong:`s = {1, 2}
print(s[0])`,right:`s = {1, 2}
print(1 in s)`,why:`Sets are not sequences. Membership replaces indexing.`}],exercises:[{id:`set-mini`,title:`Unique letters`,prompt:`s = "balloon". Print the number of unique letters.`,difficulty:`easy`,starter:`s = "balloon"
`,solution:`s = "balloon"
print(len(set(s)))`,explanation:`A set of characters collapses repeats. Length is the unique count. 'balloon' has a, b, l, n, o → 5.`,checks:[{kind:`stdout`,expected:`5`}]},{id:`set-practical`,title:`Shared skills`,prompt:`a = {'python', 'git', 'sql'} and b = {'python', 'html', 'git'}. Print a sorted list of skills they share.`,difficulty:`medium`,starter:`a = {'python', 'git', 'sql'}
b = {'python', 'html', 'git'}
`,solution:`a = {'python', 'git', 'sql'}
b = {'python', 'html', 'git'}
print(sorted(a & b))`,explanation:"Intersection `&` is the shared set. `sorted` gives a list Python will print the same way every time.",checks:[{kind:`stdout`,expected:`['git', 'python']`}]},{id:`set-hard`,title:`Only in the left`,prompt:`Print a sorted list of items in [1, 2, 3, 3, 4] that are not in [3, 5].`,difficulty:`hard`,starter:`left = [1, 2, 3, 3, 4]
right = [3, 5]
`,solution:`left = [1, 2, 3, 3, 4]
right = [3, 5]
print(sorted(set(left) - set(right)))`,optional:!0,explanation:`Convert both to sets, then difference. Sorting for a stable print.`,checks:[{kind:`stdout`,expected:`[1, 2, 4]`}]}]},dictionaries:{topicId:`dictionaries`,revision:{heading:`Lookup by name`,body:`A list answers 'what is at position 3?'. A dictionary answers 'what is the score for Ada?'. Keys must be hashable. Values can be anything.`,code:`user = {'name': 'Ada', 'year': 2026}
print(user['name'])`},concept:{heading:`Mappings, not sequences`,explanation:"A dict maps keys to values. You insert and fetch with `d[key]`. Missing keys raise `KeyError` — use `d.get(key, default)` when absence is normal. Iteration walks keys by default; `.values()` and `.items()` give the rest. Since Python 3.7, insertion order is preserved, but a dict is still a mapping, not a list. Dict comprehensions `{k: v for ...}` build new mappings. Nesting dicts is how JSON-shaped data lives in Python.",definition:`A dictionary is a mutable mapping from hashable keys to values, providing average-case constant-time lookup.`,analogy:`A dictionary is a labelled filing cabinet. You do not count drawers from the left; you ask for the folder named 'Ada'.`},examples:[{title:`get versus index`,code:`scores = {'Ada': 98}
print(scores.get('Lin', 0))
print('Ada' in scores)`,why:"`get` returns the default instead of crashing. `in` on a dict checks keys, not values."},{title:`items and a running total`,code:`cart = {'pen': 2, 'book': 5}
total = 0
for item, price in cart.items():
    total += price
print(total)`,why:"`.items()` unpacks each pair. This is the standard loop over a mapping."},{title:`Comprehension`,code:`names = ['Ada', 'Lin']
print({n: len(n) for n in names})`,why:`Each name becomes a key; the value is derived. This is how you project a list into a lookup table.`}],mistakes:[{wrong:`for k, v in scores:`,right:`for k, v in scores.items():`,why:`Iterating a dict yields keys only. Unpacking a string key into k, v is not what you wanted.`},{wrong:`d = {[1, 2]: 'ok'}`,right:`d = {(1, 2): 'ok'}`,why:`Lists are unhashable. Use a tuple for a composite key.`}],exercises:[{id:`dict-mini`,title:`Safe lookup`,prompt:`ages = {'Ada': 36, 'Lin': 29}. Print ages.get('Moe', 'unknown').`,difficulty:`easy`,starter:`ages = {'Ada': 36, 'Lin': 29}
`,solution:`ages = {'Ada': 36, 'Lin': 29}
print(ages.get('Moe', 'unknown'))`,explanation:`Moe is missing, so get returns the default instead of raising.`,checks:[{kind:`stdout`,expected:`unknown`}]},{id:`dict-practical`,title:`Count letters`,prompt:`Count characters in "ababa" using a dict. Print the count for "a".`,difficulty:`medium`,starter:`text = "ababa"
counts = {}
`,solution:`text = "ababa"
counts = {}
for ch in text:
    counts[ch] = counts.get(ch, 0) + 1
print(counts["a"])`,hint:`get(ch, 0) + 1 is the usual increment.`,explanation:`This is a frequency map. Each character is a key; the value is how often it appeared.`,checks:[{kind:`stdout`,expected:`3`}]},{id:`dict-hard`,title:`Invert`,prompt:`Given {'Ada': 'math', 'Lin': 'physics'}, print a new dict mapping field to name.`,difficulty:`hard`,starter:`fields = {'Ada': 'math', 'Lin': 'physics'}
`,solution:`fields = {'Ada': 'math', 'Lin': 'physics'}
print({v: k for k, v in fields.items()})`,optional:!0,explanation:`A dict comprehension swapping k and v inverts a one-to-one mapping.`,checks:[{kind:`stdout`,expected:`{'math': 'Ada', 'physics': 'Lin'}`}]}]},strings:{topicId:`strings`,revision:{heading:`Text is a sequence`,body:`Strings are immutable sequences of characters. You can index and slice them like lists, but you cannot assign to an index. Methods return new strings.`,code:`s = "Helix"
print(s[0], s[-1], s[1:4])`},concept:{heading:`Methods, splits, and f-strings`,explanation:"Because strings are immutable, `s.upper()` returns a new string; `s` is unchanged unless you rebind. `split` turns text into a list; `join` goes the other way — and `join` is called on the separator: `' '.join(words)`. `strip` removes surrounding whitespace. f-strings (`f'{name} is {age}'`) interpolate expressions. Prefer them over `+` chains. `in` tests substrings. `find` / `replace` cover search and substitute.",definition:`A string is an immutable sequence of Unicode characters. String methods return new strings; they do not mutate in place.`,analogy:"A string is a printed sentence. You can copy it in capitals, but the original page does not change. `split` cuts the sentence into word cards; `join` tapes them back with a chosen glue."},examples:[{title:`split and join`,code:`line = "ada,lin,moe"
names = line.split(",")
print(" | ".join(names))`,why:`split takes a separator and returns a list. join is a method of the glue string, not of the list.`},{title:`f-string with an expression`,code:`n = 7
print(f'{n} squared is {n * n}')`,why:`The braces hold any expression, not just a variable. Formatting happens at runtime.`}],mistakes:[{wrong:`s = "abc"
s[0] = "A"`,right:`s = "A" + s[1:]`,why:`Strings do not support item assignment. Build a new string.`},{wrong:`words.join(",")`,right:`"," .join(words)`,why:`join lives on the separator string.`}],exercises:[{id:`str-mini`,title:`Title case words`,prompt:`text = "pyduke python tutor". Print it with each word capitalised (str.title).`,difficulty:`easy`,starter:`text = "pyduke python tutor"
`,solution:`text = "pyduke python tutor"
print(text.title())`,explanation:"`title` capitalises the first character of each word.",checks:[{kind:`stdout`,expected:`Pyduke Python Tutor`}]},{id:`str-practical`,title:`CSV names`,prompt:`raw = " ada, lin, moe ". Split on commas, strip each name, and print the cleaned list.`,difficulty:`medium`,starter:`raw = " ada, lin, moe "
`,solution:`raw = " ada, lin, moe "
print([part.strip() for part in raw.split(",")])`,explanation:`split gives pieces that still have spaces. strip on each piece is the usual cleanup.`,checks:[{kind:`stdout`,expected:`['ada', 'lin', 'moe']`}]},{id:`str-hard`,title:`Initials`,prompt:`name = "Ada Lovelace". Print initials joined by dots, like A.L.`,difficulty:`hard`,starter:`name = "Ada Lovelace"
`,solution:`name = "Ada Lovelace"
parts = name.split()
print(".".join(p[0] for p in parts) + ".")`,optional:!0,explanation:`Split into words, take the first character of each, join with dots, and add a trailing dot.`,checks:[{kind:`stdout`,expected:`A.L.`}]}]},functions:{topicId:`functions`,revision:{heading:`Name the work`,body:"A function packages a suite of statements under a name. You call it with arguments. `return` hands a value back; without it the function returns None.",code:`def double(n):
    return n * 2

print(double(5))`},concept:{heading:`Parameters, arguments, return`,explanation:"Parameters are the names in the definition. Arguments are the values you pass at the call. Defaults (`def greet(name, punct='!')`) fill in missing arguments. A function should do one job. Return a value instead of printing when the caller might want to use the result. `*args` collects extra positional arguments into a tuple; `**kwargs` collects extra keywords into a dict. Docstrings are the first string in the body — they document, they are not comments.",definition:`A function is a callable object that executes a suite in its own frame, binding parameters to arguments, and returns a value (or None).`,analogy:`A function is a recipe card: ingredients are parameters, the meal is the return value. Printing from a function is serving the meal in the kitchen — the dining room never sees it.`},examples:[{title:`Return versus print`,code:`def area(w, h):
    return w * h

print(area(3, 4) + 1)`,why:`Because area returns a number, the caller can add 1. If area printed instead, you could not compute with the result.`},{title:`Default argument`,code:`def greet(name, title='friend'):
    return f'Hello, {title} {name}'

print(greet('Ada'))
print(greet('Ada', 'Dr'))`,why:`The default is used only when the caller omits the argument. Never use a mutable object as a default — we cover that in Scope.`}],mistakes:[{wrong:`def add(a, b):
    print(a + b)

x = add(1, 2) + 3`,right:`def add(a, b):
    return a + b

x = add(1, 2) + 3`,why:`print does not return the sum. x would be None + 3, which crashes.`}],exercises:[{id:`fn-mini`,title:`is_even`,prompt:`Define is_even(n) that returns True when n is even. Print is_even(6) and is_even(7) on two lines.`,difficulty:`easy`,starter:`def is_even(n):
    ...
`,solution:`def is_even(n):
    return n % 2 == 0

print(is_even(6))
print(is_even(7))`,explanation:`Return the boolean expression directly. No if is required.`,checks:[{kind:`stdout`,expected:`True
False`}]},{id:`fn-practical`,title:`clamp`,prompt:`Write clamp(n, lo, hi) that returns n limited to the inclusive range [lo, hi]. Print clamp(12, 0, 10), clamp(-3, 0, 10), clamp(7, 0, 10) on three lines.`,difficulty:`medium`,starter:`def clamp(n, lo, hi):
    ...
`,solution:`def clamp(n, lo, hi):
    if n < lo:
        return lo
    if n > hi:
        return hi
    return n

print(clamp(12, 0, 10))
print(clamp(-3, 0, 10))
print(clamp(7, 0, 10))`,explanation:"Two guards, then the value itself. Equivalent: `max(lo, min(hi, n))`.",checks:[{kind:`stdout`,expected:`10
0
7`}]},{id:`fn-hard`,title:`average`,prompt:`Write average(*nums) that returns the arithmetic mean as a float. Print average(2, 4, 6) and average(10).`,difficulty:`hard`,starter:`def average(*nums):
    ...
`,solution:`def average(*nums):
    return sum(nums) / len(nums)

print(average(2, 4, 6))
print(average(10))`,optional:!0,explanation:"*nums packs positional arguments into a tuple. Mean is total divided by count. 10/1 is 10.0 because `/` is true division.",checks:[{kind:`stdout`,expected:`4.0
10.0`}]}]},scope:{topicId:`scope`,revision:{heading:`Names live somewhere`,body:`A name bound inside a function is local. A name bound at the top of a file is global. Python looks up names using LEGB: Local, Enclosing, Global, Built-in.`,code:`x = 1

def f():
    x = 2
    print(x)

f()
print(x)`},concept:{heading:`LEGB and the mutable default trap`,explanation:"When Python sees a name, it searches the local function, then any enclosing functions, then the module, then builtins. Assignment in a function makes the name local for the whole function, which is why `x = x + 1` can raise UnboundLocalError if x was only global. `global` and `nonlocal` rebind outer names — use them rarely. Default argument values are evaluated once, when `def` runs. A default of `[]` is the same list on every call, which leaks state. Use `None` and create the list inside the body.",definition:`Scope is the region of a program where a name is visible. Python uses lexical (static) scope with the LEGB lookup rule.`,analogy:`A local variable is a sticky note on your desk. A global is a poster in the hallway. You can read the poster from your desk, but writing on a new sticky note does not change the poster.`},examples:[{title:`UnboundLocalError`,code:`n = 1

def bump():
    print(n)

bump()`,why:"This works because bump only reads n. If bump contained `n = n + 1` without `global n`, the name n would be local and the read would fail."},{title:`Safe default`,code:`def add_item(item, box=None):
    if box is None:
        box = []
    box.append(item)
    return box

print(add_item('a'))
print(add_item('b'))`,why:"Each call that omits box gets a fresh list. A default of `[]` would keep growing one shared list."}],mistakes:[{wrong:`def add(item, box=[]):
    box.append(item)
    return box`,right:`def add(item, box=None):
    if box is None:
        box = []
    box.append(item)
    return box`,why:`The empty list is created once. Later calls reuse it.`}],exercises:[{id:`scope-mini`,title:`Local versus global`,prompt:`x = 10. Define f that binds a local x to 20 and prints it. Call f, then print the global x. Two lines: 20 then 10.`,difficulty:`easy`,starter:`x = 10

def f():
    ...
`,solution:`x = 10

def f():
    x = 20
    print(x)

f()
print(x)`,explanation:`The assignment inside f is local. The global x is unchanged.`,checks:[{kind:`stdout`,expected:`20
10`}]},{id:`scope-practical`,title:`Fresh list each call`,prompt:`Write bag(item, items=None) that appends item to a new list when items is omitted. Print bag('a') and bag('b') on two lines.`,difficulty:`medium`,starter:`def bag(item, items=None):
    ...
`,solution:`def bag(item, items=None):
    if items is None:
        items = []
    items.append(item)
    return items

print(bag('a'))
print(bag('b'))`,explanation:`None is immutable, so it is a safe default. You create the list per call.`,checks:[{kind:`stdout`,expected:`['a']
['b']`}]}]},errors:{topicId:`errors`,revision:{heading:`Failures are values too`,body:`When Python cannot continue, it raises an exception. If nothing handles it, the program stops and prints a traceback. You can handle exceptions with try/except.`,code:`try:
    int('q')
except ValueError:
    print('not a number')`},concept:{heading:`Catch specific, raise clearly`,explanation:"A try suite is the risky work. except matches by type. Catch the narrowest type you can (`ValueError`, `KeyError`, `FileNotFoundError`) — a bare `except:` also swallows KeyboardInterrupt and bugs. `else` runs when no exception occurred. `finally` always runs (cleanup). `raise ValueError('msg')` starts an exception. Exceptions are for exceptional paths, not everyday branching.",definition:`An exception is an object signalling that a statement failed. Handling transfers control to a matching except clause.`,analogy:`A fire alarm is an exception. You do not use it to announce lunch. You do install a sprinkler (except) for the fires you can handle, and you let the others reach the fire department (the traceback).`},examples:[{title:`else and finally`,code:`def parse(s):
    try:
        n = int(s)
    except ValueError:
        return None
    else:
        return n * 2

print(parse('4'))
print(parse('x'))`,why:"`else` runs only on success, so `n * 2` never sees a failed conversion. Returning None is one way to signal 'could not parse'."}],mistakes:[{wrong:`try:
    risky()
except:
    pass`,right:`try:
    risky()
except ValueError as e:
    print(e)`,why:`Bare except hides bugs. Name the exception you expect.`}],exercises:[{id:`err-mini`,title:`Safe int`,prompt:`Write safe_int(s) that returns the integer or None if conversion fails. Print safe_int('9') and safe_int('q').`,difficulty:`easy`,starter:`def safe_int(s):
    ...
`,solution:`def safe_int(s):
    try:
        return int(s)
    except ValueError:
        return None

print(safe_int('9'))
print(safe_int('q'))`,explanation:`int('q') raises ValueError. Catching that type and returning None is a clean API for 'maybe a number'.`,checks:[{kind:`stdout`,expected:`9
None`}]},{id:`err-practical`,title:`Raise on bad age`,prompt:`Write adult(age) that returns True if age >= 18, False if 0 <= age < 18, and raises ValueError if age is negative. Print adult(20) and adult(7), then try adult(-1) and print 'bad' in except ValueError.`,difficulty:`medium`,starter:`def adult(age):
    ...
`,solution:`def adult(age):
    if age < 0:
        raise ValueError('age')
    return age >= 18

print(adult(20))
print(adult(7))
try:
    adult(-1)
except ValueError:
    print('bad')`,explanation:`Invalid input is exceptional — raise. Valid ages return a boolean.`,checks:[{kind:`stdout`,expected:`True
False
bad`}]}]},modules:{topicId:`modules`,revision:{heading:`Files as namespaces`,body:"A module is a Python file. `import math` loads it and binds the name math. `from math import sqrt` binds sqrt directly. `if __name__ == '__main__'` is true only when the file is the program being run.",code:`import math
print(math.sqrt(16))`},concept:{heading:`import is execution plus a cache`,explanation:"The first import executes the file from top to bottom and stores the module in `sys.modules`. Later imports reuse that object. Aliases (`import math as m`) change only the local name. `__name__` is `'__main__'` for the entry file and the module name otherwise — that is how you keep a file both importable and runnable. In this sandbox, `math`, `json`, `random`, `datetime`, and other stdlib modules work. Network and OS process modules are blocked.",definition:`A module is a unit of organisation: a file whose top-level names form a namespace, loaded with import.`,analogy:"A module is a toolbox. `import math` puts the whole box on the bench. `from math import sqrt` takes one tool out. `__name__ == '__main__'` asks 'was this toolbox opened as the job, or borrowed by another job?'"},examples:[{title:`Alias and from-import`,code:`import math as m
from math import pi
print(m.ceil(2.1), round(pi, 2))`,why:`Two styles, same module. The alias keeps the namespace. from-import copies a name into yours.`}],mistakes:[{wrong:`from math import *`,right:`from math import sqrt, pi`,why:`Star imports dump unknown names into your scope and make collisions hard to see.`}],exercises:[{id:`mod-mini`,title:`Hypotenuse`,prompt:`Use math.hypot to print the hypotenuse of a 3-4-5 triangle as an integer if it is whole, else as is. For 3 and 4 it is 5.0 — print it.`,difficulty:`easy`,starter:`import math
`,solution:`import math
print(math.hypot(3, 4))`,explanation:`hypot(dx, dy) is the Euclidean length. 3-4-5 is the classic integer triangle, returned as 5.0.`,checks:[{kind:`stdout`,expected:`5.0`}]},{id:`mod-practical`,title:`Main guard demo`,prompt:`Bind a function hello() that returns 'hi'. Under if __name__ == '__main__', print hello(). (In the playground the file is main, so it will print.)`,difficulty:`medium`,starter:`def hello():
    return 'hi'
`,solution:`def hello():
    return 'hi'

if __name__ == '__main__':
    print(hello())`,explanation:`The guard runs here because the sandbox executes your file as the main program. If another module imported it, hello would exist but the print would not run.`,checks:[{kind:`stdout`,expected:`hi`}]}]},files:{topicId:`files`,revision:{heading:`Data that outlives the run`,body:"Files are how programs remember. `open(path)` returns a file object. Always close it — the `with` statement does that even if an error occurs. This playground uses a virtual disk: files you write are real inside the sandbox, not on a host machine.",code:`with open('note.txt', 'w') as f:
    f.write('hello')
`},concept:{heading:`Modes, context managers, paths`,explanation:"`'r'` reads (default), `'w'` writes (truncates), `'a'` appends, `'rb'`/`'wb'` are binary. `read()` returns the whole text; `readline()` one line; iterating the file walks lines including newline characters — `strip()` them. `write` takes a string and does not add a newline for you. The `with` statement is a context manager: it enters (opens) and exits (closes) reliably. Paths can be relative; we start in a workspace folder.",definition:"A file object is a handle to a stream of bytes or text. A context manager (`with`) guarantees setup and teardown around a block.",analogy:"Opening a file is borrowing a book from a desk. `with` puts it back on the shelf even if you knock the lamp over mid-sentence."},examples:[{title:`Write then read`,code:`with open('memo.txt', 'w') as f:
    f.write('helix\\n')
with open('memo.txt') as f:
    print(f.read().strip())`,why:`Two with-blocks: one writes, one reads. strip removes the trailing newline so print does not add a blank line.`}],mistakes:[{wrong:`f = open('a.txt', 'w')
f.write('x')`,right:`with open('a.txt', 'w') as f:
    f.write('x')`,why:`Without with (or close), data may not flush and the handle leaks.`}],exercises:[{id:`file-mini`,title:`Round trip`,prompt:`Write 'Ada' to 'name.txt', read it back, and print the contents with no extra newline.`,difficulty:`easy`,starter:``,solution:`with open('name.txt', 'w') as f:
    f.write('Ada')
with open('name.txt') as f:
    print(f.read())`,explanation:`write does not add a newline. read returns exactly what was written. print adds one newline at the end.`,checks:[{kind:`stdout`,expected:`Ada`}]},{id:`file-practical`,title:`Line count`,prompt:`Write three lines 'a', 'b', 'c' (each ended by newline) to 'lines.txt'. Then print how many lines the file has.`,difficulty:`medium`,starter:``,solution:`with open('lines.txt', 'w') as f:
    f.write('a\\nb\\nc\\n')
with open('lines.txt') as f:
    print(len(f.readlines()))`,explanation:`readlines returns a list of lines. Its length is the line count.`,checks:[{kind:`stdout`,expected:`3`}]}]},oop:{topicId:`oop`,revision:{heading:`Data plus behaviour`,body:"A class is a blueprint. An instance (object) is one concrete value of that blueprint. Methods are functions that receive the instance as `self`.",code:`class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y`},concept:{heading:`Objects are namespaces you define`,explanation:"`class Name:` creates a type. `__init__` initialises a new instance; it is not the constructor itself — `Point(1, 2)` constructs, then `__init__` fills in attributes. `self` is the instance, passed automatically on method calls. Attributes live on `self`. `__str__` is the human string (print); `__repr__` is the unambiguous developer string. Inheritance (`class Admin(User)`) reuses and extends. Start with one class that earns its keep — do not invent hierarchies for their own sake.",definition:`A class defines a type. An object is an instance of a class, combining state (attributes) with behaviour (methods).`,analogy:"A class is the blueprint of a bicycle. Each bike in the rack is an instance. `self` is 'this bike'. A method like `brake` only makes sense on a particular bike."},examples:[{title:`A tiny counter`,code:`class Counter:
    def __init__(self):
        self.n = 0
    def inc(self):
        self.n += 1

c = Counter()
c.inc()
c.inc()
print(c.n)`,why:`State lives on the instance. Two Counter() objects would not share n.`}],mistakes:[{wrong:`def __init__(x, y):
    self.x = x`,right:`def __init__(self, x, y):
    self.x = x
    self.y = y`,why:`The first parameter of an instance method is the instance. By convention it is named self.`}],exercises:[{id:`oop-mini`,title:`Rectangle area`,prompt:`Write class Rect with __init__(self, w, h) and method area(self). Print Rect(3, 4).area().`,difficulty:`easy`,starter:`class Rect:
    ...
`,solution:`class Rect:
    def __init__(self, w, h):
        self.w = w
        self.h = h
    def area(self):
        return self.w * self.h

print(Rect(3, 4).area())`,explanation:`Store width and height on self, then multiply in area.`,checks:[{kind:`stdout`,expected:`12`}]},{id:`oop-practical`,title:`Bank-ish`,prompt:`Class Vault with balance starting at 0, methods deposit(n) and withdraw(n) that refuse to go negative (leave balance unchanged if n is too big). Deposit 50, withdraw 20, withdraw 100, print balance.`,difficulty:`medium`,starter:`class Vault:
    ...
`,solution:`class Vault:
    def __init__(self):
        self.balance = 0
    def deposit(self, n):
        self.balance += n
    def withdraw(self, n):
        if n <= self.balance:
            self.balance -= n

v = Vault()
v.deposit(50)
v.withdraw(20)
v.withdraw(100)
print(v.balance)`,explanation:`The guard on withdraw is an invariant: balance never drops below zero. 50-20=30, the 100 is ignored.`,checks:[{kind:`stdout`,expected:`30`}]}]},stdlib:{topicId:`stdlib`,revision:{heading:`Batteries included`,body:`The standard library is the set of modules that ship with Python. You already used math. Next: datetime, random, json, collections.`,code:`import json
print(json.dumps({'ok': True}))`},concept:{heading:`Prefer the stdlib until it hurts`,explanation:"`datetime` handles dates. `random` samples (seed it in tests). `json` serialises dicts and lists to text. `collections.Counter` counts, `defaultdict` supplies missing keys. `pathlib.Path` is object-oriented paths. Read the docs for the module you import — do not guess method names. In this sandbox, `random` works; output that depends on randomness should be seeded.",definition:`The Python standard library is a collection of modules distributed with the interpreter, covering common tasks without third-party packages.`,analogy:`The stdlib is the kitchen already in the apartment. You can cook a lot before you buy a specialty gadget (an external package).`},examples:[{title:`Counter and json`,code:`from collections import Counter
import json
c = Counter('ababa')
print(json.dumps({'a': c['a'], 'b': c['b']}))`,why:`Counter is a dict specialised for counts. json.dumps turns a dict into a string that another program could parse.`},{title:`Seeded random`,code:`import random
random.seed(1)
print(random.randint(1, 6))`,why:`A seed makes the sequence reproducible — essential for tests and lessons.`}],mistakes:[{wrong:`import random
print(random.randint(1, 6))`,right:`import random
random.seed(0)
print(random.randint(1, 6))`,why:`Unseeded random is correct in apps, but not in checks that need a fixed answer.`}],exercises:[{id:`std-mini`,title:`JSON round trip`,prompt:`Dump {'n': 3} to a JSON string, load it back, print the n value.`,difficulty:`easy`,starter:`import json
`,solution:`import json
text = json.dumps({'n': 3})
data = json.loads(text)
print(data['n'])`,explanation:`dumps is to text; loads is back to a dict. Keys in JSON objects become strings.`,checks:[{kind:`stdout`,expected:`3`}]},{id:`std-practical`,title:`Most common`,prompt:`Use Counter on 'mississippi'. Print the count of s.`,difficulty:`medium`,starter:`from collections import Counter
`,solution:`from collections import Counter
print(Counter('mississippi')['s'])`,explanation:`s appears four times in mississippi.`,checks:[{kind:`stdout`,expected:`4`}]}]},apis:{topicId:`apis`,revision:{heading:`Programs talking to programs`,body:`An API is a contract: you send a request, you get a structured response. On the web that is often HTTP plus JSON. This sandbox does not open the real network. We practise the shape with a tiny fake client.`,code:`import json
body = json.dumps({'q': 'ada'})
print(json.loads(body)['q'])`},concept:{heading:`HTTP, status, JSON`,explanation:"A client sends a method (GET to read, POST to create) to a URL. The server answers with a status code: 200 ok, 201 created, 400 bad request, 404 missing, 500 server error. The body is often JSON — the same dict/list structure you already know, serialised as text. You parse it, then use keys. Real code uses `urllib` or `requests`; here we inject `pyduke_net.fetch(url)` which returns a dict for a few teaching URLs and raises on unknown ones.",definition:`An application programming interface is a documented set of operations a program exposes. A web API typically uses HTTP methods, URLs, and JSON payloads.`,analogy:`An API is a restaurant order slip. You do not walk into the kitchen (the other program's internals). You write the dish (the URL and body) and get a plate back (JSON) plus a note if the dish is off (status code).`},examples:[{title:`Fake GET`,code:`from pyduke_net import fetch
user = fetch('/users/1')
print(user['name'])`,why:`fetch hides HTTP. You still treat the result as a dict. That is the skill that transfers to real clients.`}],mistakes:[{wrong:`data = fetch('/users/1')
print(data.name)`,right:`data = fetch('/users/1')
print(data['name'])`,why:`JSON objects become dicts, not attribute bags. Use brackets.`}],exercises:[{id:`api-mini`,title:`Read a user`,prompt:`Use pyduke_net.fetch('/users/1') and print the email field.`,difficulty:`easy`,starter:`from pyduke_net import fetch
`,solution:`from pyduke_net import fetch
print(fetch('/users/1')['email'])`,explanation:`The teaching server maps /users/1 to a dict with name, email, id.`,checks:[{kind:`stdout`,expected:`ada@pyduke.dev`}]},{id:`api-practical`,title:`List names`,prompt:`fetch('/users') returns a list of user dicts. Print a comma-separated list of names in order.`,difficulty:`medium`,starter:`from pyduke_net import fetch
`,solution:`from pyduke_net import fetch
users = fetch('/users')
print(','.join(u['name'] for u in users))`,explanation:`Walk the list, pick the name key, join. Same pattern as any list of dicts.`,checks:[{kind:`stdout`,expected:`Ada,Lin`}]}]},projects:{topicId:`projects`,revision:{heading:`From exercises to programs`,body:`A project is several ideas working together. You do not write it top to bottom in one breath. You split: data, input, logic, output. The Projects tab has full builds. Here we practise the split.`},concept:{heading:`Design a thin slice`,explanation:`Start with the smallest thing that runs: one function, one print, one test. Name the nouns (what data exists) and the verbs (what happens). Keep I/O at the edges so logic can be tested. A number-guessing game is: secret, guess, compare, repeat. A to-do list is: a list of strings, add, show, remove. Resist pasting a whole program you do not understand.`,definition:`A software project is a program with a purpose, split into modules or functions, built in thin vertical slices that each run.`,analogy:`You do not build a house by finishing every brick first. You build a room you can stand in, then another.`},examples:[{title:`A slice: compare one guess`,code:`def judge(secret, guess):
    if guess == secret:
        return 'match'
    if guess < secret:
        return 'low'
    return 'high'

print(judge(7, 3))
print(judge(7, 7))`,why:`The comparison is a function. The loop and input wrap it later. You can test judge without typing.`}],mistakes:[{wrong:`one 200-line file, no functions`,right:`small functions, then a main that calls them`,why:`Without functions you cannot test or reuse a piece. The program becomes a script you are afraid to touch.`}],exercises:[{id:`proj-mini`,title:`Judge`,prompt:`Write judge(secret, guess) returning 'low', 'high', or 'match'. Print judge(10, 4), judge(10, 12), judge(10, 10).`,difficulty:`easy`,starter:`def judge(secret, guess):
    ...
`,solution:`def judge(secret, guess):
    if guess == secret:
        return 'match'
    if guess < secret:
        return 'low'
    return 'high'

print(judge(10, 4))
print(judge(10, 12))
print(judge(10, 10))`,explanation:`This is the core of a guessing game, isolated from input. Three paths, three prints.`,checks:[{kind:`stdout`,expected:`low
high
match`}]},{id:`proj-practical`,title:`Todo add`,prompt:`todos = []. Write add(todos, item) that appends and returns todos. Add 'read' and 'run', print the list.`,difficulty:`medium`,starter:`todos = []

def add(todos, item):
    ...
`,solution:`todos = []

def add(todos, item):
    todos.append(item)
    return todos

add(todos, 'read')
add(todos, 'run')
print(todos)`,explanation:`Passing the list in keeps add testable. Mutating and returning is a simple API for a first project.`,checks:[{kind:`stdout`,expected:`['read', 'run']`}]}]},advanced:{topicId:`advanced`,revision:{heading:`The next layer`,body:`You can write real programs now. Advanced Python is not a new language — it is better ways to express iteration, contracts, and wrapping behaviour: generators, type hints, and a first look at decorators.`},concept:{heading:`Lazy sequences, hints, wrappers`,explanation:"A generator function uses `yield`. It produces a stream without building the whole list. Type hints (`def f(n: int) -> str`) document contracts; Python does not enforce them at runtime unless a checker does. A decorator is a callable that takes a function and returns a wrapped function — `@decorator` is sugar for `f = decorator(f)`. Use these when they remove noise, not as decoration.",definition:`A generator is an iterator defined by a function that yields values. A type hint is an annotation of expected types. A decorator is a function that wraps another function.`,analogy:`A list is a baked loaf. A generator is slicing bread as people eat. A type hint is the label on the bag. A decorator is a sleeve you slip the loaf into — same bread, extra wrapping.`},examples:[{title:`A generator`,code:`def squares(n):
    for i in range(n):
        yield i * i

print(list(squares(4)))`,why:`yield pauses the function and hands back a value. list() consumes the generator to show the values.`},{title:`A hint`,code:`def shout(text: str) -> str:
    return text.upper()

print(shout('ok'))`,why:`The hints tell humans (and type checkers) the contract. The body is ordinary Python.`}],mistakes:[{wrong:`return i  # inside a supposed generator loop`,right:`yield i`,why:`return stops the function. yield produces the next item.`}],exercises:[{id:`adv-mini`,title:`Countdown generator`,prompt:`Write countdown(n) that yields n, n-1, ... 1. Print list(countdown(3)).`,difficulty:`medium`,starter:`def countdown(n):
    ...
`,solution:`def countdown(n):
    while n > 0:
        yield n
        n -= 1

print(list(countdown(3)))`,explanation:`Each yield emits the current n, then n moves down. When n is 0 the function ends and the generator stops.`,checks:[{kind:`stdout`,expected:`[3, 2, 1]`}]},{id:`adv-practical`,title:`Typed join`,prompt:`Write def label(name: str, n: int) -> str that returns 'name: n'. Print label('Ada', 3).`,difficulty:`easy`,starter:`def label(name: str, n: int) -> str:
    ...
`,solution:`def label(name: str, n: int) -> str:
    return f'{name}: {n}'

print(label('Ada', 3))`,explanation:`Hints do not change runtime. The f-string builds the contract you promised.`,checks:[{kind:`stdout`,expected:`Ada: 3`}]}]}},y={easy:12,medium:20,hard:32,advanced:48};function b(){let e=Date.now(),t={};for(let n of a){let r=`available`;s.includes(n.id)?r=`mastered`:n.id===`lists`&&(r=`in_progress`),t[n.id]={status:r,score:r===`mastered`?100:0,attempts:0,lastSeenAt:n.id===`loops`?e-1728e5:r===`mastered`?e:0,completedExercises:[],mistakes:[]}}return t}var x=[];function S(e){let t=Date.now(),n=[];for(let r of a){let i=e[r.id];i&&i.status===`mastered`&&t-(i.lastSeenAt||0)>1296e5&&n.push(r.id)}return n}var C=()=>({name:``,xp:580,streak:1,lastActiveDate:t(),currentTopicId:c,preferredDifficulty:`medium`,recentResults:[],topics:b(),games:{},projectsCompleted:[],typingHistory:[],snippets:[],tutor:[],lessonsCompleted:[...s],dailyDate:t(),dailyDone:[],seenAchievements:[],hydrated:!1}),w=h(()=>typeof window>`u`?{getItem:()=>null,setItem:()=>{},removeItem:()=>{}}:localStorage),T=m()(_((e,n)=>({...C(),setHydrated:t=>{n().hydrated!==t&&e({hydrated:t})},setName:t=>e({name:t}),tickStreak:()=>{let r=t(),i=n().lastActiveDate;if(i===r)return;let a=new Date;a.setDate(a.getDate()-1),e({lastActiveDate:r,streak:i===t(a)?n().streak+1:1})},awardXp:t=>e({xp:n().xp+t}),recordExercise:({topicId:t,exerciseId:r,ok:i,difficulty:a,note:o})=>{let s={...n().topics},c={...s[t]};c.attempts+=1,c.lastSeenAt=Date.now(),i&&!c.completedExercises.includes(r)&&(c.completedExercises=[...c.completedExercises,r],c.score=Math.min(100,c.score+(a===`easy`?15:a===`medium`?22:30))),!i&&o&&(c.mistakes=[...c.mistakes.slice(-11),{exerciseId:r,note:o,at:Date.now()}]),c.status===`available`&&(c.status=`in_progress`),s[t]=c;let l=[...n().recentResults,i].slice(-6),u=n().preferredDifficulty,d=l.slice(-3);d.length===3&&d.every(Boolean)&&(u=u===`easy`?`medium`:u===`medium`?`hard`:`advanced`),d.length===3&&d.every(e=>!e)&&(u=u===`advanced`?`hard`:u===`hard`?`medium`:`easy`),e({topics:s,recentResults:l,preferredDifficulty:u,currentTopicId:t,xp:n().xp+(i?y[a]:4)})},completeLesson:t=>{let r={...n().topics};r[t]={...r[t],status:`mastered`,score:100,lastSeenAt:Date.now()},e({topics:r,lessonsCompleted:n().lessonsCompleted.includes(t)?n().lessonsCompleted:[...n().lessonsCompleted,t],xp:n().xp+40,currentTopicId:t}),n().unlockNext(t)},unlockNext:t=>{let r=a[a.findIndex(e=>e.id===t)+1];if(!r)return;let i={...n().topics},o=i[r.id];o&&o.status===`available`&&(i[r.id]={...o,status:`in_progress`},e({topics:i,currentTopicId:r.id}))},completeGameItem:(t,r,i=1)=>{let a={...n().games},o=a[t]??{completed:[],best:{}};a[t]={completed:o.completed.includes(r)?o.completed:[...o.completed,r],best:{...o.best,[r]:Math.max(o.best[r]??0,i)}};let s=o.completed.includes(r);e({games:a,xp:n().xp+(s?4:18)})},completeProject:t=>{if(n().projectsCompleted.includes(t)){e({xp:n().xp+8});return}e({projectsCompleted:[...n().projectsCompleted,t],xp:n().xp+80})},recordTyping:t=>{let r=t.accuracy>=95?16:t.accuracy>=85?10:4;e({typingHistory:[...n().typingHistory.slice(-79),t],xp:n().xp+r})},saveSnippet:(t,r)=>{e({snippets:[{id:`${Date.now()}`,title:t.trim()||`Untitled`,code:r,at:Date.now()},...n().snippets].slice(0,40)})},deleteSnippet:t=>e({snippets:n().snippets.filter(e=>e.id!==t)}),pushTutor:t=>{let r={...t,id:`${Date.now()}-${Math.random()}`,at:Date.now()};e({tutor:[...n().tutor,r].slice(-40)})},clearTutor:()=>e({tutor:[]}),completeDaily:r=>{let i=t(),a=n().dailyDate===i?n().dailyDate:i,o=n().dailyDate===i?n().dailyDone:[];o.includes(r)||e({dailyDate:a,dailyDone:[...o,r],xp:n().xp+12})},resetProgress:()=>{let t=n().name;e({...C(),name:t,hydrated:!0})},dueRevision:()=>S(n().topics)}),{name:`pyduke-progress-v1`,skipHydration:!0,storage:w,partialize:e=>({name:e.name,xp:e.xp,streak:e.streak,lastActiveDate:e.lastActiveDate,currentTopicId:e.currentTopicId,preferredDifficulty:e.preferredDifficulty,recentResults:e.recentResults,topics:e.topics,games:e.games,projectsCompleted:e.projectsCompleted,typingHistory:e.typingHistory,snippets:e.snippets,tutor:e.tutor,lessonsCompleted:e.lessonsCompleted,dailyDate:e.dailyDate,dailyDone:e.dailyDone,seenAchievements:e.seenAchievements}),onRehydrateStorage:()=>e=>{if(e){e.dailyDone||=[],e.seenAchievements||=[],e.dailyDate||=t();let n={...e.topics};for(let e of a){let t=n[e.id];t?t.status===`locked`&&(n[e.id]={...t,status:`available`}):n[e.id]={status:s.includes(e.id)?`mastered`:`available`,score:s.includes(e.id)?100:0,attempts:0,lastSeenAt:0,completedExercises:[],mistakes:[]}}e.topics=n,e.setHydrated(!0)}}}));function E(t){let n=a.filter(e=>t.topics[e.id].status===`mastered`).map(e=>e.title),r=a.find(e=>e.id===t.currentTopicId)?.title??t.currentTopicId,i=Object.entries(t.topics).flatMap(([e,t])=>t.mistakes.slice(-2).map(t=>`${e}: ${t.note}`)).slice(-6),o=v[t.currentTopicId];return[`Learner name: ${t.name||`(not set)`}`,`XP: ${t.xp}, level: ${e(t.xp)}, streak: ${t.streak}`,`Current topic: ${r}`,`Mastered: ${n.join(`, `)||`none`}`,`Preferred difficulty: ${t.preferredDifficulty}`,`Typing last WPM: ${t.typingHistory.at(-1)?.wpm??`n/a`} accuracy ${t.typingHistory.at(-1)?.accuracy??`n/a`}`,`Recent mistakes: ${i.join(` | `)||`none recorded`}`,`Lesson heading: ${o.concept.heading}`].join(`
`)}export{v as a,o as c,T as i,S as n,s as o,E as r,a as s,x as t};