var e=[{id:`kw-1`,title:`Keywords`,focus:`Common keywords`,code:`def if elif else for while return True False None and or not in is pass`},{id:`syn-1`,title:`Brackets and colons`,focus:`(), [], {}, :`,code:`data = {'ok': [1, 2, 3], 'n': (4, 5)}
for k, v in data.items():
    print(k, v)`},{id:`syn-2`,title:`Quotes and commas`,focus:`quotes, commas`,code:`names = ["Ada", "Lin", "Moe"]
print(", ".join(names))`},{id:`ind-1`,title:`Indentation`,focus:`4-space blocks`,code:`def grade(n):
    if n >= 10:
        return 'high'
    return 'low'`},{id:`op-1`,title:`Operators`,focus:`arithmetic and compare`,code:`n = 7
print(n // 2, n % 2, n ** 2, n != 0, n <= 10)`},{id:`und-1`,title:`Underscores`,focus:`snake_case names`,code:`user_name = 'ada_lovelace'
max_count = 3
print(user_name, max_count)`},{id:`fn-1`,title:`A small function`,focus:`def, return, f-string`,code:`def label(name, year):
    return f'{name}_{year}'

print(label('helix', 2026))`},{id:`lc-1`,title:`Comprehension`,focus:`list comprehension syntax`,code:`nums = [1, 2, 3, 4]
squares = [n * n for n in nums if n % 2 == 0]
print(squares)`},{id:`cls-1`,title:`A tiny class`,focus:`class, self, init`,code:`class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y`},{id:`sym-1`,title:`Symbols sprint`,focus:`()[]{}:"'_*/<>=`,code:`print("hi")
data = {"n": 3, "ok": True}
xs = [i * 2 for i in range(4) if i < 3]
print(xs[0] != xs[-1])`},{id:`err-1`,title:`try / except`,focus:`error handling layout`,code:`try:
    n = int('8')
except ValueError:
    n = 0
print(n)`}];export{e as t};