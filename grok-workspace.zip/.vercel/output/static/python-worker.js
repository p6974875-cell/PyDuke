/* PyDuke Python sandbox — Pyodide in a worker. Isolated from the page. */
/* global loadPyodide */

let pyodide = null;
let bootPromise = null;

const HELIX_NET = `
class _HelixNet:
    _users = [
        {"id": 1, "name": "Ada", "email": "ada@pyduke.dev"},
        {"id": 2, "name": "Lin", "email": "lin@pyduke.dev"},
    ]
    def fetch(self, url):
        if url in ("/users/1", "https://api.example.com/users/1"):
            return dict(self._users[0])
        if url in ("/users", "https://api.example.com/users"):
            return [dict(u) for u in self._users]
        raise ValueError("unknown URL in the PyDuke sandbox: " + str(url))

pyduke_net = _HelixNet()
fetch = pyduke_net.fetch
`;

const BOOT = `
import sys, builtins, types
BAN = {
    "subprocess", "socket", "ctypes", "multiprocessing", "webbrowser",
    "http", "urllib", "requests", "js", "pyodide", "pyodide_js",
    "xmlrpc", "ftplib", "telnetlib", "imaplib", "smtplib", "ssl",
}
_real = builtins.__import__
def _imp(name, globals=None, locals=None, fromlist=(), level=0):
    root = name.split(".")[0]
    if root in BAN:
        raise ImportError(root + " is blocked in the PyDuke sandbox")
    return _real(name, globals, locals, fromlist, level)
builtins.__import__ = _imp
import os
os.makedirs("/home/pyodide/workspace", exist_ok=True)
os.chdir("/home/pyodide/workspace")
`;

async function boot() {
  if (pyodide) return pyodide;
  if (bootPromise) return bootPromise;
  bootPromise = (async () => {
    importScripts("https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js");
    const py = await loadPyodide({
      indexURL: "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/",
    });
    await py.runPythonAsync(BOOT);
    py.FS.writeFile("/home/pyodide/workspace/pyduke_net.py", HELIX_NET);
    py.FS.writeFile("/home/pyodide/workspace/helix_net.py", HELIX_NET);
    pyodide = py;
    return py;
  })();
  return bootPromise;
}

self.onmessage = async (ev) => {
  const msg = ev.data || {};
  if (msg.type === "boot") {
    try {
      await boot();
      self.postMessage({ type: "ready" });
    } catch (err) {
      self.postMessage({ type: "error", error: String(err) });
    }
    return;
  }
  if (msg.type !== "run") return;
  const id = msg.id;
  try {
    const py = await boot();
    py.globals.set("_helix_stdin", String(msg.stdin ?? ""));
    py.globals.set("_helix_code", String(msg.code ?? ""));
    await py.runPythonAsync(`
import sys
from io import StringIO
sys.stdin = StringIO(_helix_stdin)
sys.stdout = StringIO()
sys.stderr = StringIO()
_helix_err = None
try:
    _ns = {"__name__": "__main__"}
    exec(compile(_helix_code, "<learner>", "exec"), _ns)
except SystemExit:
    pass
except Exception as _e:
    _helix_err = f"{type(_e).__name__}: {_e}"
_helix_out = sys.stdout.getvalue()
_helix_err_out = sys.stderr.getvalue()
`);
    const stdout = py.globals.get("_helix_out") ?? "";
    const stderr = py.globals.get("_helix_err_out") ?? "";
    const error = py.globals.get("_helix_err");
    const errStr = error && error !== "None" ? String(error) : "";
    self.postMessage({
      type: "result",
      id,
      ok: !errStr,
      stdout: String(stdout),
      stderr: String(stderr),
      error: errStr,
    });
  } catch (err) {
    self.postMessage({
      type: "result",
      id,
      ok: false,
      stdout: "",
      stderr: "",
      error: String(err),
    });
  }
};
