-- PyDuke persistent schema: profiles (no auth), progress, gamification,
-- learning events. Content (topics/lessons/exercises) stays in
-- src/lib/content/*.ts — the TS definitions are the version-controlled
-- curriculum; PostgreSQL is the source of truth for learner STATE only.

CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    display_name VARCHAR(50) NOT NULL DEFAULT '',
    recovery_code_hash TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_active_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS profile_stats (
    profile_id UUID PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
    xp INTEGER NOT NULL DEFAULT 0,
    streak INTEGER NOT NULL DEFAULT 0,
    last_active_date TEXT,
    current_topic_id TEXT,
    preferred_difficulty TEXT NOT NULL DEFAULT 'medium',
    recent_results JSONB NOT NULL DEFAULT '[]',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- One row per topic the learner has touched. lesson_id holds the TS content
-- topic id (e.g. "loops"); no FK on purpose — content ships in the bundle.
CREATE TABLE IF NOT EXISTS lesson_progress (
    profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    lesson_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'not_started'
        CHECK (status IN ('not_started','available','in_progress','review','locked','mastered')),
    progress_percent SMALLINT NOT NULL DEFAULT 0,
    attempts INTEGER NOT NULL DEFAULT 0,
    completed_exercises JSONB NOT NULL DEFAULT '[]',
    mistakes JSONB NOT NULL DEFAULT '[]',
    last_seen_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (profile_id, lesson_id)
);

CREATE TABLE IF NOT EXISTS exercise_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    exercise_id TEXT NOT NULL,
    topic_id TEXT,
    passed BOOLEAN NOT NULL,
    score SMALLINT,
    code TEXT,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS exercise_attempts_profile_idx
    ON exercise_attempts(profile_id, exercise_id, created_at DESC);

CREATE TABLE IF NOT EXISTS project_progress (
    profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    project_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'in_progress'
        CHECK (status IN ('not_started','in_progress','completed')),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (profile_id, project_id)
);

CREATE TABLE IF NOT EXISTS game_progress (
    profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    game_id TEXT NOT NULL,
    completed JSONB NOT NULL DEFAULT '[]',
    best JSONB NOT NULL DEFAULT '{}',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (profile_id, game_id)
);

CREATE TABLE IF NOT EXISTS typing_sessions (
    id BIGSERIAL PRIMARY KEY,
    profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    drill_id TEXT NOT NULL,
    wpm SMALLINT NOT NULL,
    cpm SMALLINT NOT NULL,
    accuracy SMALLINT NOT NULL,
    errors SMALLINT NOT NULL,
    chars SMALLINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS typing_sessions_profile_idx
    ON typing_sessions(profile_id, created_at DESC);

CREATE TABLE IF NOT EXISTS snippets (
    id TEXT PRIMARY KEY,
    profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    code TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS achievements (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    icon TEXT
);

CREATE TABLE IF NOT EXISTS profile_achievements (
    profile_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    achievement_id TEXT REFERENCES achievements(id),
    earned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (profile_id, achievement_id)
);

CREATE TABLE IF NOT EXISTS learning_events (
    id BIGSERIAL PRIMARY KEY,
    profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    event_type TEXT NOT NULL,
    topic_id TEXT,
    exercise_id TEXT,
    project_id TEXT,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS learning_events_profile_idx
    ON learning_events(profile_id, created_at DESC);

-- Reserved for server-side tutor history (not yet wired into the UI; the
-- client keeps the recent transcript locally).
CREATE TABLE IF NOT EXISTS tutor_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    title TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tutor_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES tutor_conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('user','assistant')),
    content TEXT NOT NULL,
    context JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS tutor_messages_conversation_idx
    ON tutor_messages(conversation_id, created_at);

-- Content tables (spec §15): the version-controlled source is
-- src/lib/content/*.ts; scripts/seed-content.mjs upserts it here so the DB
-- mirrors the shipped curriculum. The MVP runtime still reads the TS bundle.
CREATE TABLE IF NOT EXISTS topics (
    id TEXT PRIMARY KEY,
    number INTEGER NOT NULL,
    title TEXT NOT NULL,
    subtitle TEXT,
    blurb TEXT,
    published BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS lessons (
    id TEXT PRIMARY KEY,
    topic_id TEXT NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
    heading TEXT,
    content JSONB NOT NULL,
    published BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS exercises (
    id TEXT PRIMARY KEY,
    topic_id TEXT NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    prompt TEXT NOT NULL,
    difficulty TEXT NOT NULL,
    starter_code TEXT,
    checks JSONB NOT NULL DEFAULT '[]',
    hints JSONB,
    sort_order INTEGER NOT NULL DEFAULT 0,
    published BOOLEAN NOT NULL DEFAULT TRUE
);
