# Deploying PyDuke fresh

This version includes:
- Tutor wired to Google's free Gemini API, with a hint-level system (soft
  hints on the first attempt, fuller help after repeated tries) — better
  than the earlier version
- A broadened offline fallback (used only if Gemini is unreachable) that
  actually answers general topic questions instead of one generic message
- Profiles + progress now persist to a real Postgres database in the
  background. If no database is connected, everything still works — it
  quietly keeps state in memory for that session instead of failing.
- `.env` pre-filled with a working Gemini key and a randomly generated
  `PROFILE_SECRET` (rotate the Gemini key later at
  https://aistudio.google.com/apikey — it's free tier, no billing risk, but
  worth refreshing once you're settled)
- The code editor now shows a "Retry" button if it ever fails to load,
  instead of silently staying blank

## Deploy with the Vercel CLI (recommended, fastest path to a clean deploy)

```bash
npm install -g vercel   # one-time
cd pyduke
vercel login
vercel --prod
```

When prompted for environment variables, or afterward in the dashboard,
add everything in this project's `.env` file (Vercel → Settings →
Environment Variables).

## Strongly recommended: connect a real database (2 minutes, free)

Progress and profiles are stored in Postgres. Without one connected, the
app still runs fine, but nothing is guaranteed to persist reliably between
visits on a serverless host like Vercel.

The easy way: in your Vercel project, go to **Storage → Create Database →
Postgres (powered by Neon)**. It's free, and Vercel automatically sets
`DATABASE_URL` for you — no separate signup, no copying connection
strings. Then redeploy.

## The two settings that broke the last deployment — do these immediately

1. **Settings → Deployment Protection → set to "Disabled"** (or "Only
   Preview Deployments" if you want previews private but the live site
   public). Without this, every visitor who isn't logged into your Vercel
   account gets a login wall instead of your app.

2. **Domains tab** — if a custom domain shows "Invalid Configuration,"
   either fix the DNS record it lists, or remove that domain and use the
   default `*.vercel.app` URL — that one always works with no DNS setup.

## If you go through Grok instead of the CLI

Upload/paste this project into Grok, make sure it deploys to Vercel with
`GEMINI_API_KEY` and `PROFILE_SECRET` set (and ideally `DATABASE_URL` via
the Neon integration above), then still check both settings above
afterward — Grok's deploy pipeline does not control Vercel's Deployment
Protection setting or its Storage integrations.
