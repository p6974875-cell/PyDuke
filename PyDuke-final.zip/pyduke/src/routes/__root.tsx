import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { ProfileProvider } from "@/lib/profile/client";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "sonner";
import appCss from "../styles.css?url";

const APP_NAME = "PyDuke";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      { name: "description", content: "A personal Python tutor that remembers where you left off." },
      { name: "theme-color", content: "#111b27" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=IBM+Plex+Mono:wght@400;500&family=Outfit:wght@400;500;600&display=swap",
      },
    ],
  }),
  component: Root,
});

function Root() {
  // One client per request (SSR-safe): component instances are per-request on
  // the server, and on the client it lives for the app's lifetime.
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { retry: 1, refetchOnWindowFocus: false },
        },
      }),
  );

  return (
    <html lang="en" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <QueryClientProvider client={queryClient}>
          <ProfileProvider>
            <TooltipProvider delayDuration={200}>
              <AppShell>
                <Outlet />
              </AppShell>
              <Toaster
                theme="dark"
                position="bottom-right"
                toastOptions={{
                  className: "bg-popover text-popover-foreground border-border",
                }}
              />
            </TooltipProvider>
          </ProfileProvider>
        </QueryClientProvider>
        <Scripts />
      </body>
    </html>
  );
}
