import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useProfile } from "@/lib/profile/client";
import { useHelix } from "@/lib/store";
import { levelFromXp } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/profile")({ component: ProfilePage });

function ProfilePage() {
  const { profile, loading, createProfile, recoverWithCode, rename, signOutProfile } = useProfile();
  const xp = useHelix((s) => s.xp);
  const streak = useHelix((s) => s.streak);
  const preferred = useHelix((s) => s.preferredDifficulty);
  const reset = useHelix((s) => s.resetProgress);

  const [draft, setDraft] = useState("");
  const [nameDraft, setNameDraft] = useState(profile?.displayName ?? "");
  const [recoveryCode, setRecoveryCode] = useState<string | null>(null);
  const [recoverCode, setRecoverCode] = useState("");
  const [recoverError, setRecoverError] = useState("");
  const [open, setOpen] = useState(false);

  if (loading) {
    return <p className="text-sm text-muted-foreground">Loading profile…</p>;
  }

  if (!profile) {
    return (
      <div className="mx-auto max-w-lg space-y-8">
        <header>
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Profile</p>
          <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Create your profile</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            No account, no password. A profile keeps your progress on the server; this browser holds
            a signed key to it. Save the recovery code so another device can find you.
          </p>
        </header>
        <div className="space-y-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
          <div className="space-y-2">
            <Label htmlFor="new-name">What should PyDuke call you?</Label>
            <Input
              id="new-name"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="A name, or leave blank"
            />
          </div>
          <Button
            onClick={() => {
              void createProfile(draft).then((res) => {
                setRecoveryCode(res.recoveryCode);
                setDraft("");
              });
            }}
          >
            Create profile
          </Button>
          {recoveryCode ? (
            <div className="rounded-lg bg-secondary p-4">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Your recovery code — store it now
              </p>
              <p className="mt-2 font-mono text-lg tracking-wider">{recoveryCode}</p>
              <p className="mt-2 text-xs text-muted-foreground">
                It is shown once. It is the only way to open this profile from another browser.
              </p>
            </div>
          ) : null}
        </div>
        <div className="space-y-2 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
          <Label htmlFor="recover">Already have a profile?</Label>
          <div className="flex gap-2">
            <Input
              id="recover"
              value={recoverCode}
              onChange={(e) => {
                setRecoverCode(e.target.value);
                setRecoverError("");
              }}
              placeholder="XXXXXX-XXXXXX-XXXXXX-XXXXXX"
              className="font-mono"
            />
            <Button
              variant="secondary"
              onClick={() => {
                void recoverWithCode(recoverCode).then((res) => {
                  if (!res.ok) setRecoverError("That code did not match any profile.");
                });
              }}
            >
              Open
            </Button>
          </div>
          {recoverError ? <p className="text-sm text-destructive">{recoverError}</p> : null}
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-lg space-y-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Profile</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">You, in PyDuke</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Progress lives on the server under this profile — safe to close the tab, and recoverable
          on another device with your code.
        </p>
      </header>
      <div className="space-y-2">
        <Label htmlFor="name">What should PyDuke call you?</Label>
        <div className="flex gap-2">
          <Input
            id="name"
            value={nameDraft}
            onChange={(e) => setNameDraft(e.target.value)}
            placeholder={profile.displayName || "A name, or leave blank"}
          />
          <Button onClick={() => void rename(nameDraft.trim())} variant="secondary">
            Save
          </Button>
        </div>
      </div>
      <dl className="grid grid-cols-2 gap-3">
        <Row k="Level" v={String(levelFromXp(xp))} />
        <Row k="XP" v={String(xp)} />
        <Row k="Streak" v={String(streak)} />
        <Row k="Adapted difficulty" v={preferred} />
      </dl>
      <p className="text-sm leading-relaxed text-muted-foreground">
        Difficulty adapts from your last few checks: three successes climb, three misses ease off.
        PyDuke will not skip lists as if you had never seen them, and it will not pretend you have
        finished tuples until you have.
      </p>
      <div className="flex flex-wrap gap-2">
        <Button variant="outline" onClick={signOutProfile}>
          Open a different profile
        </Button>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button variant="outline">Reset progress</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reset this profile?</DialogTitle>
              <DialogDescription>
                Lessons, games, typing history, and XP return to the arrival state (lists as the
                live lesson, earlier topics mastered). Your name is kept.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="secondary" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={() => {
                  reset();
                  setOpen(false);
                }}
              >
                Reset
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <dt className="text-xs text-muted-foreground">{k}</dt>
      <dd className="mt-1 font-medium capitalize tabular-nums">{v}</dd>
    </div>
  );
}
