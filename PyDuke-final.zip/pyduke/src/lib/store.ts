import { create } from "zustand";
import { todayKey, levelFromXp } from "@/lib/utils";
import { MASTERED_ON_ARRIVAL, START_TOPIC, TOPICS } from "@/lib/content/topics";
import { LESSONS } from "@/lib/content/lessons";
import {
  completeGameItemFn,
  completeLessonFn,
  completeProjectFn,
  deleteSnippetFn,
  getProgressStateFn,
  pushTutorMessageFn,
  recordExerciseFn,
  recordTypingFn,
  resetProgressFn,
  saveSnippetFn,
  tickStreakFn,
} from "@/lib/progress/server";
import { getProfileFn, renameProfileFn } from "@/lib/profile/server";
import type {
  ChatMessage,
  Difficulty,
  GameProgress,
  SavedSnippet,
  TopicId,
  TopicProgress,
  TypingRecord,
} from "@/lib/types";

/**
 * Zustand is the CLIENT CACHE. The source of truth is PostgreSQL behind the
 * server functions in @/lib/progress/server. Every action below:
 *   1. applies the same optimistic local update as the original store, and
 *   2. persists to PostgreSQL (fire-and-forget; failures never block the UI,
 *      and the next hydration reconciles with the server).
 */

const XP_FOR: Record<Difficulty, number> = {
  easy: 12,
  medium: 20,
  hard: 32,
  advanced: 48,
};

/** Fire-and-forget persistence that never rejects. */
function persist(p: Promise<unknown>) {
  void p.catch(() => undefined);
}

function emptyTopics(): Record<TopicId, TopicProgress> {
  const now = Date.now();
  const out = {} as Record<TopicId, TopicProgress>;
  for (const t of TOPICS) {
    let status: TopicProgress["status"] = "locked";
    if (MASTERED_ON_ARRIVAL.includes(t.id)) status = "mastered";
    else if (t.id === START_TOPIC) status = "in_progress";
    out[t.id] = {
      status,
      score: status === "mastered" ? 100 : 0,
      attempts: 0,
      lastSeenAt:
        t.id === "loops"
          ? now - 86400000 * 2
          : status === "mastered"
            ? now
            : 0,
      completedExercises: [],
      mistakes: [],
    };
  }
  return out;
}

export const EMPTY_IDS: string[] = [];

export function dueTopicIds(topics: Record<TopicId, TopicProgress>): TopicId[] {
  const now = Date.now();
  const due: TopicId[] = [];
  for (const t of TOPICS) {
    const p = topics[t.id];
    if (!p || p.status !== "mastered") continue;
    const age = now - (p.lastSeenAt || 0);
    if (age > 1000 * 60 * 60 * 36) due.push(t.id);
  }
  return due;
}

export interface HelixState {
  name: string;
  xp: number;
  streak: number;
  lastActiveDate: string;
  currentTopicId: TopicId;
  preferredDifficulty: Difficulty;
  recentResults: boolean[];
  topics: Record<TopicId, TopicProgress>;
  games: Record<string, GameProgress>;
  projectsCompleted: string[];
  typingHistory: TypingRecord[];
  snippets: SavedSnippet[];
  tutor: ChatMessage[];
  lessonsCompleted: TopicId[];
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  setName: (name: string) => void;
  tickStreak: () => void;
  awardXp: (n: number) => void;
  recordExercise: (opts: {
    topicId: TopicId;
    exerciseId: string;
    ok: boolean;
    difficulty: Difficulty;
    note?: string;
    code?: string;
    errorMessage?: string;
  }) => void;
  completeLesson: (topicId: TopicId) => void;
  completeGameItem: (gameId: string, itemId: string, score?: number) => void;
  completeProject: (projectId: string) => void;
  recordTyping: (rec: TypingRecord) => void;
  saveSnippet: (title: string, code: string) => void;
  deleteSnippet: (id: string) => void;
  pushTutor: (msg: Omit<ChatMessage, "id" | "at">) => void;
  resetProgress: () => void;
  dueRevision: () => TopicId[];
  unlockNext: (topicId: TopicId) => void;
}

const initialSlice = () => ({
  name: "",
  xp: 0,
  streak: 0,
  lastActiveDate: todayKey(),
  currentTopicId: START_TOPIC as TopicId,
  preferredDifficulty: "medium" as Difficulty,
  recentResults: [] as boolean[],
  topics: emptyTopics(),
  games: {} as Record<string, GameProgress>,
  projectsCompleted: [] as string[],
  typingHistory: [] as TypingRecord[],
  snippets: [] as SavedSnippet[],
  tutor: [] as ChatMessage[],
  lessonsCompleted: [...MASTERED_ON_ARRIVAL] as TopicId[],
  hydrated: false,
});

export const useHelix = create<HelixState>()((set, get) => ({
  ...initialSlice(),
  setHydrated: (v) => set({ hydrated: v }),
  setName: (name) => {
    set({ name });
    persist(renameProfileFn({ data: { displayName: name } }));
  },
  tickStreak: () => {
    const today = todayKey();
    const last = get().lastActiveDate;
    if (last === today) return;
    const yest = new Date();
    yest.setDate(yest.getDate() - 1);
    const yestKey = todayKey(yest);
    set({
      lastActiveDate: today,
      streak: last === yestKey ? get().streak + 1 : 1,
    });
    persist(tickStreakFn());
  },
  awardXp: (n) => set({ xp: get().xp + n }),
  recordExercise: ({ topicId, exerciseId, ok, difficulty, note, code, errorMessage }) => {
    const topics = { ...get().topics };
    const t = { ...topics[topicId] };
    t.attempts += 1;
    t.lastSeenAt = Date.now();
    if (ok && !t.completedExercises.includes(exerciseId)) {
      t.completedExercises = [...t.completedExercises, exerciseId];
      t.score = Math.min(
        100,
        t.score + (difficulty === "easy" ? 15 : difficulty === "medium" ? 22 : 30),
      );
    }
    if (!ok && note) {
      t.mistakes = [...t.mistakes.slice(-11), { exerciseId, note, at: Date.now() }];
    }
    if (t.status === "locked" || t.status === "available") t.status = "in_progress";
    topics[topicId] = t;
    const recent = [...get().recentResults, ok].slice(-6);
    let preferred = get().preferredDifficulty;
    const last3 = recent.slice(-3);
    if (last3.length === 3 && last3.every(Boolean)) {
      preferred =
        preferred === "easy" ? "medium" : preferred === "medium" ? "hard" : "advanced";
    }
    if (last3.length === 3 && last3.every((x) => !x)) {
      preferred =
        preferred === "advanced" ? "hard" : preferred === "hard" ? "medium" : "easy";
    }
    set({
      topics,
      recentResults: recent,
      preferredDifficulty: preferred,
      currentTopicId: topicId,
      xp: get().xp + (ok ? XP_FOR[difficulty] : 4),
    });
    persist(
      recordExerciseFn({ data: { topicId, exerciseId, ok, difficulty, note, code, errorMessage } }),
    );
  },
  completeLesson: (topicId) => {
    const topics = { ...get().topics };
    const t = {
      ...topics[topicId],
      status: "mastered" as const,
      score: 100,
      lastSeenAt: Date.now(),
    };
    topics[topicId] = t;
    const done = get().lessonsCompleted.includes(topicId)
      ? get().lessonsCompleted
      : [...get().lessonsCompleted, topicId];
    set({ topics, lessonsCompleted: done, xp: get().xp + 40, currentTopicId: topicId });
    get().unlockNext(topicId);
    persist(completeLessonFn({ data: { topicId } }));
  },
  unlockNext: (topicId) => {
    const idx = TOPICS.findIndex((t) => t.id === topicId);
    const next = TOPICS[idx + 1];
    if (!next) return;
    const topics = { ...get().topics };
    const cur = topics[next.id];
    if (cur.status === "locked") {
      topics[next.id] = { ...cur, status: "available" };
      set({ topics });
    }
  },
  completeGameItem: (gameId, itemId, score = 1) => {
    const games = { ...get().games };
    const g = games[gameId] ?? { completed: [], best: {} };
    const completed = g.completed.includes(itemId) ? g.completed : [...g.completed, itemId];
    const best = { ...g.best, [itemId]: Math.max(g.best[itemId] ?? 0, score) };
    games[gameId] = { completed, best };
    const already = g.completed.includes(itemId);
    set({ games, xp: get().xp + (already ? 4 : 18) });
    persist(completeGameItemFn({ data: { gameId, itemId, score } }));
  },
  completeProject: (projectId) => {
    if (get().projectsCompleted.includes(projectId)) {
      set({ xp: get().xp + 8 });
      persist(completeProjectFn({ data: { projectId } }));
      return;
    }
    set({
      projectsCompleted: [...get().projectsCompleted, projectId],
      xp: get().xp + 80,
    });
    persist(completeProjectFn({ data: { projectId } }));
  },
  recordTyping: (rec) => {
    const xp = rec.accuracy >= 95 ? 16 : rec.accuracy >= 85 ? 10 : 4;
    set({ typingHistory: [...get().typingHistory.slice(-79), rec], xp: get().xp + xp });
    persist(recordTypingFn({ data: rec }));
  },
  saveSnippet: (title, code) => {
    const item: SavedSnippet = {
      id: `${Date.now()}`,
      title: title.trim() || "Untitled",
      code,
      at: Date.now(),
    };
    set({ snippets: [item, ...get().snippets].slice(0, 40) });
    persist(saveSnippetFn({ data: { id: item.id, title: item.title, code } }));
  },
  deleteSnippet: (id) => {
    set({ snippets: get().snippets.filter((s) => s.id !== id) });
    persist(deleteSnippetFn({ data: { id } }));
  },
  pushTutor: (msg) => {
    const item: ChatMessage = {
      ...msg,
      id: `${Date.now()}-${Math.random()}`,
      at: Date.now(),
    };
    set({ tutor: [...get().tutor, item].slice(-40) });
    persist(pushTutorMessageFn({ data: { role: msg.role, content: msg.content } }));
  },
  resetProgress: () => {
    const keepName = get().name;
    set({ ...initialSlice(), name: keepName, hydrated: true });
    persist(resetProgressFn());
  },
  dueRevision: () => dueTopicIds(get().topics),
}));

/**
 * Hydrate the client cache from PostgreSQL (profile + progress snapshot).
 * Called once on app mount (AppShell). With no profile yet, the defaults
 * stand and the Profile page offers creation.
 */
export async function hydrateFromServer(): Promise<void> {
  try {
    const profileRes = await getProfileFn();
    if (profileRes.ok) {
      const progressRes = await getProgressStateFn();
      if (progressRes.ok) {
        const s = progressRes.snapshot;
        useHelix.setState({
          name: profileRes.profile.displayName,
          xp: s.xp,
          streak: s.streak,
          lastActiveDate: s.lastActiveDate ?? todayKey(),
          currentTopicId: s.currentTopicId,
          preferredDifficulty: s.preferredDifficulty,
          recentResults: s.recentResults,
          topics: s.topics as Record<TopicId, TopicProgress>,
          games: s.games as Record<string, GameProgress>,
          projectsCompleted: s.projectsCompleted,
          typingHistory: s.typingHistory as TypingRecord[],
          snippets: s.snippets as SavedSnippet[],
          tutor: s.tutor as ChatMessage[],
          lessonsCompleted: TOPICS.filter(
            (t) => s.topics[t.id]?.status === "mastered",
          ).map((t) => t.id),
          hydrated: true,
        });
        return;
      }
    }
  } catch {
    // Server unreachable or no profile yet — keep optimistic defaults.
  }
  useHelix.setState({ hydrated: true });
}

export function progressSummary(s: HelixState) {
  const mastered = TOPICS.filter((t) => s.topics[t.id].status === "mastered").map((t) => t.title);
  const current = TOPICS.find((t) => t.id === s.currentTopicId)?.title ?? s.currentTopicId;
  const mistakes = Object.entries(s.topics)
    .flatMap(([id, p]) => p.mistakes.slice(-2).map((m) => `${id}: ${m.note}`))
    .slice(-6);
  const lesson = LESSONS[s.currentTopicId];
  return [
    `Learner name: ${s.name || "(not set)"}`,
    `XP: ${s.xp}, level: ${levelFromXp(s.xp)}, streak: ${s.streak}`,
    `Current topic: ${current}`,
    `Mastered: ${mastered.join(", ") || "none"}`,
    `Preferred difficulty: ${s.preferredDifficulty}`,
    `Typing last WPM: ${s.typingHistory.at(-1)?.wpm ?? "n/a"} accuracy ${s.typingHistory.at(-1)?.accuracy ?? "n/a"}`,
    `Recent mistakes: ${mistakes.join(" | ") || "none recorded"}`,
    `Lesson heading: ${lesson.concept.heading}`,
  ].join("\n");
}
