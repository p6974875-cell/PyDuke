import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Gemini tutor RPC (client-importable). Mirrors the original ask-tutor
 * pattern: the handler body is extracted into the server bundle by the
 * TanStack Start compiler, so server-only imports happen lazily (dynamic
 * import) inside the handler and never reach the client.
 *
 * GEMINI_API_KEY is read from process.env server-side only — never prefixed
 * with VITE_ (it must not reach client bundles).
 *
 * Hybrid policy (spec §12): the SERVER decides how strong a hint may be,
 * based on the attempt count for the current exercise. The grader — not
 * Gemini — remains the judge of correctness; Gemini output is advisory.
 */

type Msg = { role: "user" | "assistant"; content: string };

const BASE_SYSTEM = `You are PyDuke, an educational Python tutor.
The learner already knows lists, variables, I/O, operators, conditions, and loops. Do not restart from "hello world".
Use simple language without talking down. Use standard terms (mutable, iterable, hashable, suite, binding) and define them once. Prefer short examples.

Rules:
- For exercises: inspect the student's attempt, explain errors, and give progressively stronger hints. Do not immediately provide the complete solution.
- For general tutoring: answer Python questions directly; provide complete examples when useful.
- Never claim that code passed unless the grading system says it passed.
- Never execute code yourself.
- Never request secrets, API keys, passwords, or private credentials.
- Never instruct Python code to access the host operating system, server secrets, or unauthorized external resources.`;

const HINT_POLICIES = [
  "HINT LEVEL 1 (first attempts): give a conceptual hint only — name the idea or tool, never the code.",
  "HINT LEVEL 2: give a targeted hint — point at the construct or line approach, still no full code.",
  "HINT LEVEL 3: identify the likely mistake in their latest attempt and explain the correction in words; a tiny fragment is allowed.",
  "HINT LEVEL 4 (many failed attempts): give detailed guidance, and only now the full solution with explanation.",
];

const requestSchema = z.object({
  messages: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(6000) }))
    .max(12),
  progressSummary: z.string().max(3000).optional(),
  context: z
    .object({
      topic: z.string().optional(),
      lesson: z.string().optional(),
      exercise: z.string().optional(),
      attempts: z.number().int().min(0).max(999).optional(),
      passed: z.boolean().optional(),
      latestCode: z.string().max(8000).optional(),
      gradingResult: z.string().max(2000).optional(),
      recentMistakes: z.array(z.string().max(300)).max(6).optional(),
      difficulty: z.string().max(20).optional(),
    })
    .optional(),
});

export type TutorContext = z.infer<typeof requestSchema>["context"];

function env(key: string): string | undefined {
  const v = process.env[key]?.trim();
  return v || undefined;
}

function hintPolicy(attempts: number | undefined): string {
  const n = attempts ?? 0;
  if (n <= 0) return HINT_POLICIES[0]!;
  if (n === 1) return HINT_POLICIES[1]!;
  if (n === 2) return HINT_POLICIES[2]!;
  return HINT_POLICIES[3]!;
}

function compactContext(ctx: TutorContext): string {
  if (!ctx) return "";
  const lines: string[] = [];
  if (ctx.topic) lines.push(`Topic: ${ctx.topic}`);
  if (ctx.lesson) lines.push(`Lesson: ${ctx.lesson}`);
  if (ctx.exercise) lines.push(`Exercise: ${ctx.exercise}`);
  if (ctx.attempts !== undefined) lines.push(`Attempts on this exercise: ${ctx.attempts}`);
  if (ctx.passed !== undefined) lines.push(`Grading says passed: ${ctx.passed}`);
  if (ctx.difficulty) lines.push(`Difficulty level: ${ctx.difficulty}`);
  if (ctx.recentMistakes?.length) lines.push(`Recent mistakes: ${ctx.recentMistakes.join(" | ")}`);
  if (ctx.latestCode) lines.push(`Student's latest code:\n${ctx.latestCode}`);
  if (ctx.gradingResult) lines.push(`Latest grading result: ${ctx.gradingResult}`);
  return lines.join("\n");
}

async function askGemini(
  apiKey: string,
  system: string,
  trimmed: Msg[],
): Promise<{ ok: true; text: string } | { ok: false; error: string }> {
  const model = env("GEMINI_MODEL") || "gemini-flash-latest";
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-goog-api-key": apiKey },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: system }] },
        contents: trimmed.map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }],
        })),
        generationConfig: { temperature: 0.4, maxOutputTokens: 700 },
      }),
    },
  );
  if (!res.ok) {
    return { ok: false, error: `Gemini API error ${res.status}` };
  }
  const body = (await res.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  const text = body.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
  return { ok: true, text };
}

async function persistTutorMessages(
  profileId: string,
  userText: string,
  assistantText: string,
  ctx: TutorContext,
) {
  try {
    // Server-only modules, imported lazily so they never reach client bundles.
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    let rows = await sql.query<{ id: string }>(
      "select id from tutor_conversations where profile_id = $1 order by updated_at desc limit 1",
      [profileId],
    );
    if (!rows.length) {
      rows = await sql.query<{ id: string }>(
        "insert into tutor_conversations (profile_id, title) values ($1, $2) returning id",
        [profileId, ctx?.exercise ?? ctx?.lesson ?? ctx?.topic ?? "Tutor"],
      );
    }
    const conversationId = rows[0]!.id;
    await sql.query(
      "insert into tutor_messages (conversation_id, role, content, context) values ($1, 'user', $2, $3::jsonb), ($1, 'assistant', $4, $3::jsonb)",
      [conversationId, userText, JSON.stringify(ctx ?? {}), assistantText],
    );
    await sql.query("update tutor_conversations set updated_at = now() where id = $1", [
      conversationId,
    ]);
    await sql.query(
      "insert into learning_events (profile_id, event_type, metadata) values ($1, 'tutor_message', $2::jsonb)",
      [profileId, JSON.stringify({ exercise: ctx?.exercise ?? null })],
    );
  } catch {
    // Tutor persistence is best-effort; never block the reply.
  }
}

export const askTutor = createServerFn({ method: "POST" })
  .validator(requestSchema)
  .handler(async ({ data }) => {
    const geminiKey = env("GEMINI_API_KEY");

    const system = [
      BASE_SYSTEM,
      data.context ? `Learner context:\n${compactContext(data.context)}` : "",
      data.context?.exercise ? hintPolicy(data.context.attempts) : "",
      data.progressSummary ? `Learner progress:\n${data.progressSummary}` : "",
    ]
      .filter(Boolean)
      .join("\n\n");

    const trimmed = data.messages.slice(-8).map((m) => ({
      role: m.role,
      content: m.content.slice(0, 4000),
    }));

    if (geminiKey) {
      const result = await askGemini(geminiKey, system, trimmed);
      if (result.ok && trimmed.length) {
        let profileId: string | null = null;
        try {
          const { currentProfileId } = await import("@/lib/profile/logic.server");
          profileId = await currentProfileId();
        } catch {
          profileId = null;
        }
        if (profileId) {
          const lastUser = [...trimmed].reverse().find((m) => m.role === "user");
          if (lastUser) {
            void persistTutorMessages(profileId, lastUser.content, result.text, data.context);
          }
        }
      }
      return result;
    }

    return { ok: false as const, error: "unavailable" };
  });
