import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  attemptValidator,
  completeGameItem,
  completeLesson,
  completeProject,
  currentProfileId,
  deleteSnippet,
  loadSnapshot,
  logEvent,
  pushTutorMessage,
  recordExercise,
  recordTyping,
  resetProgress,
  saveSnippet,
  tickStreak,
} from "./logic.server";

/**
 * Progress RPC surface (client-importable). All logic lives in
 * ./logic.server.ts — this file only defines createServerFn handlers so the
 * compiler strips server code from client bundles.
 */

export const getProgressStateFn = createServerFn({ method: "GET" }).handler(async () => {
  const id = await currentProfileId();
  if (!id) return { ok: false as const, error: "no_profile" };
  const snapshot = await loadSnapshot(id);
  return { ok: true as const, snapshot };
});

export const tickStreakFn = createServerFn({ method: "POST" }).handler(async () => {
  return tickStreak();
});

export const recordExerciseFn = createServerFn({ method: "POST" })
  .validator(attemptValidator)
  .handler(async ({ data }) => recordExercise(data));

export const completeLessonFn = createServerFn({ method: "POST" })
  .validator(z.object({ topicId: z.string() }))
  .handler(async ({ data }) => completeLesson(data.topicId));

export const completeGameItemFn = createServerFn({ method: "POST" })
  .validator(
    z.object({ gameId: z.string(), itemId: z.string(), score: z.number().optional() }),
  )
  .handler(async ({ data }) => completeGameItem(data));

export const completeProjectFn = createServerFn({ method: "POST" })
  .validator(z.object({ projectId: z.string() }))
  .handler(async ({ data }) => completeProject(data.projectId));

export const recordTypingFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      drillId: z.string(),
      wpm: z.number().int().min(0).max(400),
      cpm: z.number().int().min(0).max(2000),
      accuracy: z.number().min(0).max(100),
      errors: z.number().int().min(0),
      chars: z.number().int().min(0),
    }),
  )
  .handler(async ({ data }) => recordTyping(data));

export const saveSnippetFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      id: z.string().max(64),
      title: z.string().max(120),
      code: z.string().max(20000),
    }),
  )
  .handler(async ({ data }) => saveSnippet(data));

export const deleteSnippetFn = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => deleteSnippet(data.id));

export const pushTutorMessageFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      role: z.enum(["user", "assistant"]),
      content: z.string().max(8000),
      context: z.record(z.string(), z.unknown()).optional(),
    }),
  )
  .handler(async ({ data }) => pushTutorMessage(data));

export const logLearningEventFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      eventType: z.string().max(60),
      topicId: z.string().optional(),
      exerciseId: z.string().optional(),
      projectId: z.string().optional(),
      metadata: z.record(z.string(), z.unknown()).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const id = await currentProfileId();
    if (!id) return { ok: false as const, error: "no_profile" };
    await logEvent(id, data.eventType, {
      topicId: data.topicId,
      exerciseId: data.exerciseId,
      projectId: data.projectId,
      metadata: data.metadata,
    });
    return { ok: true as const };
  });

export const resetProgressFn = createServerFn({ method: "POST" }).handler(async () => {
  return resetProgress();
});
