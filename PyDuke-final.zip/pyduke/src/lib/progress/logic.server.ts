import { z } from "zod";
import { getSql } from "@/lib/db";
import { currentProfileId, requireProfileId } from "@/lib/profile/logic.server";
import { LESSONS } from "@/lib/content/lessons";
import { MASTERED_ON_ARRIVAL, START_TOPIC, TOPICS } from "@/lib/content/topics";
import type { Difficulty, TopicId, TopicProgress, TopicStatus } from "@/lib/types";

/**
 * Server-only progress logic (.server.ts — stripped from client bundles).
 * The RPC surface clients import lives in ./server.ts.
 *
 * PostgreSQL (Neon in production, PGLite in preview) is the source of truth;
 * the Zustand store is a client cache that optimistically mirrors these
 * operations.
 */

const XP_FOR: Record<Difficulty, number> = {
  easy: 12,
  medium: 20,
  hard: 32,
  advanced: 48,
};

function todayKey(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function defaultTopics(): Record<string, TopicProgress> {
  const now = Date.now();
  const out: Record<string, TopicProgress> = {};
  for (const t of TOPICS) {
    let status: TopicStatus = "locked";
    if (MASTERED_ON_ARRIVAL.includes(t.id)) status = "mastered";
    else if (t.id === START_TOPIC) status = "in_progress";
    out[t.id] = {
      status,
      score: status === "mastered" ? 100 : 0,
      attempts: 0,
      lastSeenAt:
        t.id === "loops" ? now - 86400000 * 2 : status === "mastered" ? now : 0,
      completedExercises: [],
      mistakes: [],
    };
  }
  return out;
}

export interface ProgressSnapshot {
  xp: number;
  streak: number;
  lastActiveDate: string | null;
  currentTopicId: TopicId;
  preferredDifficulty: Difficulty;
  recentResults: boolean[];
  topics: Record<string, TopicProgress>;
  games: Record<string, { completed: string[]; best: Record<string, number> }>;
  projectsCompleted: string[];
  typingHistory: {
    at: number;
    wpm: number;
    cpm: number;
    accuracy: number;
    errors: number;
    chars: number;
    drillId: string;
  }[];
  snippets: { id: string; title: string; code: string; at: number }[];
  tutor: { id: string; role: "user" | "assistant"; content: string; at: number }[];
}

type StatsRow = {
  xp: number;
  streak: number;
  last_active_date: string | null;
  current_topic_id: string | null;
  preferred_difficulty: string;
  recent_results: unknown;
};

type LessonRow = {
  lesson_id: string;
  status: TopicStatus;
  progress_percent: number;
  attempts: number;
  completed_exercises: unknown;
  mistakes: unknown;
  last_seen_at: string | null;
};

export async function loadSnapshot(profileId: string): Promise<ProgressSnapshot> {
  const sql = await getSql();
  const [statsRes, lessonsRes, projectsRes, gamesRes, typingRows, snippetRows] =
    await Promise.all([
      sql.query<StatsRow>("select * from profile_stats where profile_id = $1", [profileId]),
      sql.query<LessonRow>("select * from lesson_progress where profile_id = $1", [profileId]),
      sql.query<{ project_id: string }>(
        "select project_id from project_progress where profile_id = $1 and status = 'completed'",
        [profileId],
      ),
      sql.query<{ game_id: string; completed: unknown; best: unknown }>(
        "select game_id, completed, best from game_progress where profile_id = $1",
        [profileId],
      ),
      sql.query<{
        drill_id: string;
        wpm: number;
        cpm: number;
        accuracy: number;
        errors: number;
        chars: number;
        created_at: string;
      }>(
        "select drill_id, wpm, cpm, accuracy, errors, chars, created_at from typing_sessions where profile_id = $1 order by created_at desc limit 80",
        [profileId],
      ),
      sql.query<{ id: string; title: string; code: string; created_at: string }>(
        "select id, title, code, created_at from snippets where profile_id = $1 order by created_at desc limit 40",
        [profileId],
      ),
    ]);

  const stats = statsRes[0];
  const topics = defaultTopics();
  for (const row of lessonsRes) {
    topics[row.lesson_id] = {
      status: row.status,
      score: Number(row.progress_percent),
      attempts: Number(row.attempts),
      lastSeenAt: row.last_seen_at ? new Date(row.last_seen_at).getTime() : 0,
      completedExercises: Array.isArray(row.completed_exercises)
        ? (row.completed_exercises as string[])
        : [],
      mistakes: Array.isArray(row.mistakes) ? (row.mistakes as TopicProgress["mistakes"]) : [],
    };
  }

  const games: ProgressSnapshot["games"] = {};
  for (const g of gamesRes) {
    games[g.game_id] = {
      completed: Array.isArray(g.completed) ? (g.completed as string[]) : [],
      best: g.best && typeof g.best === "object" ? (g.best as Record<string, number>) : {},
    };
  }

  return {
    xp: Number(stats?.xp ?? 0),
    streak: Number(stats?.streak ?? 0),
    lastActiveDate: stats?.last_active_date ?? null,
    currentTopicId: (stats?.current_topic_id as TopicId | null) ?? START_TOPIC,
    preferredDifficulty: (stats?.preferred_difficulty as Difficulty) ?? "medium",
    recentResults: Array.isArray(stats?.recent_results)
      ? (stats!.recent_results as boolean[])
      : [],
    topics,
    games,
    projectsCompleted: projectsRes.map((r) => r.project_id),
    typingHistory: typingRows
      .slice()
      .reverse()
      .map((t) => ({
        at: new Date(t.created_at).getTime(),
        wpm: Number(t.wpm),
        cpm: Number(t.cpm),
        accuracy: Number(t.accuracy),
        errors: Number(t.errors),
        chars: Number(t.chars),
        drillId: t.drill_id,
      })),
    snippets: snippetRows.map((s) => ({
      id: s.id,
      title: s.title,
      code: s.code,
      at: new Date(s.created_at).getTime(),
    })),
    tutor: [],
  };
}

/** Touch streak/last-active; idempotent per day. */
export async function tickStreak(): Promise<{ ok: true; streak: number }> {
  const id = await requireProfileId();
  const sql = await getSql();
  const today = todayKey();
  const rows = await sql.query<{ streak: number; last_active_date: string | null }>(
    "select streak, last_active_date from profile_stats where profile_id = $1",
    [id],
  );
  const row = rows[0];
  if (!row) return { ok: true, streak: 0 };
  if (row.last_active_date === today) return { ok: true, streak: Number(row.streak) };
  const yesterday = todayKey(new Date(Date.now() - 86400000));
  const streak = row.last_active_date === yesterday ? Number(row.streak) + 1 : 1;
  await sql.query(
    "update profile_stats set streak = $2, last_active_date = $3, updated_at = now() where profile_id = $1",
    [id, streak, today],
  );
  return { ok: true, streak };
}

export type AttemptInput = {
  topicId: string;
  exerciseId: string;
  ok: boolean;
  difficulty: Difficulty;
  note?: string;
  code?: string;
  errorMessage?: string;
};

/** Record an exercise attempt: attempt row + topic progress + adaptive XP. */
export async function recordExercise(data: AttemptInput) {
  const id = await requireProfileId();
  const sql = await getSql();

  await sql.query(
    `insert into exercise_attempts (profile_id, exercise_id, topic_id, passed, code, error_message)
     values ($1, $2, $3, $4, $5, $6)`,
    [id, data.exerciseId, data.topicId, data.ok, data.code ?? null, data.errorMessage ?? null],
  );

  const existing = await sql.query<LessonRow>(
    "select * from lesson_progress where profile_id = $1 and lesson_id = $2",
    [id, data.topicId],
  );
  const prev = existing[0];
  const completed: string[] =
    prev && Array.isArray(prev.completed_exercises)
      ? (prev.completed_exercises as string[])
      : [];
  const mistakes: { exerciseId: string; note: string; at: number }[] =
    prev && Array.isArray(prev.mistakes) ? (prev.mistakes as typeof mistakes) : [];

  const alreadyDone = completed.includes(data.exerciseId);
  if (data.ok && !alreadyDone) completed.push(data.exerciseId);
  if (!data.ok && data.note) {
    mistakes.push({ exerciseId: data.exerciseId, note: data.note, at: Date.now() });
    if (mistakes.length > 12) mistakes.shift();
  }

  const attempts = Number(prev?.attempts ?? 0) + 1;
  const scoreGain =
    data.ok && !alreadyDone
      ? data.difficulty === "easy"
        ? 15
        : data.difficulty === "medium"
          ? 22
          : 30
      : 0;
  const prevScore = Number(prev?.progress_percent ?? 0);
  const score = Math.min(100, prevScore + scoreGain);
  const status: TopicStatus =
    !prev || prev.status === "locked" || prev.status === "available"
      ? "in_progress"
      : prev.status;

  await sql.query(
    `insert into lesson_progress
       (profile_id, lesson_id, status, progress_percent, attempts, completed_exercises, mistakes, last_seen_at, updated_at)
     values ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, now(), now())
     on conflict (profile_id, lesson_id) do update set
       status = excluded.status,
       progress_percent = excluded.progress_percent,
       attempts = excluded.attempts,
       completed_exercises = excluded.completed_exercises,
       mistakes = excluded.mistakes,
       last_seen_at = now(),
       updated_at = now()`,
    [
      id,
      data.topicId,
      status,
      score,
      attempts,
      JSON.stringify(completed),
      JSON.stringify(mistakes),
    ],
  );

  // Adaptive difficulty + XP mirror the original client logic.
  const statsRes = await sql.query<StatsRow>("select * from profile_stats where profile_id = $1", [id]);
  const stats = statsRes[0];
  const recent = [
    ...(Array.isArray(stats?.recent_results) ? (stats!.recent_results as boolean[]) : []),
    data.ok,
  ].slice(-6);
  let preferred = (stats?.preferred_difficulty as Difficulty) ?? "medium";
  const last3 = recent.slice(-3);
  if (last3.length === 3 && last3.every(Boolean)) {
    preferred = preferred === "easy" ? "medium" : preferred === "medium" ? "hard" : "advanced";
  }
  if (last3.length === 3 && last3.every((x) => !x)) {
    preferred = preferred === "advanced" ? "hard" : preferred === "hard" ? "medium" : "easy";
  }
  const xpGain = data.ok ? XP_FOR[data.difficulty] : 4;
  await sql.query(
    `update profile_stats set
       xp = xp + $2,
       preferred_difficulty = $3,
       recent_results = $4::jsonb,
       current_topic_id = $5,
       updated_at = now()
     where profile_id = $1`,
    [id, xpGain, preferred, JSON.stringify(recent), data.topicId],
  );

  await logEvent(id, data.ok ? "exercise_passed" : "exercise_failed", {
    topicId: data.topicId,
    exerciseId: data.exerciseId,
    metadata: { difficulty: data.difficulty },
  });

  return { ok: true as const, xpGain, score, completed, mistakes };
}

export async function completeLesson(topicId: string) {
  const id = await requireProfileId();
  const sql = await getSql();
  await sql.query(
    `insert into lesson_progress
       (profile_id, lesson_id, status, progress_percent, completed_exercises, last_seen_at, updated_at)
     values ($1, $2, 'mastered', 100, '[]'::jsonb, now(), now())
     on conflict (profile_id, lesson_id) do update set
       status = 'mastered', progress_percent = 100, last_seen_at = now(), updated_at = now()`,
    [id, topicId],
  );
  await sql.query(
    "update profile_stats set xp = xp + 40, current_topic_id = $2, updated_at = now() where profile_id = $1",
    [id, topicId],
  );
  // Unlock the next topic in path order.
  const idx = TOPICS.findIndex((t) => t.id === topicId);
  const next = TOPICS[idx + 1];
  if (next) {
    await sql.query(
      `insert into lesson_progress (profile_id, lesson_id, status, updated_at)
       values ($1, $2, 'available', now())
       on conflict (profile_id, lesson_id) do update set
         status = case when lesson_progress.status = 'locked' then 'available' else lesson_progress.status end,
         updated_at = now()`,
      [id, next.id],
    );
  }
  await logEvent(id, "lesson_completed", { topicId });
  return { ok: true as const };
}

export async function completeGameItem(data: {
  gameId: string;
  itemId: string;
  score?: number;
}) {
  const id = await requireProfileId();
  const sql = await getSql();
  const rows = await sql.query<{ completed: unknown; best: unknown }>(
    "select completed, best from game_progress where profile_id = $1 and game_id = $2",
    [id, data.gameId],
  );
  const completed: string[] =
    rows[0] && Array.isArray(rows[0]!.completed) ? (rows[0]!.completed as string[]) : [];
  const best: Record<string, number> =
    rows[0] && rows[0]!.best && typeof rows[0]!.best === "object"
      ? (rows[0]!.best as Record<string, number>)
      : {};
  const already = completed.includes(data.itemId);
  if (!already) completed.push(data.itemId);
  best[data.itemId] = Math.max(best[data.itemId] ?? 0, data.score ?? 1);
  await sql.query(
    `insert into game_progress (profile_id, game_id, completed, best, updated_at)
     values ($1, $2, $3::jsonb, $4::jsonb, now())
     on conflict (profile_id, game_id) do update set
       completed = excluded.completed, best = excluded.best, updated_at = now()`,
    [id, data.gameId, JSON.stringify(completed), JSON.stringify(best)],
  );
  await sql.query(
    "update profile_stats set xp = xp + $2, updated_at = now() where profile_id = $1",
    [id, already ? 4 : 18],
  );
  await logEvent(id, "game_completed", {
    metadata: { gameId: data.gameId, itemId: data.itemId },
  });
  return { ok: true as const };
}

export async function completeProject(projectId: string) {
  const id = await requireProfileId();
  const sql = await getSql();
  const res = await sql.query<{ project_id: string }>(
    "select project_id from project_progress where profile_id = $1 and project_id = $2 and status = 'completed'",
    [id, projectId],
  );
  const already = res.length > 0;
  await sql.query(
    `insert into project_progress (profile_id, project_id, status, progress_percent, updated_at)
     values ($1, $2, 'completed', 100, now())
     on conflict (profile_id, project_id) do update set
       status = 'completed', progress_percent = 100, updated_at = now()`,
    [id, projectId],
  );
  await sql.query(
    "update profile_stats set xp = xp + $2, updated_at = now() where profile_id = $1",
    [id, already ? 8 : 80],
  );
  await logEvent(id, "project_completed", { projectId });
  return { ok: true as const };
}

export type TypingInput = {
  drillId: string;
  wpm: number;
  cpm: number;
  accuracy: number;
  errors: number;
  chars: number;
};

export async function recordTyping(data: TypingInput) {
  const id = await requireProfileId();
  const sql = await getSql();
  await sql.query(
    `insert into typing_sessions (profile_id, drill_id, wpm, cpm, accuracy, errors, chars)
     values ($1, $2, $3, $4, $5, $6, $7)`,
    [id, data.drillId, data.wpm, data.cpm, Math.round(data.accuracy), data.errors, data.chars],
  );
  const xp = data.accuracy >= 95 ? 16 : data.accuracy >= 85 ? 10 : 4;
  await sql.query(
    "update profile_stats set xp = xp + $2, updated_at = now() where profile_id = $1",
    [id, xp],
  );
  await logEvent(id, "typing_session", { metadata: { wpm: data.wpm, accuracy: data.accuracy } });
  return { ok: true as const, xp };
}

export async function saveSnippet(data: { id: string; title: string; code: string }) {
  const id = await requireProfileId();
  const sql = await getSql();
  await sql.query(
    `insert into snippets (id, profile_id, title, code) values ($1, $2, $3, $4)
     on conflict (id) do update set title = excluded.title, code = excluded.code`,
    [data.id, id, data.title, data.code],
  );
  return { ok: true as const };
}

export async function deleteSnippet(id: string) {
  const profileId = await requireProfileId();
  const sql = await getSql();
  await sql.query("delete from snippets where id = $1 and profile_id = $2", [id, profileId]);
  return { ok: true as const };
}

async function ensureConversation(profileId: string): Promise<string> {
  const sql = await getSql();
  const rows = await sql.query<{ id: string }>(
    "select id from tutor_conversations where profile_id = $1 order by updated_at desc limit 1",
    [profileId],
  );
  if (rows[0]) return rows[0]!.id;
  const created = await sql.query<{ id: string }>(
    "insert into tutor_conversations (profile_id, title) values ($1, 'Tutor') returning id",
    [profileId],
  );
  return created[0]!.id;
}

export async function pushTutorMessage(data: {
  role: "user" | "assistant";
  content: string;
  context?: unknown;
}) {
  const id = await requireProfileId();
  const conversationId = await ensureConversation(id);
  const sql = await getSql();
  await sql.query(
    "insert into tutor_messages (conversation_id, role, content, context) values ($1, $2, $3, $4::jsonb)",
    [conversationId, data.role, data.content, JSON.stringify(data.context ?? {})],
  );
  await sql.query("update tutor_conversations set updated_at = now() where id = $1", [
    conversationId,
  ]);
  return { ok: true as const };
}

export async function resetProgress() {
  const id = await requireProfileId();
  const sql = await getSql();
  await sql.query("delete from lesson_progress where profile_id = $1", [id]);
  await sql.query("delete from exercise_attempts where profile_id = $1", [id]);
  await sql.query("delete from project_progress where profile_id = $1", [id]);
  await sql.query("delete from game_progress where profile_id = $1", [id]);
  await sql.query("delete from typing_sessions where profile_id = $1", [id]);
  await sql.query("delete from snippets where profile_id = $1", [id]);
  await sql.query("delete from tutor_conversations where profile_id = $1", [id]);
  await sql.query("delete from learning_events where profile_id = $1", [id]);
  await sql.query(
    `update profile_stats set xp = 0, streak = 0, last_active_date = $2,
       current_topic_id = 'lists', preferred_difficulty = 'medium',
       recent_results = '[]'::jsonb, updated_at = now()
     where profile_id = $1`,
    [id, todayKey()],
  );
  // Re-seed the arrival state.
  for (const [topicId, p] of Object.entries(defaultTopics())) {
    await sql.query(
      `insert into lesson_progress (profile_id, lesson_id, status, progress_percent, last_seen_at, updated_at)
       values ($1, $2, $3, $4, $5, now())`,
      [id, topicId, p.status, p.score, p.lastSeenAt ? new Date(p.lastSeenAt) : null],
    );
  }
  return { ok: true as const };
}

export async function logEvent(
  profileId: string,
  eventType: string,
  opts: { topicId?: string; exerciseId?: string; projectId?: string; metadata?: unknown } = {},
) {
  const sql = await getSql();
  await sql.query(
    `insert into learning_events (profile_id, event_type, topic_id, exercise_id, project_id, metadata)
     values ($1, $2, $3, $4, $5, $6::jsonb)`,
    [
      profileId,
      eventType,
      opts.topicId ?? null,
      opts.exerciseId ?? null,
      opts.projectId ?? null,
      JSON.stringify(opts.metadata ?? {}),
    ],
  );
}

export { currentProfileId };
export const attemptValidator = z.object({
  topicId: z.string(),
  exerciseId: z.string(),
  ok: z.boolean(),
  difficulty: z.enum(["easy", "medium", "hard", "advanced"]),
  note: z.string().max(400).optional(),
  code: z.string().max(20000).optional(),
  errorMessage: z.string().max(2000).optional(),
});
