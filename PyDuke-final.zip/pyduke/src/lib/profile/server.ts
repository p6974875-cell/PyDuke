import { createServerFn } from "@tanstack/react-start";
import {
  createProfile,
  currentProfileId,
  getProfile,
  recoverProfile,
  renameProfile,
  requireProfileId,
  signProfileId,
} from "./logic.server";

/**
 * Profile RPC surface (client-importable). All logic lives in
 * ./logic.server.ts — this file only defines createServerFn handlers so the
 * compiler can strip server code from the client bundle.
 */

export const createProfileFn = createServerFn({ method: "POST" })
  .validator((input: { displayName?: string }) => input)
  .handler(async ({ data }): Promise<
    { ok: true; id: string; recoveryCode: string; cookieValue: string }
  | { ok: false; error: string }> => {
    try {
      const created = await createProfile(data?.displayName ?? "");
      return { ok: true, ...created, cookieValue: signProfileId(created.id) };
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : "create_failed" };
    }
  });

export const renameProfileFn = createServerFn({ method: "POST" })
  .validator((input: { displayName: string }) => input)
  .handler(async ({ data }) => {
    const id = await requireProfileId();
    await renameProfile(id, data.displayName);
    return { ok: true as const };
  });

export const recoverProfileFn = createServerFn({ method: "POST" })
  .validator((input: { code: string }) => input)
  .handler(async ({ data }): Promise<
    { ok: true; id: string; cookieValue: string } | { ok: false; error: string }
  > => {
    const id = await recoverProfile(data.code);
    if (!id) return { ok: false, error: "not_found" };
    return { ok: true, id, cookieValue: signProfileId(id) };
  });

export const getProfileFn = createServerFn({ method: "GET" }).handler(async () => {
  const id = await currentProfileId();
  if (!id) return { ok: false as const, error: "no_profile" };
  const profile = await getProfile(id);
  if (!profile) return { ok: false as const, error: "no_profile" };
  return { ok: true as const, profile };
});
