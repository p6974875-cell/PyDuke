import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  createProfileFn,
  getProfileFn,
  recoverProfileFn,
  renameProfileFn,
} from "@/lib/profile/server";

/**
 * Client side of the no-login profile system.
 *
 * The active profile id travels in a cookie whose value is signed on the
 * server (HMAC) — the browser can read it, but cannot forge one for an
 * arbitrary UUID. All persistent state lives in PostgreSQL behind the
 * server functions; this provider only holds the identity + profile cache.
 */

const COOKIE_NAME = "pyduke_profile";
const COOKIE_MAX_AGE = 60 * 60 * 24 * 365 * 2;

export function readProfileCookie(): string | null {
  if (typeof document === "undefined") return null;
  const match = document.cookie
    .split(";")
    .map((c) => c.trim())
    .find((c) => c.startsWith(`${COOKIE_NAME}=`));
  return match ? decodeURIComponent(match.slice(COOKIE_NAME.length + 1)) : null;
}

function writeProfileCookie(value: string) {
  document.cookie = `${COOKIE_NAME}=${encodeURIComponent(value)}; Path=/; SameSite=Lax; Max-Age=${COOKIE_MAX_AGE}`;
}

function deleteProfileCookie() {
  document.cookie = `${COOKIE_NAME}=; Path=/; SameSite=Lax; Max-Age=0`;
}

export interface ProfileData {
  id: string;
  displayName: string;
  xp: number;
  streak: number;
  lastActiveDate: string | null;
  currentTopicId: string | null;
  preferredDifficulty: string;
  recentResults: boolean[];
}

interface ProfileContextValue {
  profile: ProfileData | null;
  loading: boolean;
  createProfile: (displayName: string) => Promise<{ recoveryCode: string }>;
  recoverWithCode: (code: string) => Promise<{ ok: boolean; error?: string }>;
  rename: (displayName: string) => Promise<void>;
  signOutProfile: () => void;
  refresh: () => void;
}

const ProfileContext = createContext<ProfileContextValue | null>(null);

export function ProfileProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [hasCookie, setHasCookie] = useState(() => Boolean(readProfileCookie()));

  const { data, isLoading } = useQuery({
    queryKey: ["profile", hasCookie],
    enabled: hasCookie,
    staleTime: 30_000,
    retry: false,
    queryFn: async () => {
      const res = await getProfileFn();
      if (!res.ok) return null;
      return res.profile;
    },
  });

  const createProfile = useCallback(
    async (displayName: string) => {
      const res = await createProfileFn({ data: { displayName } });
      if (!res.ok) throw new Error(res.error);
      writeProfileCookie(res.cookieValue);
      setHasCookie(true);
      return { recoveryCode: res.recoveryCode };
    },
    [],
  );

  const recoverWithCode = useCallback(async (code: string) => {
    const res = await recoverProfileFn({ data: { code } });
    if (!res.ok) return { ok: false, error: res.error };
    writeProfileCookie(res.cookieValue);
    setHasCookie(true);
    return { ok: true };
  }, []);

  const rename = useCallback(
    async (displayName: string) => {
      await renameProfileFn({ data: { displayName } });
      void queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    [queryClient],
  );

  const signOutProfile = useCallback(() => {
    deleteProfileCookie();
    setHasCookie(false);
    queryClient.clear();
  }, [queryClient]);

  const refresh = useCallback(() => {
    void queryClient.invalidateQueries({ queryKey: ["profile"] });
  }, [queryClient]);

  const value = useMemo<ProfileContextValue>(
    () => ({
      profile: data ?? null,
      loading: hasCookie && isLoading,
      createProfile,
      recoverWithCode,
      rename,
      signOutProfile,
      refresh,
    }),
    [data, hasCookie, isLoading, createProfile, recoverWithCode, rename, signOutProfile, refresh],
  );

  return <ProfileContext.Provider value={value}>{children}</ProfileContext.Provider>;
}

export function useProfile(): ProfileContextValue {
  const ctx = useContext(ProfileContext);
  if (!ctx) throw new Error("useProfile must be used inside ProfileProvider");
  return ctx;
}
