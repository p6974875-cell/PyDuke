import { getRequest } from "@tanstack/react-start/server";
import { createHmac, timingSafeEqual, randomBytes } from "node:crypto";
import { getSql } from "@/lib/db";
import { env } from "@/lib/env.server";

/**
 * Server-only profile logic (.server.ts — stripped from client bundles by
 * the TanStack Start compiler). The RPC surface that clients import lives
 * in ./server.ts as createServerFn definitions only.
 *
 * No-login identity: the active profile lives in a cookie holding
 * `id.hmac(id)`. The browser can never forge a cookie for an arbitrary
 * UUID — the server recomputes the HMAC and compares in constant time.
 * Profile data lives in PostgreSQL; the cookie only proves "this browser
 * created/selected this profile".
 */

const COOKIE_NAME = "pyduke_profile";
export const PROFILE_COOKIE_NAME = COOKIE_NAME;
export const PROFILE_COOKIE_MAX_AGE = 60 * 60 * 24 * 365 * 2; // 2 years

type ProfileRow = {
  id: string;
  display_name: string;
  created_at: string;
  last_active_at: string;
};

type StatsRow = {
  xp: number;
  streak: number;
  last_active_date: string | null;
  current_topic_id: string | null;
  preferred_difficulty: string;
  recent_results: unknown;
};

function profileSecret(): string {
  return env("PROFILE_SECRET") ?? env("GEMINI_API_KEY") ?? "pyduke-dev-secret";
}

export function signProfileId(id: string): string {
  return `${id}.${createHmac("sha256", profileSecret()).update(id).digest("base64url")}`;
}

function verifySigned(value: string): string | null {
  const idx = value.lastIndexOf(".");
  if (idx <= 0) return null;
  const id = value.slice(0, idx);
  const sig = value.slice(idx + 1);
  const expected = createHmac("sha256", profileSecret()).update(id).digest();
  let actual: Buffer;
  try {
    actual = Buffer.from(sig, "base64url");
  } catch {
    return null;
  }
  if (actual.length !== expected.length) return null;
  return timingSafeEqual(actual, expected) ? id : null;
}

function cookieFrom(request: Request): string | null {
  const header = request.headers.get("cookie") ?? "";
  for (const part of header.split(";")) {
    const [k, ...rest] = part.trim().split("=");
    if (k === COOKIE_NAME) return rest.join("=");
  }
  return null;
}

/** Resolve the caller's profile, or null when no valid cookie is present. */
export async function currentProfileId(): Promise<string | null> {
  let request: Request | null = null;
  try {
    request = getRequest();
  } catch {
    return null;
  }
  const raw = request ? cookieFrom(request) : null;
  if (!raw) return null;
  const id = verifySigned(raw);
  if (!id) return null;
  const sql = await getSql();
  const rows = await sql.query<{ id: string }>(
    "select id from profiles where id = $1",
    [id],
  );
  return rows.length ? id : null;
}

/** Require a valid profile; throws a 401-shaped error for server functions. */
export async function requireProfileId(): Promise<string> {
  const id = await currentProfileId();
  if (!id) throw new Error("no_profile");
  return id;
}

function recoveryCode(): string {
  // 24 hex chars, grouped for reading aloud.
  const raw = randomBytes(15).toString("hex").toUpperCase();
  return raw.replace(/(.{6})/g, "$1-").slice(0, 29);
}

export async function createProfile(displayName: string): Promise<{
  id: string;
  recoveryCode: string;
}> {
  const sql = await getSql();
  const name = displayName.trim().slice(0, 50);
  const recovery = recoveryCode();
  const rows = await sql.query<ProfileRow & { recovery_code_hash: string }>(
    `insert into profiles (display_name, recovery_code_hash)
     values ($1, $2)
     returning id, display_name, created_at, last_active_at, recovery_code_hash`,
    [name, createHmac("sha256", profileSecret()).update(`recovery:${recovery}`).digest("hex")],
  );
  const row = rows[0]!;
  await sql.query(
    `insert into profile_stats (profile_id, current_topic_id) values ($1, 'lists')
     on conflict (profile_id) do nothing`,
    [row.id],
  );
  return { id: row.id, recoveryCode: recovery };
}

export async function getProfile(id: string): Promise<{
  id: string;
  displayName: string;
  xp: number;
  streak: number;
  lastActiveDate: string | null;
  currentTopicId: string | null;
  preferredDifficulty: string;
  recentResults: boolean[];
} | null> {
  const sql = await getSql();
  const p = await sql.query<ProfileRow>("select * from profiles where id = $1", [id]);
  if (!p.length) return null;
  const s = await sql.query<StatsRow>("select * from profile_stats where profile_id = $1", [id]);
  const stats = s[0];
  return {
    id,
    displayName: p[0]!.display_name,
    xp: Number(stats?.xp ?? 0),
    streak: Number(stats?.streak ?? 0),
    lastActiveDate: stats?.last_active_date ?? null,
    currentTopicId: stats?.current_topic_id ?? null,
    preferredDifficulty: stats?.preferred_difficulty ?? "medium",
    recentResults: Array.isArray(stats?.recent_results)
      ? (stats!.recent_results as boolean[])
      : [],
  };
}

export async function renameProfile(id: string, displayName: string) {
  const sql = await getSql();
  await sql.query("update profiles set display_name = $2, last_active_at = now() where id = $1", [
    id,
    displayName.trim().slice(0, 50),
  ]);
}

/** Recover a profile from the code issued at creation; returns its id. */
export async function recoverProfile(code: string): Promise<string | null> {
  const sql = await getSql();
  const hash = createHmac("sha256", profileSecret())
    .update(`recovery:${code.trim().toUpperCase()}`)
    .digest("hex");
  const rows = await sql.query<{ id: string }>(
    "select id from profiles where recovery_code_hash = $1",
    [hash],
  );
  return rows[0]?.id ?? null;
}
