import { useEffect, useState, type ReactNode } from "react";
import { RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";

type InnerProps = {
  value: string;
  onChange: (v: string) => void;
  onRun?: () => void;
  className?: string;
  minHeight?: number;
};

export function CodeEditor(props: InnerProps) {
  const [Inner, setInner] = useState<null | ((p: InnerProps) => ReactNode)>(null);
  const [failed, setFailed] = useState(false);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let live = true;
    setFailed(false);
    void import("./code-editor-inner")
      .then((m) => {
        if (live) setInner(() => m.CodeEditorInner);
      })
      .catch(() => {
        if (live) setFailed(true);
      });
    return () => {
      live = false;
    };
  }, [attempt]);

  if (failed) {
    return (
      <div
        className={cn(
          "flex flex-col items-center justify-center gap-3 rounded-lg bg-code p-6 text-center shadow-[var(--shadow-border)]",
          props.className,
        )}
        style={{ minHeight: props.minHeight ?? 220 }}
      >
        <p className="text-sm text-muted-foreground">
          The editor failed to load. This usually happens right after a new deploy — reloading the
          page fixes it.
        </p>
        <button
          type="button"
          onClick={() => {
            setAttempt((a) => a + 1);
          }}
          className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1.5 text-xs text-foreground hover:opacity-80"
        >
          <RotateCcw className="size-3.5" />
          Retry
        </button>
      </div>
    );
  }

  if (!Inner) {
    return (
      <div
        className={cn("rounded-lg bg-code shadow-[var(--shadow-border)]", props.className)}
        style={{ minHeight: props.minHeight ?? 220 }}
      />
    );
  }
  return <Inner {...props} />;
}
