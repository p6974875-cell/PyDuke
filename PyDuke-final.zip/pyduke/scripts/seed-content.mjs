#!/usr/bin/env node
/**
 * Content seed pipeline (spec §15): TypeScript content definitions →
 * validation → PostgreSQL seed.
 *
 * The version-controlled curriculum lives in src/lib/content/*.ts. This
 * script typechecks nothing itself — it imports the compiled-shape content
 * via a tiny TS-stripping loader (node --experimental-strip-types) and
 * upserts topics / lessons / exercises into DATABASE_URL so the database
 * mirrors the shipped curriculum. The MVP runtime still reads the TS bundle;
 * the tables exist so runtime progress and future server-side content can
 * converge on one store.
 *
 * Usage: node --experimental-strip-types scripts/seed-content.mjs
 * (Runs against DATABASE_URL; skipped on the PGLite fallback, which seeds
 * nothing — the bundle is already the content source there.)
 */
import pg from "pg";
import { TOPICS } from "../src/lib/content/topics.ts";
import { LESSONS } from "../src/lib/content/lessons.ts";
import { PROJECTS } from "../src/lib/content/projects.ts";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  console.log("[seed-content] DATABASE_URL not set — nothing to seed (bundle is the source).");
  process.exit(0);
}

// --- Validation (fail loudly on malformed curriculum before touching the DB) ---
function assert(cond, msg) {
  if (!cond) throw new Error(`[seed-content] validation failed: ${msg}`);
}

const topicIds = new Set(TOPICS.map((t) => t.id));
assert(topicIds.size === TOPICS.length, "duplicate topic ids");
for (const t of TOPICS) {
  assert(typeof t.id === "string" && t.title, `topic ${t.id} missing title`);
}
for (const [id, lesson] of Object.entries(LESSONS)) {
  assert(topicIds.has(lesson.topicId), `lesson ${id} references unknown topic ${lesson.topicId}`);
  assert(Array.isArray(lesson.exercises), `lesson ${id} has no exercises array`);
  for (const ex of lesson.exercises) {
    assert(ex.id && ex.title && Array.isArray(ex.checks), `exercise ${ex.id} in ${id} malformed`);
  }
}
for (const p of PROJECTS) {
  assert(p.id && Array.isArray(p.steps) && Array.isArray(p.checks), `project ${p.id} malformed`);
}

// --- Seed ---
const pool = new pg.Pool({ connectionString: databaseUrl, max: 1 });
const client = await pool.connect();
try {
  await client.query("BEGIN");

  for (const t of TOPICS) {
    await client.query(
      `insert into topics (id, number, title, subtitle, blurb)
       values ($1, $2, $3, $4, $5)
       on conflict (id) do update set
         number = excluded.number, title = excluded.title,
         subtitle = excluded.subtitle, blurb = excluded.blurb`,
      [t.id, t.number, t.title, t.subtitle, t.blurb],
    );
  }

  for (const [id, lesson] of Object.entries(LESSONS)) {
    await client.query(
      `insert into lessons (id, topic_id, heading, content)
       values ($1, $2, $3, $4)
       on conflict (id) do update set
         topic_id = excluded.topic_id, heading = excluded.heading, content = excluded.content`,
      [id, lesson.topicId, lesson.concept.heading, JSON.stringify(lesson)],
    );
    let sort = 0;
    for (const ex of lesson.exercises) {
      await client.query(
        `insert into exercises (id, topic_id, title, prompt, difficulty, starter_code, checks, hints, sort_order)
         values ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         on conflict (id) do update set
           topic_id = excluded.topic_id, title = excluded.title, prompt = excluded.prompt,
           difficulty = excluded.difficulty, starter_code = excluded.starter_code,
           checks = excluded.checks, hints = excluded.hints, sort_order = excluded.sort_order`,
        [
          ex.id,
          lesson.topicId,
          ex.title,
          ex.prompt,
          ex.difficulty,
          ex.starter,
          JSON.stringify(ex.checks),
          ex.hint ? JSON.stringify([ex.hint]) : null,
          sort++,
        ],
      );
    }
  }

  await client.query("COMMIT");
  console.log(
    `[seed-content] done — ${TOPICS.length} topics, ${Object.keys(LESSONS).length} lessons, ` +
      `${Object.values(LESSONS).reduce((n, l) => n + l.exercises.length, 0)} exercises.`,
  );
} catch (err) {
  await client.query("ROLLBACK");
  console.error("[seed-content] failed:", err?.message || err);
  process.exitCode = 1;
} finally {
  client.release();
  await pool.end();
}
