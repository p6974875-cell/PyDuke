# PyDuke — Python Learning Site

This workspace is a complete React/TanStack Start learning site for practicing Python through lessons, coding, games, projects, and typing practice.

## Included

- 20-topic Python curriculum
- Lesson explanations, definitions, analogies, examples, mistakes, hints and coding exercises
- Browser Python playground
- Mini-games:
  - Code Fixer
  - Predict the Output
  - Code Ordering
  - Python Typing Sprint
  - Debugging Challenge
  - Build It
  - Boss Battle
- Python typing trainer with WPM, CPM, accuracy, errors, history and local persistence
- Typing-technique lessons covering:
  - Home position
  - Touch typing / eyes-off practice
  - Python symbols
  - Indentation
  - Accuracy before speed
  - Typing rhythm
- Guided projects
- Progress dashboard and XP/levels
- Revision reminders
- Local saved snippets
- Tutor/progress context
- Responsive mobile and desktop navigation
- Persistent progress through browser localStorage

## Run locally

Requirements: Node.js and npm.

```bash
npm install
npm run dev
```

Then open the local address printed by Vite (the project defaults to port 8080).

For a production build:

```bash
npm run build
```

## Learning flow

The initial learner state starts after the first five foundational topics and opens the Lists lesson, matching a learner who already knows basic Python lists. Progress can be reset from the Profile page.

The app is intentionally designed around short revision, active coding, games, and typing rather than passive reading.
