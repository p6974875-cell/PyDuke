import { cn } from "@/lib/utils";

const KEYWORDS =
  /\b(False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b/g;

export function highlightPython(code: string) {
  const escaped = code
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">");
  return escaped
    .replace(/(#.*)$/gm, '<span class="text-muted-foreground">$1</span>')
    .replace(
      /(".*?"|&#39;.*?&#39;|"""[\s\S]*?""")/g,
      '<span class="text-accent">$1</span>',
    )
    .replace(KEYWORDS, '<span class="text-success">$1</span>')
    .replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="text-warning">$1</span>');
}

export function CodeBlock({
  code,
  className,
}: {
  code: string;
  className?: string;
}) {
  return (
    <pre
      className={cn(
        "overflow-x-auto rounded-lg bg-code p-4 text-[13px] leading-relaxed text-foreground shadow-[var(--shadow-border)]",
        className,
      )}
    >
      <code
        className="font-mono"
        dangerouslySetInnerHTML={{ __html: highlightPython(code) }}
      />
    </pre>
  );
}
