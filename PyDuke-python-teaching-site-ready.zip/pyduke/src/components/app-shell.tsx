import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  BookOpen,
  ChartNoAxesColumn,
  CircleUser,
  FolderKanban,
  Home,
  Keyboard,
  Menu,
  MessageSquare,
  Puzzle,
  Terminal,
} from "lucide-react";
import { PyDukeMark } from "@/components/helix-mark";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { cn, levelFromXp, xpIntoLevel } from "@/lib/utils";
import { useHelix } from "@/lib/store";

const PRIMARY = [
  { to: "/", label: "Home", icon: Home },
  { to: "/learn", label: "Learn", icon: BookOpen },
  { to: "/code", label: "Code", icon: Terminal },
  { to: "/games", label: "Games", icon: Puzzle },
] as const;

const MORE = [
  { to: "/typing", label: "Typing", icon: Keyboard },
  { to: "/projects", label: "Projects", icon: FolderKanban },
  { to: "/progress", label: "Progress", icon: ChartNoAxesColumn },
  { to: "/tutor", label: "Tutor", icon: MessageSquare },
  { to: "/profile", label: "Profile", icon: CircleUser },
] as const;

const ALL = [...PRIMARY, ...MORE];

function NavLink({
  to,
  label,
  icon: Icon,
  onClick,
}: {
  to: string;
  label: string;
  icon: typeof Home;
  onClick?: () => void;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const active = to === "/" ? pathname === "/" : pathname === to || pathname.startsWith(`${to}/`);
  return (
    <Link
      to={to}
      onClick={onClick}
      className={cn(
        "flex h-11 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors duration-150",
        active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground",
      )}
    >
      <Icon className="size-4 shrink-0" />
      {label}
    </Link>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const xp = useHelix((s) => s.xp);
  const streak = useHelix((s) => s.streak);
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    const finish = () => {
      useHelix.getState().setHydrated(true);
      useHelix.getState().tickStreak();
    };
    const unsub = useHelix.persist.onFinishHydration(finish);
    void useHelix.persist.rehydrate();
    if (useHelix.persist.hasHydrated()) finish();
    return unsub;
  }, []);

  const level = levelFromXp(xp);
  const into = xpIntoLevel(xp);

  return (
    <div className="flex min-h-dvh bg-background text-foreground">
      <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border bg-sidebar px-3 py-5 md:flex">
        <Link to="/" className="mb-6 flex items-center gap-2.5 px-2">
          <PyDukeMark className="size-8" />
          <span className="font-display text-lg font-medium tracking-tight">PyDuke</span>
        </Link>
        <nav className="flex flex-1 flex-col gap-0.5">
          {ALL.map((item) => (
            <NavLink key={item.to} {...item} />
          ))}
        </nav>
        <div className="mt-4 space-y-2 rounded-lg bg-secondary p-3">
          <div className="flex items-baseline justify-between text-xs">
            <span className="text-muted-foreground">Level {level}</span>
            <span className="tabular-nums text-foreground">{into}/150</span>
          </div>
          <Progress value={(into / 150) * 100} />
          <p className="text-xs text-muted-foreground">
            Streak <span className="tabular-nums text-foreground">{streak}</span>
          </p>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-3 border-b border-border px-4 py-3 md:hidden">
          <Link to="/" className="flex items-center gap-2">
            <PyDukeMark className="size-7" />
            <span className="font-display text-base font-medium">PyDuke</span>
          </Link>
          <div className="flex items-center gap-2 text-xs tabular-nums text-muted-foreground">
            Lv {level}
            <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon-sm" aria-label="Menu">
                  <Menu className="size-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom">
                <SheetHeader>
                  <SheetTitle>PyDuke</SheetTitle>
                </SheetHeader>
                <nav className="grid grid-cols-2 gap-1 pb-4">
                  {ALL.map((item) => (
                    <NavLink key={item.to} {...item} onClick={() => setMoreOpen(false)} />
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </header>

        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 pb-24 md:px-8 md:py-8 md:pb-8">
          {children}
        </main>

        <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-sidebar/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm md:hidden">
          <div className="grid grid-cols-5">
            {PRIMARY.map((item) => {
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className="flex h-14 flex-col items-center justify-center gap-1 text-[11px] text-muted-foreground"
                >
                  <item.icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              className="flex h-14 flex-col items-center justify-center gap-1 text-[11px] text-muted-foreground"
            >
              <Menu className="size-4" />
              More
            </button>
          </div>
        </nav>
      </div>
    </div>
  );
}
