import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { Lock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TOPICS } from "@/lib/content/topics";
import { dueTopicIds, useHelix } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/learn")({ component: LearnIndex });

const STATUS_LABEL: Record<string, string> = {
  mastered: "Mastered",
  in_progress: "In progress",
  review: "Review",
  available: "Available",
  locked: "Locked",
};

function LearnIndex() {
  const topics = useHelix((s) => s.topics);
  const due = useMemo(() => dueTopicIds(topics), [topics]);

  return (
    <div className="space-y-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Learn</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Curriculum</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Earlier topics stay marked mastered. Lists is the first live lesson — a recap, then the
          parts lists usually hide.
        </p>
      </header>
      <ol className="grid gap-2 sm:grid-cols-2">
        {TOPICS.map((t) => {
          const p = topics[t.id];
          const locked = p.status === "locked";
          const isDue = due.includes(t.id);
          const inner = (
            <>
              <div className="flex items-start justify-between gap-2">
                <span className="font-mono text-xs text-muted-foreground">
                  {String(t.number).padStart(2, "0")}
                </span>
                <Badge variant={p.status === "mastered" ? "success" : "outline"}>
                  {isDue ? "Review due" : STATUS_LABEL[p.status]}
                </Badge>
              </div>
              <h2 className="mt-3 font-display text-lg font-medium">{t.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{t.blurb}</p>
              <Progress value={p.score} className="mt-4" />
            </>
          );
          if (locked) {
            return (
              <li
                key={t.id}
                className="rounded-xl bg-card/50 p-4 text-muted-foreground shadow-[var(--shadow-border)]"
              >
                <div className="flex items-center gap-2 text-xs">
                  <Lock className="size-3.5" />
                  Complete the previous lesson to unlock
                </div>
                {inner}
              </li>
            );
          }
          return (
            <li key={t.id}>
              <Link
                to="/learn/$topicId"
                params={{ topicId: t.id }}
                className={cn(
                  "block rounded-xl bg-card p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
                )}
              >
                {inner}
              </Link>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
