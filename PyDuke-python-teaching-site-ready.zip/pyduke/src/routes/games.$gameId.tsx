import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Check, Play } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { CodeEditor } from "@/components/code-editor";
import { DifficultyBadge } from "@/components/difficulty-badge";
import { Input } from "@/components/ui/input";
import { PythonOutput } from "@/components/python-output";
import { CodeBlock } from "@/components/code-block";
import { GAMES, GAME_META } from "@/lib/content/games";
import { TYPING_DRILLS } from "@/lib/content/typing";
import { gradeCode } from "@/lib/grade";
import { outputsMatch, type RunResult } from "@/lib/python-engine";
import { EMPTY_IDS, useHelix } from "@/lib/store";
import type { GameId, GameItem } from "@/lib/types";
import { TypingArena } from "@/components/typing-arena";

export const Route = createFileRoute("/games/$gameId")({ component: GamePage });

function GamePage() {
  const { gameId } = Route.useParams();
  const meta = GAME_META.find((g) => g.id === gameId);
  if (!meta) {
    return (
      <p>
        Unknown game. <Link to="/games">Back</Link>
      </p>
    );
  }
  if (gameId === "typing") {
    return (
      <div className="space-y-6">
        <Head meta={meta} />
        <TypingArena drills={TYPING_DRILLS} />
      </div>
    );
  }
  const items = GAMES[gameId] ?? [];
  return (
    <div className="space-y-6">
      <Head meta={meta} />
      <GameRunner gameId={gameId as GameId} items={items} />
    </div>
  );
}

function Head({ meta }: { meta: (typeof GAME_META)[number] }) {
  return (
    <header>
      <Link to="/games" className="text-xs text-muted-foreground hover:text-foreground">
        Games
      </Link>
      <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">{meta.title}</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{meta.blurb}</p>
    </header>
  );
}

function GameRunner({ gameId, items }: { gameId: GameId; items: GameItem[] }) {
  const completed = useHelix((s) => s.games[gameId]?.completed ?? EMPTY_IDS);
  const complete = useHelix((s) => s.completeGameItem);
  const [index, setIndex] = useState(0);

  const unlockedIndex = useMemo(() => {
    if (gameId !== "boss") return items.length;
    let u = 0;
    for (const it of items) {
      if (completed.includes(it.id)) u += 1;
      else break;
    }
    return Math.min(items.length, u + 1);
  }, [gameId, items, completed]);

  const safeIndex = Math.min(index, Math.max(0, unlockedIndex - 1));
  const item = items[safeIndex];
  if (!item) return <p className="text-muted-foreground">No challenges yet.</p>;

  function mark(ok: boolean) {
    if (!ok) return;
    complete(gameId, item.id);
    toast("Challenge cleared");
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {items.map((it, i) => {
          const locked = i >= unlockedIndex;
          return (
            <button
              key={it.id}
              type="button"
              disabled={locked}
              onClick={() => setIndex(i)}
              className={`h-9 min-w-9 rounded-md px-2 text-xs tabular-nums ${
                i === safeIndex ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
              } disabled:opacity-30`}
            >
              {i + 1}
            </button>
          );
        })}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="font-display text-xl font-medium">{item.title}</h2>
        <DifficultyBadge value={item.difficulty} />
        {completed.includes(item.id) ? (
          <span className="inline-flex items-center gap-1 text-xs text-success">
            <Check className="size-3.5" /> Done
          </span>
        ) : null}
      </div>
      <p className="text-sm text-muted-foreground">{item.prompt}</p>
      {gameId === "predict" ? (
        <PredictCard key={item.id} item={item} onResult={mark} />
      ) : gameId === "ordering" ? (
        <OrderCard key={item.id} item={item} onResult={mark} />
      ) : (
        <FixCard key={item.id} item={item} onResult={mark} />
      )}
      <div className="flex gap-2">
        <Button
          variant="secondary"
          size="sm"
          disabled={safeIndex === 0}
          onClick={() => setIndex((i) => Math.max(0, i - 1))}
        >
          <ArrowLeft className="size-4" />
          Prev
        </Button>
        <Button
          variant="secondary"
          size="sm"
          disabled={safeIndex >= unlockedIndex - 1}
          onClick={() => setIndex((i) => i + 1)}
        >
          Next
          <ArrowRight className="size-4" />
        </Button>
      </div>
    </div>
  );
}

function FixCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [code, setCode] = useState(item.starter ?? "");
  const [result, setResult] = useState<RunResult | null>(null);
  const [msg, setMsg] = useState("");
  const [ok, setOk] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const [show, setShow] = useState(false);
  const [running, setRunning] = useState(false);

  async function run() {
    setRunning(true);
    try {
      const g = await gradeCode(code, item.checks ?? []);
      setResult(g.run);
      setMsg(g.message);
      setOk(g.passed);
      setAttempted(true);
      onResult(g.passed);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-3">
      <CodeEditor value={code} onChange={setCode} onRun={run} minHeight={200} />
      <div className="flex gap-2">
        <Button size="sm" onClick={run} disabled={running}>
          <Play className="size-4" />
          Check
        </Button>
        <Button size="sm" variant="ghost" disabled={!attempted} onClick={() => setShow(true)}>
          Compare
        </Button>
      </div>
      {msg ? <p className={ok ? "text-sm text-success" : "text-sm text-destructive"}>{msg}</p> : null}
      <PythonOutput result={result} code={code} />
      {show && item.solution ? (
        <div className="rounded-lg bg-secondary p-4">
          <CodeBlock code={item.solution} />
          <p className="mt-2 text-sm text-muted-foreground">{item.explanation}</p>
        </div>
      ) : null}
    </div>
  );
}

function PredictCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [guess, setGuess] = useState("");
  const [revealed, setRevealed] = useState(false);
  const correct = outputsMatch(guess, item.expected ?? "");

  return (
    <div className="space-y-3">
      <CodeBlock code={item.code ?? ""} />
      <Input
        value={guess}
        onChange={(e) => setGuess(e.target.value)}
        placeholder="What does it print?"
        disabled={revealed}
      />
      <Button
        size="sm"
        disabled={revealed || !guess.trim()}
        onClick={() => {
          setRevealed(true);
          onResult(correct);
        }}
      >
        Reveal
      </Button>
      {revealed ? (
        <div className="space-y-2 rounded-lg bg-secondary p-4 text-sm">
          <p className={correct ? "text-success" : "text-destructive"}>
            {correct ? "Your prediction matched." : "Not quite."}
          </p>
          <p className="font-mono text-foreground">Actual: {item.expected}</p>
          <p className="text-muted-foreground">{item.explanation}</p>
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">Predict before you see the output.</p>
      )}
    </div>
  );
}

function OrderCard({ item, onResult }: { item: GameItem; onResult: (ok: boolean) => void }) {
  const [lines, setLines] = useState(() => shuffle(item.lines ?? []));
  const [result, setResult] = useState<RunResult | null>(null);
  const [ok, setOk] = useState(false);
  const [show, setShow] = useState(false);
  const [running, setRunning] = useState(false);

  function move(i: number, dir: -1 | 1) {
    const j = i + dir;
    if (j < 0 || j >= lines.length) return;
    const next = lines.slice();
    [next[i], next[j]] = [next[j], next[i]];
    setLines(next);
  }

  async function check() {
    setRunning(true);
    try {
      const g = await gradeCode(lines.join("\n"), [{ kind: "stdout", expected: item.expected }]);
      setResult(g.run);
      setOk(g.passed);
      onResult(g.passed);
      if (g.passed) setShow(true);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-3">
      <ul className="space-y-2">
        {lines.map((line, i) => (
          <li
            key={`${line}-${i}`}
            className="flex items-center gap-2 rounded-lg bg-code px-3 py-2 font-mono text-[13px]"
          >
            <div className="flex flex-col">
              <button type="button" className="px-1 text-muted-foreground" onClick={() => move(i, -1)}>
                ↑
              </button>
              <button type="button" className="px-1 text-muted-foreground" onClick={() => move(i, 1)}>
                ↓
              </button>
            </div>
            <span className="whitespace-pre">{line}</span>
          </li>
        ))}
      </ul>
      <Button size="sm" onClick={check} disabled={running}>
        Run in order
      </Button>
      {ok ? <p className="text-sm text-success">That order works.</p> : null}
      <PythonOutput result={result} code={lines.join("\n")} />
      {show ? <p className="text-sm text-muted-foreground">{item.explanation}</p> : null}
    </div>
  );
}

function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
