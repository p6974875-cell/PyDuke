import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { askTutor } from "@/lib/ask-tutor";
import { localTutorReply } from "@/lib/explain-error";
import { progressSummary, useHelix } from "@/lib/store";

export const Route = createFileRoute("/tutor")({ component: TutorPage });

const STARTERS = [
  "Why can't I modify this tuple?",
  "Explain dictionaries simply.",
  "What does this error mean: TypeError: can only concatenate str (not int) to str",
  "Give me a harder challenge.",
  "Revise what I should not forget from lists.",
];

function TutorPage() {
  const messages = useHelix((s) => s.tutor);
  const push = useHelix((s) => s.pushTutor);
  const snapshot = useHelix((s) => s);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  async function send(content: string) {
    const q = content.trim();
    if (!q || busy) return;
    setText("");
    push({ role: "user", content: q });
    setBusy(true);
    const summary = progressSummary(useHelix.getState());
    try {
      const history = [
        ...useHelix.getState().tutor.slice(-8).map((m) => ({
          role: m.role,
          content: m.content,
        })),
      ];
      const res = await askTutor({ data: { messages: history, progressSummary: summary } });
      if (res.ok && res.text.trim()) {
        push({ role: "assistant", content: res.text.trim() });
      } else {
        push({ role: "assistant", content: localTutorReply(q, summary) });
      }
    } catch {
      push({ role: "assistant", content: localTutorReply(q, summary) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Tutor</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight">Ask PyDuke</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Answers use your current path — lists onward, not a beginner reset. Questions beat quizzes.
        </p>
      </header>
      <div className="flex flex-wrap gap-2">
        {STARTERS.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => send(s)}
            className="rounded-full bg-secondary px-3 py-1.5 text-left text-xs text-muted-foreground hover:text-foreground"
          >
            {s}
          </button>
        ))}
      </div>
      <div className="space-y-3">
        {messages.length === 0 ? (
          <p className="rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
            Progress snapshot used in replies:
            <span className="mt-2 block whitespace-pre-wrap font-mono text-xs text-foreground/80">
              {progressSummary(snapshot)}
            </span>
          </p>
        ) : (
          messages.map((m) => (
            <div
              key={m.id}
              className={
                m.role === "user"
                  ? "ml-8 rounded-xl bg-secondary px-4 py-3 text-sm"
                  : "mr-8 rounded-xl bg-card px-4 py-3 text-sm shadow-[var(--shadow-border)]"
              }
            >
              <p className="mb-1 text-[11px] uppercase tracking-wider text-muted-foreground">
                {m.role === "user" ? "You" : "PyDuke"}
              </p>
              <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
            </div>
          ))
        )}
        {busy ? <p className="text-xs text-muted-foreground">Thinking…</p> : null}
      </div>
      <form
        className="flex flex-col gap-2 sm:flex-row"
        onSubmit={(e) => {
          e.preventDefault();
          void send(text);
        }}
      >
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Why does this loop stop?"
          className="min-h-20 flex-1"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void send(text);
            }
          }}
        />
        <Button type="submit" disabled={busy || !text.trim()} className="sm:self-end">
          <Send className="size-4" />
          Send
        </Button>
      </form>
    </div>
  );
}
