import { createServerFn } from "@tanstack/react-start";

type Msg = { role: "user" | "assistant" | "system"; content: string };

const SYSTEM_PROMPT_HEADER = `You are PyDuke, a personal Python tutor. The learner already knows lists, variables, I/O, operators, conditions, and loops. Do not restart from "hello world". Use simple language without talking down. Use standard terms (mutable, iterable, hashable, suite, binding) and define them once. Prefer short examples. If they ask for an answer to an exercise, give a hint and the idea, not a full dump, unless they already attempted it. Never execute or request OS/network access.`;

export const askTutor = createServerFn({ method: "POST" })
  .validator((input: { messages: Msg[]; progressSummary: string }) => input)
  .handler(async ({ data }) => {
    const system = `${SYSTEM_PROMPT_HEADER}\n\nLearner progress:\n${data.progressSummary.slice(0, 1800)}`;
    const trimmed = data.messages
      .filter((m) => m.role !== "system")
      .slice(-8)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 4000) }));

    const geminiKey = process.env.GEMINI_API_KEY;
    if (geminiKey) {
      return askGemini(geminiKey, system, trimmed);
    }

    const xaiKey = process.env.XAI_API_KEY;
    if (xaiKey) {
      return askXai(xaiKey, system, trimmed);
    }

    return { ok: false as const, error: "unavailable" };
  });

async function askGemini(apiKey: string, system: string, trimmed: { role: string; content: string }[]) {
  const model = process.env.GEMINI_MODEL || "gemini-flash-latest";
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-goog-api-key": apiKey },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: system }] },
        contents: trimmed.map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }],
        })),
        generationConfig: { temperature: 0.4, maxOutputTokens: 700 },
      }),
    },
  );
  if (!res.ok) {
    return { ok: false as const, error: `Gemini API error ${res.status}` };
  }
  const body = (await res.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  const text = body.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
  return { ok: true as const, text };
}

async function askXai(apiKey: string, system: string, trimmed: { role: string; content: string }[]) {
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      temperature: 0.4,
      max_tokens: 700,
      messages: [{ role: "system", content: system }, ...trimmed],
    }),
  });
  if (!res.ok) {
    return { ok: false as const, error: `xAI API error ${res.status}` };
  }
  const body = (await res.json()) as {
    choices: { message: { content: string } }[];
  };
  return { ok: true as const, text: body.choices[0]?.message.content ?? "" };
}
