import type { Topic, TopicId } from "@/lib/types";

export const TOPICS: Topic[] = [
  {
    id: "variables",
    number: 1,
    title: "Variables & data types",
    subtitle: "Names, values, types",
    blurb: "How Python stores values and why types matter.",
  },
  {
    id: "io",
    number: 2,
    title: "Input & output",
    subtitle: "print and input",
    blurb: "Talking to the user through the terminal.",
  },
  {
    id: "operators",
    number: 3,
    title: "Operators",
    subtitle: "Arithmetic, comparison, logic",
    blurb: "The symbols that compute and compare.",
  },
  {
    id: "conditions",
    number: 4,
    title: "Conditions",
    subtitle: "if, elif, else",
    blurb: "Making decisions in code.",
  },
  {
    id: "loops",
    number: 5,
    title: "Loops",
    subtitle: "for and while",
    blurb: "Repeating work without repeating yourself.",
  },
  {
    id: "lists",
    number: 6,
    title: "Lists, deeper",
    subtitle: "Mutability, copies, comprehensions",
    blurb: "You already know lists. Now we go further.",
  },
  {
    id: "tuples",
    number: 7,
    title: "Tuples",
    subtitle: "Immutable sequences",
    blurb: "When a collection should not change.",
  },
  {
    id: "sets",
    number: 8,
    title: "Sets",
    subtitle: "Unique unordered values",
    blurb: "Membership and uniqueness as first-class ideas.",
  },
  {
    id: "dictionaries",
    number: 9,
    title: "Dictionaries",
    subtitle: "Key and value maps",
    blurb: "Look things up by name, not by position.",
  },
  {
    id: "strings",
    number: 10,
    title: "Strings",
    subtitle: "Text as data",
    blurb: "Slicing, methods, and formatting with intent.",
  },
  {
    id: "functions",
    number: 11,
    title: "Functions",
    subtitle: "Named reusable work",
    blurb: "Package behaviour so you can call it again.",
  },
  {
    id: "scope",
    number: 12,
    title: "Scope",
    subtitle: "Where names live",
    blurb: "Why a variable in a function is not the same as one outside.",
  },
  {
    id: "errors",
    number: 13,
    title: "Error handling",
    subtitle: "try, except, raise",
    blurb: "Expecting failure and recovering cleanly.",
  },
  {
    id: "modules",
    number: 14,
    title: "Modules",
    subtitle: "import and __name__",
    blurb: "Splitting programs into reusable files.",
  },
  {
    id: "files",
    number: 15,
    title: "File handling",
    subtitle: "read, write, with",
    blurb: "Persisting data beyond a single run.",
  },
  {
    id: "oop",
    number: 16,
    title: "Object-oriented Python",
    subtitle: "classes and objects",
    blurb: "Bundling data and behaviour together.",
  },
  {
    id: "stdlib",
    number: 17,
    title: "Standard library",
    subtitle: "batteries included",
    blurb: "Useful modules you already have.",
  },
  {
    id: "apis",
    number: 18,
    title: "Working with APIs",
    subtitle: "HTTP and JSON",
    blurb: "Talking to other programs over the network — conceptually, then in code.",
  },
  {
    id: "projects",
    number: 19,
    title: "Project craft",
    subtitle: "Design before code",
    blurb: "How to break a real program into pieces you can finish.",
  },
  {
    id: "advanced",
    number: 20,
    title: "Advanced Python",
    subtitle: "generators, hints, decorators",
    blurb: "The next layer once the core is solid.",
  },
];

export const TOPIC_BY_ID: Record<TopicId, Topic> = Object.fromEntries(
  TOPICS.map((t) => [t.id, t]),
) as Record<TopicId, Topic>;

export const MASTERED_ON_ARRIVAL: TopicId[] = [
  "variables",
  "io",
  "operators",
  "conditions",
  "loops",
];

export const START_TOPIC: TopicId = "lists";
